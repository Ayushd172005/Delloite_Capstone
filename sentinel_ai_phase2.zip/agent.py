"""
Sentinel AI Phase 2 - Agent orchestration.

Builds the exact prompt sent to the LLM for each flagged transaction, and the
grounding/hallucination-control logic described in Section 3 and Section 10 of
the original guide: every claim in the draft must trace to a retrieved doc_id,
and the agent must say "insufficient evidence" rather than guess when the
retrieved evidence doesn't clearly support a conclusion.

This script is written to call the Anthropic API directly (anthropic Python SDK)
so it can run unattended in a real deployment. In THIS environment there is no
API key configured, so running this file standalone will print the constructed
prompt and skip the actual call - see generate_case_files_demo.py for real,
already-drafted case files produced by having the reasoning done directly
instead of through this script.
"""
import os
import json
import pandas as pd

SYSTEM_PROMPT = """You are an audit investigation agent. For a flagged transaction and its retrieved \
supporting evidence, produce a case file with exactly these fields:

1. anomaly_statement: one or two sentences stating what about this transaction looks anomalous, \
based ONLY on the risk signals provided (composite score, which component scores drove it, which \
rules triggered).
2. evidence_review: for EACH retrieved document, state what it shows and whether it supports, \
contradicts, or is neutral toward the anomaly concern. Cite the doc_id for every claim - a claim \
with no doc_id citation must not appear here.
3. risk_rating: one of Low / Medium / High / Critical.
4. explanation: a plain-language paragraph an auditor can read in under 30 seconds, citing doc_ids \
for every factual claim.
5. sufficiency: either "sufficient" or "insufficient" - if the retrieved evidence does not clearly \
support a conclusion, say so explicitly and set risk_rating based on the risk signals alone, not \
on invented context.

Hard rule: never state a fact that isn't directly present in the risk signals or the retrieved \
evidence text. If you don't have a document to point to, say "insufficient evidence to confirm" \
rather than making a plausible-sounding claim. Output valid JSON matching the schema above, nothing else."""

def build_user_prompt(txn_row, retrieved_docs):
    signals = {
        "transaction_id": txn_row["transaction_id"],
        "vertical": txn_row["vertical"],
        "amount": float(txn_row["amount"]),
        "composite_score": float(txn_row["composite_score"]),
        "review_tier": txn_row["review_tier"],
        "isoforest_score": round(float(txn_row.get("isoforest_score", 0)), 3),
        "autoencoder_score": round(float(txn_row.get("autoencoder_score", 0)), 3),
        "benford_flag": bool(txn_row.get("benford_flag", 0)),
        "rules_triggered": [c.replace("flag_", "") for c in txn_row.index
                             if c.startswith("flag_") and txn_row.get(c) == 1] if hasattr(txn_row, "index") else [],
    }
    if txn_row["vertical"] == "corporate":
        signals["benford_reliability_note"] = (
            "Benford's Law was found NOT to discriminate fraud in this vertical (see evaluation report, "
            "Section 3.1) - the vendor population does not follow a Benford-conforming digit distribution "
            "regardless of fraud status. Do not cite benford_flag as evidence for this transaction."
        )
    docs = [{"doc_id": d["doc_id"], "relation": d["relation"],
             "similarity": round(float(d["similarity"]), 2), "text": d["synthetic_evidence_text"]}
            for d in retrieved_docs]
    return json.dumps({"transaction_signals": signals, "retrieved_evidence": docs}, indent=2)

def call_agent(txn_row, retrieved_docs, model="claude-sonnet-4-6"):
    user_prompt = build_user_prompt(txn_row, retrieved_docs)
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("No ANTHROPIC_API_KEY set in this environment - printing the prompt instead of calling the API.")
        print("SYSTEM PROMPT:\n", SYSTEM_PROMPT)
        print("\nUSER PROMPT:\n", user_prompt)
        return None
    from anthropic import Anthropic
    client = Anthropic(api_key=api_key)
    resp = client.messages.create(
        model=model, max_tokens=800,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )
    text = "".join(b.text for b in resp.content if b.type == "text")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"raw_output": text}

if __name__ == "__main__":
    from retrieval import EvidenceStore
    corpus = pd.read_parquet("evidence_corpus.parquet")
    flagged = pd.read_csv("synthetic_evidence_flagged_cases.csv")
    store = EvidenceStore(corpus)

    sample_txn = corpus[corpus["transaction_id"] == flagged.iloc[0]["transaction_id"]].iloc[0]
    docs = store.retrieve(sample_txn)
    print(build_user_prompt(sample_txn, docs))
