"""
Sentinel AI Phase 2 - Retrieval layer.

Builds the evidence corpus a flagged transaction's case file draws from:
  (a) the account's own prior transaction history
  (b) the counterparty's other transaction history
  (c) TF-IDF nearest-neighbor documents by text similarity
This stands in for "chunk and embed into FAISS" (Phase 2, Week 4-6 in the
original guide) - a real deployment would use sentence embeddings + FAISS;
TF-IDF is used here because this environment has no access to embedding-model
downloads, but the retrieval CONTRACT (query -> ranked doc_ids -> text) is
identical, so swapping in FAISS later is a drop-in replacement for retrieve().
"""
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from evidence import generate_evidence, rng

TOP_K = 5

def build_corpus(scored_path="scored_transactions.parquet",
                  flagged_path="synthetic_evidence_flagged_cases.csv"):
    """Evidence corpus = every transaction belonging to an account or counterparty
    that appears at least once in the flagged set (their relevant history),
    not the full 345k rows - keeps the corpus focused and retrieval meaningful."""
    full = pd.read_parquet(scored_path)
    flagged = pd.read_csv(flagged_path)

    accounts = set(flagged["account_id"])
    counterparties = set(flagged["counterparty_id"])
    relevant = full[full["account_id"].isin(accounts) | full["counterparty_id"].isin(counterparties)].copy()

    # generate evidence text for the whole relevant pool (flagged cases already have text;
    # regenerate with the same seeded RNG order isn't guaranteed identical, so just regenerate
    # for the full pool for consistency)
    relevant = generate_evidence(relevant)
    relevant = relevant.reset_index(drop=True)
    relevant["doc_id"] = [f"DOC_{i:06d}" for i in range(len(relevant))]
    return relevant

class EvidenceStore:
    def __init__(self, corpus_df):
        self.corpus = corpus_df.reset_index(drop=True)
        self.vectorizer = TfidfVectorizer(max_features=2000, stop_words="english")
        self.matrix = self.vectorizer.fit_transform(self.corpus["synthetic_evidence_text"])

    def retrieve(self, transaction_row, top_k=TOP_K):
        """Returns a ranked list of dicts: doc_id, text, similarity, relation."""
        account_hist = self.corpus[
            (self.corpus["account_id"] == transaction_row["account_id"]) &
            (self.corpus["transaction_id"] != transaction_row["transaction_id"])
        ].copy()
        account_hist["relation"] = "same_account_history"

        # aml account_id is near-unique per transaction (see prep.py ENTITY_COL note) - the
        # recurring entity there is customer_id, so also pull that history when present.
        if "customer_id" in self.corpus.columns:
            cust_hist = self.corpus[
                (self.corpus["customer_id"] == transaction_row.get("customer_id")) &
                (self.corpus["transaction_id"] != transaction_row["transaction_id"])
            ].copy()
            cust_hist["relation"] = "same_customer_history"
        else:
            cust_hist = self.corpus.iloc[0:0].copy()

        cp_hist = self.corpus[
            (self.corpus["counterparty_id"] == transaction_row["counterparty_id"]) &
            (self.corpus["transaction_id"] != transaction_row["transaction_id"])
        ].copy()
        cp_hist["relation"] = "same_counterparty_history"

        query_vec = self.vectorizer.transform([transaction_row["synthetic_evidence_text"]])
        sims = cosine_similarity(query_vec, self.matrix).flatten()
        top_idx = np.argsort(-sims)[:top_k * 2]
        text_hits = self.corpus.iloc[top_idx].copy()
        text_hits["similarity"] = sims[top_idx]
        text_hits = text_hits[text_hits["transaction_id"] != transaction_row["transaction_id"]]
        text_hits["relation"] = "text_similarity"

        combined = pd.concat([account_hist, cust_hist, cp_hist, text_hits], ignore_index=True)
        combined = combined.drop_duplicates(subset="doc_id")
        combined["similarity"] = combined.get("similarity", 0)
        combined["similarity"] = combined["similarity"].fillna(0)
        combined = combined.sort_values("similarity", ascending=False).head(top_k)

        return combined[["doc_id", "transaction_id", "relation", "amount", "transaction_time",
                          "synthetic_evidence_text", "similarity"]].to_dict("records")

if __name__ == "__main__":
    corpus = build_corpus()
    corpus.to_parquet("evidence_corpus.parquet", index=False)
    print("Evidence corpus:", corpus.shape)

    store = EvidenceStore(corpus)
    flagged = pd.read_csv("synthetic_evidence_flagged_cases.csv")
    sample_txn = corpus[corpus["transaction_id"] == flagged.iloc[0]["transaction_id"]].iloc[0]
    hits = store.retrieve(sample_txn)
    print(f"\nSample retrieval for {sample_txn['transaction_id']} ({sample_txn['vertical']}):")
    for h in hits:
        print(f"  [{h['doc_id']}] ({h['relation']}, sim={h['similarity']:.2f}) {h['synthetic_evidence_text'][:90]}")
