"""
Sentinel AI Phase 2 - FastAPI backend.

Exposes the review queue and case-file endpoints described in Section 4 (App tier)
and Section 7 (auditor experience) of the original guide:
  GET  /queue                 -> list of flagged transactions, sortable by score/tier
  GET  /case/{transaction_id}  -> full case file (signals + retrieved evidence + agent draft)
  POST /case/{transaction_id}/decision -> log an auditor decision (accept/edit/reject) to the
                                            append-only audit trail

Run with: uvicorn app:app --reload
This reads from the artifacts already produced by the pipeline (scored_transactions.parquet,
evidence_corpus.parquet, case_files_demo.json) rather than a live database - swap the loaders
below for real DB/queue calls in a production deployment.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime
import pandas as pd
import json
import os

app = FastAPI(title="Sentinel AI Auditor API")

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
AUDIT_TRAIL_PATH = os.path.join(DATA_DIR, "audit_trail.jsonl")

_scored = None
_case_files = {}

def load_data():
    global _scored, _case_files
    _scored = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    case_path = os.path.join(DATA_DIR, "case_files_demo.json")
    if os.path.exists(case_path):
        with open(case_path) as f:
            _case_files = json.load(f)

@app.on_event("startup")
def startup():
    load_data()

class Decision(BaseModel):
    auditor: str
    action: str  # "accept" | "edit" | "reject"
    edited_explanation: str | None = None
    reason: str | None = None

@app.get("/queue")
def get_queue(vertical: str | None = None, tier: str | None = None, limit: int = 50):
    df = _scored[_scored["review_tier"] != "auto_clear"].copy()
    if vertical:
        df = df[df["vertical"] == vertical]
    if tier:
        df = df[df["review_tier"] == tier]
    df = df.sort_values("composite_score", ascending=False).head(limit)
    cols = ["transaction_id", "vertical", "amount", "composite_score", "review_tier",
            "rule_flag_count", "transaction_time"]
    return df[cols].to_dict("records")

@app.get("/case/{transaction_id}")
def get_case(transaction_id: str):
    row = _scored[_scored["transaction_id"] == transaction_id]
    if row.empty:
        raise HTTPException(404, "transaction not found")
    row = row.iloc[0]
    signals = {
        "transaction_id": transaction_id,
        "vertical": row["vertical"],
        "amount": float(row["amount"]),
        "composite_score": float(row["composite_score"]),
        "review_tier": row["review_tier"],
        "isoforest_score": round(float(row["isoforest_score"]), 3),
        "autoencoder_score": round(float(row["autoencoder_score"]), 3),
        "benford_flag": bool(row["benford_flag"]),
        "rules_triggered": [c.replace("flag_", "") for c in row.index
                             if c.startswith("flag_") and row[c] == 1],
    }
    draft = _case_files.get(transaction_id, {
        "anomaly_statement": "Case file not yet drafted by the agent for this transaction.",
        "evidence_review": [], "risk_rating": "Not yet assessed",
        "explanation": "No agent draft available - run agent.py for this transaction_id.",
        "sufficiency": "not_yet_assessed",
    })
    return {"signals": signals, "agent_draft": draft}

@app.post("/case/{transaction_id}/decision")
def log_decision(transaction_id: str, decision: Decision):
    if _scored[_scored["transaction_id"] == transaction_id].empty:
        raise HTTPException(404, "transaction not found")
    entry = {
        "transaction_id": transaction_id, "timestamp": datetime.utcnow().isoformat(),
        **decision.dict(),
    }
    with open(AUDIT_TRAIL_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return {"status": "logged", "entry": entry}

@app.get("/audit_trail/{transaction_id}")
def get_audit_trail(transaction_id: str):
    if not os.path.exists(AUDIT_TRAIL_PATH):
        return []
    entries = []
    with open(AUDIT_TRAIL_PATH) as f:
        for line in f:
            e = json.loads(line)
            if e["transaction_id"] == transaction_id:
                entries.append(e)
    return entries
