"""
Sentinel AI v2 - populates SQLite from the pipeline's parquet/json outputs.
Run once after risk_engine.py (or as part of run_pipeline.py).
"""
import pandas as pd
import json
import db

def main():
    db.init_db()
    conn = db.get_connection()

    scored = pd.read_parquet("scored_transactions.parquet")
    print(f"Loading {len(scored)} transactions + risk scores into SQLite...")
    has_use_cases = "use_case" in scored.columns
    for _, row in scored.iterrows():
        db.upsert_transaction(conn, row)
        db.upsert_risk_score(conn, row, model_version="v2.0")
        if has_use_cases:
            db.upsert_use_case_signals(conn, row)
    conn.commit()
    if has_use_cases:
        print("Loaded mentor-aligned use-case signals")
    else:
        print("use_cases.py has not run yet - skipping use-case signal load "
              "(scored_transactions.parquet has no use_case columns)")

    try:
        with open("model_metadata.json") as f:
            meta = json.load(f)
        with open("calibrated_thresholds.json") as f:
            thresholds = json.load(f)
        with open("evaluation_component_metrics.csv") as f:
            eval_metrics = f.read()
        for m in meta:
            db.record_model_version(
                conn, model_version="v2.0", dataset_version="pro_dataset_v1",
                feature_version="prep.py:v2", thresholds=thresholds,
                eval_metrics={"vertical": m["vertical"], "note": "see evaluation_component_metrics.csv"},
            )
        conn.commit()
        print("Recorded model version metadata")
    except FileNotFoundError as e:
        print(f"Skipping model version metadata (not yet generated): {e}")

    conn.close()
    print(f"Done. Database at {db.DB_PATH}")

if __name__ == "__main__":
    main()
