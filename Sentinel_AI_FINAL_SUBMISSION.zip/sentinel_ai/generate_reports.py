"""
Sentinel AI v2 - consolidates every generated artifact into reports/ as readable
markdown, pulling numbers directly from the CSV/JSON files already produced by the
pipeline (never re-deriving or restating numbers by hand, to avoid transcription
drift between this file and the source data).
"""
import pandas as pd
import json
import os

os.makedirs("reports", exist_ok=True)

def df_to_md(df):
    return df.to_markdown(index=False, floatfmt=".4f")

# --- data quality report ---
with open("data_quality_report.json") as f:
    dq = json.load(f)
lines = ["# Data Quality Report\n"]
for r in dq:
    lines.append(f"## {r['dataset']} - {r['status']}\n")
    lines.append(f"- Rows: {r['n_rows']}")
    lines.append(f"- Duplicate transaction IDs: {r['duplicate_transaction_ids']}")
    lines.append(f"- Non-positive amounts: {r.get('non_positive_amounts', 'n/a')}")
    lines.append(f"- Negative balance_after: {r.get('negative_balance_after', 'n/a')}")
    lines.append(f"- Date range: {r.get('date_range', 'n/a')}")
    lines.append(f"- Timestamps date-only (no intraday component): {r.get('timestamps_are_date_only', 'n/a')}")
    lines.append(f"- Fraud label distribution: {r.get('fraud_label_distribution', 'n/a')}")
    if r["issues"]:
        lines.append("\n**Issues found:**")
        for issue in r["issues"]:
            lines.append(f"- {issue}")
    else:
        lines.append("\nNo issues found.")
    lines.append("")
with open("reports/data_quality_report.md", "w") as f:
    f.write("\n".join(lines))

# --- evaluation report ---
comp = pd.read_csv("evaluation_component_metrics.csv")
pak = pd.read_csv("evaluation_precision_recall_at_k.csv")
curve = pd.read_csv("evaluation_threshold_curve.csv")
tiers = pd.read_csv("evaluation_review_tiers.csv")
lines = ["# Evaluation Report\n",
         "All metrics below are computed on the HOLDOUT split only - the time window never "
         "touched by model fitting, contamination selection, or threshold/tier calibration "
         "(those all used TRAIN and VALIDATION). See model.py and risk_engine.py.\n",
         "## Component ROC-AUC / PR-AUC by vertical\n", df_to_md(comp), "",
         "## Precision@K / Recall@K\n", df_to_md(pak), "",
         "## Threshold curve (precision/recall/F1/FPR/FNR at multiple flag rates)\n", df_to_md(curve), "",
         "## Applied review tiers (frozen from validation calibration, evaluated on holdout)\n", df_to_md(tiers), ""]
with open("reports/evaluation_report.md", "w") as f:
    f.write("\n".join(lines))

# --- ablation report ---
abl = pd.read_csv("ablation_results.csv")
abl["note"] = abl["note"].fillna("")
weights_ba = pd.read_csv("weight_calibration_before_after.csv")
lines = ["# Ablation Report\n",
         "Compares 5 scoring configurations on the SAME holdout data and frozen component "
         "scores (nothing is refit for this comparison). See ablation.py.\n",
         "## Configuration comparison\n", df_to_md(abl), "",
         "## Finding: fixed prototype weights underperformed ML alone\n",
         "The original fixed weights (25% isoforest / 25% autoencoder / 30% Benford / 20% rules) "
         "scored WORSE than isolation-forest+autoencoder alone in every vertical - see the "
         "`5_full_sentinel_composite` vs `2_ml_only` columns above. Root cause: Benford's AUC "
         "is ~0.50 (no signal) in all three verticals for this specific fraud pattern, so a 30% "
         "weight on it diluted a working signal. Fixed via `weight_calibration.py` "
         "(validation-only grid search):\n",
         "## Weight calibration before/after (holdout)\n", df_to_md(weights_ba.drop(columns=["weights_used"])), ""]
with open("reports/ablation_report.md", "w") as f:
    f.write("\n".join(lines))

# --- workload report ---
with open("workload_metrics.json") as f:
    workload = json.load(f)
cost = pd.read_csv("cost_sensitive_evaluation.csv")
with open("cost_assumptions.json") as f:
    cost_assumptions = json.load(f)
lines = ["# Workload & Business Value Report\n"]
for v, m in workload.items():
    lines.append(f"## {v}\n")
    for k, val in m.items():
        lines.append(f"- {k}: {val}")
    lines.append("")
lines.append("## Cost-sensitive evaluation (STATED PLACEHOLDER cost assumptions, not sourced from real client data)\n")
lines.append(f"```json\n{json.dumps(cost_assumptions, indent=2)}\n```\n")
lines.append(df_to_md(cost))
lines.append("\n**Honest caveat:** under these specific placeholder assumptions, retail's "
             "`review_nothing_cost_inr` comes out lower than `sentinel_expected_cost_inr` - "
             "this is an artifact of the FN:investigation cost ratio chosen for the illustration, "
             "not a real claim that reviewing nothing is better than using Sentinel. It's reported "
             "as-is rather than adjusted to look better, to show how sensitive this kind of "
             "calculation is to its cost assumptions.")
with open("reports/workload_report.md", "w") as f:
    f.write("\n".join(lines))

# --- drift report ---
with open("drift_report.json") as f:
    drift = json.load(f)
lines = ["# Drift Monitoring Report\n",
         "Compares TRAIN (baseline) vs HOLDOUT (current) population statistics. In a real "
         "deployment this would run on a rolling window of live data vs. the original "
         "training baseline; here it demonstrates the mechanism against the same historical "
         "split already used for modeling.\n"]
for v, rows in drift.items():
    lines.append(f"## {v}\n")
    lines.append(df_to_md(pd.DataFrame(rows)))
    flagged = [r for r in rows if r["flagged"]]
    lines.append(f"\n**Status: {'DRIFT_DETECTED' if flagged else 'NORMAL'}**")
    if flagged:
        lines.append(f"Flagged metrics: {[r['metric'] for r in flagged]}")
    lines.append("")
with open("reports/drift_report.md", "w") as f:
    f.write("\n".join(lines))

print("Generated reports/data_quality_report.md")
print("Generated reports/evaluation_report.md")
print("Generated reports/ablation_report.md")
print("Generated reports/workload_report.md")
print("Generated reports/drift_report.md")
