# Sentinel AI - Presentation Outline

All figures below are pulled directly from `reports/` - regenerate them via
`python3 run_pipeline.py` before presenting if the underlying code or data changes.

---

### Slide 1 - Problem
Audit teams sample well under 5% of transactions. The other 95%+ is never checked.
Issues surface months later, if at all.

### Slide 2 - Why Traditional Audit Struggles
Three gaps: **Coverage** (unsampled transactions go unchecked), **Speed** (quarterly/
annual review cycles), **Leverage** (auditor time spent on routine checks, not judgment
work).

### Slide 3 - Sentinel AI Solution
*"Sentinel AI doesn't replace auditors. It compresses large transaction populations
into a small, explainable, evidence-backed investigation queue."*
Score 100% of transactions → prioritized queue → evidence-grounded investigation →
human decision → audit trail.

### Slide 4 - Architecture
Show `reports/architecture_diagram.png` directly. Every box names its implementing file
- nothing on this slide is aspirational.

### Slide 5 - Multi-Layer Detection
IsolationForest + autoencoder (behavioral) + 7 deterministic rules (policy) + Benford's
Law (statistical, where applicable) + lightweight network features (relationship). Each
layer's purpose stated plainly - not added to inflate the model count.

### Slide 6 - Explainable Risk
Live dashboard screenshot: composite score, "Relative Signal Strength" breakdown (not
fake additive percentages), ranked rule triggers. Answers "why was this flagged?"
without requiring ML literacy.

### Slide 7 - Evidence-Grounded Investigation
Show a real case: risk signals → retrieved evidence (with `document_id` citations) →
**supporting AND counter-evidence** → sufficiency determination → recommendation. Every
factual claim traces to a real document - verified by test, not just designed that way.

### Slide 8 - Auditor Workflow
Queue → case → evidence → AI recommendation → auditor decision (Accept/Escalate/Dismiss/
Request More Evidence) → persisted, survives browser refresh → audit trail visible.

### Slide 9 - Results
```
                IsoForest AUC   Composite AUC   Fraud Captured   Workload Reduction
AML             0.972           0.970           98.7%            76.8%
Corporate       0.707           0.707           52.9%            80.8%
Retail          0.701           0.700           50.3%            82.6%
```
All numbers from `reports/evaluation_report.md` and `reports/workload_report.md` -
measured on holdout, never touched by fitting or calibration.

### Slide 10 - The Honest Finding (credibility slide)
The original fixed component weights *underperformed ML alone in every vertical*.
Found it, fixed it with a validation-only grid search, can show the before/after:
AML +0.033 AUC, retail +0.022 AUC. This slide exists specifically to demonstrate the
evaluation methodology is rigorous enough to catch its own mistakes - the same
methodology later caught and fixed a real O(n²) performance bug in feature engineering
(prep.py: 205s → 15s, equivalence-tested), and, in the final hardening pass, a genuine
future-distribution leak in the peer-group percentile feature (an early transaction's
percentile was influenced by transactions that hadn't happened yet) - fixing it
legitimately *improved* AML's autoencoder AUC by +0.048, a real result of doing the
right thing methodologically, not a retune.

### Slide 11 - Responsible AI
Human-in-the-loop (auditor decision is authoritative) - Evidence grounding (no
fabricated facts, tested) - Mandatory counter-evidence check (demonstrated: a
would-be-CRITICAL case downgraded to MEDIUM after finding a real approval record) -
"Investigation confidence" explicitly not a fraud probability - Full audit trail with
model versioning.

### Slide 12 - Scalability / Future Architecture
Swap points identified and documented: SQLite → PostgreSQL, TF-IDF → real embeddings +
vector DB, deterministic fallback → live LLM, local CSVs → ERP connectors. Same logical
architecture throughout - only the infrastructure underneath changes.

---

## Anticipated Judge Questions (answers below drawn from README/ENGINEERING_REPORT.md)

**Why not supervised learning?** Fraud labels are often incomplete/delayed in practice;
Sentinel is designed to catch unknown/novel anomaly patterns an unsupervised model can
flag without ever having seen a labeled example of that specific pattern.

**Why Isolation Forest?** Interpretable unsupervised baseline for behavioral anomalies,
no label dependency at fit time - verified: `fraud_label` never appears in the fitting
code (`tests/unit/test_no_lookahead_static.py`).

**Why rules + ML?** Rules catch known policy violations explainably; ML catches
previously-unknown behavioral patterns rules can't anticipate.

**Why Benford?** A contextual statistical signal, not a universal fraud detector - and
we found it has zero discriminative power for this specific dataset's fraud pattern
(AUC ~0.50 everywhere), which we report rather than force a signal that isn't there.

**Why synthetic data?** Validates the architecture and workflow without exposing
confidential enterprise data - explicitly disclosed throughout, never presented as a
real-world performance claim.

**Is the LLM making the fraud decision?** No - it drafts a recommendation; only a
recorded auditor decision is authoritative. Demonstrated concretely in demo Case 3.

**How do you prevent hallucination?** Evidence grounding (every claim cites a real
`document_id`, tested), structured/validated output (Pydantic schema, invalid output
falls back to a deterministic path), mandatory counter-evidence check.

**How do you prevent leakage?** Three-way chronological split, causal-only features
(tested), frozen scaler/threshold/weight calibration on train+validation only, temporal
evidence rule enforced and tested against 30 sampled transactions with zero violations.

**What's your biggest limitation?** The live-LLM investigation path has never actually
executed in this environment (no API key available) - only the deterministic fallback
has been run end-to-end. Stated directly, not glossed over.

**How would this scale?** Enterprise ERP connectors replace flat files, a managed vector
store + real embeddings replace TF-IDF, PostgreSQL replaces SQLite, IAM/RBAC replaces
the current no-auth prototype - all identified as explicit swap points against the same
logical architecture, not a redesign.
