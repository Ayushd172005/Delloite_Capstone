# Model Card - Sentinel AI v2 Detection Ensemble

## Purpose

Prioritizes a large population of transactions into a small, explainable review queue
for human auditors. Does not make fraud determinations - it flags transactions for
investigation and provides evidence-grounded context; a human auditor makes every final
decision (accept/escalate/dismiss/request more evidence).

## Input Data

Three synthetic transaction populations (`pro_dataset_corporate.csv`, `pro_dataset_aml.csv`,
`pro_dataset_retail.csv`), 115,000 rows each, ~1-3.5% labeled fraud rate. **Confirmed
synthetic** - all three appear to share a common generator (identical schema; several
fields, like corporate's `device_id` and `location`, are constant placeholder values
with zero real variance). See `reports/data_quality_report.md` for full findings,
including 89 retail transactions with negative post-transaction balances.

## Features

~25 causal features per transaction: rolling amount z-score, personal and peer-group
amount percentile, 7-day/30-day transaction velocity and spike ratio, balance depletion
and amount-to-balance ratio, cumulative amount, counterparty/device/location/payment-method
novelty, and lightweight network features (counterparty fan-in, merchant concentration).
All computed using only information available strictly before the transaction being
scored - see `tests/unit/test_no_lookahead_static.py`,
`tests/integration/test_no_lookahead_data.py`, and
`tests/unit/test_peer_group_percentile_causal.py`. The behavioral entity used for
"personal baseline" differs by vertical (`config.ENTITY_COL`) because AML's
`account_id` field is a near-unique per-transaction SWIFT reference, not a recurring
account.

**Correction applied:** the peer-group amount percentile did not originally satisfy the
causal claim above - it ranked against the entire vertical's amount column, including
transactions after the one being scored (future-distribution leakage, not label
leakage). Fixed by freezing the reference distribution to the train period only
(`model.three_way_split`), mirroring how `StandardScaler` is already handled elsewhere
in this pipeline. See `ENGINEERING_REPORT.md` Section E/O for the full account.

**Performance:** the velocity and personal-percentile features were originally computed
via O(n²) nested loops (205s for `prep.py` alone). Replaced with vectorized equivalents,
proven byte-for-byte equivalent on both synthetic fixtures and real sampled data
(`tests/unit/test_prep_optimization_equivalence.py`) - now 15.1s.

## Algorithms

- **IsolationForest** (scikit-learn), 200 estimators, fit independently per vertical.
- **Bottleneck-MLP autoencoder** (`sklearn.neural_network.MLPRegressor`, hidden layers
  8-3-8) as a lightweight stand-in for a deep autoencoder - this environment has no
  TensorFlow/PyTorch available. Reconstruction error is the anomaly signal.
- **7 deterministic rules** (config-driven thresholds, `config.py`).
- **Benford's Law** (Mean Absolute Deviation method, per-cohort-size simulation-calibrated
  threshold) - **disabled for the corporate vertical**, where the underlying amount
  population does not follow a Benford-conforming distribution at all (a data-generation
  artifact, not a fraud signal - see `reports/ablation_report.md`).
- **Lightweight network features** (fan-in/fan-out counts) - explicitly not a graph
  neural network.

## Training Procedure

Three-way time-based split per vertical: TRAIN (first 8 months) fits the IsolationForest,
autoencoder, and StandardScaler; VALIDATION (next 2 months) calibrates the review-tier
thresholds and the composite-score component weights (both against `fraud_label`, but
only on this split - never on holdout); HOLDOUT (remaining months) is scored once with
the fully frozen model+thresholds and used for evaluation only.

**No target leakage:** `fraud_label` never appears in model fitting or contamination
selection (`model.py`'s `fit_score_vertical` function contains zero references to it -
this is a static test assertion, not just a code review claim). Contamination is a
stated business assumption (`ASSUMED_REVIEW_CAPACITY_PCT = 3.0`), not derived from the
true fraud rate.

## Threshold / Weight Selection

Composite score weights were originally a fixed guess (25% isoforest / 25% autoencoder /
30% Benford / 20% rules). An ablation study found this **underperformed isolation-forest
+ autoencoder alone in every vertical** (see `reports/ablation_report.md`). Fixed via a
validation-only grid search (`weight_calibration.py`); the resulting weights
(~55% isoforest / ~15-35% autoencoder / 5% rules / 0% Benford) measurably improved
holdout AUC (AML +0.033, retail +0.024, corporate +0.001).

## Evaluation (holdout, never touched by fitting or calibration)

| Vertical | Composite ROC-AUC | Composite PR-AUC |
|---|---|---|
| AML | 0.970 | 0.533 |
| Corporate | 0.707 | 0.442 |
| Retail | 0.700 | 0.345 |

Full precision/recall/F1 curves, Precision@K, and workload-reduction figures are in
`reports/evaluation_report.md` and `reports/workload_report.md`.

## Limitations

- Trained and evaluated exclusively on synthetic data from an apparently shared generator -
  no claim is made about real-world transferability.
- The autoencoder is a shallow MLP, not a production-grade deep autoencoder.
- Benford's Law provides zero discriminative signal (AUC ~0.50) for this specific
  synthetic fraud pattern in all three verticals - it may still be useful for other
  fraud types (e.g. invoice/digit fabrication) not represented in this dataset.
- Rule thresholds and cost assumptions throughout are explicitly stated placeholders.
- Retail data contains 89 transactions with negative post-transaction balances and 10
  with >100% balance depletion, which were flagged by `data_validation.py` but not
  removed from the modeling population.

## Intended Use

Prototype/capstone demonstration of a continuous-audit anomaly-detection architecture.
Suitable for evaluating the *methodology* (causal feature engineering, leakage-free
model fitting, evidence-grounded investigation, human-in-the-loop decisioning). Not
validated for, and not intended for, production fraud/AML decisioning without
revalidation on real, representative data and a real regulatory/compliance review.

## Prohibited Use

- Making autonomous fraud or AML determinations without human review.
- Any production deployment without revalidation on real transaction data.
- Presenting the synthetic evaluation numbers in this model card as real-world
  performance figures.
