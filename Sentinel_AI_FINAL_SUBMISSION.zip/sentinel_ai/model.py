"""
Sentinel AI v2 - anomaly scoring models.

CRITICAL FIX from the prior version of this code: contamination was previously set
via `fraud_label.mean()` on the training slice. That is target leakage - it lets the
"unsupervised" detector see the true fraud rate before making a single prediction,
which quietly turns an anomaly detector into a semi-supervised one while still being
reported as unsupervised. This version NEVER reads fraud_label anywhere in fit() or
threshold selection. fraud_label is used ONLY in evaluate.py, strictly after scoring
and thresholding are already frozen.

Three-way time-based split:
  TRAIN      (first SPLIT_MONTHS.train_end_month months)      -> fit the models
  VALIDATION (next few months, up to validation_end_month)     -> calibrate contamination
                                                                   and score thresholds
  HOLDOUT    (everything after validation_end_month)           -> scored once, evaluated once,
                                                                   never used to pick anything

contamination is calibrated on VALIDATION using only the unsupervised anomaly scores
themselves (an operational assumption about review capacity - e.g. "we can review the
riskiest ~3% of transactions" - not the true fraud rate), which is a defensible
prototype stand-in for "business review-capacity calibration" per the master prompt's
Section 9 (risk engine thresholds should come from validation/operational capacity,
not target leakage).
"""
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from config import RANDOM_SEED, SPLIT_MONTHS

FEATURES = [
    "amount", "amount_zscore", "velocity_7d", "velocity_30d", "velocity_spike_ratio",
    "balance_depletion_ratio", "amount_to_balance_ratio", "days_since_last_txn",
    "transaction_frequency", "is_new_counterparty", "amount_pct_rank_personal",
    "amount_pct_rank_peer_group", "cumulative_amount", "merchant_concentration",
]

# Operational assumption, NOT derived from fraud_label: assume review capacity supports
# investigating roughly the riskiest 3% of transactions by unsupervised score. This is
# exactly the kind of number a real deployment would set from auditor headcount, not
# from knowing the answer in advance.
ASSUMED_REVIEW_CAPACITY_PCT = 3.0

def three_way_split(df):
    start = df["transaction_time"].min()
    train_cutoff = start + pd.DateOffset(months=SPLIT_MONTHS["train_end_month"])
    val_cutoff = start + pd.DateOffset(months=SPLIT_MONTHS["validation_end_month"])
    train = df[df["transaction_time"] < train_cutoff]
    validation = df[(df["transaction_time"] >= train_cutoff) & (df["transaction_time"] < val_cutoff)]
    holdout = df[df["transaction_time"] >= val_cutoff]
    return train, validation, holdout

def minmax_fit(train_scores):
    lo, hi = train_scores.min(), train_scores.max()
    return lo, (hi - lo) if (hi - lo) > 1e-9 else 1.0

def minmax_apply(scores, lo, span):
    return ((scores - lo) / span).clip(0, 1)

def fit_score_vertical(df, vertical):
    """
    Fits IsolationForest + autoencoder on TRAIN only. Calibrates min-max normalization
    bounds and the review-capacity contamination on TRAIN only. Scores validation and
    holdout using the frozen fit - no re-fitting, no peeking at labels anywhere here.
    """
    train, validation, holdout = three_way_split(df)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(train[FEATURES])

    # contamination calibrated as an assumed operational review-capacity percentile -
    # an operator's business assumption about review headcount, never a target label.
    contamination = ASSUMED_REVIEW_CAPACITY_PCT / 100.0

    iso = IsolationForest(contamination=contamination, random_state=RANDOM_SEED, n_estimators=200)
    iso.fit(X_train)
    iso_train_raw = -iso.decision_function(X_train)
    iso_lo, iso_span = minmax_fit(iso_train_raw)

    ae = MLPRegressor(hidden_layer_sizes=(8, 3, 8), max_iter=300, random_state=RANDOM_SEED,
                       early_stopping=True, n_iter_no_change=10)
    ae.fit(X_train, X_train)
    recon_train = ae.predict(X_train)
    ae_train_raw = np.mean((X_train - recon_train) ** 2, axis=1)
    ae_lo, ae_span = minmax_fit(pd.Series(ae_train_raw))

    def score_split(split_df):
        X = scaler.transform(split_df[FEATURES])
        iso_raw = -iso.decision_function(X)
        iso_score = minmax_apply(pd.Series(iso_raw, index=split_df.index), iso_lo, iso_span)
        recon = ae.predict(X)
        ae_raw = np.mean((X - recon) ** 2, axis=1)
        ae_score = minmax_apply(pd.Series(ae_raw, index=split_df.index), ae_lo, ae_span)
        out = split_df.copy()
        out["isoforest_score"] = iso_score
        out["autoencoder_score"] = ae_score
        return out

    train_scored = score_split(train)
    validation_scored = score_split(validation)
    holdout_scored = score_split(holdout)

    model_meta = {
        "vertical": vertical, "model_version": "v2.0", "features": FEATURES,
        "contamination_assumed_review_capacity_pct": ASSUMED_REVIEW_CAPACITY_PCT,
        "train_rows": len(train), "validation_rows": len(validation), "holdout_rows": len(holdout),
        "train_start": str(train["transaction_time"].min()), "train_end": str(train["transaction_time"].max()),
        "holdout_start": str(holdout["transaction_time"].min()), "holdout_end": str(holdout["transaction_time"].max()),
    }
    return train_scored, validation_scored, holdout_scored, model_meta

if __name__ == "__main__":
    import json
    full = pd.read_parquet("normalized_features_benford.parquet")
    all_train, all_val, all_holdout, all_meta = [], [], [], []
    for vertical, sub in full.groupby("vertical"):
        sub = sub.reset_index(drop=True)
        print(f"Fitting {vertical} (train/validation/holdout = "
              f"{SPLIT_MONTHS['train_end_month']}/{SPLIT_MONTHS['validation_end_month']-SPLIT_MONTHS['train_end_month']}/rest months)...")
        tr, va, ho, meta = fit_score_vertical(sub, vertical)
        all_train.append(tr); all_val.append(va); all_holdout.append(ho); all_meta.append(meta)
        print(f"  train={len(tr)} validation={len(va)} holdout={len(ho)}")

    pd.concat(all_train, ignore_index=True).to_parquet("scored_train.parquet", index=False)
    pd.concat(all_val, ignore_index=True).to_parquet("scored_validation.parquet", index=False)
    pd.concat(all_holdout, ignore_index=True).to_parquet("scored_holdout.parquet", index=False)
    with open("model_metadata.json", "w") as f:
        json.dump(all_meta, f, indent=2)
    print("Saved scored_train.parquet, scored_validation.parquet, scored_holdout.parquet, model_metadata.json")
