"""
Sentinel AI v2 - auditor workload metrics.
Computed on holdout only. The core claim to demonstrate (or honestly fail to
demonstrate) is: does Sentinel reduce the volume of transactions requiring human
attention while preserving detection quality, relative to reviewing everything?
"""
import pandas as pd
import json

def compute_workload_metrics(holdout):
    results = {}
    for vertical, sub in holdout.groupby("vertical"):
        n = len(sub)
        n_fraud = int(sub["fraud_label"].sum())
        flagged = sub[sub["review_tier"] != "auto_clear"]
        n_flagged = len(flagged)
        fraud_in_flagged = int(flagged["fraud_label"].sum())

        top1 = sub.nlargest(max(1, int(n * 0.01)), "composite_score")
        top5 = sub.nlargest(max(1, int(n * 0.05)), "composite_score")

        results[vertical] = {
            "transactions_analyzed": n,
            "transactions_flagged_for_review": n_flagged,
            "pct_flagged": round(n_flagged / n * 100, 2),
            "pct_auto_cleared": round((n - n_flagged) / n * 100, 2),
            "high_risk_cases": int((sub["review_tier"] == "immediate_escalation").sum()),
            "total_fraud_in_holdout": n_fraud,
            "fraud_caught_in_flagged_queue": fraud_in_flagged,
            "fraud_missed_by_auto_clear": n_fraud - fraud_in_flagged,
            "top_1pct_capture_rate": round(top1["fraud_label"].sum() / n_fraud, 4) if n_fraud else None,
            "top_5pct_capture_rate": round(top5["fraud_label"].sum() / n_fraud, 4) if n_fraud else None,
            "false_positive_burden_in_queue": int(n_flagged - fraud_in_flagged),
            "manual_review_of_everything_would_require": n,
            "sentinel_review_queue_size": n_flagged,
            "workload_reduction_pct": round((1 - n_flagged / n) * 100, 2),
        }
    return results

if __name__ == "__main__":
    holdout = pd.read_parquet("risk_scored_holdout.parquet")
    metrics = compute_workload_metrics(holdout)
    for v, m in metrics.items():
        print(f"\n=== {v} ===")
        for k, val in m.items():
            print(f"  {k}: {val}")
    with open("workload_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    print("\nSaved workload_metrics.json")
