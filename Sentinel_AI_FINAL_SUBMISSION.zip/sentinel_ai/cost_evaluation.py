"""
Sentinel AI v2 - cost-sensitive evaluation.

Expected Audit Cost = (FP x false_positive_cost) + (FN x false_negative_cost) + (flagged x investigation_cost)

Cost assumptions below are STATED PLACEHOLDERS, not derived from any real client data -
labeled as such throughout, per the same discipline as config.APPROVAL_LIMIT. The point
is to demonstrate the calculation exists and is honest about its assumptions, not to
claim a specific rupee figure is real.
"""
import pandas as pd
import numpy as np
import json

# Stated placeholder assumptions (INR) - an auditor's hour, roughly, for investigation
# cost; a missed-fraud cost order-of-magnitude larger than a wasted-review cost, which
# is the standard qualitative shape of this tradeoff in audit literature - the specific
# numbers are illustrative, not sourced.
COST_ASSUMPTIONS = {
    "investigation_cost_per_flagged_txn": 500,      # analyst time to review one flagged case
    "false_positive_cost": 500,                      # same as investigation cost - wasted review time
    "false_negative_cost": {"corporate": 50000, "aml": 200000, "retail": 5000},  # missed fraud, by vertical severity
}

def compute_expected_cost(holdout):
    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        y = sub["fraud_label"].values
        flagged = (sub["review_tier"] != "auto_clear").values
        tp = int(((flagged == 1) & (y == 1)).sum())
        fp = int(((flagged == 1) & (y == 0)).sum())
        fn = int(((flagged == 0) & (y == 1)).sum())
        tn = int(((flagged == 0) & (y == 0)).sum())

        fn_cost = COST_ASSUMPTIONS["false_negative_cost"][vertical]
        investigation_cost = COST_ASSUMPTIONS["investigation_cost_per_flagged_txn"]

        cost_sentinel = flagged.sum() * investigation_cost + fn * fn_cost
        cost_review_everything = len(sub) * investigation_cost  # no fraud missed, but reviews everything
        cost_review_nothing = int(y.sum()) * fn_cost  # reviews nothing, all fraud missed

        rows.append({
            "vertical": vertical, "n": len(sub), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "sentinel_expected_cost_inr": int(cost_sentinel),
            "review_everything_cost_inr": int(cost_review_everything),
            "review_nothing_cost_inr": int(cost_review_nothing),
            "sentinel_vs_review_everything_savings_inr": int(cost_review_everything - cost_sentinel),
            "sentinel_vs_review_everything_savings_pct": round(
                (cost_review_everything - cost_sentinel) / cost_review_everything * 100, 1
            ) if cost_review_everything else None,
        })
    return pd.DataFrame(rows)

if __name__ == "__main__":
    holdout = pd.read_parquet("risk_scored_holdout.parquet")
    result = compute_expected_cost(holdout)
    print("Cost assumptions (STATED PLACEHOLDERS, not sourced from real client data):")
    print(json.dumps(COST_ASSUMPTIONS, indent=2))
    print()
    print(result.to_string(index=False))
    result.to_csv("cost_sensitive_evaluation.csv", index=False)
    with open("cost_assumptions.json", "w") as f:
        json.dump(COST_ASSUMPTIONS, f, indent=2)
    print("\nSaved cost_sensitive_evaluation.csv, cost_assumptions.json")
