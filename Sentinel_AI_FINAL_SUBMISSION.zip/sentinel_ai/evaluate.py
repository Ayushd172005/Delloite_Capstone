"""
Sentinel AI v2 - evaluation harness.

Everything here reads risk_scored_holdout.parquet - the one split never touched by
fitting, contamination selection, or threshold/tier calibration (all of which happened
on train/validation in model.py and risk_engine.py). fraud_label is used here for the
FIRST time in the pipeline.
"""
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, precision_score, recall_score, f1_score

COMPONENTS = ["isoforest_score", "autoencoder_score", "benford_score", "rule_score", "composite_score"]

def component_metrics(holdout):
    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        y = sub["fraud_label"].values
        row = {"vertical": vertical}
        for col in COMPONENTS:
            try:
                row[f"{col}_roc_auc"] = round(roc_auc_score(y, sub[col]), 3)
                row[f"{col}_pr_auc"] = round(average_precision_score(y, sub[col]), 3)
            except ValueError:
                row[f"{col}_roc_auc"] = np.nan
                row[f"{col}_pr_auc"] = np.nan
        rows.append(row)
    return pd.DataFrame(rows)

def precision_recall_at_k(holdout, k_pcts=(1, 3, 5, 10, 15, 20)):
    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        y = sub["fraud_label"].values
        n_fraud = y.sum()
        for k in k_pcts:
            n_flag = max(1, int(len(sub) * k / 100))
            top_idx = sub["composite_score"].nlargest(n_flag).index
            caught = sub.loc[top_idx, "fraud_label"].sum()
            precision_at_k = caught / n_flag
            recall_at_k = caught / n_fraud if n_fraud else np.nan
            rows.append({"vertical": vertical, "k_pct": k, "n_flagged": n_flag,
                          "fraud_caught": int(caught), "total_fraud": int(n_fraud),
                          "precision_at_k": round(precision_at_k, 4),
                          "recall_at_k": round(recall_at_k, 4) if not np.isnan(recall_at_k) else None})
    return pd.DataFrame(rows)

def threshold_curve(holdout, pcts=(80, 85, 90, 95, 97, 99)):
    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        y = sub["fraud_label"].values
        for pct in pcts:
            thr = np.percentile(sub["composite_score"], pct)
            pred = (sub["composite_score"] >= thr).astype(int)
            tp = ((pred == 1) & (y == 1)).sum(); fp = ((pred == 1) & (y == 0)).sum()
            fn = ((pred == 0) & (y == 1)).sum(); tn = ((pred == 0) & (y == 0)).sum()
            precision = tp / (tp + fp) if (tp + fp) else np.nan
            recall = tp / (tp + fn) if (tp + fn) else np.nan
            f1 = 2 * precision * recall / (precision + recall) if precision and recall else np.nan
            fpr = fp / (fp + tn) if (fp + tn) else np.nan
            fnr = fn / (fn + tp) if (fn + tp) else np.nan
            rows.append({
                "vertical": vertical, "flag_top_pct": 100 - pct, "score_threshold": round(thr, 2),
                "precision": round(precision, 3), "recall": round(recall, 3),
                "f1": round(f1, 3) if not np.isnan(f1) else None,
                "false_positive_rate": round(fpr, 4), "false_negative_rate": round(fnr, 4),
                "n_flagged": int(pred.sum()),
            })
    return pd.DataFrame(rows)

def review_tier_summary(holdout):
    """Actual tiers applied (frozen from validation calibration), evaluated on holdout."""
    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        for tier in ["auto_clear", "standard_review", "priority_review", "immediate_escalation"]:
            t = sub[sub["review_tier"] == tier]
            if len(t) == 0:
                continue
            rows.append({
                "vertical": vertical, "tier": tier, "n": len(t),
                "pct_of_vertical": round(len(t) / len(sub) * 100, 2),
                "fraud_rate_in_tier": round(t["fraud_label"].mean(), 4),
                "n_fraud_in_tier": int(t["fraud_label"].sum()),
            })
    return pd.DataFrame(rows)

if __name__ == "__main__":
    holdout = pd.read_parquet("risk_scored_holdout.parquet")
    print(f"Holdout size: {len(holdout)} rows ({holdout['transaction_time'].min()} to {holdout['transaction_time'].max()})\n")

    comp = component_metrics(holdout)
    print("=== Component ROC-AUC / PR-AUC (holdout, never used for fitting/thresholds) ===")
    print(comp.to_string(index=False))
    comp.to_csv("evaluation_component_metrics.csv", index=False)

    pak = precision_recall_at_k(holdout)
    print("\n=== Precision@K / Recall@K ===")
    print(pak.to_string(index=False))
    pak.to_csv("evaluation_precision_recall_at_k.csv", index=False)

    curve = threshold_curve(holdout)
    print("\n=== Threshold curve ===")
    print(curve.to_string(index=False))
    curve.to_csv("evaluation_threshold_curve.csv", index=False)

    tiers = review_tier_summary(holdout)
    print("\n=== Applied review tiers (frozen from validation calibration) ===")
    print(tiers.to_string(index=False))
    tiers.to_csv("evaluation_review_tiers.csv", index=False)
