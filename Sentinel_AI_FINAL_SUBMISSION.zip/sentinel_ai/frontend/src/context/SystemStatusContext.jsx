import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { checkHealth } from "../api/transactions";
import { USE_MOCK, API_BASE } from "../api/client";

const SystemStatusContext = createContext(null);

export function SystemStatusProvider({ children }) {
  const [status, setStatus] = useState("checking"); // checking | operational | unreachable
  const [error, setError] = useState(null);
  const [transactionsLoaded, setTransactionsLoaded] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);

  const check = useCallback(async () => {
    try {
      const res = await checkHealth();
      setStatus("operational");
      setTransactionsLoaded(res.transactions_loaded ?? null);
      setError(null);
    } catch (e) {
      setStatus("unreachable");
      setError(e.message);
    } finally {
      setLastChecked(new Date());
    }
  }, []);

  useEffect(() => {
    check();
    const id = setInterval(check, 30000);
    return () => clearInterval(id);
  }, [check]);

  return (
    <SystemStatusContext.Provider
      value={{ status, error, transactionsLoaded, lastChecked, isMock: USE_MOCK, apiBase: API_BASE, recheck: check }}
    >
      {children}
    </SystemStatusContext.Provider>
  );
}

export function useSystemStatus() {
  return useContext(SystemStatusContext);
}
