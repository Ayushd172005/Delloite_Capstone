// Mock data mirrors the exact shape returned by app.py + agent.py so the UI
// never has to know whether it's running against the real backend or this
// fallback. Field names copied 1:1 from the FastAPI/Pydantic contract -
// nothing here invents a field the backend doesn't actually return.

const VERTICALS = ["retail", "corporate", "aml"];
const TIERS = ["standard_review", "priority_review", "immediate_escalation"];
const RULE_FLAGS = [
  "just_under_limit",
  "round_number",
  "velocity_spike",
  "new_counterparty_high_value",
  "balance_depletion",
  "off_hours_weekend",
  "dormant_reactivation",
  "shared_device",
  "hub_counterparty",
];

function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function buildQueue(n = 42) {
  const rand = seededRandom(7);
  const rows = [];
  for (let i = 0; i < n; i++) {
    const vertical = VERTICALS[Math.floor(rand() * VERTICALS.length)];
    const score = Math.round((55 + rand() * 44) * 10) / 10;
    const tier =
      score >= 85 ? "immediate_escalation" : score >= 70 ? "priority_review" : "standard_review";
    const flagCount = 1 + Math.floor(rand() * 3);
    rows.push({
      transaction_id: `MOCK_TXN_${String(i + 1).padStart(5, "0")}`,
      vertical,
      amount: Math.round(rand() * 480000 + 5000),
      composite_score: score,
      review_tier: tier,
      rule_flag_count: flagCount,
      auditor_decision: rand() > 0.8 ? "ACCEPT" : null,
    });
  }
  return rows.sort((a, b) => b.composite_score - a.composite_score);
}

export const MOCK_QUEUE = buildQueue();

export function mockCase(transactionId) {
  const base =
    MOCK_QUEUE.find((r) => r.transaction_id === transactionId) || MOCK_QUEUE[0];
  const rand = seededRandom(transactionId.length * 31);
  const rulesTriggered = RULE_FLAGS.filter(() => rand() > 0.65).slice(0, 3);

  const signals = {
    composite_score: base.composite_score,
    review_tier: base.review_tier,
    isoforest_score: Math.round(rand() * 0.4 * 100 + 55) / 100,
    autoencoder_score: Math.round(rand() * 0.4 * 100 + 50) / 100,
    benford_flag: rand() > 0.7,
    rules_triggered: rulesTriggered,
  };

  return { signals, investigation: null, case: null, _isMock: true };
}

export function mockInvestigation(transactionId) {
  const { signals } = mockCase(transactionId);
  const hasCounter = signals.composite_score < 90;
  const level =
    signals.composite_score >= 90
      ? "CRITICAL"
      : signals.composite_score >= 75
      ? "HIGH"
      : signals.composite_score >= 50
      ? "MEDIUM"
      : "LOW";

  return {
    transaction_id: transactionId,
    risk_score: signals.composite_score,
    risk_level: level,
    finding: `Transaction ${transactionId} scored ${signals.composite_score}/100, driven by ${
      signals.rules_triggered.length
    } rule signal(s) and elevated model scores.${
      hasCounter ? " A prior record was found that partially offsets the initial concern." : ""
    }`,
    anomaly_drivers: signals.rules_triggered,
    supporting_evidence: [
      {
        document_id: "DOC_MOCK_0001",
        statement: "Isolation-forest anomaly score is elevated relative to peer transactions.",
        stance: "supports",
      },
      {
        document_id: "DOC_MOCK_0002",
        statement: "Transaction amount sits above the 95th percentile for this account's history.",
        stance: "supports",
      },
    ],
    counter_evidence: hasCounter
      ? [
          {
            document_id: "DOC_MOCK_0003",
            statement: "A prior approval record exists covering a similarly sized transfer.",
            stance: "contradicts",
          },
        ]
      : [],
    evidence_sufficiency: hasCounter ? "SUFFICIENT" : "INSUFFICIENT",
    recommended_action: hasCounter ? "REQUEST_MORE_EVIDENCE" : "ESCALATE",
    confidence: hasCounter ? 0.72 : 0.85,
    _isMock: true,
  };
}

export function mockAuditTrail(transactionId) {
  const now = Date.now();
  return [
    {
      event_id: 1,
      transaction_id: transactionId,
      case_id: `CASE_${transactionId}`,
      event_type: "model_scored",
      payload_json: JSON.stringify({ composite_score: 88.4, review_tier: "priority_review" }),
      actor: "system",
      timestamp: new Date(now - 1000 * 60 * 30).toISOString(),
    },
    {
      event_id: 2,
      transaction_id: transactionId,
      case_id: `CASE_${transactionId}`,
      event_type: "investigated",
      payload_json: JSON.stringify({ evidence_sufficiency: "SUFFICIENT" }),
      actor: "agent",
      timestamp: new Date(now - 1000 * 60 * 20).toISOString(),
    },
  ];
}
