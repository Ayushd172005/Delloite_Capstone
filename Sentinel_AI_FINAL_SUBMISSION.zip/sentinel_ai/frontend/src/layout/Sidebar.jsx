import { NavLink } from "react-router-dom";
import { ListChecks, History, ShieldCheck } from "lucide-react";
import { useSystemStatus } from "../context/SystemStatusContext";

const NAV = [
  { to: "/", label: "Risk Queue", icon: ListChecks, end: true },
  { to: "/audit-trail", label: "Audit Trail", icon: History },
];

function navClass({ isActive }) {
  return [
    "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
    isActive
      ? "bg-panel-raised text-ink border-l-2 border-accent -ml-px pl-[11px]"
      : "text-ink-muted hover:bg-panel-raised/60 hover:text-ink",
  ].join(" ");
}

export default function Sidebar() {
  const { status } = useSystemStatus();
  return (
    <aside className="flex h-full w-56 shrink-0 flex-col border-r border-border bg-base">
      <div className="flex items-center gap-2 border-b border-border px-4 py-4">
        <ShieldCheck className="h-5 w-5 text-accent" strokeWidth={1.75} />
        <div>
          <div className="text-sm font-semibold leading-none text-ink">Sentinel AI</div>
          <div className="mt-1 text-2xs leading-none text-ink-faint">Continuous Audit Intelligence</div>
        </div>
      </div>
      <nav className="flex-1 space-y-1 px-2 py-3">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={navClass}>
            <Icon className="h-4 w-4" strokeWidth={1.75} />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-border px-4 py-3">
        <div className="text-2xs uppercase tracking-wide text-ink-faint">System</div>
        <div className="mt-1 flex items-center gap-1.5 text-xs font-medium">
          <span
            className={`h-1.5 w-1.5 rounded-full ${
              status === "operational" ? "bg-low" : status === "checking" ? "bg-medium" : "bg-critical"
            }`}
          />
          <span className={status === "operational" ? "text-low" : status === "checking" ? "text-medium" : "text-critical"}>
            {status === "operational" ? "Operational" : status === "checking" ? "Checking…" : "Unreachable"}
          </span>
        </div>
      </div>
    </aside>
  );
}
