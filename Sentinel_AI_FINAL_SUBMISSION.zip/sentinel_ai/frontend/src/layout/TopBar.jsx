import { useSystemStatus } from "../context/SystemStatusContext";

export default function TopBar() {
  const { isMock, transactionsLoaded, lastChecked, apiBase } = useSystemStatus();
  return (
    <header className="flex h-12 shrink-0 items-center justify-between border-b border-border bg-base px-5">
      <div className="flex items-center gap-3 text-2xs text-ink-faint">
        {isMock ? (
          <span className="rounded border border-medium-border bg-medium-bg px-2 py-0.5 font-medium text-medium">
            Mock data mode
          </span>
        ) : (
          <span className="font-mono">{apiBase}</span>
        )}
        {transactionsLoaded != null && (
          <span>
            {transactionsLoaded.toLocaleString("en-IN")} transactions loaded
          </span>
        )}
      </div>
      <div className="text-2xs text-ink-faint">
        {lastChecked && <>Last checked {lastChecked.toLocaleTimeString()}</>}
      </div>
    </header>
  );
}
