import { apiFetch, USE_MOCK } from "./client";
import { MOCK_QUEUE, mockCase } from "../mocks/data";

export async function getQueue({ vertical, tier, limit = 50 } = {}) {
  if (USE_MOCK) {
    let rows = MOCK_QUEUE;
    if (vertical) rows = rows.filter((r) => r.vertical === vertical);
    if (tier) rows = rows.filter((r) => r.review_tier === tier);
    return rows.slice(0, limit);
  }
  const params = new URLSearchParams();
  if (vertical) params.set("vertical", vertical);
  if (tier) params.set("tier", tier);
  params.set("limit", String(limit));
  return apiFetch(`/queue?${params.toString()}`);
}

export async function getCase(transactionId) {
  if (USE_MOCK) return mockCase(transactionId);
  return apiFetch(`/case/${transactionId}`);
}

export async function checkHealth() {
  if (USE_MOCK) return { status: "ok", transactions_loaded: MOCK_QUEUE.length, _isMock: true };
  return apiFetch("/health");
}

export async function getMetrics() {
  if (USE_MOCK) return null;
  return apiFetch("/metrics");
}
