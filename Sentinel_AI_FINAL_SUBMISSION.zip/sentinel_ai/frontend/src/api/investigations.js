import { apiFetch, USE_MOCK } from "./client";
import { mockInvestigation } from "../mocks/data";

export async function investigateTransaction(transactionId) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600));
    return { case_id: `CASE_${transactionId}`, investigation: mockInvestigation(transactionId) };
  }
  return apiFetch(`/case/${transactionId}/investigate`, { method: "POST" });
}

export async function submitAuditorDecision(transactionId, { auditor, action, reason }) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 300));
    return { status: "recorded", case_id: `CASE_${transactionId}`, action, _isMock: true };
  }
  return apiFetch(`/case/${transactionId}/decision`, {
    method: "POST",
    body: JSON.stringify({ auditor, action, reason: reason || null }),
  });
}
