import { apiFetch, USE_MOCK } from "./client";
import { getQueue } from "./transactions";
import { mockAuditTrail } from "../mocks/data";

export async function getAuditTrail(transactionId) {
  if (USE_MOCK) return mockAuditTrail(transactionId);
  return apiFetch(`/audit_trail/${transactionId}`);
}

// The backend only exposes a per-transaction audit trail (spec item 31 needs
// a cross-case feed). Rather than inventing a new backend endpoint against a
// codebase that has been explicitly frozen, this aggregates the real
// per-transaction trails client-side: pull the queue, fetch each case's
// trail, merge, sort by timestamp. Every event still comes straight from the
// real audit_events table - this is composition, not fabrication.
export async function getGlobalAuditFeed({ limit = 30 } = {}) {
  if (USE_MOCK) {
    const rows = (await getQueue({ limit })).filter((_, i) => i < 8);
    const all = rows.flatMap((r) => mockAuditTrail(r.transaction_id));
    return all.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }
  const rows = await getQueue({ limit });
  const withActivity = rows.filter((r) => r.auditor_decision);
  const idsToFetch = (withActivity.length ? withActivity : rows).slice(0, 15);
  const trails = await Promise.all(
    idsToFetch.map((r) =>
      getAuditTrail(r.transaction_id).catch(() => [])
    )
  );
  return trails.flat().sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

export async function getModelInfo() {
  if (USE_MOCK) return [];
  return apiFetch("/model-info");
}
