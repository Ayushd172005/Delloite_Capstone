const STANCE_STYLE = {
  supports: { icon: "✓", text: "text-low" },
  contradicts: { icon: "⚠", text: "text-medium" },
  neutral: { icon: "•", text: "text-ink-faint" },
};

function EvidenceLine({ item }) {
  const cfg = STANCE_STYLE[item.stance] || STANCE_STYLE.neutral;
  return (
    <div className="flex gap-2.5 border-b border-border/60 py-2.5 last:border-0">
      <span className={`mt-0.5 shrink-0 font-semibold ${cfg.text}`}>{cfg.icon}</span>
      <div className="text-xs leading-relaxed text-ink-muted">
        <span className="mr-2 rounded bg-link-bg px-1.5 py-0.5 font-mono text-2xs text-link">
          {item.document_id}
        </span>
        {item.statement}
      </div>
    </div>
  );
}

export function SupportingEvidencePanel({ items }) {
  return (
    <div className="rounded-lg border border-low-border bg-panel p-4">
      <div className="text-2xs font-semibold uppercase tracking-wide text-low">Supporting Evidence</div>
      <div className="mt-2">
        {items.length === 0 ? (
          <div className="py-2 text-xs text-ink-faint">None found.</div>
        ) : (
          items.map((e, i) => <EvidenceLine key={i} item={e} />)
        )}
      </div>
    </div>
  );
}

export function CounterEvidencePanel({ items }) {
  return (
    <div className="rounded-lg border border-medium-border bg-panel p-4">
      <div className="text-2xs font-semibold uppercase tracking-wide text-medium">Counter-Evidence</div>
      <div className="mt-2">
        {items.length === 0 ? (
          <div className="py-2 text-xs text-ink-faint">
            None found — the agent checked and found nothing contradicting the flag.
          </div>
        ) : (
          items.map((e, i) => <EvidenceLine key={i} item={e} />)
        )}
      </div>
      <div className="mt-3 border-t border-border/60 pt-2 text-2xs italic text-ink-faint">
        Sentinel AI always checks for counter-evidence before recommending escalation — it does
        not simply confirm its initial suspicion.
      </div>
    </div>
  );
}
