export default function EmptyState({ title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-16 text-center">
      <div className="text-sm font-medium text-ink-muted">{title}</div>
      {description && <div className="mt-1.5 max-w-sm text-2xs text-ink-faint">{description}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
