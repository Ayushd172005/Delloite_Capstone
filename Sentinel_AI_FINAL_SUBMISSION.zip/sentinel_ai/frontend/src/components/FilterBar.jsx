import { Search, RefreshCw } from "lucide-react";

const VERTICALS = ["retail", "corporate", "aml"];
const TIERS = [
  { value: "standard_review", label: "Standard" },
  { value: "priority_review", label: "Priority" },
  { value: "immediate_escalation", label: "Escalation" },
];

function Pill({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
        active ? "bg-panel-raised text-ink border border-border-strong" : "text-ink-faint hover:text-ink-muted"
      }`}
    >
      {children}
    </button>
  );
}

export default function FilterBar({ search, onSearch, vertical, onVertical, tier, onTier, onRefresh, refreshing }) {
  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-b border-border px-6 py-3">
      <div className="relative w-64">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-faint" />
        <input
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search transaction ID…"
          className="w-full rounded-md border border-border bg-panel py-1.5 pl-8 pr-3 text-xs text-ink placeholder:text-ink-faint focus:border-accent"
        />
      </div>
      <div className="flex items-center gap-1">
        <span className="mr-1 text-2xs uppercase tracking-wide text-ink-faint">Vertical</span>
        <Pill active={!vertical} onClick={() => onVertical(null)}>All</Pill>
        {VERTICALS.map((v) => (
          <Pill key={v} active={vertical === v} onClick={() => onVertical(v)}>
            {v[0].toUpperCase() + v.slice(1)}
          </Pill>
        ))}
      </div>
      <div className="flex items-center gap-1">
        <span className="mr-1 text-2xs uppercase tracking-wide text-ink-faint">Tier</span>
        <Pill active={!tier} onClick={() => onTier(null)}>All</Pill>
        {TIERS.map((t) => (
          <Pill key={t.value} active={tier === t.value} onClick={() => onTier(t.value)}>
            {t.label}
          </Pill>
        ))}
      </div>
      <button
        onClick={onRefresh}
        className="ml-auto flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium text-ink-muted hover:text-ink"
      >
        <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
        Refresh
      </button>
    </div>
  );
}
