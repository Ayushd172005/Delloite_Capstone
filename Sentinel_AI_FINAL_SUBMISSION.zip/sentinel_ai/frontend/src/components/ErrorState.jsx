export default function ErrorState({ title, message, onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-high-border bg-high-bg py-14 text-center">
      <div className="text-sm font-semibold text-high">{title}</div>
      {message && <div className="mt-2 max-w-md text-2xs text-ink-muted">{message}</div>}
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 rounded-md border border-low-border bg-low-bg px-4 py-1.5 text-xs font-semibold text-low hover:brightness-110"
        >
          Retry
        </button>
      )}
    </div>
  );
}
