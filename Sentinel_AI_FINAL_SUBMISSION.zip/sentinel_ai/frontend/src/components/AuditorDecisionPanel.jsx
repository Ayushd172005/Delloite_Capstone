import { useState } from "react";

const ACTIONS = [
  { value: "ACCEPT", label: "Accept", tone: "border-low-border bg-low-bg text-low" },
  { value: "ESCALATE", label: "Escalate", tone: "border-critical-border bg-critical-bg text-critical" },
  { value: "REQUEST_MORE_EVIDENCE", label: "Request more evidence", tone: "border-medium-border bg-medium-bg text-medium" },
  { value: "DISMISS", label: "Dismiss", tone: "border-border bg-panel-raised text-ink-muted" },
];

export default function AuditorDecisionPanel({ existingDecision, existingReason, busy, onDecide }) {
  const [reason, setReason] = useState("");

  if (existingDecision) {
    return (
      <div className="rounded-lg border border-low-border bg-low-bg p-4">
        <div className="text-sm font-semibold text-low">✓ Decision recorded: {existingDecision.replace(/_/g, " ")}</div>
        {existingReason && <div className="mt-1.5 text-xs text-ink-muted">Rationale: {existingReason}</div>}
        <div className="mt-1 text-2xs text-ink-faint">Audit event created.</div>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-panel p-4">
      <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">Auditor Decision</div>
      <input
        value={reason}
        onChange={(e) => setReason(e.target.value)}
        placeholder="Decision rationale (optional)…"
        className="mt-2.5 w-full rounded-md border border-border bg-base px-3 py-2 text-xs text-ink placeholder:text-ink-faint focus:border-accent"
      />
      <div className="mt-3 flex flex-wrap gap-2">
        {ACTIONS.map((a) => (
          <button
            key={a.value}
            disabled={busy}
            onClick={() => onDecide(a.value, reason)}
            className={`rounded-md border px-3 py-1.5 text-xs font-semibold disabled:opacity-50 ${a.tone}`}
          >
            {a.label}
          </button>
        ))}
      </div>
    </div>
  );
}
