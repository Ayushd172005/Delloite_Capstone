import { Link } from "react-router-dom";

const EVENT_COPY = {
  model_scored: { label: "Risk Alert", tone: "text-ink-muted" },
  investigated: { label: "AI Investigation", tone: "text-link" },
  decision: { label: "Auditor Decision", tone: "text-low" },
  override: { label: "Decision Overridden", tone: "text-medium" },
};

function summarize(event) {
  let payload = {};
  try {
    payload = JSON.parse(event.payload_json);
  } catch {
    /* leave empty */
  }
  if (event.event_type === "model_scored") {
    return `Score ${payload.composite_score?.toFixed?.(1) ?? payload.composite_score} · ${(payload.review_tier || "").replace(/_/g, " ")}`;
  }
  if (event.event_type === "investigated") {
    return `Evidence sufficiency: ${payload.evidence_sufficiency || "—"}`;
  }
  if (event.event_type === "decision" || event.event_type === "override") {
    return `${payload.action}${payload.reason ? ` — ${payload.reason}` : ""}`;
  }
  return "";
}

export default function AuditTimeline({ events }) {
  return (
    <ol className="space-y-0">
      {events.map((e, i) => {
        const cfg = EVENT_COPY[e.event_type] || { label: e.event_type, tone: "text-ink-muted" };
        return (
          <li key={e.event_id ?? i} className="relative border-l border-border pb-5 pl-5 last:pb-0">
            <span className={`absolute -left-[3.5px] top-1 h-1.5 w-1.5 rounded-full bg-current ${cfg.tone}`} />
            <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
              <span className={`text-xs font-semibold ${cfg.tone}`}>{cfg.label}</span>
              <Link to={`/investigation/${e.transaction_id}`} className="font-mono text-2xs text-ink-faint hover:text-link">
                {e.transaction_id}
              </Link>
              <span className="text-2xs text-ink-faint">by {e.actor}</span>
              <span className="ml-auto font-mono text-2xs text-ink-faint">
                {new Date(e.timestamp).toLocaleString()}
              </span>
            </div>
            <div className="mt-0.5 text-2xs text-ink-muted">{summarize(e)}</div>
          </li>
        );
      })}
    </ol>
  );
}
