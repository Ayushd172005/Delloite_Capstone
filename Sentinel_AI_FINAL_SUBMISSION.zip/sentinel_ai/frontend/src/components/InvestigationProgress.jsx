// A single deterministic label, not a fake asynchronous multi-step
// simulation - the real /investigate call is one blocking POST (see app.py),
// so pretending there are separately-timed backend stages would misrepresent
// how the system actually works (spec item 36: "do not fake progress if the
// backend is actually synchronous").
export default function InvestigationProgress() {
  return (
    <div className="rounded-lg border border-border bg-panel p-4">
      <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">
        Investigation in progress
      </div>
      <div className="mt-2 flex items-center gap-2 text-xs text-ink-muted">
        <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
        Retrieving evidence and generating findings…
      </div>
    </div>
  );
}
