export function SkeletonLine({ className = "" }) {
  return <div className={`animate-pulse rounded bg-panel-raised ${className}`} />;
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-4 border-b border-border px-4 py-3">
      <SkeletonLine className="h-4 w-16" />
      <SkeletonLine className="h-4 w-28" />
      <SkeletonLine className="h-4 w-20" />
      <SkeletonLine className="h-4 flex-1" />
      <SkeletonLine className="h-4 w-16" />
    </div>
  );
}

export function SkeletonQueue({ rows = 8 }) {
  return (
    <div>
      {Array.from({ length: rows }).map((_, i) => (
        <SkeletonRow key={i} />
      ))}
    </div>
  );
}
