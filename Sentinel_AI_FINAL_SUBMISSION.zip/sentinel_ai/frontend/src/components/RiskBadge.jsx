const LEVELS = {
  LOW: { label: "Low", text: "text-low", bg: "bg-low-bg", border: "border-low-border" },
  MEDIUM: { label: "Medium", text: "text-medium", bg: "bg-medium-bg", border: "border-medium-border" },
  HIGH: { label: "High", text: "text-high", bg: "bg-high-bg", border: "border-high-border" },
  CRITICAL: { label: "Critical", text: "text-critical", bg: "bg-critical-bg", border: "border-critical-border" },
};

const TIER_TO_LEVEL = {
  standard_review: "LOW",
  priority_review: "MEDIUM",
  immediate_escalation: "HIGH",
};

// Accepts either a risk_level ("HIGH") or a review_tier ("priority_review") -
// the two endpoints in the real API use different vocabularies for the same
// concept, so this badge normalizes rather than every caller doing it.
export default function RiskBadge({ level, tier, score, size = "md" }) {
  const resolved = level || TIER_TO_LEVEL[tier] || "LOW";
  const cfg = LEVELS[resolved] || LEVELS.LOW;
  const pad = size === "sm" ? "px-1.5 py-0.5 text-2xs" : "px-2 py-1 text-xs";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded border ${cfg.bg} ${cfg.border} ${cfg.text} ${pad} font-semibold uppercase tracking-wide`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${cfg.text.replace("text-", "bg-")}`} />
      {cfg.label}
      {score != null && <span className="font-mono font-normal opacity-80">{Math.round(score)}</span>}
    </span>
  );
}
