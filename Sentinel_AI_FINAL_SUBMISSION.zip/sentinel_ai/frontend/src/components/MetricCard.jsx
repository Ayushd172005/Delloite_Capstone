export default function MetricCard({ label, value, hint, isMock }) {
  return (
    <div className="rounded-lg border border-border bg-panel px-4 py-3">
      <div className="flex items-center gap-1.5 text-2xs uppercase tracking-wide text-ink-faint">
        {label}
        {isMock && <span className="rounded bg-medium-bg px-1 text-medium normal-case">mock</span>}
      </div>
      <div className="mt-1 font-mono text-xl font-semibold text-ink">{value}</div>
      {hint && <div className="mt-0.5 text-2xs text-ink-faint">{hint}</div>}
    </div>
  );
}
