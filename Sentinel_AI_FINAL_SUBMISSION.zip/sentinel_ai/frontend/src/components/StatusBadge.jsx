const STATUS = {
  ACCEPT: { label: "Accepted", text: "text-low", bg: "bg-low-bg", border: "border-low-border" },
  ESCALATE: { label: "Escalated", text: "text-critical", bg: "bg-critical-bg", border: "border-critical-border" },
  DISMISS: { label: "Dismissed", text: "text-ink-muted", bg: "bg-panel-raised", border: "border-border" },
  REQUEST_MORE_EVIDENCE: { label: "Needs evidence", text: "text-medium", bg: "bg-medium-bg", border: "border-medium-border" },
  OVERRIDE: { label: "Overridden", text: "text-link", bg: "bg-link-bg", border: "border-border-strong" },
  PENDING: { label: "Pending", text: "text-ink-faint", bg: "bg-panel-raised", border: "border-border" },
};

export default function StatusBadge({ status }) {
  const cfg = STATUS[status] || STATUS.PENDING;
  return (
    <span className={`inline-flex items-center rounded px-1.5 py-0.5 text-2xs font-medium ${cfg.bg} ${cfg.text} border ${cfg.border}`}>
      {cfg.label}
    </span>
  );
}
