const ACTION_COPY = {
  ACCEPT: { label: "Accept — no further action recommended", tone: "text-low" },
  ESCALATE: { label: "Escalate for manual review", tone: "text-critical" },
  DISMISS: { label: "Dismiss — evidence contradicts the flag", tone: "text-ink-muted" },
  REQUEST_MORE_EVIDENCE: { label: "Request more evidence before deciding", tone: "text-medium" },
};

export default function RecommendationCard({ investigation }) {
  const cfg = ACTION_COPY[investigation.recommended_action] || ACTION_COPY.REQUEST_MORE_EVIDENCE;
  return (
    <div className="rounded-lg border border-border-strong bg-panel-raised p-4">
      <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">
        AI Recommended Action
      </div>
      <div className={`mt-1 text-sm font-semibold ${cfg.tone}`}>{cfg.label}</div>
      <p className="mt-2 text-xs leading-relaxed text-ink-muted">{investigation.finding}</p>

      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-2xs">
        <span
          className={
            investigation.evidence_sufficiency === "SUFFICIENT"
              ? "font-medium text-low"
              : "font-medium text-medium"
          }
        >
          {investigation.evidence_sufficiency === "SUFFICIENT" ? "✓ Evidence sufficient" : "⚠ Evidence insufficient"}
        </span>
        <span className="text-ink-faint">
          Investigation confidence <span className="font-mono text-ink">{Math.round(investigation.confidence * 100)}%</span>
        </span>
      </div>
      <div className="mt-1.5 text-2xs italic text-ink-faint">
        Confidence reflects evidence sufficiency and internal consistency — it is not a
        calibrated probability that fraud occurred.
      </div>
      <div className="mt-3 border-t border-border pt-2.5 text-2xs text-ink-faint">
        The final decision remains with the auditor.
      </div>
    </div>
  );
}
