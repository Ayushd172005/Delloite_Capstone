export default function SignalBar({ label, value, hint }) {
  const pct = Math.max(0, Math.min(100, Math.round((value || 0) * 100)));
  return (
    <div className="mb-2.5 last:mb-0">
      <div className="mb-1 flex items-baseline justify-between font-mono text-2xs text-ink-faint">
        <span className="font-sans">{label}</span>
        <span>{(value || 0).toFixed(3)}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-border">
        <div
          className="h-full rounded-full bg-accent transition-[width] duration-500 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>
      {hint && <div className="mt-1 text-2xs italic text-ink-faint">{hint}</div>}
    </div>
  );
}
