// Human-readable labels for the *real* rule flags the risk engine emits
// (see rules.py / network.py). No invented use-case taxonomy - every label
// here maps 1:1 to an actual flag_* column so nothing on screen claims a
// signal that isn't really in the data.
const RULE_LABELS = {
  just_under_limit: "Near-Threshold Structuring",
  round_number: "Round-Number Amount",
  velocity_spike: "Velocity Spike",
  new_counterparty_high_value: "New Counterparty + High Value",
  balance_depletion: "Balance Depletion",
  off_hours_weekend: "Off-Hours / Weekend Activity",
  dormant_reactivation: "Dormant Account Reactivation",
  shared_device: "Shared Device Network",
  hub_counterparty: "Fan-In / Fan-Out Counterparty",
};

export function ruleLabel(flag) {
  return RULE_LABELS[flag] || flag.replace(/_/g, " ");
}

export default function UseCaseBadge({ flag, size = "sm" }) {
  const pad = size === "sm" ? "px-1.5 py-0.5 text-2xs" : "px-2 py-1 text-xs";
  return (
    <span className={`inline-block rounded bg-link-bg text-link border border-border-strong ${pad} font-medium whitespace-nowrap`}>
      {ruleLabel(flag)}
    </span>
  );
}
