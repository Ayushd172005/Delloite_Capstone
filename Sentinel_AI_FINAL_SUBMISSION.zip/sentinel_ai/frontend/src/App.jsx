import { Routes, Route } from "react-router-dom";
import { SystemStatusProvider } from "./context/SystemStatusContext";
import AppShell from "./layout/AppShell";
import RiskQueue from "./pages/RiskQueue";
import Investigation from "./pages/Investigation";
import AuditTrail from "./pages/AuditTrail";

export default function App() {
  return (
    <SystemStatusProvider>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<RiskQueue />} />
          <Route path="/investigation/:transactionId" element={<Investigation />} />
          <Route path="/audit-trail" element={<AuditTrail />} />
        </Route>
      </Routes>
    </SystemStatusProvider>
  );
}
