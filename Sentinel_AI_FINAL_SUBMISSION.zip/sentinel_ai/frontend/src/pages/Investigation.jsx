import { useState, useEffect, useCallback } from "react";
import { useParams, useLocation, useNavigate, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { getCase, getQueue } from "../api/transactions";
import { investigateTransaction, submitAuditorDecision } from "../api/investigations";
import { getAuditTrail } from "../api/audit";
import RiskBadge from "../components/RiskBadge";
import UseCaseBadge, { ruleLabel } from "../components/UseCaseBadge";
import MentorUseCaseBadge from "../components/MentorUseCaseBadge";
import SignalBar from "../components/SignalBar";
import { SupportingEvidencePanel, CounterEvidencePanel } from "../components/EvidencePanel";
import RecommendationCard from "../components/RecommendationCard";
import AuditorDecisionPanel from "../components/AuditorDecisionPanel";
import InvestigationProgress from "../components/InvestigationProgress";
import ErrorState from "../components/ErrorState";
import { SkeletonLine } from "../components/Skeleton";

function fmtMoney(n) {
  return "₹" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });
}

export default function Investigation() {
  const { transactionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const [queueRow, setQueueRow] = useState(location.state?.row || null);
  const [detail, setDetail] = useState(null);
  const [trail, setTrail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [investigating, setInvestigating] = useState(false);
  const [deciding, setDeciding] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await getCase(transactionId);
      setDetail(d);
      if (!queueRow) {
        // /case doesn't return amount/vertical (see app.py) - fall back to
        // the queue listing for those fields if the row wasn't passed via nav.
        const q = await getQueue({ limit: 200 });
        setQueueRow(q.find((r) => r.transaction_id === transactionId) || null);
      }
      if (d.case?.auditor_decision) {
        setTrail(await getAuditTrail(transactionId));
      }
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transactionId]);

  useEffect(() => {
    load();
  }, [load]);

  async function runInvestigation() {
    setInvestigating(true);
    try {
      await investigateTransaction(transactionId);
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setInvestigating(false);
    }
  }

  async function handleDecide(action, reason) {
    setDeciding(true);
    try {
      await submitAuditorDecision(transactionId, { auditor: "dashboard_user", action, reason });
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setDeciding(false);
    }
  }

  if (loading) {
    return (
      <div className="max-w-3xl px-6 py-6">
        <SkeletonLine className="h-4 w-40" />
        <SkeletonLine className="mt-4 h-8 w-64" />
        <SkeletonLine className="mt-6 h-40 w-full" />
      </div>
    );
  }

  if (error && !detail) {
    return (
      <div className="max-w-3xl px-6 py-6">
        <ErrorState title="Unable to load investigation" message={error} onRetry={load} />
      </div>
    );
  }

  const { signals, investigation, case: caseRow } = detail;

  return (
    <div className="mx-auto max-w-3xl px-6 py-6">
      <Link to="/" className="flex items-center gap-1.5 text-xs text-ink-faint hover:text-ink-muted">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Risk Queue
      </Link>

      <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-mono text-xs text-ink-faint">{transactionId}</div>
          <div className="mt-1 flex items-center gap-3">
            <RiskBadge tier={signals.review_tier} level={investigation?.risk_level} score={signals.composite_score} />
            <span className="text-2xs capitalize text-ink-faint">{signals.review_tier.replace(/_/g, " ")}</span>
          </div>
          {signals.use_case && (
            <div className="mt-2">
              <div className="mb-1 text-2xs font-semibold uppercase tracking-wide text-ink-faint">
                Mentor-Aligned Use Case
              </div>
              <div className="flex flex-wrap gap-1.5">
                <MentorUseCaseBadge useCase={signals.use_case} size="md" />
              </div>
              {signals.use_case_reasons?.length > 0 && (
                <ul className="mt-1.5 space-y-0.5">
                  {signals.use_case_reasons.map((reason, i) => (
                    <li key={i} className="text-2xs text-ink-faint">
                      • {reason}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
        {signals.rules_triggered.length > 0 && (
          <div className="flex flex-wrap justify-end gap-1.5">
            {signals.rules_triggered.map((f) => (
              <UseCaseBadge key={f} flag={f} />
            ))}
          </div>
        )}
      </div>

      {error && (
        <div className="mt-4">
          <ErrorState title="Something went wrong" message={error} onRetry={load} />
        </div>
      )}

      {/* Transaction summary — only fields the API actually returns */}
      <div className="mt-5 rounded-lg border border-border bg-panel p-4">
        <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">Transaction Details</div>
        <div className="mt-2.5 grid grid-cols-2 gap-x-6 gap-y-2 text-xs sm:grid-cols-4">
          <div>
            <div className="text-2xs text-ink-faint">Amount</div>
            <div className="mt-0.5 font-mono text-ink">{queueRow ? fmtMoney(queueRow.amount) : "—"}</div>
          </div>
          <div>
            <div className="text-2xs text-ink-faint">Vertical</div>
            <div className="mt-0.5 capitalize text-ink">{queueRow?.vertical || "—"}</div>
          </div>
          <div>
            <div className="text-2xs text-ink-faint">Composite Score</div>
            <div className="mt-0.5 font-mono text-ink">{signals.composite_score.toFixed(1)} / 100</div>
          </div>
          <div>
            <div className="text-2xs text-ink-faint">Benford Flag</div>
            <div className="mt-0.5 text-ink">{signals.benford_flag ? "Yes" : "No"}</div>
          </div>
        </div>
      </div>

      {/* Why was this flagged */}
      <div className="mt-4 rounded-lg border border-border bg-panel p-4">
        <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">Why Was This Flagged?</div>
        <div className="mt-3">
          <SignalBar label="Isolation forest (behavioral anomaly)" value={signals.isoforest_score} />
          <SignalBar label="Autoencoder reconstruction error" value={signals.autoencoder_score} />
        </div>
        {signals.rules_triggered.length > 0 && (
          <div className="mt-1 text-2xs text-ink-faint">
            Rule signals: {signals.rules_triggered.map(ruleLabel).join(", ")}
          </div>
        )}
      </div>

      {/* AI-assisted investigation */}
      <div className="mt-4">
        {!investigation && !investigating && (
          <button
            onClick={runInvestigation}
            className="rounded-md border border-link-bg bg-link-bg px-4 py-2 text-xs font-semibold text-link hover:brightness-110"
          >
            Run AI-assisted investigation
          </button>
        )}
        {investigating && <InvestigationProgress />}

        {investigation && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-2xs font-semibold uppercase tracking-wide text-ink-faint">
              AI-Assisted Investigation
              <span className="flex items-center gap-1 rounded bg-low-bg px-1.5 py-0.5 text-low normal-case">
                <span className="h-1.5 w-1.5 rounded-full bg-low" /> Evidence-grounded
              </span>
            </div>
            <SupportingEvidencePanel items={investigation.supporting_evidence} />
            <CounterEvidencePanel items={investigation.counter_evidence} />
            <RecommendationCard investigation={investigation} />
            <AuditorDecisionPanel
              existingDecision={caseRow?.auditor_decision}
              existingReason={caseRow?.auditor_reason}
              busy={deciding}
              onDecide={handleDecide}
            />

            {trail && trail.length > 0 && (
              <div className="rounded-lg border border-border bg-panel p-4">
                <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">Audit Trail</div>
                <div className="mt-2 space-y-2">
                  {trail.slice(-3).map((e) => (
                    <div key={e.event_id} className="text-2xs text-ink-muted">
                      <span className="mr-2 font-mono text-ink-faint">
                        {new Date(e.timestamp).toLocaleTimeString()}
                      </span>
                      {e.event_type.replace(/_/g, " ")} — {e.actor}
                    </div>
                  ))}
                </div>
                <Link to="/audit-trail" className="mt-2 inline-block text-2xs text-link hover:underline">
                  View full audit trail →
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
