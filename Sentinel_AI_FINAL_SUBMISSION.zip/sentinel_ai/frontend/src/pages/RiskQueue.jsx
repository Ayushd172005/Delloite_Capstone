import { useState, useEffect, useCallback, useMemo } from "react";
import { getQueue } from "../api/transactions";
import { useSystemStatus } from "../context/SystemStatusContext";
import FilterBar from "../components/FilterBar";
import TransactionTable from "../components/TransactionTable";
import MetricCard from "../components/MetricCard";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { SkeletonQueue } from "../components/Skeleton";

export default function RiskQueue() {
  const { isMock, status: systemStatus } = useSystemStatus();
  const [rows, setRows] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const [search, setSearch] = useState("");
  const [vertical, setVertical] = useState(null);
  const [tier, setTier] = useState(null);

  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      const data = await getQueue({ vertical, tier, limit: 100 });
      setRows(data);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [vertical, tier]);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    if (!rows) return [];
    if (!search.trim()) return rows;
    const q = search.trim().toLowerCase();
    return rows.filter((r) => r.transaction_id.toLowerCase().includes(q));
  }, [rows, search]);

  const kpis = useMemo(() => {
    if (!rows) return null;
    const flagged = rows.length;
    const highRisk = rows.filter((r) => r.review_tier === "immediate_escalation").length;
    const priority = rows.filter((r) => r.review_tier === "priority_review").length;
    const decided = rows.filter((r) => r.auditor_decision).length;
    return { flagged, highRisk, priority, decided };
  }, [rows]);

  return (
    <div>
      <div className="px-6 pt-6">
        <h1 className="text-lg font-semibold text-ink">Risk Queue</h1>
        <p className="mt-0.5 text-xs text-ink-faint">
          Prioritized transactions requiring auditor attention.
        </p>
      </div>

      {kpis && (
        <div className="grid grid-cols-2 gap-3 px-6 pt-4 sm:grid-cols-4">
          <MetricCard label="In queue" value={kpis.flagged.toLocaleString("en-IN")} isMock={isMock} />
          <MetricCard label="Escalation tier" value={kpis.highRisk.toLocaleString("en-IN")} isMock={isMock} />
          <MetricCard label="Priority tier" value={kpis.priority.toLocaleString("en-IN")} isMock={isMock} />
          <MetricCard label="Decided" value={kpis.decided.toLocaleString("en-IN")} isMock={isMock} />
        </div>
      )}

      <div className="mt-4">
        <FilterBar
          search={search}
          onSearch={setSearch}
          vertical={vertical}
          onVertical={setVertical}
          tier={tier}
          onTier={setTier}
          onRefresh={load}
          refreshing={refreshing}
        />
      </div>

      <div className="px-6 py-4">
        {loading && <SkeletonQueue />}
        {!loading && error && (
          <ErrorState
            title="Unable to load the risk queue"
            message={`The Sentinel backend could not be reached: ${error}`}
            onRetry={load}
          />
        )}
        {!loading && !error && filtered.length === 0 && (
          <EmptyState
            title="No transactions match your filters."
            description="Try adjusting your vertical, tier, or search term."
          />
        )}
        {!loading && !error && filtered.length > 0 && (
          <div className="overflow-hidden rounded-lg border border-border">
            <TransactionTable rows={filtered} />
          </div>
        )}
      </div>
    </div>
  );
}
