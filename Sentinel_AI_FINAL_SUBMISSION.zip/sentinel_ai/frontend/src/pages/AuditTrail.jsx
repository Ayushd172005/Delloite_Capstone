import { useState, useEffect, useCallback, useMemo } from "react";
import { getGlobalAuditFeed } from "../api/audit";
import AuditTimeline from "../components/AuditTimeline";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { SkeletonLine } from "../components/Skeleton";

const ACTION_FILTERS = [
  { value: "model_scored", label: "Risk Alerts" },
  { value: "investigated", label: "Investigations" },
  { value: "decision", label: "Decisions" },
  { value: "override", label: "Overrides" },
];

export default function AuditTrail() {
  const [events, setEvents] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionFilter, setActionFilter] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getGlobalAuditFeed({ limit: 100 });
      setEvents(data);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    if (!events) return [];
    if (!actionFilter) return events;
    return events.filter((e) => e.event_type === actionFilter);
  }, [events, actionFilter]);

  return (
    <div className="mx-auto max-w-3xl px-6 py-6">
      <h1 className="text-lg font-semibold text-ink">Audit Trail</h1>
      <p className="mt-0.5 text-xs text-ink-faint">
        Complete record of investigations and auditor decisions.
      </p>

      <div className="mt-4 rounded-lg border border-border bg-panel px-4 py-3 text-2xs text-ink-faint">
        <span className="font-semibold text-ink-muted">Audit integrity — </span>
        Backend verification unavailable. This system does not currently expose a
        hash-chain check, so no integrity claim is shown here.
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        <button
          onClick={() => setActionFilter(null)}
          className={`rounded-md px-2.5 py-1 text-xs font-medium ${
            !actionFilter ? "bg-panel-raised text-ink border border-border-strong" : "text-ink-faint hover:text-ink-muted"
          }`}
        >
          All events
        </button>
        {ACTION_FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setActionFilter(f.value)}
            className={`rounded-md px-2.5 py-1 text-xs font-medium ${
              actionFilter === f.value
                ? "bg-panel-raised text-ink border border-border-strong"
                : "text-ink-faint hover:text-ink-muted"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {loading && (
          <div className="space-y-3">
            <SkeletonLine className="h-10 w-full" />
            <SkeletonLine className="h-10 w-full" />
            <SkeletonLine className="h-10 w-full" />
          </div>
        )}
        {!loading && error && (
          <ErrorState title="Unable to load the audit trail" message={error} onRetry={load} />
        )}
        {!loading && !error && filtered.length === 0 && (
          <EmptyState title="No audit events found." description="Investigate and decide on a case from the Risk Queue to see events here." />
        )}
        {!loading && !error && filtered.length > 0 && <AuditTimeline events={filtered} />}
      </div>
    </div>
  );
}
