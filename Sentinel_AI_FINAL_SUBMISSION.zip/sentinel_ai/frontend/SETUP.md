# Sentinel AI Frontend — Setup

This replaces the previous single-file `SentinelDashboard.jsx` with the full
three-page auditor console (Risk Queue / Investigation / Audit Trail) from
the master frontend prompt, built against your existing FastAPI backend
contract — no backend, ML, or agent code was touched.

## Run it

```bash
cd frontend
npm install
npm run dev
```

Then in another terminal, from the repo root:

```bash
uvicorn app:app --reload
```

By default the app points at `http://localhost:8000` (see `.env.example`).
Copy `.env.example` to `.env` if you need to change the API URL, or to run
in `VITE_USE_MOCK_DATA=true` mode with no backend at all (useful for
frontend-only iteration — never use this for the actual demo).

## What changed vs. the old dashboard

- `SentinelDashboard.jsx` (one 400-line file) → proper `pages/`,
  `components/`, `layout/`, `api/`, `context/`, `mocks/` structure.
- React Router: `/` (Risk Queue), `/investigation/:transactionId`,
  `/audit-trail`.
- Tailwind CSS (was inline styles) using the same dark-navy/gold palette
  you'd already established, now as a proper token system in
  `tailwind.config.js`.
- Global Audit Trail page: your API only exposes a per-transaction
  `/audit_trail/{id}`, so this aggregates real per-transaction trails
  client-side (queue → each case's trail → merge/sort) rather than adding a
  new backend endpoint to a frozen codebase.
- "Use case" badges are labeled from your actual `flag_*` rule columns
  (`rules.py` / `network.py`), not invented category names — e.g.
  `hub_counterparty` → "Fan-In / Fan-Out Counterparty".
- Mock-data mode behind `VITE_USE_MOCK_DATA` so the UI is buildable/demoable
  even if the backend isn't running, without ever silently showing fake data
  as if it were real (mock mode is visibly labeled in the UI).

## Verified

- `npm run build` — clean, no errors.
- Full flow tested against your live backend directly (health → queue →
  case → investigate → decision → audit trail) — every field the frontend
  consumes matches the live API response.

One note: that live test recorded a real test decision
(`REQUEST_MORE_EVIDENCE`) on transaction `TRF_A9C62B92707E` in the copy of
`sentinel.db` bundled in this package. Delete `sentinel.db` and rerun
`populate_db.py` first if you want a clean database for your actual demo.
