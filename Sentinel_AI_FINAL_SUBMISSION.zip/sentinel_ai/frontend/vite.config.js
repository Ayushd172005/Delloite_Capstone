import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Minimal Vite config - no unnecessary plugins or complexity.
// Dev server on :5173 by default; the dashboard's API_BASE (in
// SentinelDashboard.jsx) points at the FastAPI backend on :8000 separately -
// this is a plain static-frontend + separate-API setup, not a proxy setup,
// to keep the two processes independently startable per the README.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
