/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        base: "#0b0f1a",
        panel: "#0f1524",
        "panel-raised": "#141b2e",
        border: "#1c2434",
        "border-strong": "#232d42",
        ink: "#e6e9ef",
        "ink-muted": "#9aa4b8",
        "ink-faint": "#6b7690",
        accent: "#c9a961",
        "accent-soft": "#241f10",
        low: "#5fb88a",
        "low-bg": "#12241c",
        "low-border": "#1f4032",
        medium: "#f2a93c",
        "medium-bg": "#241f10",
        "medium-border": "#3a2a12",
        high: "#e8793a",
        "high-bg": "#2a1b10",
        "high-border": "#3a2412",
        critical: "#e8536b",
        "critical-bg": "#2a1418",
        "critical-border": "#3a1414",
        link: "#8fb4ff",
        "link-bg": "#1f2a44",
      },
      fontFamily: {
        sans: ["Inter", "-apple-system", "BlinkMacSystemFont", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"],
      },
      fontSize: {
        "2xs": "0.6875rem",
      },
      boxShadow: {
        panel: "0 1px 2px rgba(0,0,0,0.4)",
      },
    },
  },
  plugins: [],
};
