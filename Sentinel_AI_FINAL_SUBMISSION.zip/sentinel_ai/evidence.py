"""
Sentinel AI v2 - structured synthetic evidence generator.

The raw datasets have no document text at all. This fabricates structured evidence
records per transaction so retrieval + the investigation agent have something concrete
to work with. CLEARLY SYNTHETIC - every record is tagged source_system="SENTINEL_SYNTH"
and this must never be presented as real enterprise evidence.

Includes an "approval_record" source_type for a fraction of transactions, specifically
so the counter-evidence path (agent.py) has real material to work with: a transaction
that looks anomalous by amount/novelty but has a matching prior approval record is the
canonical "supporting evidence vs. counter-evidence" case from the master prompt.
"""
import pandas as pd
import numpy as np

rng = np.random.default_rng(42)

CORPORATE_DESCRIPTIONS = [
    "Invoice payment for consulting services rendered", "Invoice payment for office supplies",
    "Invoice payment for IT equipment and licenses", "Invoice payment for facilities maintenance",
    "Invoice payment for marketing/advertising services", "Invoice payment for logistics and freight",
    "Invoice payment for professional/legal services", "Invoice payment for raw materials procurement",
]
AML_PURPOSES = [
    "Trade settlement - goods shipment", "Family remittance", "Consulting fee payment",
    "Investment fund transfer", "Property purchase settlement", "Business loan repayment",
    "Charitable donation transfer", "Equipment import payment",
]
RETAIL_NOTES = {
    "Purchase": ["Retail purchase - electronics", "Retail purchase - groceries", "Retail purchase - apparel",
                 "Online purchase - marketplace", "Retail purchase - dining"],
    "Withdrawal": ["ATM cash withdrawal", "Branch cash withdrawal"],
    "Transfer": ["Peer-to-peer transfer", "Bill payment transfer", "Savings sweep transfer"],
}
DEPARTMENTS = {"corporate": "Accounts Payable", "aml": "Treasury/Correspondent Banking", "retail": "Card Operations"}

# fraction of transactions that get a matching approval record generated alongside the
# primary evidence doc - deliberately independent of fraud_label, so some anomalous-
# looking transactions have real counter-evidence and some don't (realistic: not every
# large transaction has a paper trail, and not every one that has an anomaly is fraud)
APPROVAL_RECORD_RATE = 0.35

def _primary_text(row):
    v = row["vertical"]
    if v == "corporate":
        desc = rng.choice(CORPORATE_DESCRIPTIONS)
        return (f"Vendor {row['counterparty_id']} invoice, GL account {row['account_id']}, "
                f"amount {row['amount']:.2f}. {desc}.")
    elif v == "aml":
        purpose = rng.choice(AML_PURPOSES)
        return (f"International wire via {row['account_id']} to beneficiary "
                f"{row['counterparty_id']}, amount {row['amount']:.2f}. Stated purpose: {purpose}.")
    else:
        note = rng.choice(RETAIL_NOTES.get(row["transaction_type"], ["Retail transaction"]))
        return (f"{row['payment_method']} transaction at {row['counterparty_id']}, "
                f"location {row['location']}, amount {row['amount']:.2f}. {note}.")

def generate_structured_evidence(df):
    """Returns a long-form evidence dataframe: possibly multiple documents per transaction."""
    df = df.copy()
    records = []
    doc_counter = 0
    for _, row in df.iterrows():
        primary_text = _primary_text(row)
        doc_counter += 1
        records.append({
            "document_id": f"DOC_{doc_counter:07d}",
            "transaction_id": row["transaction_id"],
            "source_type": {"corporate": "invoice", "aml": "payment_record", "retail": "payment_record"}[row["vertical"]],
            "source_system": "SENTINEL_SYNTH",
            "created_at": row["transaction_time"],
            "author": f"system_{row['vertical']}",
            "department": DEPARTMENTS[row["vertical"]],
            "text": primary_text,
            "metadata": {"amount": float(row["amount"]), "account_id": row["account_id"],
                         "counterparty_id": row["counterparty_id"]},
        })
        if rng.random() < APPROVAL_RECORD_RATE:
            doc_counter += 1
            records.append({
                "document_id": f"DOC_{doc_counter:07d}",
                "transaction_id": row["transaction_id"],
                "source_type": "approval_record",
                "source_system": "SENTINEL_SYNTH",
                "created_at": row["transaction_time"] - pd.Timedelta(days=int(rng.integers(1, 10))),
                "author": f"approver_{rng.integers(1, 50)}",
                "department": DEPARTMENTS[row["vertical"]],
                "text": (f"Approval on file for transaction to {row['counterparty_id']}, "
                         f"amount {row['amount']:.2f}, approved prior to execution."),
                "metadata": {"amount": float(row["amount"]), "counterparty_id": row["counterparty_id"]},
            })
    return pd.DataFrame(records)

if __name__ == "__main__":
    scored = pd.read_parquet("scored_transactions.parquet")
    flagged = scored[scored["review_tier"] != "auto_clear"].copy()
    evidence_df = generate_structured_evidence(flagged)
    evidence_df.to_parquet("evidence_documents.parquet", index=False)
    print(f"Generated {len(evidence_df)} evidence documents for {len(flagged)} flagged transactions")
    print(evidence_df["source_type"].value_counts())
