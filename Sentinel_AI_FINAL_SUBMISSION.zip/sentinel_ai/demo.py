"""
Sentinel AI v2 - demo mode.

Produces 3 deterministic cases end-to-end (real data, real scores, real retrieval,
real agent output - nothing scripted/faked):

  CASE 1: Strong behavioral anomaly (high ML score, no counter-evidence found)
  CASE 2: Policy/threshold anomaly (rule-engine driven, e.g. round-number / velocity)
  CASE 3: False positive - the agent finds real counter-evidence (a matching approval
          record), and an auditor decision to DISMISS is recorded and persisted -
          this case is mandatory per the master prompt and demonstrates the
          human-in-the-loop + counter-evidence workflow together.

Tells the full story: transactions -> queue -> case -> risk signals -> evidence ->
agent investigation -> supporting/counter-evidence -> auditor decision -> audit trail.
"""
import pandas as pd
import json
import db
from retrieval import EvidenceStore
from agent import SentinelTools, deterministic_investigate

def find_case_1(scored, tools):
    """Strong behavioral anomaly: high composite score, no rule triggers, no counter-evidence."""
    candidates = scored[
        (scored["review_tier"] == "immediate_escalation") & (scored["rule_flag_count"] == 0)
    ].sort_values("composite_score", ascending=False)
    for tid in candidates["transaction_id"].head(20):
        inv = deterministic_investigate(tid, tools)
        if not inv.counter_evidence:
            return tid, inv
    return candidates.iloc[0]["transaction_id"], deterministic_investigate(candidates.iloc[0]["transaction_id"], tools)

def find_case_2(scored, tools):
    """Policy/threshold anomaly: rule-driven flag (e.g. round number / just-under-limit) with a
    modest ML score, where the agent itself still recommends action (not a case it already
    dismisses) - so the auditor's ACCEPT decision below is a consistent story."""
    candidates = scored[
        (scored["review_tier"].isin(["standard_review", "priority_review"])) &
        (scored["rule_flag_count"] >= 2) & (scored["isoforest_score"] < 0.6)
    ].sort_values("rule_flag_count", ascending=False)
    for tid in candidates["transaction_id"].head(30):
        inv = deterministic_investigate(tid, tools)
        if inv.recommended_action in ("ESCALATE", "REQUEST_MORE_EVIDENCE") and not inv.counter_evidence:
            return tid, inv
    # fallback: first candidate regardless, rather than error out
    tid = candidates.iloc[0]["transaction_id"]
    return tid, deterministic_investigate(tid, tools)

def find_case_3(scored, tools):
    """False positive: flagged, but the agent finds a matching approval record (counter-evidence)."""
    candidates = scored[scored["review_tier"] != "auto_clear"].sort_values("composite_score", ascending=False)
    for tid in candidates["transaction_id"].head(200):
        inv = deterministic_investigate(tid, tools)
        if inv.counter_evidence:
            return tid, inv
    raise RuntimeError("No counter-evidence case found in top 200 flagged transactions - "
                        "check evidence.py's APPROVAL_RECORD_RATE")


# ---------------------------------------------------------------------------
# Mentor-aligned business use case demo selection (Section 22-23 of the governing
# prompt): deterministic (highest-risk transaction satisfying the use-case condition),
# using real transactions only - no fabricated demo data.
# ---------------------------------------------------------------------------

def find_mentor_usecase_demo(scored, tools, column, condition_desc):
    """Highest composite_score transaction matching a use-case boolean/enum column.
    Returns (None, None) if genuinely no transaction in this dataset satisfies it -
    this is reported honestly rather than fabricated (see use_cases.py's documented
    limitations: e.g. UC3 only fires in AML in this dataset)."""
    if column not in scored.columns:
        return None, None
    candidates = scored[scored[column] != 0] if scored[column].dtype != bool else scored[scored[column]]
    if len(candidates) == 0:
        return None, None
    candidates = candidates.sort_values("composite_score", ascending=False)
    tid = candidates.iloc[0]["transaction_id"]
    inv = deterministic_investigate(tid, tools)
    return tid, inv


def run_mentor_usecase_demos(scored, tools, conn):
    print(f"\n{'='*70}\nMENTOR-ALIGNED BUSINESS USE CASES (real transactions, not fabricated)\n{'='*70}")
    results = {}

    print("\n--- MENTOR USE CASE 1: New Device + High-Value Transaction ---")
    tid, inv = find_mentor_usecase_demo(scored, tools, "uc_new_device_high_value", "new device + high value")
    if tid:
        db.upsert_investigation_and_case(conn, tid, inv.model_dump(), "v2.0-demo")
        conn.commit()
        row = scored[scored["transaction_id"] == tid].iloc[0]
        print(f"Transaction: {tid} ({row['vertical']})")
        print(f"Use case: {row['use_case']}")
        print(f"Reasons: {list(row['use_case_reasons'])}")
        print(f"Risk: {inv.risk_level} ({inv.risk_score:.1f}/100), action: {inv.recommended_action}")
        results["mentor_uc1_new_device_high_value"] = tid
    else:
        print("No transaction in this dataset triggers this use case (see use_cases.py docstring - "
              "only retail has real device_id variance).")
        results["mentor_uc1_new_device_high_value"] = None

    print("\n--- MENTOR USE CASE 2: Fan-In / Fan-Out Transaction Network ---")
    # prefer "both" (code 3) for the richest demo, else fan-out, else fan-in
    tid, inv = None, None
    for code, label in [(3, "both"), (2, "fan-out"), (1, "fan-in")]:
        sub = scored[scored["uc_fan_in_fan_out"] == code]
        if len(sub) > 0:
            sub = sub.sort_values("composite_score", ascending=False)
            tid = sub.iloc[0]["transaction_id"]
            inv = deterministic_investigate(tid, tools)
            break
    if tid:
        db.upsert_investigation_and_case(conn, tid, inv.model_dump(), "v2.0-demo")
        conn.commit()
        row = scored[scored["transaction_id"] == tid].iloc[0]
        print(f"Transaction: {tid} ({row['vertical']})")
        print(f"Use case: {row['use_case']}")
        print(f"Reasons: {list(row['use_case_reasons'])}")
        print(f"Risk: {inv.risk_level} ({inv.risk_score:.1f}/100), action: {inv.recommended_action}")
        results["mentor_uc2_fan_in_fan_out"] = tid
    else:
        print("No transaction in this dataset triggers this use case.")
        results["mentor_uc2_fan_in_fan_out"] = None

    print("\n--- MENTOR USE CASE 3: Near-Threshold Structuring ---")
    tid, inv = find_mentor_usecase_demo(scored, tools, "uc_near_threshold_structuring", "near-threshold structuring")
    if tid:
        db.upsert_investigation_and_case(conn, tid, inv.model_dump(), "v2.0-demo")
        conn.commit()
        row = scored[scored["transaction_id"] == tid].iloc[0]
        print(f"Transaction: {tid} ({row['vertical']})")
        print(f"Use case: {row['use_case']}")
        print(f"Reasons: {list(row['use_case_reasons'])}")
        print(f"Risk: {inv.risk_level} ({inv.risk_score:.1f}/100), action: {inv.recommended_action}")
        results["mentor_uc3_near_threshold_structuring"] = tid
    else:
        print("No transaction in this dataset triggers this use case in the current sample - "
              "documented limitation, not fabricated (see README).")
        results["mentor_uc3_near_threshold_structuring"] = None

    print(f"{'='*70}")
    return results

def run_demo():
    scored = pd.read_parquet("scored_transactions.parquet")
    evidence_df = pd.read_parquet("evidence_documents.parquet")
    store = EvidenceStore(evidence_df, scored)
    tools = SentinelTools(scored, store)

    db.init_db()
    conn = db.get_connection()
    existing_count = conn.execute("SELECT COUNT(*) as n FROM transactions").fetchone()["n"]
    if existing_count == 0:
        print(f"Database empty - loading {len(scored)} transactions + risk scores...")
        for _, row in scored.iterrows():
            db.upsert_transaction(conn, row)
            db.upsert_risk_score(conn, row, model_version="v2.0-demo")
        conn.commit()
    else:
        print(f"Database already populated ({existing_count} transactions) - skipping bulk load, "
              f"just running the 3 demo investigations.")

    print(f"\n{'='*70}\nSENTINEL AI DEMO - {len(scored)} transactions analyzed\n{'='*70}")

    print("\n--- CASE 1: Strong behavioral anomaly ---")
    tid1, inv1 = find_case_1(scored, tools)
    case_id1 = db.upsert_investigation_and_case(conn, tid1, inv1.model_dump(), "v2.0-demo")
    conn.commit()
    print(f"Transaction: {tid1}")
    print(f"Risk: {inv1.risk_level} ({inv1.risk_score:.1f}/100)")
    print(f"Finding: {inv1.finding}")
    print(f"Recommended action: {inv1.recommended_action}")
    db.record_decision(conn, tid1, "ESCALATE", "Confirmed anomaly, no counter-evidence found - escalating for full investigation", "demo_auditor")
    conn.commit()
    print("Auditor decision: ESCALATE (recorded, persisted)")

    print("\n--- CASE 2: Policy/threshold anomaly ---")
    tid2, inv2 = find_case_2(scored, tools)
    case_id2 = db.upsert_investigation_and_case(conn, tid2, inv2.model_dump(), "v2.0-demo")
    conn.commit()
    print(f"Transaction: {tid2}")
    print(f"Risk: {inv2.risk_level} ({inv2.risk_score:.1f}/100)")
    print(f"Anomaly drivers: {inv2.anomaly_drivers}")
    print(f"Recommended action: {inv2.recommended_action}")
    db.record_decision(conn, tid2, "ACCEPT", "Policy threshold triggered as designed - accepting flag for standard review", "demo_auditor")
    conn.commit()
    print("Auditor decision: ACCEPT (recorded, persisted)")

    print("\n--- CASE 3: False positive - dismissed via counter-evidence (MANDATORY case) ---")
    tid3, inv3 = find_case_3(scored, tools)
    case_id3 = db.upsert_investigation_and_case(conn, tid3, inv3.model_dump(), "v2.0-demo")
    conn.commit()
    print(f"Transaction: {tid3}")
    print(f"Risk: {inv3.risk_level} ({inv3.risk_score:.1f}/100)")
    print(f"Anomaly drivers: {inv3.anomaly_drivers}")
    print(f"Counter-evidence found: {[c.statement for c in inv3.counter_evidence]}")
    print(f"Agent recommendation: {inv3.recommended_action} (sufficiency: {inv3.evidence_sufficiency})")
    db.record_decision(conn, tid3, "DISMISS",
                        "Reviewed the agent's flagged counter-evidence: a matching approval record was found "
                        "on file for this transaction. Dismissing as false positive.", "demo_auditor")
    conn.commit()
    print("Auditor decision: DISMISS (recorded, persisted - this is the false-positive-caught-by-evidence story)")

    print(f"\n{'='*70}\nAudit trail for CASE 3 (proving persistence + full history):")
    for e in db.get_audit_trail(conn, tid3):
        print(f"  [{e['timestamp']}] {e['event_type']} by {e['actor']}")
    print(f"{'='*70}")

    mentor_results = {}
    if "use_case" in scored.columns:
        mentor_results = run_mentor_usecase_demos(scored, tools, conn)
    else:
        print("\nuse_cases.py has not run yet - skipping mentor-aligned use case demos "
              "(run the full pipeline first).")

    conn.close()
    return {"case_1": tid1, "case_2": tid2, "case_3": tid3, **mentor_results}

if __name__ == "__main__":
    result = run_demo()
    with open("demo_case_ids.json", "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nDemo case transaction IDs saved to demo_case_ids.json: {result}")
