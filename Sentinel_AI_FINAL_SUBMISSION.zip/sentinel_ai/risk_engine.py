"""
Sentinel AI v2 - Risk Engine.

Centralizes the composite 0-100 risk score with explainable component contributions
(model_score, rule_score, benford_score, network_score). Review-tier thresholds are
calibrated using VALIDATION data's fraud_label - not holdout - so the holdout remains a
clean, never-touched final evaluation set. Calibrating an operating threshold against
validation is standard practice; calibrating against holdout would be leakage.
"""
import pandas as pd
import numpy as np
import json
import os
from config import (COMPOSITE_WEIGHTS, COMPOSITE_WEIGHTS_NO_BENFORD,
                     BENFORD_DISABLED_VERTICALS, DEFAULT_REVIEW_TIERS, tier_for_score)

_CALIBRATED_WEIGHTS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "calibrated_composite_weights.json")

def _load_calibrated_weights():
    """
    Loads validation-calibrated weights if weight_calibration.py has been run (see
    evaluate_calibrated.py for the honest before/after this produced: e.g. AML ROC-AUC
    0.935 -> 0.968). Falls back to the fixed prototype weights in config.py if the
    calibration file doesn't exist yet - this makes risk_engine.py runnable standalone
    on a fresh checkout, at the cost of using un-calibrated weights until calibration
    is run once.
    """
    if os.path.exists(_CALIBRATED_WEIGHTS_PATH):
        with open(_CALIBRATED_WEIGHTS_PATH) as f:
            raw = json.load(f)
        return {v: r["weights"] for v, r in raw.items()}
    return None

CALIBRATED_WEIGHTS = _load_calibrated_weights()

def compute_composite(df):
    df = df.copy()

    rule_cols = [c for c in df.columns if c.startswith("flag_") and "shared" not in c and "hub" not in c]
    rule_count = df[rule_cols].sum(axis=1)
    rule_max = max(rule_count.max(), 1)
    rules_norm = rule_count / rule_max

    network_flags = [c for c in ["flag_shared_device", "flag_hub_counterparty"] if c in df.columns]
    network_score = df[network_flags].sum(axis=1) / max(len(network_flags), 1) if network_flags else pd.Series(0, index=df.index)

    benford_component = df["benford_flag"].fillna(0) if "benford_flag" in df.columns else pd.Series(0, index=df.index)

    model_score = 0.5 * df["isoforest_score"] + 0.5 * df["autoencoder_score"]

    df["rule_score"] = rules_norm * 100
    df["benford_score"] = benford_component * 100
    df["network_score"] = network_score * 100
    df["model_score"] = model_score * 100

    composite = np.zeros(len(df))
    for vertical in df["vertical"].unique():
        mask = (df["vertical"] == vertical).values
        if CALIBRATED_WEIGHTS and vertical in CALIBRATED_WEIGHTS:
            w = CALIBRATED_WEIGHTS[vertical]
            total = sum(w.values())
            composite[mask] = (
                w["isoforest"] * df.loc[mask, "isoforest_score"] * 100
                + w["autoencoder"] * df.loc[mask, "autoencoder_score"] * 100
                + w["rules"] * df.loc[mask, "rule_score"]
                + w["benford"] * df.loc[mask, "benford_score"]
            ) / total
        else:
            # fallback: fixed prototype weights (see config.py) - only used if
            # weight_calibration.py hasn't been run yet
            w = COMPOSITE_WEIGHTS_NO_BENFORD if vertical in BENFORD_DISABLED_VERTICALS else COMPOSITE_WEIGHTS
            composite[mask] = (
                w["isoforest"] * df.loc[mask, "isoforest_score"] * 100
                + w["autoencoder"] * df.loc[mask, "autoencoder_score"] * 100
                + w.get("benford", 0) * df.loc[mask, "benford_score"]
                + w["rules"] * df.loc[mask, "rule_score"]
            )
    df["composite_score"] = composite
    return df

def calibrate_thresholds_on_validation(validation_scored, target_fpr=0.15):
    """
    Uses VALIDATION's fraud_label (never holdout's) to pick a composite-score cutoff per
    vertical closest to (but not exceeding, where possible) the target false-positive
    rate. Returns a frozen per-vertical threshold dict to apply to holdout.
    """
    thresholds = {}
    for vertical, sub in validation_scored.groupby("vertical"):
        y = sub["fraud_label"].values
        best = None
        for pct in np.arange(50, 100, 0.5):
            thr = np.percentile(sub["composite_score"], pct)
            pred = (sub["composite_score"] >= thr).astype(int)
            fp = ((pred == 1) & (y == 0)).sum()
            tn = ((pred == 0) & (y == 0)).sum()
            fpr = fp / (fp + tn) if (fp + tn) else 1.0
            if fpr <= target_fpr:
                best = thr
                break
        thresholds[vertical] = float(best) if best is not None else float(sub["composite_score"].max())
    return thresholds

def calibrate_tiers_on_validation(validation_scored, target_fpr=0.15):
    """
    Builds per-vertical tier cutoffs entirely from VALIDATION data - never holdout.
    standard_review = the target_fpr threshold from calibrate_thresholds_on_validation();
    priority_review / immediate_escalation = the 95th / 99th percentile of VALIDATION's
    own composite score distribution (an operational-capacity framing: "the riskiest 5%"
    / "riskiest 1%"), not an arbitrary fixed number on an unrelated 0-100 scale.
    """
    base_thresholds = calibrate_thresholds_on_validation(validation_scored, target_fpr)
    tiers_by_vertical = {}
    for vertical, sub in validation_scored.groupby("vertical"):
        standard_cut = base_thresholds[vertical]
        priority_cut = float(np.percentile(sub["composite_score"], 95))
        escalation_cut = float(np.percentile(sub["composite_score"], 99))
        # guard against inversions (can happen if the FPR-based cutoff already sits above
        # the 95th percentile) by sorting the cutoffs ascending
        cuts = sorted([standard_cut, priority_cut, escalation_cut])
        tiers_by_vertical[vertical] = [
            (cuts[0], "auto_clear"), (cuts[1], "standard_review"),
            (cuts[2], "priority_review"), (101, "immediate_escalation"),
        ]
    return tiers_by_vertical

def apply_tiers(df, tiers_by_vertical):
    df = df.copy()
    df["review_tier"] = df.apply(
        lambda r: tier_for_score(r["composite_score"], tiers_by_vertical[r["vertical"]]), axis=1
    )
    return df

if __name__ == "__main__":
    import json
    train = pd.read_parquet("scored_train.parquet")
    validation = pd.read_parquet("scored_validation.parquet")
    holdout = pd.read_parquet("scored_holdout.parquet")

    train = compute_composite(train)
    validation = compute_composite(validation)
    holdout = compute_composite(holdout)

    thresholds = calibrate_thresholds_on_validation(validation)
    print("Calibrated operating thresholds (from VALIDATION only):", thresholds)
    tiers_by_vertical = calibrate_tiers_on_validation(validation)
    print("Calibrated tier cutoffs (from VALIDATION only):")
    for v, t in tiers_by_vertical.items():
        print(" ", v, t)

    train = apply_tiers(train, tiers_by_vertical)
    validation = apply_tiers(validation, tiers_by_vertical)
    holdout = apply_tiers(holdout, tiers_by_vertical)

    train.to_parquet("risk_scored_train.parquet", index=False)
    validation.to_parquet("risk_scored_validation.parquet", index=False)
    holdout.to_parquet("risk_scored_holdout.parquet", index=False)
    with open("calibrated_thresholds.json", "w") as f:
        json.dump({"fpr_target_thresholds": thresholds, "tiers_by_vertical": tiers_by_vertical}, f, indent=2)

    all_scored = pd.concat([train, validation, holdout], ignore_index=True)
    all_scored.to_parquet("scored_transactions.parquet", index=False)
    print("Saved risk_scored_{train,validation,holdout}.parquet, scored_transactions.parquet, calibrated_thresholds.json")

    for v, sub in holdout.groupby("vertical"):
        print(v, "holdout tier distribution:")
        print(sub["review_tier"].value_counts(normalize=True).round(3).to_dict())
