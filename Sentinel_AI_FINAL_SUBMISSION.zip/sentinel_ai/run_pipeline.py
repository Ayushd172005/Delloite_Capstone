"""
Sentinel AI v2 - end-to-end pipeline runner.

Executes, in order: data validation -> feature engineering -> network features ->
Benford -> rules -> model fitting (leakage-free) -> risk scoring + threshold
calibration -> weight calibration -> evaluation -> ablation -> workload metrics ->
evidence generation -> retrieval index build -> database population.

Reproducible: re-running this from a clean checkout regenerates every intermediate
file and produces the same numbers (models use config.RANDOM_SEED throughout).
"""
import subprocess
import sys
import time

STEPS = [
    ("Data validation", "data_validation.py"),
    ("Feature engineering", "prep.py"),
    ("Network features", "network.py"),
    ("Rule engine", "rules.py"),
    ("Benford's Law", "benford.py"),
    ("Model fitting (leakage-free, 3-way split)", "model.py"),
    ("Risk engine + threshold calibration (validation only)", "risk_engine.py"),
    ("Composite weight calibration (validation only)", "weight_calibration.py"),
    ("Weight calibration before/after report", "evaluate_calibrated.py"),
    ("Apply calibrated weights + re-score", "risk_engine.py"),  # re-run so composite_score uses calibrated weights
    ("Evaluation (holdout only)", "evaluate.py"),
    ("Ablation study (holdout only)", "ablation.py"),
    ("Auditor workload metrics", "workload_metrics.py"),
    ("Drift monitoring (train vs holdout)", "drift.py"),
    ("Structured evidence generation", "evidence.py"),
    ("Mentor-aligned business use cases", "use_cases.py"),
    ("Retrieval index build + sanity check", "retrieval.py"),
    ("Database population", "populate_db.py"),
    ("Cost-sensitive evaluation", "cost_evaluation.py"),
    ("Consolidated markdown reports", "generate_reports.py"),
    ("Architecture diagram", "generate_architecture_diagram.py"),
]

def run_step(name, script):
    print(f"\n{'='*70}\n{name}  ({script})\n{'='*70}")
    start = time.time()
    result = subprocess.run([sys.executable, script], capture_output=False)
    elapsed = time.time() - start
    if result.returncode != 0:
        print(f"\nFAILED: {script} (exit code {result.returncode}) after {elapsed:.1f}s")
        sys.exit(1)
    print(f"-- completed in {elapsed:.1f}s")

if __name__ == "__main__":
    overall_start = time.time()
    for name, script in STEPS:
        run_step(name, script)
    print(f"\n{'='*70}\nPipeline complete in {time.time() - overall_start:.1f}s")
    print("Run demo.py for the 3 deterministic demo cases, or start the API with:")
    print("  uvicorn app:app --reload")
    print(f"{'='*70}")
