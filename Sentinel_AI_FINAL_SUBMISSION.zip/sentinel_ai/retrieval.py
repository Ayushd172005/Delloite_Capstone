"""
Sentinel AI v2 - Retrieval layer.

TEMPORAL EVIDENCE RULE (master prompt item 14): for real-time audit mode, only
evidence created at or before the transaction being investigated may be retrieved.
This was NOT enforced in the prior version of this code - same-account/counterparty
history and TF-IDF text matches could surface documents from AFTER the transaction
under investigation, which is evidence leakage (an auditor investigating a March
transaction should not see July's transactions as if they were prior history). Fixed
here: every retrieval call filters the corpus to created_at <= transaction_time first,
unless retrospective=True is explicitly passed.

TF-IDF stands in for FAISS/embeddings (no embedding-model downloads available in this
environment) - retrieve() has the same query -> ranked doc_ids -> text contract either
way, so swapping in real embeddings later is a drop-in replacement.
"""
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

TOP_K = 6

class EvidenceStore:
    def __init__(self, evidence_df, transactions_df):
        """
        evidence_df: output of evidence.generate_structured_evidence() - document_id,
            transaction_id, source_type, created_at, text, metadata, ...
        transactions_df: scored transactions (for account_id/counterparty_id/vertical
            lookups per transaction_id, and to resolve created_at ordering).
        """
        self.evidence = evidence_df.reset_index(drop=True)
        self.txns = transactions_df.set_index("transaction_id")
        self.vectorizer = TfidfVectorizer(max_features=2000, stop_words="english")
        self.matrix = self.vectorizer.fit_transform(self.evidence["text"])

    def _txn_meta(self, transaction_id):
        row = self.txns.loc[transaction_id]
        return row

    def retrieve(self, transaction_id, top_k=TOP_K, retrospective=False):
        """
        Returns ranked evidence dicts with a `reason_for_retrieval` field. Enforces
        evidence_timestamp <= transaction_timestamp unless retrospective=True.
        """
        txn = self._txn_meta(transaction_id)
        query_text_row = self.evidence[self.evidence["transaction_id"] == transaction_id]
        query_text = query_text_row.iloc[0]["text"] if len(query_text_row) else ""

        pool = self.evidence
        if not retrospective:
            pool = pool[pool["created_at"] <= txn["transaction_time"]]
        pool = pool[pool["transaction_id"] != transaction_id]

        if len(pool) == 0:
            return []

        # account/counterparty history within the temporally-valid pool
        acct_docs = pool[pool["metadata"].apply(lambda m: m.get("account_id") == txn.get("account_id"))].copy()
        acct_docs["reason_for_retrieval"] = "same_account_history"
        cp_docs = pool[pool["metadata"].apply(lambda m: m.get("counterparty_id") == txn.get("counterparty_id"))].copy()
        cp_docs["reason_for_retrieval"] = "same_counterparty_history"

        # approval records specifically for THIS transaction (temporally valid by construction -
        # generated with created_at before transaction_time)
        approvals = pool[(pool["transaction_id"] == transaction_id) & (pool["source_type"] == "approval_record")].copy()

        # text similarity over the temporally-valid pool only
        pool_idx = pool.index
        sub_matrix = self.matrix[pool_idx]
        query_vec = self.vectorizer.transform([query_text])
        sims = cosine_similarity(query_vec, sub_matrix).flatten()
        top_local = np.argsort(-sims)[:top_k * 2]
        text_hits = pool.iloc[top_local].copy()
        text_hits["similarity"] = sims[top_local]
        text_hits["reason_for_retrieval"] = "text_similarity"

        combined = pd.concat([acct_docs, cp_docs, text_hits], ignore_index=True)
        if "similarity" not in combined.columns:
            combined["similarity"] = 0.0
        combined["similarity"] = combined["similarity"].fillna(0.0)
        combined = combined.drop_duplicates(subset="document_id").sort_values("similarity", ascending=False).head(top_k)

        results = combined.to_dict("records")
        for r in results:
            r["relevance_score"] = round(float(r.pop("similarity", 0.0)), 3)
        return results

    def retrieve_own_transaction_docs(self, transaction_id):
        """The transaction's OWN evidence documents (its invoice/wire/payment record and
        any matching approval record) - not "retrieved" in the similarity sense, but
        directly attached, and still subject to the temporal rule trivially (they're
        created at/near the transaction's own time)."""
        docs = self.evidence[self.evidence["transaction_id"] == transaction_id].copy()
        docs["reason_for_retrieval"] = docs["source_type"].apply(
            lambda s: "primary_transaction_record" if s != "approval_record" else "matching_approval_record"
        )
        docs["relevance_score"] = 1.0
        return docs.to_dict("records")

if __name__ == "__main__":
    evidence_df = pd.read_parquet("evidence_documents.parquet")
    txns = pd.read_parquet("scored_transactions.parquet")
    store = EvidenceStore(evidence_df, txns)

    sample_id = evidence_df.iloc[0]["transaction_id"]
    own = store.retrieve_own_transaction_docs(sample_id)
    related = store.retrieve(sample_id)
    print(f"Sample transaction: {sample_id}")
    print(f"Own documents ({len(own)}):")
    for d in own:
        print(f"  [{d['document_id']}] ({d['source_type']}, {d['reason_for_retrieval']}) {d['text'][:80]}")
    print(f"Related evidence ({len(related)}):")
    for d in related:
        print(f"  [{d['document_id']}] ({d['reason_for_retrieval']}, rel={d['relevance_score']}) {d['text'][:80]}")
