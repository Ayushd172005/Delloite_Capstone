"""
Sentinel AI v2 - FastAPI backend.

Endpoints (master prompt item 22):
  GET  /health
  GET  /queue
  GET  /case/{transaction_id}
  POST /case/{transaction_id}/investigate
  POST /case/{transaction_id}/decision
  GET  /audit_trail/{transaction_id}
  GET  /metrics
  GET  /model-info

Decisions and investigations persist to SQLite (db.py) - restarting this process does
NOT lose case state; every response below is read back from the database, not from
in-memory globals (the earlier version of this code kept CASES in a Python dict, which
is exactly what item 23 in the master prompt flags as a problem: "refreshing the
browser must NOT erase decisions").
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Literal, Optional
import pandas as pd
import json
import os

import db
from retrieval import EvidenceStore
from agent import SentinelTools, call_agent

app = FastAPI(title="Sentinel AI API", version="2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
_state = {}

def load_state():
    scored = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    evidence_path = os.path.join(DATA_DIR, "evidence_documents.parquet")
    if os.path.exists(evidence_path):
        evidence_df = pd.read_parquet(evidence_path)
        store = EvidenceStore(evidence_df, scored)
        tools = SentinelTools(scored, store)
    else:
        store, tools = None, None
    _state["scored"] = scored
    _state["tools"] = tools
    db.init_db()

@app.on_event("startup")
def startup():
    load_state()

class Decision(BaseModel):
    auditor: str
    action: Literal["ACCEPT", "ESCALATE", "DISMISS", "REQUEST_MORE_EVIDENCE", "OVERRIDE"]
    reason: Optional[str] = None

@app.get("/health")
def health():
    return {"status": "ok", "transactions_loaded": len(_state.get("scored", []))}

@app.get("/queue")
def get_queue(vertical: Optional[str] = None, tier: Optional[str] = None, limit: int = 50):
    df = _state["scored"]
    df = df[df["review_tier"] != "auto_clear"]
    if vertical:
        df = df[df["vertical"] == vertical]
    if tier:
        df = df[df["review_tier"] == tier]
    df = df.sort_values("composite_score", ascending=False).head(limit)

    conn = db.get_connection()
    decided = {r["transaction_id"]: r["auditor_decision"] for r in
               conn.execute("SELECT transaction_id, auditor_decision FROM cases").fetchall()}
    conn.close()

    cols = ["transaction_id", "vertical", "amount", "composite_score", "review_tier", "rule_flag_count"]
    has_use_cases = "use_case" in df.columns
    if has_use_cases:
        cols += ["use_case"]
    records = df[cols].to_dict("records")
    for r in records:
        r["auditor_decision"] = decided.get(r["transaction_id"])
        if not has_use_cases:
            r["use_case"] = None
        elif pd.isna(r["use_case"]):
            # pandas gives NaN (float), not None, for missing object-column values on
            # this parquet round-trip - a raw NaN fails FastAPI's strict JSON encoder
            # (ValueError: Out of range float values are not JSON compliant) - caught by
            # actually hitting the live /queue endpoint, not by the direct-function-call
            # integration test alone, which happened not to exercise a NaN row.
            r["use_case"] = None
    return records

@app.get("/case/{transaction_id}")
def get_case(transaction_id: str):
    df = _state["scored"]
    row = df[df["transaction_id"] == transaction_id]
    if row.empty:
        raise HTTPException(404, "transaction not found")
    row = row.iloc[0]

    conn = db.get_connection()
    inv_row = conn.execute(
        "SELECT investigation_json FROM investigations WHERE transaction_id = ?", (transaction_id,)
    ).fetchone()
    case_row = conn.execute("SELECT * FROM cases WHERE transaction_id = ?", (transaction_id,)).fetchone()
    conn.close()

    signals = {
        "composite_score": float(row["composite_score"]), "review_tier": row["review_tier"],
        "isoforest_score": round(float(row["isoforest_score"]), 3),
        "autoencoder_score": round(float(row["autoencoder_score"]), 3),
        "benford_flag": bool(row.get("benford_flag", 0)),
        "rules_triggered": [c.replace("flag_", "") for c in row.index
                             if c.startswith("flag_") and row[c] == 1 and "shared" not in c and "hub" not in c],
    }
    if "use_case" in row.index:
        signals["use_case"] = row["use_case"] if pd.notna(row["use_case"]) else None
        signals["use_case_reasons"] = list(row["use_case_reasons"]) if row["use_case_reasons"] is not None else []
        signals["uc_new_device_high_value"] = bool(row.get("uc_new_device_high_value", 0))
        signals["uc_fan_in_fan_out"] = int(row.get("uc_fan_in_fan_out", 0))
        signals["uc_near_threshold_structuring"] = bool(row.get("uc_near_threshold_structuring", 0))
    else:
        signals["use_case"] = None
        signals["use_case_reasons"] = []
    investigation = json.loads(inv_row["investigation_json"]) if inv_row else None
    case = dict(case_row) if case_row else None
    return {"signals": signals, "investigation": investigation, "case": case}

@app.post("/case/{transaction_id}/investigate")
def investigate(transaction_id: str):
    if _state["tools"] is None:
        raise HTTPException(503, "evidence store not loaded - run evidence.py and retrieval.py first")
    df = _state["scored"]
    if df[df["transaction_id"] == transaction_id].empty:
        raise HTTPException(404, "transaction not found")

    inv = call_agent(transaction_id, _state["tools"])
    inv_dict = inv.model_dump()

    conn = db.get_connection()
    case_id = db.upsert_investigation_and_case(conn, transaction_id, inv_dict, model_version="v2.0")
    conn.commit()
    conn.close()
    return {"case_id": case_id, "investigation": inv_dict}

@app.post("/case/{transaction_id}/decision")
def decision(transaction_id: str, decision: Decision):
    df = _state["scored"]
    if df[df["transaction_id"] == transaction_id].empty:
        raise HTTPException(404, "transaction not found")
    conn = db.get_connection()
    case_id = db.record_decision(conn, transaction_id, decision.action, decision.reason, decision.auditor)
    conn.commit()
    conn.close()
    if case_id is None:
        raise HTTPException(400, "no case exists for this transaction yet - call /investigate first")
    return {"status": "recorded", "case_id": case_id, "action": decision.action}

@app.get("/audit_trail/{transaction_id}")
def audit_trail(transaction_id: str):
    conn = db.get_connection()
    trail = db.get_audit_trail(conn, transaction_id)
    conn.close()
    return trail

@app.get("/metrics")
def metrics():
    path = os.path.join(DATA_DIR, "workload_metrics.json")
    if not os.path.exists(path):
        raise HTTPException(503, "workload_metrics.json not found - run workload_metrics.py first")
    with open(path) as f:
        return json.load(f)

@app.get("/model-info")
def model_info():
    conn = db.get_connection()
    rows = conn.execute("SELECT * FROM model_versions").fetchall()
    conn.close()
    return [dict(r) for r in rows]
