"""
Sentinel AI v2 - Data preparation.

Loads the 3 raw datasets, normalizes onto a common schema, tags vertical, and
engineers per-account behavioral features. Every feature here is computed causally
(shift(1)/expanding, never using the current or future row) - this is verified by
tests/unit/test_no_lookahead_static.py and tests/integration/test_no_lookahead_data.py,
not just asserted in a comment. velocity_vectorized() and pct_rank_vectorized() below
replace what were originally O(n^2) nested-loop implementations; exact equivalence to
the original logic is proven in tests/unit/test_prep_optimization_equivalence.py.
"""
import pandas as pd
import numpy as np
from config import ENTITY_COL
from model import three_way_split

RAW_FILES = {
    "corporate": "pro_dataset_corporate.csv",
    "aml": "pro_dataset_aml.csv",
    "retail": "pro_dataset_retail.csv",
}

def load_and_normalize():
    frames = []
    for vertical, path in RAW_FILES.items():
        df = pd.read_csv(path)
        df["vertical"] = vertical
        df = df.rename(columns={"merchant_id": "counterparty_id"})
        df["transaction_time"] = pd.to_datetime(df["transaction_time"])
        frames.append(df)
    return frames

def velocity_vectorized(times, window_days):
    """
    Vectorized replacement for the original nested-loop velocity count. EXACT semantic
    match, proven by tests/unit/test_prep_optimization_equivalence.py against the
    preserved original logic, including the tied-timestamp edge case (common in
    corporate/aml's date-only raw data): counts, for each position i, the number of
    PRIOR positions j<i (by row order, not just by time value - this distinction only
    matters for ties) whose timestamp t[j] >= t[i] - window_days.

    times must already be sorted ascending (ties broken by stable row order, matching
    prep.py's own sort discipline) - this is what makes the searchsorted trick exact:
    for a non-decreasing array, "count of prior positions with time >= threshold" equals
    i minus the position of the first entry >= threshold, found via binary search.
    O(n log n) instead of the original O(n^2).
    """
    times = np.asarray(times, dtype="datetime64[ns]")
    n = len(times)
    if n == 0:
        return np.array([], dtype=np.int64)
    thresholds = times - np.timedelta64(window_days, "D")
    # first index where times >= threshold, per row - vectorized binary search
    left_idx = np.searchsorted(times, thresholds, side="left")
    positions = np.arange(n)
    return positions - left_idx

def pct_rank_vectorized(values):
    """
    Vectorized replacement for the original nested-loop percentile-rank calculation.
    EXACT semantic match (not an approximation), proven by
    tests/unit/test_prep_optimization_equivalence.py: for each position i, the fraction
    of PRIOR values (positions 0..i-1) strictly less than values[i]; 0.5 for i=0
    (no prior data), matching the original's `shifted.iloc[:i+1].dropna()` behavior
    exactly. Uses a full pairwise comparison matrix rather than a Fenwick tree / BIT for
    simplicity and provable correctness - safe here because entity group sizes in this
    dataset top out at 174 rows (checked directly, not assumed), making an O(n^2)-memory
    but fully-vectorized (no Python-level per-row loop) numpy computation both correct
    and fast. Would need revisiting only if entity sizes grew into the thousands.
    """
    values = np.asarray(values, dtype=np.float64)
    n = len(values)
    if n <= 1:
        return np.full(n, 0.5)
    # less_than[i, j] = True if values[j] < values[i]
    less_than = values[:, None] > values[None, :]
    prior_mask = np.tril(np.ones((n, n), dtype=bool), k=-1)  # True where j < i
    counts = (less_than & prior_mask).sum(axis=1)
    denom = np.arange(n)
    denom[0] = 1  # placeholder to avoid divide-by-zero; row 0 is overwritten below anyway
    out = counts / denom
    out[0] = 0.5
    return out

def engineer_features(df):
    """Per-entity rolling features, computed causally (no lookahead)."""
    vertical = df["vertical"].iloc[0]
    entity = ENTITY_COL[vertical]
    # kind="stable" (mergesort) is REQUIRED here, not cosmetic: pandas' default quicksort
    # is not stable, and corporate/aml timestamps are date-only (see config docstring) so
    # same-day ties within one entity are common. An unstable sort makes the "causal" order
    # used for every rolling feature below non-deterministic between runs on tied rows -
    # caught by tests/test_no_lookahead.py, which failed under quicksort's default ordering.
    df = df.sort_values([entity, "transaction_time"], kind="stable").reset_index(drop=True)

    # --- personal behavioral baseline ---
    df["prev_time"] = df.groupby(entity)["transaction_time"].shift(1)
    df["days_since_last_txn"] = (df["transaction_time"] - df["prev_time"]).dt.total_seconds() / 86400
    df["days_since_last_txn"] = df["days_since_last_txn"].fillna(999)

    grp = df.groupby(entity)["amount"]
    df["roll_mean_amount"] = grp.transform(lambda s: s.shift(1).expanding().mean())
    df["roll_std_amount"] = grp.transform(lambda s: s.shift(1).expanding().std())
    df["roll_mean_amount"] = df["roll_mean_amount"].fillna(df["amount"])
    df["roll_std_amount"] = df["roll_std_amount"].fillna(0)
    df["amount_zscore"] = (df["amount"] - df["roll_mean_amount"]) / df["roll_std_amount"].replace(0, np.nan)
    df["amount_zscore"] = df["amount_zscore"].fillna(0).clip(-10, 10)

    df["cumulative_amount"] = grp.transform(lambda s: s.shift(1).expanding().sum()).fillna(0)

    # --- multi-window velocity (7-day and 30-day trailing counts) ---
    # Vectorized via velocity_vectorized() (searchsorted-based, O(n log n)) - EXACT
    # semantic match to the original nested-loop implementation, proven by
    # tests/unit/test_prep_optimization_equivalence.py including the tied-timestamp
    # edge case. df is already sorted by [entity, transaction_time] (stable) from the
    # top of this function, and nothing since has reordered it, so no re-sort is needed
    # here - groupby().transform() preserves each group's existing row order.
    df["velocity_7d"] = df.groupby(entity)["transaction_time"].transform(
        lambda s: velocity_vectorized(s.values, 7)
    )
    df["velocity_30d"] = df.groupby(entity)["transaction_time"].transform(
        lambda s: velocity_vectorized(s.values, 30)
    )

    grp2 = df.groupby(entity)["velocity_30d"]
    df["velocity_hist_avg"] = grp2.transform(lambda s: s.shift(1).expanding().mean()).fillna(0)
    df["velocity_spike_ratio"] = df["velocity_30d"] / df["velocity_hist_avg"].replace(0, np.nan)
    df["velocity_spike_ratio"] = df["velocity_spike_ratio"].fillna(1).clip(0, 20)

    # --- balance / amount-to-balance ---
    df["balance_depletion_ratio"] = (
        (df["balance_before"] - df["balance_after"]) / df["balance_before"].replace(0, np.nan)
    ).fillna(0).clip(-5, 5)
    df["amount_to_balance_ratio"] = (df["amount"] / df["balance_before"].replace(0, np.nan)).fillna(0).clip(0, 50)

    # --- novelty flags (counterparty, device, location, payment method) ---
    for col, out in [("counterparty_id", "counterparty"), ("device_id", "device"),
                      ("location", "location"), ("payment_method", "payment_method")]:
        seen_count = df.groupby([entity, col]).cumcount()
        df[f"is_new_{out}"] = (seen_count == 0).astype(int)

    # --- time-of-day / day-of-week deviation (only meaningful where timestamps have real
    # intraday granularity - see config.HAS_INTRADAY_TIMESTAMPS, applied downstream in rules.py) ---
    df["hour"] = df["transaction_time"].dt.hour
    df["is_weekend"] = df["transaction_time"].dt.dayofweek.isin([5, 6]).astype(int)
    df["is_off_hours"] = (~df["hour"].between(8, 20)).astype(int)
    df["is_round_number"] = (df["amount"].round(0) % 100 == 0).astype(int)

    # --- amount percentile within this entity's own history (causal - prior txns only) ---
    # Vectorized via pct_rank_vectorized() (numpy broadcast comparison matrix) - EXACT
    # semantic match to the original nested-loop implementation, proven by
    # tests/unit/test_prep_optimization_equivalence.py.
    df["amount_pct_rank_personal"] = df.groupby(entity)["amount"].transform(
        lambda s: pct_rank_vectorized(s.values)
    )

    # --- peer-group baseline: percentile of this transaction's amount against the
    # vertical's FROZEN TRAIN-PERIOD amount distribution (config.SPLIT_MONTHS, via
    # model.three_way_split - the same chronological split model.py itself uses to fit
    # the ML models). FIX (future-distribution leakage): the original implementation
    # ranked against the FULL vertical column via `.groupby("vertical")["amount"].rank(
    # pct=True)`, which meant every transaction's percentile was influenced by
    # transactions that occur AFTER it - not label leakage, but inappropriate for a
    # feature meant to reflect what would actually be knowable at scoring time in a
    # continuous/real-time deployment. This mirrors exactly how StandardScaler is fit on
    # TRAIN only and applied to validation/holdout in model.py - the same already-accepted
    # pattern in this codebase, not a new framework. Frozen train-only reference means:
    # - validation/holdout transactions' percentiles never depend on each other or on
    #   anything after the train cutoff.
    # - train transactions are scored against the very distribution built from train
    #   itself, identical in spirit to how StandardScaler.fit_transform(train) works.
    train_only, _, _ = three_way_split(df)
    train_amounts_sorted = np.sort(train_only["amount"].values)
    df["amount_pct_rank_peer_group"] = (
        np.searchsorted(train_amounts_sorted, df["amount"].values, side="left")
        / len(train_amounts_sorted)
    )

    df = df.drop(columns=["prev_time"])
    return df

if __name__ == "__main__":
    frames = load_and_normalize()
    out = []
    for df in frames:
        v = df["vertical"].iloc[0]
        print(f"Engineering features for {v} ({len(df)} rows)...")
        df2 = engineer_features(df)
        out.append(df2)
    full = pd.concat(out, ignore_index=True)
    full.to_parquet("normalized_features.parquet", index=False)
    print("Saved normalized_features.parquet:", full.shape, "columns:", len(full.columns))
