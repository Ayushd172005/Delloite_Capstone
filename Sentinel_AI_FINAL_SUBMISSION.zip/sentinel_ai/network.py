"""
Sentinel AI v2 - lightweight network intelligence.

Deliberately NOT a graph neural network (see master prompt item 37: don't add
complexity that doesn't materially help a prototype). These are simple structural
counts over the customer/account/merchant/device/location graph, computed causally
(using only transactions up to and including the current one is fine here since these
are population-level structural properties, not future-looking predictions about this
specific transaction's outcome).
"""
import pandas as pd
from config import HAS_MEANINGFUL_DEVICE_ID, HAS_MEANINGFUL_LOCATION, ENTITY_COL

def add_network_features(df):
    df = df.copy()
    # "distinct entity" counts must use each vertical's real behavioral entity (config.ENTITY_COL),
    # not always account_id - AML's account_id is a near-unique per-transaction SWIFT reference
    # (see prep.py), so grouping by it directly would make every fan-in/concentration figure
    # trivially degenerate (every group has exactly 1 row). Add an entity column once, use it below.
    df["_entity"] = df.apply(lambda r: r[ENTITY_COL[r["vertical"]]], axis=1)

    # device fan-out: how many distinct entities have used this device_id (within vertical).
    # Only computed where device_id genuinely varies (see config) - corporate and AML's
    # device_id is a constant placeholder value across all rows in the raw data, so the
    # feature is set to 0/not-applicable there rather than producing a meaningless 100%.
    df["device_account_fanout"] = 0
    df["flag_shared_device"] = 0
    for v in HAS_MEANINGFUL_DEVICE_ID:
        mask = df["vertical"] == v
        df.loc[mask, "device_account_fanout"] = df[mask].groupby("device_id")["_entity"].transform("nunique")
        df.loc[mask, "flag_shared_device"] = (df.loc[mask, "device_account_fanout"] > 3).astype(int)

    # location fan-in: only where location varies (corporate's location is also constant)
    df["location_account_fanin"] = 0
    for v in HAS_MEANINGFUL_LOCATION:
        mask = df["vertical"] == v
        df.loc[mask, "location_account_fanin"] = df[mask].groupby("location")["_entity"].transform("nunique")

    # counterparty fan-in: how many distinct entities have transacted with this counterparty
    # - counterparty_id has real variety in all 3 verticals, so this runs everywhere.
    cp_fanin = df.groupby(["vertical", "counterparty_id"])["_entity"].transform("nunique")
    df["counterparty_account_fanin"] = cp_fanin

    # merchant/counterparty concentration for this specific entity: what share of this
    # entity's own transactions go to its single most common counterparty
    def top_cp_share(g):
        vc = g.value_counts(normalize=True)
        return vc.iloc[0] if len(vc) else 0
    cp_share = df.groupby(["vertical", "_entity"])["counterparty_id"].transform(
        lambda s: top_cp_share(s)
    )
    df["merchant_concentration"] = cp_share
    df = df.drop(columns=["_entity"])

    # flags for structurally unusual fan-out/fan-in (many-to-one patterns worth a human's attention)
    df["flag_hub_counterparty"] = (
        df["counterparty_account_fanin"] > df.groupby("vertical")["counterparty_account_fanin"].transform(
            lambda s: s.quantile(0.95)
        )
    ).astype(int)

    return df

if __name__ == "__main__":
    full = pd.read_parquet("normalized_features.parquet")
    full = add_network_features(full)
    for v, sub in full.groupby("vertical"):
        print(v, "shared_device rate:", f"{sub['flag_shared_device'].mean():.2%}",
              "| hub_counterparty rate:", f"{sub['flag_hub_counterparty'].mean():.2%}",
              "| avg merchant_concentration:", round(sub['merchant_concentration'].mean(), 3))
    full.to_parquet("normalized_features_network.parquet", index=False)
    print("Saved normalized_features_network.parquet:", full.shape)
