# Sentinel AI v2 - Continuous Audit Investigation Platform

Deloitte Capstone 2026 - Team Stack Synapse (Ehsaas Bhalla, Aaditya Upadhyay, Ayush Dudhat), Manipal University Jaipur.

## 1. Executive Summary

Sentinel AI continuously scores 100% of an organization's transactions (not a ~5%
sample), compresses that population into a small, explainable, evidence-backed
investigation queue, and gives auditors an AI investigation assistant that gathers
supporting **and** counter-evidence before the human makes the final call. On the
included synthetic holdout data, Sentinel reduces the manual review population by
76-82% while capturing the large majority of labeled fraud in the retained queue (see
Section 13). Every number in this document was produced by actually running the code
in this repository - see [reports/](reports/) for the generated evidence.

## 2. Problem

Audit teams sample well under 5% of transactions and extrapolate confidence about the
rest. This creates a coverage gap (anomalies in the unsampled 95%+ go undetected), a
speed gap (issues surface months later on a quarterly/annual cycle), and a leverage gap
(auditor time goes to routine checks instead of judgment work).

## 3. Sentinel AI Solution

> **Sentinel AI doesn't replace auditors. It compresses large transaction populations
> into a small, explainable, evidence-backed investigation queue.**
> Detection tells us where to look. Evidence tells us why. The auditor decides what
> happens next.

Score every transaction with unsupervised ML, deterministic rules, and Benford's Law →
prioritize into a risk queue → have an evidence-grounded agent pre-investigate each
flagged case (supporting AND counter-evidence, never assuming anomaly = fraud) → human
auditor makes the final, recorded decision → immutable audit trail of everything.

## 4. Architecture

See `reports/architecture_diagram.png` - every box in it names the actual file that
implements it.

```
raw CSVs -> data_validation.py -> prep.py -> network.py -> rules.py -> benford.py
  -> model.py (leakage-free, 3-way split) -> risk_engine.py (calibrated on VALIDATION only)
  -> weight_calibration.py -> evaluate.py / ablation.py / workload_metrics.py / drift.py
  -> evidence.py -> retrieval.py (temporal rule enforced) -> agent.py (Pydantic-validated)
  -> db.py (SQLite) -> app.py (FastAPI) -> frontend/ (React/Vite console, live API, no hardcoded cases)
```

## 5. Detection Methodology

- **IsolationForest** + a bottleneck-MLP **autoencoder** (stand-in for a deep autoencoder -
  no TensorFlow/PyTorch in this environment), fit on TRAIN only, applied to
  validation/holdout via `transform()` only.
- **7 deterministic rules**, all thresholds in `config.py`, labeled prototype policy
  thresholds, not regulatory requirements.
- **Benford's Law** (MAD method, simulation-calibrated per-cohort threshold) -
  **disabled for corporate** because its amount population doesn't follow a
  Benford-conforming distribution at all (data-generation artifact, not fraud signal).
- **Lightweight network features** (fan-in/fan-out, merchant concentration) - no graph
  neural network.

Every feature is causal (`shift(1)`/`expanding()`, never a future or current row) -
verified in `tests/unit/test_no_lookahead_static.py` and
`tests/integration/test_no_lookahead_data.py`.

**Performance note:** the personal amount-percentile and multi-window velocity features
were originally computed via O(n²) nested Python loops. Profiling showed this alone
consumed 134 of `prep.py`'s 205 seconds. Replaced with vectorized equivalents
(`velocity_vectorized()` via binary search, `pct_rank_vectorized()` via a numpy
comparison matrix) - proven byte-for-byte equivalent to the original logic, including
the tied-timestamp edge case, in `tests/unit/test_prep_optimization_equivalence.py` and
verified again against real sampled entities from the actual dataset. Result:
`prep.py` 205s → 15.1s; full pipeline ~220-230s → ~126-173s (see Section 19). This
optimization alone changed zero downstream metrics (confirmed identical before/after).

**Future-distribution leakage fix (separate change, does affect metrics):**
`amount_pct_rank_peer_group` originally ranked each transaction's amount against the
*entire* vertical column (`.groupby("vertical")["amount"].rank(pct=True)`), meaning an
early transaction's percentile was influenced by transactions that hadn't happened yet
at its own scoring time - not label leakage, but inappropriate for a feature meant to
reflect what would actually be knowable in a real-time deployment. Fixed by freezing the
reference distribution to the TRAIN period only (via `model.three_way_split`, the same
chronological split already used to fit the ML models - mirroring how `StandardScaler`
is fit on train and applied everywhere). Proven by a dedicated regression test
(`tests/unit/test_peer_group_percentile_causal.py`) showing a train-period transaction's
percentile is unaffected even when later (holdout-period) amounts are changed by orders
of magnitude. This fix legitimately changed some downstream metrics - see Section 11.

## 6. Risk Engine

`risk_engine.py` outputs a 0-100 composite score with exposed component contributions
(`model_score`, `rule_score`, `benford_score`, `network_score`) and a risk tier
(`auto_clear` / `standard_review` / `priority_review` / `immediate_escalation`), all
calibrated on **validation data only**, targeting a 15% false-positive rate. The
dashboard labels this breakdown "Relative Signal Strength," not additive percentages,
since the components aren't a true decomposition of the score.

## 7. Evidence / RAG

`evidence.py` generates structured documents (`document_id`, `transaction_id`,
`source_type`, `source_system="SENTINEL_SYNTH"`, `created_at`, `author`, `department`,
`text`, `metadata`) - always tagged synthetic, never presented as real. `retrieval.py`
enforces `created_at <= transaction_time` for every retrieval unless `retrospective=True`
is explicit - verified against 30 sampled transactions with zero violations
(`tests/integration/test_retrieval_and_evidence.py`). TF-IDF stands in for FAISS/embeddings (no
embedding-model downloads available in this sandboxed environment).

## 8. Investigation Agent

`agent.py`: risk signals → account history → evidence retrieval → supporting evidence →
**mandatory counter-evidence check** → sufficiency determination → structured,
**Pydantic-validated** `Investigation` output. Tool functions (`get_transaction`,
`get_account_history`, `search_evidence`, `get_risk_signals`) are the only way the agent
obtains facts - it cannot invent transaction details.

**Live LLM vs. deterministic fallback:** when `ANTHROPIC_API_KEY` is set, `call_agent()`
drives a real Claude call and validates the response against the schema, falling back to
the deterministic path if validation fails. **This environment has no API key**, so only
the deterministic fallback (`deterministic_investigate()`) has actually been executed
and tested end-to-end - it performs the real supporting/counter-evidence logic, just via
rules rather than an LLM, and produces the identical schema. Stated explicitly rather
than implied to be live-LLM-tested.

`confidence` in the output schema is explicitly documented as **not** a probability of
fraud - it reflects evidence sufficiency and signal consistency (see Section 15).

## 9. Auditor Workflow

`app.py` (FastAPI): `GET /health`, `GET /queue`, `GET /case/{id}`,
`POST /case/{id}/investigate`, `POST /case/{id}/decision`, `GET /audit_trail/{id}`,
`GET /metrics`, `GET /model-info`. Auditor actions: ACCEPT, ESCALATE, DISMISS,
REQUEST_MORE_EVIDENCE. Every case, investigation, and decision persists to SQLite -
verified to survive a full process restart (`tests/unit/test_db_and_api.py`, plus a manual
restart-and-reread check documented in `ENGINEERING_REPORT.md`).

## 10. Database

SQLite (`db.py`): `transactions`, `risk_scores`, `cases`, `investigations`,
`audit_events`, `model_versions`. Chosen for reproducible local deployment - a real
deployment would swap this for PostgreSQL behind the same `db.py` interface.

## 11. Evaluation

All metrics computed on **holdout only** (the time window never touched by fitting,
contamination selection, or threshold/weight calibration):

| Vertical | IsoForest AUC | Autoencoder AUC | Benford AUC | Rules AUC | Composite AUC |
|---|---|---|---|---|---|
| AML | 0.972 | 0.806 | 0.501 (no signal) | 0.676 | 0.970 |
| Corporate | 0.707 | 0.674 | disabled | 0.665 | 0.707 |
| Retail | 0.701 | 0.670 | 0.501 (no signal) | 0.670 | 0.700 |

AML's autoencoder AUC improved from 0.758 to 0.806 after the peer-group percentile
leakage fix above - a genuine, unforced improvement from removing a leaky feature, not
a retune. Numbers regenerated by rerunning the full pipeline after the fix; not the
pre-fix values.

Full precision/recall/F1/Precision@K tables: `reports/evaluation_report.md`.

## 12. Ablation

The original fixed composite weights (25% isoforest / 25% autoencoder / 30% Benford /
20% rules) **underperformed ML alone in every vertical** (AML composite AUC 0.937 vs.
0.972 ML-only) - not smoothed over, reported and then fixed via a validation-only grid
search (`weight_calibration.py`):

| Vertical | Old weights AUC | Calibrated weights AUC | Change |
|---|---|---|---|
| AML | 0.937 | 0.970 | +0.033 |
| Corporate | 0.706 | 0.707 | +0.001 |
| Retail | 0.679 | 0.700 | +0.022 |

Full 5-configuration comparison: `reports/ablation_report.md`.

## 13. Workload Results

| Vertical | Flagged for review | Workload reduction | Fraud caught in queue | Top-5% capture |
|---|---|---|---|---|
| AML | 23.2% | 76.8% | 304/308 (98.7%) | 72.1% |
| Corporate | 19.2% | 80.8% | 138/261 (52.9%) | 46.0% |
| Retail | 17.4% | 82.6% | 334/664 (50.3%) | 34.3% |

Cost-sensitive evaluation (stated placeholder cost assumptions, not sourced from real
client data) and the full workload breakdown: `reports/workload_report.md`.

## 14. Limitations

- All 3 datasets appear to share one synthetic generator - every number in this
  repository is a baseline sanity check, not a validated real-world result.
- The "autoencoder" is a small bottleneck MLP, not a deep autoencoder.
- Evidence text is fabricated/templated.
- The live-LLM agent path is unexercised in this environment (no API key available).
- Rule thresholds and cost assumptions are explicitly stated placeholders.
- TF-IDF, not real embeddings, powers retrieval (environment constraint).
- The corporate vertical's fraud capture is materially weaker than AML's (52.9% vs.
  98.7% in the review queue) - reported as-is, not adjusted to look better.

## 15. Responsible AI

- **Human-in-the-loop**: the agent recommends (ACCEPT/ESCALATE/DISMISS/
  REQUEST_MORE_EVIDENCE); only a recorded auditor decision is authoritative.
- **Evidence grounding**: every factual claim in an investigation must trace to a real
  `document_id` from `search_evidence()` - verified in
  `tests/integration/test_agent_schema_data.py::test_agent_never_fabricates_document_ids`.
- **Counter-evidence is mandatory to check**, not optional - the `Investigation` schema
  requires the field to exist even when empty, and the deterministic path has been
  observed to downgrade a would-be HIGH/CRITICAL case to MEDIUM after finding a matching
  approval record (Case 3 in `demo.py`).
- **No automatic fraud accusation** - `finding` and `recommended_action` never claim
  fraud occurred, only that a transaction merits investigation.
- **Investigation confidence is not a fraud probability** - explicitly documented in the
  schema and the UI (Section 8).
- **Model versioning + audit trail**: every case, investigation, and decision is
  attributed, timestamped, and versioned (`model_version` on every table).
- **Uncertainty handling**: `evidence_sufficiency: INSUFFICIENT` is a valid, expected
  output, not a failure state.
- **Fallback behavior**: documented explicitly in Section 8, not glossed over.

## 16. Synthetic Data Disclosure

All three datasets are synthetic and appear to share a common generator (identical
schema; several fields are constant placeholders with zero real variance - e.g.
corporate's `device_id` and `location`). **No claim in this repository should be read
as a real-world fraud-detection performance figure.** Every metric is described as
"on the provided synthetic benchmark."

## 17. Setup

```bash
pip install -r requirements.txt
```

## 18. Testing (fast unit tests, no pipeline required)

```bash
python3 -m pytest tests/unit -q
```

**28 tests, ~2 seconds, from a genuinely clean checkout** - verified directly, not
assumed: these tests use small synthetic fixtures or pure logic/schema checks and never
read a generated pipeline artifact, by construction (`tests/unit/` has no fixture that
can read one - see `tests/conftest.py`, which only does `sys.path` setup). This
includes `tests/unit/test_prep_optimization_equivalence.py` (proving the vectorized
`prep.py` functions are equivalent to the originals) and
`tests/unit/test_peer_group_percentile_causal.py` (proving the future-distribution
leakage fix in Section 5, added alongside that fix).

## 19. One-Command Pipeline Execution

```bash
python3 run_pipeline.py
```

**Measured runtime: ~126-173s** across multiple clean-checkout runs in this
environment (some variance observed, reported as a range rather than a single number to
avoid implying more precision than actually measured) - well under the original
implementation's ~220-230s - see Section 5 for what changed and why. Produces every
`.parquet`/`.json`/`.csv` file the integration tests and reports depend on, plus
`sentinel.db` and `reports/*.md` + `reports/architecture_diagram.png`.

## 20. Integration Tests & Demo

```bash
python3 -m pytest tests/integration -q   # 27 tests - run AFTER run_pipeline.py
python3 demo.py                          # 3 deterministic cases, printed + persisted to sentinel.db
uvicorn app:app --reload                 # API on http://localhost:8000
```

Then, in a separate terminal: `cd frontend && npm install && npm run dev` (the
multi-page React/Vite console - Risk Queue / Investigation / Audit Trail). It points at
`http://localhost:8000` by default; copy `frontend/.env.example` to `frontend/.env` and
set `VITE_API_BASE_URL` if the API runs elsewhere.

**Full test suite:** `python3 -m pytest tests/ -q` runs all 68 tests (41 unit + 27
integration) - **verified end-to-end from a completely clean checkout** in this exact
sequence: `pip install` → `pytest tests/unit` (~7-10s, 41 passed) → `run_pipeline.py`
(~180-200s) → `pytest tests/integration` (~35-45s, 27 passed) → `frontend: npm ci &&
npm run build` → live end-to-end HTTP workflow including a genuine process restart to
confirm persistence. See `ENGINEERING_REPORT.md` for the full verification log.

**Recommended demo flow:** `run_pipeline.py` (narrate the Benford-disable and
weight-calibration findings as they print) → `demo.py` (walk through all 3 cases,
especially Case 3's counter-evidence-driven dismissal) → start the API and dashboard →
click a few more live queue items, run an investigation, record a decision, refresh the
browser to show it persisted → open the Executive Summary view for the aggregate story.

## 21. Future Production Architecture

Replace local CSV/SQLite with enterprise ERP/GL connectors and a production feature
store; swap TF-IDF for a real embedding model + managed vector store (the `EvidenceStore`
interface is the documented swap point); replace the bottleneck-MLP autoencoder with a
proper deep model if justified by real data; add IAM/RBAC and real authentication (out
of scope for this prototype, stated plainly rather than faked); add a real drift-alerting
pipeline on live rolling windows instead of the train-vs-holdout comparison used here;
validate every threshold, rule limit, and cost assumption against real client data before
any production use. The logical architecture (validation → features → detection → risk
→ queue → evidence → agent → case → auditor → audit trail → monitoring) does not need to
change - only the infrastructure underneath each stage does.

## 22. Mentor-Aligned Business Use Cases

Three focused, explainable business scenarios layered on top of the existing risk
engine (`use_cases.py`) - not competing detection models. Each reuses existing signals
wherever they already exist, per the same "don't build a parallel system" discipline
used throughout this project.

### 1. New Device + High-Value Transaction

**Business problem:** a transaction from a device never seen before on this
account, combined with an unusually large amount, is a classic account-takeover
pattern.

**Detection logic:** reuses `prep.py`'s existing causal `is_new_device` flag directly,
combined with the (leakage-fixed) `amount_pct_rank_peer_group >= 0.95`. No new
computation - a business interpretation of two signals already trustworthy. Only
meaningful where `device_id` genuinely varies (`config.HAS_MEANINGFUL_DEVICE_ID` =
retail only in this dataset - corporate/AML's `device_id` is a constant placeholder,
confirmed by direct cardinality check, not assumed) - forced to 0 elsewhere rather than
reporting a meaningless "new device" on every entity's first-ever transaction.

**Signals:** `uc_new_device_high_value` (0/1).

**Coverage in this dataset:** 931 detections, retail only (as expected/documented).
Zero in corporate/AML - a genuine data-structure limitation, not a bug.

### 2. Fan-In / Fan-Out Transaction Network

**Business problem:** an entity receiving from unusually many distinct counterparties
(fan-in, e.g. a mule/collection account) or sending to unusually many (fan-out, e.g.
layering) is a classic AML/fraud network pattern.

**Detection logic:** a NEW rolling (30-day, configurable), strictly causal (prior
transactions only) distinct-counterparty count - `network.py`'s existing
`counterparty_account_fanin` is population-wide and non-rolling, a genuinely different
computation, added alongside it rather than replacing it. Adapted honestly to this
dataset's structure: `account_id`/`customer_id` and `counterparty_id` are different ID
namespaces (a GL account is never itself a vendor) - there's no single node that is
both sender and receiver here, so fan-in is computed on the transaction's
**counterparty** (the receiver) and fan-out on the transaction's **entity** (the
sender), both attached to every row. Thresholds are the 95th percentile of the
TRAIN-only distribution per vertical (same frozen-reference pattern as the peer-group
percentile leakage fix), never recalculated against validation/holdout.

**Signals:** `uc_fan_in_fan_out` (0=none, 1=fan-in, 2=fan-out, 3=both), plus
`fan_in_count_30d` / `fan_out_count_30d`.

**Coverage:** AML 6,965 detections (2,382 fan-in / 4,701 fan-out), corporate 6,348
(3,831 / 2,608), retail 7,826 (3,249 / 4,716) - present and meaningful in all three
verticals.

### 3. Near-Threshold Structuring

**Business problem:** repeated transactions individually below an approval/reporting
limit, clustering in a short period, is a classic structuring/smurfing pattern.

**Detection logic:** defines its own near-threshold band (70% of `config.APPROVAL_LIMIT`,
independent from `rules.py`'s existing 95%-band `flag_just_under_limit` rule - checked
empirically before choosing this, not guessed: at the existing rule's narrower band,
the maximum cluster size observed in ANY vertical at ANY window up to 90 days never
reached 3). The window was similarly widened from an initial 7-day starting point to
60 days after checking real cluster sizes at 7/14/30/60/90 days - AML (the densest
vertical) only reaches a genuine 3-transaction cluster at 60 days; corporate never
exceeds 2 regardless of window (too sparse - ~13 transactions/entity/year); retail
cannot support this use case AT ALL regardless of configuration, because retail amounts
structurally never approach its configured limit (max observed ~₹7,994 vs. a ₹10,000
limit - even the 99th percentile is only ~₹1,273). Reported honestly rather than
lowering the retail limit to manufacture detections.

**Signals:** `uc_near_threshold_structuring` (0/1), plus `near_threshold_cluster_count`.

**Coverage:** 7 detections, AML only - documented and expected, not a bug (see above).

**Example (real transaction, holdout data):** entity with 3 near-threshold wires
(≥70% of the illustrative ₹500,000 AML threshold) within 60 days - full trace in
`demo.py`'s `run_mentor_usecase_demos()`.

### Integration

All three signals flow through the existing pipeline unchanged elsewhere: `use_cases.py`
runs after the final `risk_engine.py` pass, is persisted to a new (additive)
`use_case_signals` SQLite table, exposed via `/queue` and `/case/{id}`, surfaced to the
investigation agent (`SentinelTools.get_use_case_context()` - included in both the
deterministic fallback's `anomaly_drivers` and the live-LLM system prompt), shown in the
dashboard (queue badges, a filter, and a dedicated "Mentor-Aligned Use Case" section on
the investigation screen), and included in `demo.py`'s output. The existing risk score
and calibration are untouched - these are an explanatory layer, not a second risk engine
(Section 6 remains authoritative).

### Limitations

The prototype demonstrates transaction-level and behavioral risk patterns using the
available synthetic transaction data. Where authentication/login-event, IP, or
geolocation feeds are unavailable, the system does not claim to detect a literal login
event - "new device" means "first time this device_id appears in this entity's
transaction history," not an authenticated login. Retail structurally cannot support
Use Case 3 in this dataset (see above) - documented rather than worked around. All
approval/reporting thresholds throughout are explicitly illustrative, not sourced from
any real regulatory limit.
