"""
Sentinel AI v2 - apply the validation-calibrated composite weights to holdout, ONCE,
and report an honest before/after against the original fixed prototype weights.

IMPORTANT ORDERING NOTE: risk_scored_holdout.parquet's `composite_score` column reflects
WHICHEVER weights risk_engine.py last used to write it - in run_pipeline.py, risk_engine.py
runs a second time AFTER weight_calibration.py specifically so the production
scored_transactions.parquet ends up using calibrated weights. That means by the time this
script runs, `composite_score` in the holdout file is already the CALIBRATED version, not
the original fixed-weight one - comparing it to itself would show a fake zero-change
"before/after" (this was caught by generate_reports.py rendering a suspicious all-zeros
table, not assumed). Fixed by recomputing the OLD fixed-weight composite directly from the
underlying component score columns (isoforest_score, autoencoder_score, benford_score,
rule_score), which are never overwritten - only composite_score itself is.
"""
import pandas as pd
import numpy as np
import json
from sklearn.metrics import roc_auc_score, average_precision_score
from weight_calibration import score_with_weights
from config import COMPOSITE_WEIGHTS, COMPOSITE_WEIGHTS_NO_BENFORD, BENFORD_DISABLED_VERTICALS

def old_fixed_weight_composite(sub, vertical):
    w = COMPOSITE_WEIGHTS_NO_BENFORD if vertical in BENFORD_DISABLED_VERTICALS else COMPOSITE_WEIGHTS
    return (
        w["isoforest"] * sub["isoforest_score"] * 100
        + w["autoencoder"] * sub["autoencoder_score"] * 100
        + w.get("benford", 0) * sub["benford_score"]
        + w["rules"] * sub["rule_score"]
    )

def main():
    holdout = pd.read_parquet("risk_scored_holdout.parquet")
    with open("calibrated_composite_weights.json") as f:
        calibrated = json.load(f)

    rows = []
    for vertical, sub in holdout.groupby("vertical"):
        y = sub["fraud_label"].values
        old_score = old_fixed_weight_composite(sub, vertical)
        old_auc = roc_auc_score(y, old_score)
        old_pr = average_precision_score(y, old_score)

        w = calibrated[vertical]["weights"]
        new_score = score_with_weights(sub, w)
        new_auc = roc_auc_score(y, new_score)
        new_pr = average_precision_score(y, new_score)

        rows.append({
            "vertical": vertical,
            "old_weights_roc_auc": round(old_auc, 4), "old_weights_pr_auc": round(old_pr, 4),
            "calibrated_weights_roc_auc": round(new_auc, 4), "calibrated_weights_pr_auc": round(new_pr, 4),
            "roc_auc_change": round(new_auc - old_auc, 4),
            "weights_used": w,
        })

    result = pd.DataFrame(rows)
    print(result.drop(columns="weights_used").to_string(index=False))
    result.to_csv("weight_calibration_before_after.csv", index=False)
    print("\nWeights used per vertical:")
    for r in rows:
        print(" ", r["vertical"], r["weights_used"])
    print("\nSaved weight_calibration_before_after.csv")

if __name__ == "__main__":
    main()
