"""
Sentinel AI v2 - Benford's Law first-digit check, computed per behavioral entity.

Uses the Mean Absolute Deviation (MAD) conformity test (Nigrini, 2012) rather than a
chi-square p-value: chi-square significance scales with n, so at n in the tens of
thousands even trivial digit-distribution deviations become "significant" - that
produced a degenerate ~100% flag rate on an earlier pass of this code. MAD thresholds
by themselves are ALSO sample-size sensitive at small n (a cohort of ~100-300 will show
elevated MAD from pure sampling noise even when genuinely Benford-conforming), so the
flag threshold is calibrated per cohort size via simulation rather than using a single
fixed cutoff for every cohort.

Empirical finding carried into config.py: the corporate vertical's amounts do not
follow a Benford-conforming distribution AT ALL (population-level MAD is large
regardless of vendor) - this is a data-generation artifact of this synthetic dataset,
not a fraud signal, and corporate is excluded from Benford scoring entirely
(config.BENFORD_DISABLED_VERTICALS) rather than emit a flag on ~98% of vendors.
"""
import pandas as pd
import numpy as np
from config import BENFORD_COHORT_COL, BENFORD_DISABLED_VERTICALS

BENFORD_PROBS = np.array([np.log10(1 + 1/d) for d in range(1, 10)])
MIN_COHORT = 30

def first_digit(x):
    x = abs(x)
    while x < 1 and x != 0:
        x *= 10
    s = str(int(x))
    return int(s[0]) if s and s[0] != '0' else np.nan

def mad_score(digits):
    digits = digits.dropna()
    n = len(digits)
    if n < MIN_COHORT:
        return np.nan, n
    counts = digits.value_counts().reindex(range(1, 10), fill_value=0).sort_index()
    observed_probs = (counts / n).values
    return np.mean(np.abs(observed_probs - BENFORD_PROBS)), n

_threshold_cache = {}
def simulated_threshold(n, n_sims=400, alpha=0.01, seed=0):
    if n in _threshold_cache:
        return _threshold_cache[n]
    rng = np.random.default_rng(seed)
    draws = rng.choice(np.arange(1, 10), size=(n_sims, n), p=BENFORD_PROBS)
    mads = np.array([
        np.mean(np.abs(np.bincount(row, minlength=10)[1:10] / n - BENFORD_PROBS))
        for row in draws
    ])
    thr = float(np.quantile(mads, 1 - alpha))
    _threshold_cache[n] = thr
    return thr

def add_benford_scores(df, entity_col):
    df = df.copy()
    df["first_digit"] = df["amount"].apply(first_digit)

    scores = df.groupby(entity_col)["first_digit"].apply(mad_score)
    mad_by_entity = scores.apply(lambda t: t[0])
    n_by_entity = scores.apply(lambda t: t[1])
    threshold_by_entity = n_by_entity.apply(lambda n: simulated_threshold(int(n)) if n >= MIN_COHORT else np.nan)

    df["benford_mad"] = df[entity_col].map(mad_by_entity)
    df["benford_threshold"] = df[entity_col].map(threshold_by_entity)
    df["benford_flag"] = (df["benford_mad"] >= df["benford_threshold"]).fillna(False).astype(int)
    df["benford_insufficient_data"] = df["benford_mad"].isna().astype(int)
    return df

if __name__ == "__main__":
    full = pd.read_parquet("normalized_features_rules.parquet")
    out = []
    for vertical, sub in full.groupby("vertical"):
        if vertical in BENFORD_DISABLED_VERTICALS:
            sub = sub.copy()
            sub["first_digit"] = np.nan
            sub["benford_mad"] = np.nan
            sub["benford_threshold"] = np.nan
            sub["benford_flag"] = 0
            sub["benford_insufficient_data"] = 1
            print(f"{vertical}: Benford DISABLED (config.BENFORD_DISABLED_VERTICALS) - "
                  f"population does not follow a Benford-conforming distribution")
        else:
            cohort_col = BENFORD_COHORT_COL[vertical]
            sub = add_benford_scores(sub, cohort_col)
            flagged = sub["benford_flag"].mean()
            print(f"{vertical}: benford flag rate = {flagged:.2%}, cohort = {cohort_col}, "
                  f"cohorts = {sub[cohort_col].nunique()}")
        out.append(sub)
    full2 = pd.concat(out, ignore_index=True)
    full2.to_parquet("normalized_features_benford.parquet", index=False)
    print("Saved normalized_features_benford.parquet:", full2.shape)
