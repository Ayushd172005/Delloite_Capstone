"""
Sentinel AI v2 - lightweight drift monitoring.

Compares TRAIN vs HOLDOUT distributions (the same split already used for modeling -
no new data needed) on a handful of population-level statistics. Deliberately simple:
percentage shift beyond a threshold is flagged for human review, nothing more elaborate.
In a real deployment this would run on a rolling window of live data vs. the original
training baseline.
"""
import pandas as pd
import numpy as np
import json

DRIFT_THRESHOLD_PCT = 20.0  # flag if a stat shifts by more than this % relative to baseline

def compute_stats(df):
    return {
        "n_rows": len(df),
        "amount_mean": float(df["amount"].mean()),
        "amount_std": float(df["amount"].std()),
        "amount_p95": float(df["amount"].quantile(0.95)),
        "transaction_frequency_mean": float(df["transaction_frequency"].mean()) if "transaction_frequency" in df else None,
        "anomaly_rate_isoforest_top5pct_score": float(df["isoforest_score"].quantile(0.95)) if "isoforest_score" in df else None,
        "missing_value_rate": float(df.isnull().mean().mean()),
        "new_counterparty_rate": float(df["is_new_counterparty"].mean()) if "is_new_counterparty" in df else None,
    }

def compare(baseline_stats, current_stats):
    rows = []
    # n_rows is excluded from drift flagging: train/holdout are different-sized time
    # windows by design (this is a split-size artifact, not population drift).
    skip_for_flagging = {"n_rows"}
    for key in baseline_stats:
        b, c = baseline_stats[key], current_stats.get(key)
        if b is None or c is None or not isinstance(b, (int, float)):
            continue
        pct_change = ((c - b) / b * 100) if b != 0 else (0 if c == 0 else float("inf"))
        rows.append({
            "metric": key, "baseline": round(b, 4), "current": round(c, 4),
            "pct_change": round(pct_change, 2),
            "flagged": abs(pct_change) > DRIFT_THRESHOLD_PCT and key not in skip_for_flagging,
        })
    return pd.DataFrame(rows)

if __name__ == "__main__":
    train = pd.read_parquet("risk_scored_train.parquet")
    holdout = pd.read_parquet("risk_scored_holdout.parquet")

    report = {}
    for vertical in train["vertical"].unique():
        baseline = compute_stats(train[train["vertical"] == vertical])
        current = compute_stats(holdout[holdout["vertical"] == vertical])
        cmp = compare(baseline, current)
        report[vertical] = cmp.to_dict("records")
        print(f"\n=== {vertical}: train (baseline) vs holdout (current) ===")
        print(cmp.to_string(index=False))
        flagged = cmp[cmp["flagged"]]
        if len(flagged):
            print(f"  DRIFT FLAGGED on: {list(flagged['metric'])}")

    with open("drift_report.json", "w") as f:
        json.dump(report, f, indent=2)
    print("\nSaved drift_report.json")
