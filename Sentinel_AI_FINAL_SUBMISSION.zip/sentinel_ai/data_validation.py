"""
Sentinel AI v2 - Data validation.

Runs before any feature engineering. Produces a concrete data-quality report rather
than assuming the raw files are clean.
"""
import pandas as pd
import numpy as np

REQUIRED_COLUMNS = [
    "transaction_id", "transaction_time", "amount", "transaction_type", "customer_id",
    "merchant_id", "account_id", "location", "device_id", "payment_method",
    "transaction_frequency", "balance_before", "balance_after", "fraud_label",
]

def validate_dataset(df, name):
    issues = []
    report = {"dataset": name, "n_rows": len(df)}

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        issues.append(f"Missing required columns: {missing_cols}")

    null_counts = df.isnull().sum()
    report["null_counts"] = {k: int(v) for k, v in null_counts[null_counts > 0].items()}
    if null_counts.sum() > 0:
        issues.append(f"{int(null_counts.sum())} null values found across columns: {list(report['null_counts'].keys())}")

    dup_ids = df["transaction_id"].duplicated().sum() if "transaction_id" in df.columns else None
    report["duplicate_transaction_ids"] = int(dup_ids) if dup_ids is not None else "n/a"
    if dup_ids:
        issues.append(f"{dup_ids} duplicate transaction_id values")

    if "amount" in df.columns:
        neg_amounts = (df["amount"] <= 0).sum()
        report["non_positive_amounts"] = int(neg_amounts)
        if neg_amounts:
            issues.append(f"{neg_amounts} transactions with amount <= 0")

    if {"balance_before", "balance_after"}.issubset(df.columns):
        impossible_balance = (df["balance_after"] < 0).sum()
        report["negative_balance_after"] = int(impossible_balance)
        if impossible_balance:
            issues.append(f"{impossible_balance} transactions with negative balance_after")

        depletion_gt_1 = ((df["balance_before"] - df["balance_after"]) / df["balance_before"].replace(0, np.nan) > 1).sum()
        report["depletion_ratio_gt_100pct"] = int(depletion_gt_1) if not np.isnan(depletion_gt_1) else 0
        if depletion_gt_1:
            issues.append(f"{depletion_gt_1} transactions where balance dropped by >100% of balance_before (data anomaly, not necessarily fraud)")

    if "transaction_time" in df.columns:
        try:
            parsed = pd.to_datetime(df["transaction_time"], errors="coerce")
            bad_dates = parsed.isna().sum()
            report["unparseable_timestamps"] = int(bad_dates)
            if bad_dates:
                issues.append(f"{bad_dates} unparseable timestamps")
            report["date_range"] = [str(parsed.min()), str(parsed.max())]
            report["timestamps_are_date_only"] = bool((parsed.dt.time == pd.Timestamp("00:00:00").time()).all())
        except Exception as e:
            issues.append(f"Timestamp parsing failed entirely: {e}")

    if "fraud_label" in df.columns:
        vc = df["fraud_label"].value_counts(normalize=True).to_dict()
        report["fraud_label_distribution"] = {int(k): round(float(v), 4) for k, v in vc.items()}
        unexpected = set(df["fraud_label"].unique()) - {0, 1}
        if unexpected:
            issues.append(f"fraud_label has unexpected values: {unexpected}")

    report["issues"] = issues
    report["status"] = "PASS" if not issues else "PASS_WITH_WARNINGS"
    return report

def validate_all(paths):
    reports = []
    for name, path in paths.items():
        df = pd.read_csv(path)
        reports.append(validate_dataset(df, name))
    return reports

if __name__ == "__main__":
    import json
    paths = {"corporate": "pro_dataset_corporate.csv", "aml": "pro_dataset_aml.csv", "retail": "pro_dataset_retail.csv"}
    reports = validate_all(paths)
    for r in reports:
        print(f"\n=== {r['dataset']} ({r['status']}) ===")
        for issue in r["issues"]:
            print("  -", issue)
        if not r["issues"]:
            print("  (no issues found)")
    with open("data_quality_report.json", "w") as f:
        json.dump(reports, f, indent=2, default=str)
    print("\nSaved data_quality_report.json")
