"""
Sentinel AI v2 - Configuration.

All rule thresholds and policy parameters live here, not scattered inside business
logic. Every threshold below is an ILLUSTRATIVE PROTOTYPE POLICY THRESHOLD, not a
regulatory requirement or a real client limit - replace with actual client/regulatory
values before any real deployment. This is stated once here rather than repeated at
every call site.
"""

# Approval/reporting limits used by the "just under limit" rule - PLACEHOLDER VALUES.
APPROVAL_LIMIT = {"corporate": 150000, "aml": 500000, "retail": 10000}

# Behavioral entity used for rolling/velocity features per vertical. AML's account_id
# is a near-unique per-transaction SWIFT reference (see prep.py), so the recurring
# entity there is customer_id instead.
ENTITY_COL = {"corporate": "account_id", "aml": "customer_id", "retail": "account_id"}

# Cohort used specifically for the Benford digit test - the population that "submits"
# the amounts. Distinct from ENTITY_COL: per-account cohorts for corporate/retail are
# too thin (~13-23 txns/account) for a reliable digit test, so Benford runs per
# counterparty (vendor/merchant, ~115 txns each) there instead.
BENFORD_COHORT_COL = {"corporate": "counterparty_id", "aml": "customer_id", "retail": "counterparty_id"}

# Verticals where Benford's Law was empirically found NOT to discriminate fraud at all
# (see benford.py docstring / evaluation report). Excluded from the composite score
# and flagged to the investigation agent so it doesn't cite an unreliable signal.
BENFORD_DISABLED_VERTICALS = {"corporate"}

# Verticals where device_id/location actually vary (are real signals). In this dataset,
# corporate's device_id AND location are literally constant (1 unique value across all
# 115,000 rows) and AML's device_id is also constant - these are synthetic filler fields,
# not real signals, and a "network" feature built on a constant column produces a
# meaningless 100%-everywhere result rather than an absent one. Confirmed by direct
# cardinality check before writing this, not assumed.
HAS_MEANINGFUL_DEVICE_ID = {"retail"}
HAS_MEANINGFUL_LOCATION = {"aml", "retail"}

# Verticals with real intraday timestamps. Corporate and AML timestamps in the raw
# data are date-only (always 00:00:00), so an "off-hours" rule would fire on 100% of
# their transactions - it's a data artifact, not a signal, there.
HAS_INTRADAY_TIMESTAMPS = {"retail"}

RULE_PARAMS = {
    "just_under_limit_ratio": 0.95,      # flag if amount is within 5% below the approval limit
    "round_number_percentile": 0.90,     # round-number rule only fires in the top 10% of amounts
    "velocity_spike_multiplier": 3.0,    # 30-day velocity >= 3x the account's own historical average
    "new_counterparty_percentile": 0.90, # "high value" for the new-counterparty rule = top 10%
    "balance_depletion_threshold": 0.5,  # single transaction draining >50% of balance
    "dormant_reactivation_days": 90,     # first transaction after 90+ days of inactivity
}

# Composite score component weights. Renormalized without Benford for verticals in
# BENFORD_DISABLED_VERTICALS (see risk_engine.py).
COMPOSITE_WEIGHTS = {"isoforest": 0.25, "autoencoder": 0.25, "benford": 0.30, "rules": 0.20}
COMPOSITE_WEIGHTS_NO_BENFORD = {"isoforest": 0.40, "autoencoder": 0.40, "rules": 0.20}

# Review tier cutoffs on the 0-100 composite score. Calibrated in calibrate_thresholds.py
# against TRAINING/VALIDATION data only - never against holdout labels (see model.py).
DEFAULT_REVIEW_TIERS = [
    (40, "auto_clear"),
    (70, "standard_review"),
    (90, "priority_review"),
    (101, "immediate_escalation"),
]

def tier_for_score(score, tiers=None):
    tiers = tiers or DEFAULT_REVIEW_TIERS
    for cutoff, label in tiers:
        if score < cutoff:
            return label
    return tiers[-1][1]

# Time-based split: how much of the timeline to use for training vs. calibration
# validation vs. final holdout evaluation. Three-way split (not two) so the threshold
# can be calibrated on validation data without ever looking at the holdout.
SPLIT_MONTHS = {"train_end_month": 8, "validation_end_month": 10}  # holdout = everything after

RANDOM_SEED = 42
