"""
Unit tests for use_cases.py - the three mentor-aligned business use cases. All use
small synthetic fixtures (no pipeline artifacts required), per the project's
established unit/integration split (tests/unit/ must never trigger a pipeline run).
"""
import pandas as pd
import numpy as np
from use_cases import (
    rolling_distinct_count_causal, add_use_case_3, UC3_MIN_CLUSTER_COUNT,
    UC3_STRUCTURING_WINDOW_DAYS, UC3_NEAR_THRESHOLD_RATIO,
)


# ---------------------------------------------------------------------------
# Use Case 1 relies entirely on prep.py's existing is_new_device and
# amount_pct_rank_peer_group - both already covered by
# tests/unit/test_no_lookahead_static.py, tests/integration/test_no_lookahead_data.py,
# and tests/unit/test_peer_group_percentile_causal.py. No new logic to test here
# beyond the business-rule AND-combination itself, tested directly below.
# ---------------------------------------------------------------------------

def test_uc1_requires_both_conditions_together():
    from use_cases import add_use_case_1
    df = pd.DataFrame({
        "vertical": ["retail"] * 4,
        "is_new_device": [1, 1, 0, 0],
        "amount_pct_rank_peer_group": [0.97, 0.50, 0.97, 0.50],
        "device_id": ["D1", "D2", "D3", "D4"],
    })
    out = add_use_case_1(df)
    # only row 0 has BOTH new device AND high value
    assert list(out["uc_new_device_high_value"]) == [1, 0, 0, 0]

def test_uc1_forced_zero_for_verticals_without_meaningful_device_id():
    from use_cases import add_use_case_1
    df = pd.DataFrame({
        "vertical": ["corporate", "aml"],
        "is_new_device": [1, 1],  # would trigger if not forced to 0
        "amount_pct_rank_peer_group": [0.99, 0.99],
        "device_id": ["CONST", "CONST"],
    })
    out = add_use_case_1(df)
    assert list(out["uc_new_device_high_value"]) == [0, 0], \
        "corporate/aml device_id is a constant placeholder - UC1 must not fire there"


# ---------------------------------------------------------------------------
# Use Case 2 - rolling_distinct_count_causal (the core primitive both fan-in and
# fan-out are built from)
# ---------------------------------------------------------------------------

def test_rolling_distinct_count_first_transaction_is_zero():
    times = pd.to_datetime(["2025-01-01"]).values
    keys = np.array(["A"])
    out = rolling_distinct_count_causal(times, keys, window_days=30)
    assert list(out) == [0]

def test_rolling_distinct_count_counts_distinct_not_repeats():
    """3 transactions to counterparty A, then 1 to B - distinct count should be 1,
    then 1, then 2 (not 3) for the 4th row, since A only counts once."""
    times = pd.to_datetime(["2025-01-01", "2025-01-02", "2025-01-03", "2025-01-04"]).values
    keys = np.array(["A", "A", "A", "B"])
    out = rolling_distinct_count_causal(times, keys, window_days=30)
    assert list(out) == [0, 1, 1, 1], \
        "prior distinct count before each row: none, {A}, {A}, {A} - the 4th row's own B doesn't count itself"

def test_rolling_distinct_count_excludes_transactions_outside_window():
    """A transaction 40 days before the current one, with a 30-day window, must not count."""
    times = pd.to_datetime(["2025-01-01", "2025-02-10"]).values  # 40 days apart
    keys = np.array(["A", "B"])
    out = rolling_distinct_count_causal(times, keys, window_days=30)
    assert out[1] == 0, "the first transaction is outside the 30-day window and must not be counted"

def test_rolling_distinct_count_includes_transactions_inside_window():
    times = pd.to_datetime(["2025-01-01", "2025-01-20"]).values  # 19 days apart
    keys = np.array(["A", "B"])
    out = rolling_distinct_count_causal(times, keys, window_days=30)
    assert out[1] == 1, "the first transaction is inside the 30-day window and must count"

def test_rolling_distinct_count_future_transactions_do_not_affect_earlier_rows():
    """The core leakage check: adding a transaction AFTER row i must never change row i's count."""
    times_a = pd.to_datetime(["2025-01-01", "2025-01-05"]).values
    keys_a = np.array(["A", "B"])
    out_a = rolling_distinct_count_causal(times_a, keys_a, window_days=30)

    times_b = pd.to_datetime(["2025-01-01", "2025-01-05", "2025-01-10"]).values
    keys_b = np.array(["A", "B", "C"])  # C is a brand-new future counterparty
    out_b = rolling_distinct_count_causal(times_b, keys_b, window_days=30)

    assert out_a[0] == out_b[0], "row 0's count must be identical regardless of what happens later"
    assert out_a[1] == out_b[1], "row 1's count must be identical regardless of what happens later"


# ---------------------------------------------------------------------------
# Use Case 3 - near-threshold structuring cluster logic
# ---------------------------------------------------------------------------

def _make_structuring_df(amounts, times, entity="E1", vertical="aml"):
    n = len(amounts)
    return pd.DataFrame({
        "transaction_id": [f"T{i}" for i in range(n)],
        "transaction_time": pd.to_datetime(times),
        "amount": amounts,
        "vertical": [vertical] * n,
        "account_id": [entity] * n,
        "customer_id": [entity] * n,
    })

def test_uc3_three_near_threshold_within_window_flags():
    limit = 500000
    band_amount = limit * (UC3_NEAR_THRESHOLD_RATIO + 0.02)  # just inside the band
    df = _make_structuring_df(
        amounts=[band_amount, band_amount, band_amount],
        times=["2025-01-01", "2025-01-10", "2025-01-20"],  # all within 60 days
    )
    out = add_use_case_3(df, {"aml": limit})
    assert out.iloc[-1]["uc_near_threshold_structuring"] == 1
    assert out.iloc[-1]["near_threshold_cluster_count"] >= UC3_MIN_CLUSTER_COUNT

def test_uc3_fewer_than_minimum_does_not_flag():
    limit = 500000
    band_amount = limit * (UC3_NEAR_THRESHOLD_RATIO + 0.02)
    df = _make_structuring_df(
        amounts=[band_amount, band_amount],  # only 2, below UC3_MIN_CLUSTER_COUNT=3
        times=["2025-01-01", "2025-01-10"],
    )
    out = add_use_case_3(df, {"aml": limit})
    assert (out["uc_near_threshold_structuring"] == 0).all()

def test_uc3_transactions_outside_window_do_not_count():
    limit = 500000
    band_amount = limit * (UC3_NEAR_THRESHOLD_RATIO + 0.02)
    far_apart_days = UC3_STRUCTURING_WINDOW_DAYS + 30
    df = _make_structuring_df(
        amounts=[band_amount, band_amount, band_amount],
        times=["2025-01-01", "2025-01-05", pd.Timestamp("2025-01-01") + pd.Timedelta(days=far_apart_days)],
    )
    out = add_use_case_3(df, {"aml": limit})
    # the 3rd transaction is far outside the window from the first two - cluster should be 2, not 3
    assert out.iloc[-1]["near_threshold_cluster_count"] < UC3_MIN_CLUSTER_COUNT
    assert out.iloc[-1]["uc_near_threshold_structuring"] == 0

def test_uc3_different_entities_are_not_mixed():
    limit = 500000
    band_amount = limit * (UC3_NEAR_THRESHOLD_RATIO + 0.02)
    df_e1 = _make_structuring_df([band_amount, band_amount], ["2025-01-01", "2025-01-05"], entity="E1")
    df_e2 = _make_structuring_df([band_amount], ["2025-01-08"], entity="E2")
    df = pd.concat([df_e1, df_e2], ignore_index=True)
    out = add_use_case_3(df, {"aml": limit})
    # E1 has 2 (below minimum), E2 has 1 (below minimum) - neither should flag even though
    # combined there are 3 near-threshold transactions within the window
    assert (out["uc_near_threshold_structuring"] == 0).all(), \
        "transactions from different entities must never be combined into one cluster"

def test_uc3_amount_outside_band_does_not_count():
    limit = 500000
    low_amount = limit * 0.30  # well below the 0.70 band
    df = _make_structuring_df(
        amounts=[low_amount, low_amount, low_amount],
        times=["2025-01-01", "2025-01-10", "2025-01-20"],
    )
    out = add_use_case_3(df, {"aml": limit})
    assert (out["uc_near_threshold_structuring"] == 0).all()

def test_uc3_deterministic_across_repeated_runs():
    limit = 500000
    band_amount = limit * (UC3_NEAR_THRESHOLD_RATIO + 0.02)
    df = _make_structuring_df(
        amounts=[band_amount, band_amount, band_amount],
        times=["2025-01-01", "2025-01-10", "2025-01-20"],
    )
    out1 = add_use_case_3(df.copy(), {"aml": limit})
    out2 = add_use_case_3(df.copy(), {"aml": limit})
    pd.testing.assert_series_equal(out1["uc_near_threshold_structuring"], out2["uc_near_threshold_structuring"])
