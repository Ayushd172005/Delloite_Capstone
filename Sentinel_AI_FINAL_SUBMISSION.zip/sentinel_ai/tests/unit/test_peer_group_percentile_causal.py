"""
Regression test for the peer-group amount-percentile future-distribution-leakage fix.

Before the fix, `amount_pct_rank_peer_group` was computed via
`df.groupby("vertical")["amount"].rank(pct=True)` - ranking against the WHOLE vertical
column, so an early transaction's percentile depended on transactions that hadn't
happened yet at its own scoring time. Not label leakage, but inappropriate for a feature
meant to reflect what would actually be knowable in a real-time deployment.

Fixed by freezing the reference distribution to the TRAIN period only (via
model.three_way_split, the same chronological split model.py itself uses to fit the ML
models - mirroring how StandardScaler is fit on train and applied everywhere).

This test proves the fix directly: an early (train-period) transaction's peer-group
percentile must be IDENTICAL regardless of what happens to later (holdout-period)
transactions' amounts, even if those later amounts are made wildly different.
"""
import pandas as pd
import numpy as np
from prep import engineer_features


def _make_synthetic_vertical_df(late_amounts):
    """5 train-period rows (within the first ~20 days, well inside the default 8-month
    train window) + 5 later rows placed 9 months in (inside the holdout window given
    config.SPLIT_MONTHS defaults: train_end_month=8, validation_end_month=10)."""
    base = pd.Timestamp("2025-01-01")
    train_times = [base + pd.Timedelta(days=5 * i) for i in range(5)]
    late_times = [base + pd.DateOffset(months=9) + pd.Timedelta(days=i) for i in range(5)]
    times = train_times + late_times
    train_amounts = [100.0, 200.0, 300.0, 400.0, 500.0]
    amounts = train_amounts + late_amounts
    n = len(times)
    return pd.DataFrame({
        "transaction_id": [f"T{i}" for i in range(n)],
        "transaction_time": times,
        "amount": amounts,
        "transaction_type": ["x"] * n,
        "customer_id": ["c1"] * n,
        "counterparty_id": [f"cp{i}" for i in range(n)],
        "account_id": ["A1"] * n,
        "location": ["L1"] * n,
        "device_id": ["D1"] * n,
        "payment_method": ["P1"] * n,
        "transaction_frequency": [1] * n,
        "balance_before": [1000.0] * n,
        "balance_after": [900.0] * n,
        "fraud_label": [0] * n,
        "vertical": ["retail"] * n,
    })


def test_peer_group_percentile_unaffected_by_future_holdout_amounts():
    """The peer-group percentile of train-period rows must not change when
    holdout-period amounts change - proving no future-distribution dependency."""
    df_a = _make_synthetic_vertical_df([600.0, 700.0, 800.0, 900.0, 1000.0])
    df_b = _make_synthetic_vertical_df([50000.0, 60000.0, 70000.0, 80000.0, 90000.0])

    out_a = engineer_features(df_a.copy())
    out_b = engineer_features(df_b.copy())

    train_period_pct_a = out_a.iloc[:5]["amount_pct_rank_peer_group"].values
    train_period_pct_b = out_b.iloc[:5]["amount_pct_rank_peer_group"].values

    np.testing.assert_allclose(
        train_period_pct_a, train_period_pct_b, atol=1e-9,
        err_msg="train-period peer-group percentile changed when only future (holdout-period) "
                "amounts changed - future-distribution leakage has regressed"
    )


def test_peer_group_percentile_still_discriminates_within_train_period():
    """Sanity check: the fix shouldn't make the feature degenerate - amounts within the
    train period should still produce a monotonically increasing percentile."""
    df = _make_synthetic_vertical_df([600.0, 700.0, 800.0, 900.0, 1000.0])
    out = engineer_features(df.copy())
    train_period_pct = out.iloc[:5]["amount_pct_rank_peer_group"].values
    assert list(train_period_pct) == sorted(train_period_pct), \
        "peer-group percentile should increase monotonically with amount within the train period"
    assert train_period_pct[0] < train_period_pct[-1], "smallest and largest train amounts must differ in percentile"
