"""
Sentinel AI v2 - equivalence test for the prep.py performance optimization.

Written and run BEFORE the optimized implementation replaced the original, comparing
against a preserved copy of the exact original O(n^2)-style logic (kept below as
_reference_* functions, not deleted) on a small synthetic fixture designed to stress
the trickiest case: TIED TIMESTAMPS on the same entity (common in corporate/aml, whose
raw timestamps are date-only - see config.py). This matters because a naive time-based
rolling-window replacement can silently redefine tie behavior; this test proves the
vectorized replacement doesn't.
"""
import numpy as np
import pandas as pd
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# ---------------------------------------------------------------------------
# Reference implementations - byte-for-byte the original logic from prep.py
# before optimization, preserved here permanently as the equivalence oracle.
# ---------------------------------------------------------------------------

def _reference_velocity(times, window_days):
    """Original nested-loop implementation. times: sorted list/array of pd.Timestamp."""
    counts = []
    for i, t in enumerate(times):
        window_start = t - pd.Timedelta(days=window_days)
        counts.append(sum(1 for pt in times[:i] if pt >= window_start))
    return counts

def _reference_pct_rank(values):
    """Original nested-loop implementation. values: pd.Series in causal (time-sorted) order."""
    shifted = values.shift(1)
    out = []
    for i, v in enumerate(values):
        prior = shifted.iloc[:i + 1].dropna()
        out.append((prior < v).mean() if len(prior) else 0.5)
    return out


# ---------------------------------------------------------------------------
# Fixtures with tied timestamps - the case that actually risks a semantic change
# ---------------------------------------------------------------------------

def make_tied_timestamp_fixture():
    """5 entries, with entries 1-3 sharing the exact same timestamp (a tie cluster),
    mimicking corporate/aml's date-only raw timestamps."""
    times = pd.to_datetime([
        "2025-01-01", "2025-01-15", "2025-01-15", "2025-01-15", "2025-02-20",
    ])
    amounts = pd.Series([100.0, 500.0, 50.0, 900.0, 200.0])
    return times, amounts

def make_larger_random_fixture(n=60, n_unique_days=10, seed=1):
    """Larger fixture with heavy timestamp repetition (n_unique_days << n forces many ties)
    and random amounts, to stress-test beyond the hand-built 5-row case."""
    rng = np.random.default_rng(seed)
    days = rng.integers(0, n_unique_days, size=n)
    times = pd.to_datetime("2025-01-01") + pd.to_timedelta(days, unit="D")
    order = np.argsort(days, kind="stable")  # stable sort matches prep.py's own sort discipline
    times = times[order]
    amounts = pd.Series(rng.uniform(10, 10000, size=n))[order].reset_index(drop=True)
    times = pd.Series(times).reset_index(drop=True)
    return times, amounts


def test_velocity_equivalence_tied_timestamps():
    from prep import velocity_vectorized
    times, _ = make_tied_timestamp_fixture()
    for window_days in [7, 30]:
        expected = _reference_velocity(list(times), window_days)
        actual = velocity_vectorized(times.values, window_days)
        assert list(actual) == expected, (
            f"velocity mismatch at window={window_days}: expected {expected}, got {list(actual)}"
        )

def test_velocity_equivalence_larger_random_fixture():
    from prep import velocity_vectorized
    times, _ = make_larger_random_fixture()
    for window_days in [7, 30]:
        expected = _reference_velocity(list(times), window_days)
        actual = velocity_vectorized(times.values, window_days)
        assert list(actual) == expected, f"velocity mismatch at window={window_days} on larger fixture"

def test_pct_rank_equivalence_tied_timestamps():
    from prep import pct_rank_vectorized
    _, amounts = make_tied_timestamp_fixture()
    expected = _reference_pct_rank(amounts)
    actual = pct_rank_vectorized(amounts.values)
    np.testing.assert_allclose(actual, expected, atol=1e-9)

def test_pct_rank_equivalence_larger_random_fixture():
    from prep import pct_rank_vectorized
    _, amounts = make_larger_random_fixture()
    expected = _reference_pct_rank(amounts)
    actual = pct_rank_vectorized(amounts.values)
    np.testing.assert_allclose(actual, expected, atol=1e-9)

def test_pct_rank_equivalence_with_duplicate_amounts():
    """Duplicate amount VALUES (not just duplicate timestamps) are a separate edge case -
    ties in the compared quantity itself, which the strict '<' comparison must handle
    identically in both implementations (a tie counts as NOT less-than in both)."""
    from prep import pct_rank_vectorized
    amounts = pd.Series([100.0, 100.0, 100.0, 50.0, 200.0, 100.0])
    expected = _reference_pct_rank(amounts)
    actual = pct_rank_vectorized(amounts.values)
    np.testing.assert_allclose(actual, expected, atol=1e-9)

def test_velocity_single_row_entity():
    from prep import velocity_vectorized
    times = pd.to_datetime(["2025-03-01"])
    actual = velocity_vectorized(times.values, 30)
    assert list(actual) == [0]

def test_pct_rank_single_row_entity():
    from prep import pct_rank_vectorized
    actual = pct_rank_vectorized(np.array([42.0]))
    assert list(actual) == [0.5]
