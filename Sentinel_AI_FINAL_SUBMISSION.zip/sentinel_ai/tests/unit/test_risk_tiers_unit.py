"""
Risk engine unit test - pure logic against config.tier_for_score, no pipeline data
required. The data-dependent risk-engine checks (composite score bounds, tier validity,
fraud concentration by tier) live in tests/integration/test_risk_engine_data.py.
"""
from config import tier_for_score

def test_higher_score_never_gets_lower_tier():
    tiers = [(40, "auto_clear"), (70, "standard_review"), (90, "priority_review"), (101, "immediate_escalation")]
    order = {"auto_clear": 0, "standard_review": 1, "priority_review": 2, "immediate_escalation": 3}
    prev_tier_rank = -1
    for score in range(0, 100, 5):
        t = tier_for_score(score, tiers)
        assert order[t] >= prev_tier_rank
        prev_tier_rank = order[t]
