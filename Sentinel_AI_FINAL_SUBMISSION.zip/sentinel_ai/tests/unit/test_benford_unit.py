"""
Benford's Law unit tests - pure synthetic data, no pipeline artifacts required.
The rule-engine data-dependent checks (off-hours rule vs. real timestamp granularity)
live in tests/integration/test_rules_data.py.
"""
import pandas as pd
import numpy as np
from benford import mad_score, BENFORD_PROBS
from config import BENFORD_DISABLED_VERTICALS

def test_benford_mad_score_on_perfect_benford_data():
    """A synthetic sample drawn exactly from the Benford distribution should score a very low MAD."""
    rng = np.random.default_rng(0)
    digits = pd.Series(rng.choice(np.arange(1, 10), size=5000, p=BENFORD_PROBS))
    mad, n = mad_score(digits)
    assert mad < 0.01, f"MAD should be small for genuinely Benford-conforming data, got {mad}"

def test_benford_mad_score_on_uniform_data():
    """Uniform digit distribution (NOT Benford-conforming) should score a much higher MAD."""
    rng = np.random.default_rng(0)
    digits = pd.Series(rng.integers(1, 10, size=5000))
    mad, n = mad_score(digits)
    assert mad > 0.05, f"MAD should be large for non-Benford-conforming uniform data, got {mad}"

def test_benford_insufficient_data_below_min_cohort():
    digits = pd.Series([1, 2, 3])  # below MIN_COHORT=30
    mad, n = mad_score(digits)
    assert np.isnan(mad)

def test_corporate_benford_is_disabled_in_config():
    assert "corporate" in BENFORD_DISABLED_VERTICALS
