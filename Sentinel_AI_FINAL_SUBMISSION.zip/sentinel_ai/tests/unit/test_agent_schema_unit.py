"""
Investigation schema unit tests - pure Pydantic validation, no pipeline data required.
The data-dependent agent checks (real investigation output, no-hallucination check
against real retrieved evidence) live in tests/integration/test_agent_schema_data.py.
"""
import pytest
from pydantic import ValidationError
from agent import Investigation

def test_investigation_schema_rejects_bad_risk_level():
    with pytest.raises(ValidationError):
        Investigation(
            transaction_id="X", risk_score=50, risk_level="SUPER_HIGH",  # invalid enum value
            finding="f", anomaly_drivers=[], supporting_evidence=[], counter_evidence=[],
            evidence_sufficiency="SUFFICIENT", recommended_action="ESCALATE", confidence=0.5,
        )

def test_investigation_schema_rejects_score_out_of_range():
    with pytest.raises(ValidationError):
        Investigation(
            transaction_id="X", risk_score=150, risk_level="HIGH",  # out of 0-100
            finding="f", anomaly_drivers=[], supporting_evidence=[], counter_evidence=[],
            evidence_sufficiency="SUFFICIENT", recommended_action="ESCALATE", confidence=0.5,
        )

def test_investigation_requires_counter_evidence_field_present():
    inv = Investigation(
        transaction_id="X", risk_score=50, risk_level="MEDIUM",
        finding="f", anomaly_drivers=[], supporting_evidence=[], counter_evidence=[],
        evidence_sufficiency="SUFFICIENT", recommended_action="ESCALATE", confidence=0.5,
    )
    assert inv.counter_evidence == []  # field must exist even when empty - explicitly checked, not omitted
