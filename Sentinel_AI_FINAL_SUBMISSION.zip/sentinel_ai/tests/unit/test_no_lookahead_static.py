"""
Static (source-inspection) leakage checks - no generated pipeline data required.
The data-dependent leakage checks (rolling features, velocity, chronological split)
live in tests/integration/test_no_lookahead_data.py.
"""
import inspect
import model

def _code_only(source):
    """Strips comments and docstring lines so the leakage check tests executable logic,
    not prose explaining what the code deliberately does NOT do (which legitimately
    mentions fraud_label by name)."""
    lines = []
    in_docstring = False
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith('"""') or stripped.startswith("'''"):
            in_docstring = not in_docstring
            continue
        if in_docstring:
            continue
        code_part = line.split("#", 1)[0]
        lines.append(code_part)
    return "\n".join(lines)

def test_model_fit_never_reads_fraud_label():
    """Static check: fraud_label must not appear in fit_score_vertical's executable code
    (comments/docstrings may reference it by name to document what's deliberately avoided)."""
    code = _code_only(inspect.getsource(model.fit_score_vertical))
    assert "fraud_label" not in code, "model fitting/thresholding must never read fraud_label"

def test_contamination_is_not_derived_from_fraud_rate():
    """The specific bug flagged: contamination used to literally be fraud_label.mean()."""
    assert model.ASSUMED_REVIEW_CAPACITY_PCT == 3.0
    code = _code_only(inspect.getsource(model.fit_score_vertical))
    assert "fraud_label" not in code
    assert "contamination = ASSUMED_REVIEW_CAPACITY_PCT / 100.0" in inspect.getsource(model)

def test_scaler_fit_only_on_train():
    """StandardScaler must be fit on train only, then applied (not re-fit) to validation/holdout."""
    source = inspect.getsource(model.fit_score_vertical)
    assert "scaler.fit_transform(train" in source
    assert "scaler.transform(split_df" in source  # transform, not fit_transform, inside score_split
