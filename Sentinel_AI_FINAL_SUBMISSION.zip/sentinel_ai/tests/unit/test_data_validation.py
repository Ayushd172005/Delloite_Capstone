import pandas as pd
from data_validation import validate_dataset, REQUIRED_COLUMNS

def test_data_validation_detects_missing_columns():
    df = pd.DataFrame({"amount": [1, 2, 3]})
    report = validate_dataset(df, "test")
    assert any("Missing required columns" in i for i in report["issues"])

def test_data_validation_detects_nulls():
    df = pd.DataFrame({c: [1] * 5 for c in REQUIRED_COLUMNS})
    df.loc[0, "amount"] = None
    report = validate_dataset(df, "test")
    assert report["null_counts"].get("amount") == 1

def test_data_validation_detects_duplicate_ids():
    df = pd.DataFrame({c: [1] * 3 for c in REQUIRED_COLUMNS})
    df["transaction_id"] = ["A", "A", "B"]
    report = validate_dataset(df, "test")
    assert report["duplicate_transaction_ids"] == 1

def test_data_validation_passes_clean_data():
    df = pd.DataFrame({
        "transaction_id": ["A", "B"], "transaction_time": ["2025-01-01", "2025-01-02"],
        "amount": [10.0, 20.0], "transaction_type": ["x", "y"], "customer_id": ["c1", "c2"],
        "merchant_id": ["m1", "m2"], "account_id": ["a1", "a2"], "location": ["L1", "L2"],
        "device_id": ["d1", "d2"], "payment_method": ["p1", "p2"], "transaction_frequency": [1, 1],
        "balance_before": [100.0, 200.0], "balance_after": [90.0, 180.0], "fraud_label": [0, 1],
    })
    report = validate_dataset(df, "test")
    assert report["status"] == "PASS"
