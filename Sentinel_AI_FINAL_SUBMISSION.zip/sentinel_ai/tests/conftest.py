"""
Sentinel AI v2 - shared pytest configuration.

Deliberately minimal: only sys.path setup, which every test (unit and integration)
needs to import the application modules. Nothing here reads generated pipeline
artifacts or runs any pipeline script - that would defeat the entire point of having
a fast `tests/unit/` tier. The pipeline-artifact-generation fixture and the
data-reading fixtures (`normalized_features`, `scored_transactions`, `holdout`,
`train`) live in tests/integration/conftest.py instead, where pytest's hierarchical
conftest discovery means they apply ONLY to tests under tests/integration/ - a
`pytest tests/unit -q` run never triggers them, by construction, not by convention.
"""
import sys
import os

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO_ROOT)
