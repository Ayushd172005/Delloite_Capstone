"""
Integration tests for the mentor-aligned use cases - verifies the full chain
(pipeline output -> risk queue -> case endpoint -> investigation context) stays
connected, using the real generated pipeline artifacts.
"""
import pandas as pd
import os

DATA_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_use_case_columns_present_in_scored_transactions():
    df = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    required = ["uc_new_device_high_value", "uc_fan_in_fan_out", "uc_near_threshold_structuring",
                "use_case", "use_case_reasons"]
    for col in required:
        assert col in df.columns, f"{col} missing from scored_transactions.parquet"

def test_use_case_flags_are_valid_values():
    df = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    assert set(df["uc_new_device_high_value"].unique()).issubset({0, 1})
    assert set(df["uc_fan_in_fan_out"].unique()).issubset({0, 1, 2, 3})
    assert set(df["uc_near_threshold_structuring"].unique()).issubset({0, 1})

def test_at_least_one_use_case_fires_somewhere_in_the_real_data():
    """Sanity check against the real dataset - not a synthetic fixture. If this ever
    fails, either the underlying data changed or the use-case logic broke silently."""
    df = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    assert df["uc_new_device_high_value"].sum() > 0, "UC1 should fire somewhere in retail"
    assert (df["uc_fan_in_fan_out"] != 0).sum() > 0, "UC2 should fire somewhere"
    # UC3 is documented as AML-only in this dataset (see use_cases.py docstring) -
    # checked specifically there, not across all verticals combined
    aml = df[df["vertical"] == "aml"]
    assert aml["uc_near_threshold_structuring"].sum() > 0, \
        "UC3 should fire in AML specifically, per the documented data-driven configuration"

def test_use_case_reasons_present_whenever_a_flag_fires():
    df = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    any_flag = (
        (df["uc_new_device_high_value"] == 1) |
        (df["uc_fan_in_fan_out"] != 0) |
        (df["uc_near_threshold_structuring"] == 1)
    )
    flagged = df[any_flag]
    assert flagged["use_case"].notna().all(), "every flagged transaction must have a human-readable use_case label"
    assert flagged["use_case_reasons"].apply(len).gt(0).all(), \
        "every flagged transaction must have at least one reason string"

def test_queue_endpoint_exposes_use_case_context():
    """Verifies app.py's /queue and /case functions surface use-case fields, using the
    real scored data (not a live HTTP server - see tests/integration/test_agent_schema_data.py
    for the pattern of calling app.py functions directly)."""
    import app
    app.load_state()
    queue = app.get_queue(limit=50)
    df = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    flagged_ids = set(df[df["use_case"].notna()]["transaction_id"])
    queue_ids = {r["transaction_id"] for r in queue}
    # at least some overlap expected between the top-scored queue and use-case-flagged
    # transactions is not guaranteed (use cases and risk score are independent signals
    # by design - Section 16), so this just confirms the case endpoint itself exposes
    # the fields when a flagged transaction IS queried directly
    any_flagged_id = next(iter(flagged_ids))
    case = app.get_case(any_flagged_id)
    assert "use_case" in case["signals"] or "use_case" in case, \
        "case endpoint response should expose use_case context somewhere in its payload"

def test_queue_use_case_field_is_json_serializable_for_every_row():
    """Regression test for a real bug: pandas gives NaN (a float), not None, for
    missing values in an object column after a parquet round-trip. A raw NaN fails
    FastAPI's strict JSON encoder (ValueError: Out of range float values are not JSON
    compliant) - this was only caught by hitting a genuinely live /queue endpoint, not
    by calling get_queue() directly in-process, so this test forces the same
    JSON-encoding path the live server uses."""
    import json
    import math
    import app
    app.load_state()
    queue = app.get_queue(limit=345000)  # exercise every queued row, not just the top few
    for r in queue:
        assert r["use_case"] is None or isinstance(r["use_case"], str), \
            f"use_case must be None or a string, got {r['use_case']!r} for {r['transaction_id']}"
        if isinstance(r["use_case"], float):
            assert not math.isnan(r["use_case"]), "use_case must never be a raw NaN float"
    # the real failure mode was at JSON serialization time, not at the Python-object level -
    # reproduce that exact check too
    json.dumps(queue)  # raises ValueError if any row still contains a bare NaN

def test_agent_receives_use_case_context():
    """Verifies agent.py's deterministic investigation includes use-case context in its
    reasoning when a transaction has one, per Section 17."""
    import pandas as pd
    from agent import SentinelTools, deterministic_investigate
    from retrieval import EvidenceStore

    scored = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    evidence_df = pd.read_parquet(os.path.join(DATA_DIR, "evidence_documents.parquet"))
    store = EvidenceStore(evidence_df, scored)
    tools = SentinelTools(scored, store)

    flagged_and_investigatable = scored[
        (scored["use_case"].notna()) & (scored["review_tier"] != "auto_clear")
    ]
    if len(flagged_and_investigatable) == 0:
        import pytest
        pytest.skip("no transaction is both use-case-flagged and in the review queue in this run")
    tid = flagged_and_investigatable.iloc[0]["transaction_id"]
    inv = deterministic_investigate(tid, tools)
    use_case_mentioned = any(
        "device" in d.lower() or "fan-in" in d.lower() or "fan-out" in d.lower()
        or "threshold" in d.lower() or "structuring" in d.lower()
        for d in inv.anomaly_drivers
    )
    assert use_case_mentioned, \
        f"agent's anomaly_drivers for {tid} should reference the mentor-aligned use case context"
