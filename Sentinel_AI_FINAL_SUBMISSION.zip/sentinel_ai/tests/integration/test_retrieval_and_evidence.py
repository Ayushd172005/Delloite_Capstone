import pandas as pd
import os
import pytest
from retrieval import EvidenceStore

DATA_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

@pytest.fixture(scope="module")
def store():
    evidence_df = pd.read_parquet(os.path.join(DATA_DIR, "evidence_documents.parquet"))
    txns = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    return EvidenceStore(evidence_df, txns), evidence_df, txns

def test_evidence_documents_have_required_schema():
    df = pd.read_parquet(os.path.join(DATA_DIR, "evidence_documents.parquet"))
    required = {"document_id", "transaction_id", "source_type", "source_system", "created_at", "text"}
    assert required.issubset(set(df.columns))

def test_all_evidence_tagged_synthetic():
    df = pd.read_parquet(os.path.join(DATA_DIR, "evidence_documents.parquet"))
    assert (df["source_system"] == "SENTINEL_SYNTH").all(), \
        "all synthetic evidence must be tagged as such - never presented as real"

def test_temporal_evidence_rule_enforced(store):
    """No retrieved document may have created_at after the queried transaction's own time,
    unless retrospective=True is explicitly passed."""
    evidence_store, evidence_df, txns = store
    txns_indexed = txns.set_index("transaction_id")
    sample = evidence_df["transaction_id"].drop_duplicates().sample(30, random_state=1)
    for tid in sample:
        txn_time = txns_indexed.loc[tid, "transaction_time"]
        results = evidence_store.retrieve(tid, retrospective=False)
        for r in results:
            assert r["created_at"] <= txn_time, \
                f"temporal leakage: doc created {r['created_at']} retrieved for transaction at {txn_time}"

def test_retrieval_excludes_the_query_transaction_itself(store):
    evidence_store, evidence_df, txns = store
    sample_tid = evidence_df["transaction_id"].iloc[0]
    results = evidence_store.retrieve(sample_tid)
    assert all(r["transaction_id"] != sample_tid for r in results)

def test_retrieval_includes_reason_for_retrieval(store):
    evidence_store, evidence_df, txns = store
    sample_tid = evidence_df["transaction_id"].iloc[0]
    results = evidence_store.retrieve(sample_tid)
    assert all("reason_for_retrieval" in r for r in results)
