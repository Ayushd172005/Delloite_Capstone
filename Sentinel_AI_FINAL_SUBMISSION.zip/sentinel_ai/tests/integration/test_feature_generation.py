import pandas as pd
import numpy as np

def test_all_three_verticals_present(normalized_features):
    assert set(normalized_features["vertical"].unique()) == {"corporate", "aml", "retail"}

def test_no_nulls_in_core_features(normalized_features):
    core = ["amount_zscore", "velocity_30d", "balance_depletion_ratio", "days_since_last_txn"]
    for col in core:
        assert normalized_features[col].isnull().sum() == 0, f"{col} has unexpected nulls"

def test_amount_zscore_is_clipped(normalized_features):
    assert normalized_features["amount_zscore"].between(-10, 10).all()

def test_novelty_flags_are_binary(normalized_features):
    for col in ["is_new_counterparty", "is_new_device", "is_new_location"]:
        assert set(normalized_features[col].unique()).issubset({0, 1})

def test_row_count_preserved(normalized_features):
    # feature engineering must not drop or duplicate rows
    assert len(normalized_features) == 345000
    assert normalized_features["transaction_id"].nunique() == 345000
