"""
Agent data-dependent checks - require scored_transactions.parquet and
evidence_documents.parquet (loaded via the module-scoped `tools` fixture below, which
needs the real generated evidence corpus, not just the shared integration fixtures in
conftest.py). The pure Pydantic schema-validation tests live in
tests/unit/test_agent_schema_unit.py and need no pipeline run.
"""
import pandas as pd
import os
import pytest
from agent import Investigation, deterministic_investigate, SentinelTools
from retrieval import EvidenceStore

DATA_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

@pytest.fixture(scope="module")
def tools():
    scored = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    evidence_df = pd.read_parquet(os.path.join(DATA_DIR, "evidence_documents.parquet"))
    store = EvidenceStore(evidence_df, scored)
    return SentinelTools(scored, store), scored

def test_deterministic_investigation_produces_valid_schema(tools):
    sentinel_tools, scored = tools
    flagged = scored[scored["review_tier"] != "auto_clear"]
    tid = flagged.iloc[0]["transaction_id"]
    inv = deterministic_investigate(tid, sentinel_tools)
    assert isinstance(inv, Investigation)
    assert inv.transaction_id == tid

def test_agent_never_fabricates_document_ids(tools):
    """Every doc_id cited in supporting/counter evidence must trace to a real retrieved document."""
    sentinel_tools, scored = tools
    flagged = scored[scored["review_tier"] != "auto_clear"]
    for tid in flagged["transaction_id"].head(10):
        inv = deterministic_investigate(tid, sentinel_tools)
        evidence = sentinel_tools.search_evidence(tid)
        real_ids = {d["document_id"] for d in evidence["own_documents"] + evidence["related_evidence"]}
        real_ids.add("N/A")
        for item in inv.supporting_evidence + inv.counter_evidence:
            assert item.document_id in real_ids, \
                f"agent cited {item.document_id} which was never retrieved for {tid}"
