"""
Risk engine data-dependent checks - require scored_transactions.parquet /
risk_scored_holdout.parquet (via fixtures in tests/integration/conftest.py). The pure
tier-ordering logic test lives in tests/unit/test_risk_tiers_unit.py and needs no
pipeline run.
"""

def test_composite_score_bounded_0_100(scored_transactions):
    assert scored_transactions["composite_score"].min() >= -0.01
    assert scored_transactions["composite_score"].max() <= 100.01

def test_review_tiers_are_valid_values(scored_transactions):
    valid = {"auto_clear", "standard_review", "priority_review", "immediate_escalation"}
    assert set(scored_transactions["review_tier"].unique()).issubset(valid)

def test_immediate_escalation_has_highest_fraud_rate_where_populated(holdout):
    """Sanity check: the top review tier should generally have equal-or-higher fraud
    concentration than auto_clear (directional check, not exact ordering across all tiers,
    since tier boundaries are calibrated on validation not holdout)."""
    for vertical, sub in holdout.groupby("vertical"):
        auto_clear_rate = sub[sub["review_tier"] == "auto_clear"]["fraud_label"].mean()
        escalation = sub[sub["review_tier"] == "immediate_escalation"]
        if len(escalation) > 0:
            escalation_rate = escalation["fraud_label"].mean()
            assert escalation_rate >= auto_clear_rate, \
                f"{vertical}: immediate_escalation fraud rate ({escalation_rate}) should be >= auto_clear ({auto_clear_rate})"
