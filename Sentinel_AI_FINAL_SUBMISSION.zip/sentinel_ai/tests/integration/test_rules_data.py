"""
Rule-engine data-dependent checks - require normalized_features.parquet (via the
`normalized_features` fixture in tests/integration/conftest.py). The Benford unit tests
on synthetic data live in tests/unit/test_benford_unit.py and need no pipeline run.
"""
from rules import add_rule_flags
from network import add_network_features

def test_off_hours_rule_disabled_for_date_only_verticals(normalized_features):
    df = add_network_features(normalized_features.copy())
    df = add_rule_flags(df)
    for v in ["corporate", "aml"]:
        sub = df[df["vertical"] == v]
        assert sub["flag_off_hours_weekend"].sum() == 0, \
            f"{v} timestamps are date-only - off-hours rule must not fire"

def test_off_hours_rule_active_for_retail(normalized_features):
    df = add_network_features(normalized_features.copy())
    df = add_rule_flags(df)
    sub = df[df["vertical"] == "retail"]
    assert sub["flag_off_hours_weekend"].sum() > 0, "retail has real intraday timestamps - rule should fire sometimes"
