"""
Data-dependent leakage/causality checks - require the generated pipeline artifacts
(normalized_features.parquet, scored_transactions.parquet). The static source-inspection
checks live in tests/unit/test_no_lookahead_static.py and need no pipeline run.
"""
from config import ENTITY_COL
from model import three_way_split

def test_rolling_amount_feature_excludes_current_row(normalized_features):
    """roll_mean_amount must be computed from PRIOR transactions only (shift(1)), so for
    an account's very first transaction, roll_mean_amount should equal that transaction's
    own amount only by the fillna fallback, not by including itself in a window."""
    for vertical in normalized_features["vertical"].unique():
        entity = ENTITY_COL[vertical]
        sub = normalized_features[normalized_features["vertical"] == vertical]
        # must match prep.py's own ordering exactly (entity, then time, stable sort) -
        # sorting by time alone re-shuffles same-day ties across DIFFERENT entities and
        # gives a wrong answer for "which row is this entity's first" (see prep.py comment).
        sub_sorted = sub.sort_values([entity, "transaction_time"], kind="stable")
        first_txns = sub_sorted.groupby(entity, sort=False).first()
        assert (first_txns["roll_std_amount"] == 0).all(), \
            f"{vertical}: first transaction per entity should have roll_std_amount=0 (no history yet)"

def test_velocity_is_causal(normalized_features):
    """velocity_30d for an entity's first-ever transaction must be 0 (no prior transactions
    exist yet to count)."""
    for vertical in normalized_features["vertical"].unique():
        entity = ENTITY_COL[vertical]
        sub = normalized_features[normalized_features["vertical"] == vertical]
        sub_sorted = sub.sort_values([entity, "transaction_time"], kind="stable")
        first_txns = sub_sorted.groupby(entity, sort=False).first()
        assert (first_txns["velocity_30d"] == 0).all(), \
            f"{vertical}: velocity_30d must be 0 for an entity's first transaction (causal, no future/self counting)"

def test_train_validation_holdout_are_chronologically_ordered(scored_transactions):
    for vertical, sub in scored_transactions.groupby("vertical"):
        train, val, holdout = three_way_split(sub)
        if len(train) and len(val):
            assert train["transaction_time"].max() <= val["transaction_time"].min()
        if len(val) and len(holdout):
            assert val["transaction_time"].max() <= holdout["transaction_time"].min()
