"""
Sentinel AI v2 - integration test fixtures.

Scoped to tests/integration/ only, via pytest's hierarchical conftest discovery -
tests under tests/unit/ never see or trigger this file's autouse fixture. This is
what makes `pytest tests/unit -q` fast and independent of any generated data, while
`pytest tests/integration -q` (or a plain `pytest tests/` run) still exercises the
real pipeline output.

REPRODUCIBILITY: on a genuinely clean checkout, none of the parquet files below exist
yet. The autouse fixture generates the minimal 9-script subset of run_pipeline.py that
integration tests actually need (verified directly, not assumed, by grepping every
integration test file's read_parquet calls) - a one-time ~2-3 minute cost, skipped
entirely on any subsequent run where the artifacts already exist (e.g. after
`python3 run_pipeline.py` was run for other reasons, such as generating reports/).
"""
import os
import sys
import subprocess
import pytest
import pandas as pd

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FINAL_TARGETS = [
    "normalized_features.parquet", "scored_transactions.parquet",
    "risk_scored_holdout.parquet", "risk_scored_train.parquet", "evidence_documents.parquet",
]

def _path(name):
    return os.path.join(REPO_ROOT, name)

def _run_script(script_name):
    result = subprocess.run(
        [sys.executable, script_name], cwd=REPO_ROOT,
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Integration fixture generation failed running {script_name}:\n"
            f"--- stdout ---\n{result.stdout}\n--- stderr ---\n{result.stderr}"
        )

@pytest.fixture(scope="session", autouse=True)
def ensure_pipeline_artifacts():
    if all(os.path.exists(_path(f)) for f in FINAL_TARGETS):
        return  # everything needed already exists - nothing to do

    print("\n[conftest:integration] Required pipeline artifacts are missing - generating "
          "them now (one-time cost on a clean checkout, ~2-3 minutes)...")
    scripts_in_order = ["prep.py", "network.py", "rules.py", "benford.py", "model.py",
                         "risk_engine.py", "weight_calibration.py", "risk_engine.py", "evidence.py",
                         "use_cases.py"]
    for script in scripts_in_order:
        print(f"[conftest:integration]   running {script}...")
        _run_script(script)

    missing_after = [f for f in FINAL_TARGETS if not os.path.exists(_path(f))]
    if missing_after:
        raise RuntimeError(f"[conftest:integration] Fixture generation ran but these are still missing: {missing_after}")
    print("[conftest:integration] All required artifacts present - proceeding with tests.\n")


@pytest.fixture(scope="session")
def normalized_features():
    return pd.read_parquet(_path("normalized_features.parquet"))

@pytest.fixture(scope="session")
def scored_transactions():
    return pd.read_parquet(_path("scored_transactions.parquet"))

@pytest.fixture(scope="session")
def holdout():
    return pd.read_parquet(_path("risk_scored_holdout.parquet"))

@pytest.fixture(scope="session")
def train():
    return pd.read_parquet(_path("risk_scored_train.parquet"))
