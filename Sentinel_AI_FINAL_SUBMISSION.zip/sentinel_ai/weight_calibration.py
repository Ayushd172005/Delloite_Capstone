"""
Sentinel AI v2 - composite weight calibration.

The ablation study (ablation.py) found that the original fixed prototype weights
(isoforest 0.25 / autoencoder 0.25 / benford 0.30 / rules 0.20) UNDERPERFORM the ML
scores alone in every single vertical - ROC-AUC on holdout: AML 0.935 vs 0.972 ML-only,
retail 0.679 vs 0.702 ML-only. The root cause is visible in evaluate.py's component
metrics: benford_score's ROC-AUC is ~0.50 (no signal) in ALL THREE verticals for this
specific fraud pattern - not just corporate, where it was already disabled - so giving
it 30% weight purely dilutes a working ML signal with noise.

This runs a small grid search over weight combinations, selecting the combo that
maximizes mean ROC-AUC ON VALIDATION ONLY (never holdout - that would just be a more
elaborate form of the same leakage this whole rebuild is fixing). The chosen weights
are then applied ONCE to holdout in evaluate_final.py for an honest before/after.
"""
import pandas as pd
import numpy as np
import json
from itertools import product
from sklearn.metrics import roc_auc_score

GRID = {
    "isoforest": [0.25, 0.35, 0.45, 0.55],
    "autoencoder": [0.15, 0.25, 0.35],
    "rules": [0.05, 0.10, 0.20],
    "benford": [0.0, 0.05, 0.10],
}

def score_with_weights(sub, w):
    total = sum(w.values())
    return (
        w["isoforest"] * sub["isoforest_score"] * 100
        + w["autoencoder"] * sub["autoencoder_score"] * 100
        + w["rules"] * sub["rule_score"]
        + w["benford"] * sub["benford_score"]
    ) / total

def calibrate(validation):
    best_by_vertical = {}
    for vertical, sub in validation.groupby("vertical"):
        y = sub["fraud_label"].values
        best_auc, best_w = -1, None
        for iso, ae, ru, bf in product(GRID["isoforest"], GRID["autoencoder"], GRID["rules"], GRID["benford"]):
            w = {"isoforest": iso, "autoencoder": ae, "rules": ru, "benford": bf}
            score = score_with_weights(sub, w)
            try:
                auc = roc_auc_score(y, score)
            except ValueError:
                continue
            if auc > best_auc:
                best_auc, best_w = auc, w
        best_by_vertical[vertical] = {"weights": best_w, "validation_roc_auc": round(best_auc, 4)}
    return best_by_vertical

if __name__ == "__main__":
    validation = pd.read_parquet("risk_scored_validation.parquet")
    result = calibrate(validation)
    print("Calibrated weights (selected on VALIDATION ROC-AUC only):")
    for v, r in result.items():
        print(f"  {v}: {r['weights']}  -> validation AUC {r['validation_roc_auc']}")
    with open("calibrated_composite_weights.json", "w") as f:
        json.dump(result, f, indent=2)
    print("\nSaved calibrated_composite_weights.json")
