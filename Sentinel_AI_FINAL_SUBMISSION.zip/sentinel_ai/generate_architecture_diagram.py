"""
Sentinel AI v2 - architecture diagram generator.
Every box below corresponds to an actual file in this repository - nothing shown here
is aspirational. See the filename annotation under each box.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

STAGES = [
    ("Raw Transaction Data", "pro_dataset_*.csv", "#2b3d63"),
    ("Data Validation", "data_validation.py", "#1a2b4c"),
    ("Causal Feature Engineering", "prep.py + network.py", "#1a2b4c"),
    ("Multi-Layer Detection\n(IsoForest + Autoencoder + Rules + Benford)", "model.py, rules.py, benford.py", "#1a2b4c"),
    ("Risk Engine\n(composite score, calibrated weights & tiers)", "risk_engine.py, weight_calibration.py", "#1a2b4c"),
    ("Prioritized Audit Queue", "app.py: GET /queue", "#1a2b4c"),
    ("Evidence Retrieval\n(temporal rule enforced)", "evidence.py, retrieval.py", "#1a2b4c"),
    ("Investigation Agent\n(Pydantic-validated, counter-evidence)", "agent.py", "#1a2b4c"),
    ("Structured Case\n(supporting + counter-evidence)", "db.py: cases table", "#1a2b4c"),
    ("Auditor Review & Decision", "frontend/SentinelDashboard.jsx", "#1a2b4c"),
    ("Persistent Audit Trail", "db.py: audit_events table", "#1a2b4c"),
    ("Model / Drift Monitoring", "drift.py, evaluate.py, ablation.py", "#1a2b4c"),
]

fig, ax = plt.subplots(figsize=(9, 16.5))
fig.patch.set_facecolor("#0d1220")
ax.set_facecolor("#0d1220")
ax.set_xlim(0, 10)
ax.set_ylim(0, len(STAGES) * 2 + 2.5)
ax.axis("off")

box_w, box_h = 8, 1.3
y = len(STAGES) * 2 - 0.5

for i, (title, filename, color) in enumerate(STAGES):
    x = 1
    box = FancyBboxPatch((x, y), box_w, box_h, boxstyle="round,pad=0.08,rounding_size=0.12",
                          linewidth=1.2, edgecolor="#3a4a6b", facecolor=color)
    ax.add_patch(box)
    ax.text(x + box_w / 2, y + box_h * 0.62, title, ha="center", va="center",
            fontsize=11.5, fontweight="bold", color="#e6e9ef", family="sans-serif")
    ax.text(x + box_w / 2, y + box_h * 0.22, filename, ha="center", va="center",
            fontsize=9, color="#c9a961", family="monospace")

    if i < len(STAGES) - 1:
        ax.add_patch(FancyArrowPatch((x + box_w / 2, y), (x + box_w / 2, y - 0.65),
                                      arrowstyle="-|>", mutation_scale=18, color="#6b7690", linewidth=1.3))
    y -= 2

ax.text(5, len(STAGES) * 2 + 1.6, "Sentinel AI v2 - Architecture", ha="center", va="center",
        fontsize=16, fontweight="bold", color="#e6e9ef", family="sans-serif")
ax.text(5, -0.7, "Every stage maps to an actual file in this repository - the annotation under\n"
                  "each box names it. Human auditor decision is the final, authoritative step;\n"
                  "the agent recommends, it does not decide.",
        ha="center", va="center", fontsize=9, color="#9aa4b8", family="sans-serif")

plt.tight_layout()
plt.savefig("reports/architecture_diagram.png", dpi=150, facecolor="#0d1220", bbox_inches="tight")
print("Saved reports/architecture_diagram.png")
