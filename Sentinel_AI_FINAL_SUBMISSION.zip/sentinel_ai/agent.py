"""
Sentinel AI v2 - Investigation agent.

Implements the workflow from the master prompt (items 16-19):
  transaction -> risk signals -> retrieve evidence -> inspect evidence ->
  identify supporting evidence -> identify counter-evidence (MANDATORY) ->
  determine evidence sufficiency -> structured, Pydantic-validated conclusion ->
  recommended auditor action

AI-assisted, evidence-grounded investigation agent. The system pre-fetches structured
transaction, risk, historical, use-case, and evidence context via real local functions
(get_transaction, get_account_history, search_evidence, get_risk_signals) operating on
the scored/evidence data - the agent must call these rather than invent facts. When
ANTHROPIC_API_KEY is set, call_agent() sends that assembled context to Claude for a
single structured investigation response and validates it against the existing schema;
when it isn't (this sandbox has no key), or validation fails, deterministic_investigate()
runs the identical evidence-gathering steps and produces the same schema using rule-based
reasoning instead of an LLM. This satisfies "agent works or has a deterministic fallback" -
the fallback is not a stub, it performs the real supporting/counter-evidence
comparison, just without LLM-authored prose.
"""
import os
import json
from typing import Literal, List
from pydantic import BaseModel, Field, field_validator
import pandas as pd

from retrieval import EvidenceStore
from config import BENFORD_DISABLED_VERTICALS

# ---------------------------------------------------------------------------
# Structured output schema (master prompt item 19) - never allow arbitrary LLM
# text to directly control the application; every agent output is validated
# against this schema before it can become a Case.
# ---------------------------------------------------------------------------

class EvidenceItem(BaseModel):
    document_id: str
    statement: str
    stance: Literal["supports", "contradicts", "neutral"]

class Investigation(BaseModel):
    transaction_id: str
    risk_score: float = Field(ge=0, le=100)
    risk_level: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    finding: str
    anomaly_drivers: List[str]
    supporting_evidence: List[EvidenceItem]
    counter_evidence: List[EvidenceItem]
    evidence_sufficiency: Literal["SUFFICIENT", "INSUFFICIENT"]
    recommended_action: Literal["ACCEPT", "ESCALATE", "DISMISS", "REQUEST_MORE_EVIDENCE"]
    confidence: float = Field(
        ge=0, le=1,
        description="Investigation confidence: how sufficient and internally consistent "
                     "the gathered evidence is. This is NOT a calibrated probability that "
                     "fraud occurred - it reflects whether the agent had enough grounded "
                     "material to reach a clear conclusion, nothing more."
    )

    @field_validator("counter_evidence")
    @classmethod
    def counter_evidence_was_checked(cls, v):
        # Not "must be non-empty" (sometimes there genuinely is none) - but the field
        # must exist and be a real list, i.e. the agent was required to consider it.
        # This validator exists to document that the check is mandatory, not to fabricate
        # counter-evidence when none was found.
        return v


# ---------------------------------------------------------------------------
# Tool functions - the ONLY way the agent may obtain facts. All operate on real
# data already computed by the pipeline (no invented facts).
# ---------------------------------------------------------------------------

class SentinelTools:
    def __init__(self, scored_df, evidence_store: EvidenceStore):
        self.scored = scored_df.set_index("transaction_id", drop=False)
        self.store = evidence_store

    def get_transaction(self, transaction_id):
        row = self.scored.loc[transaction_id]
        return {
            "transaction_id": transaction_id, "vertical": row["vertical"],
            "amount": float(row["amount"]), "transaction_time": str(row["transaction_time"]),
            "account_id": row["account_id"], "counterparty_id": row["counterparty_id"],
        }

    def get_risk_signals(self, transaction_id):
        row = self.scored.loc[transaction_id]
        rules_triggered = [c.replace("flag_", "") for c in row.index
                            if c.startswith("flag_") and row.get(c) == 1
                            and "shared" not in c and "hub" not in c]
        signals = {
            "composite_score": round(float(row["composite_score"]), 2),
            "review_tier": row["review_tier"],
            "isoforest_score": round(float(row["isoforest_score"]), 3),
            "autoencoder_score": round(float(row["autoencoder_score"]), 3),
            "benford_flag": bool(row.get("benford_flag", 0)),
            "rules_triggered": rules_triggered,
            "amount_zscore": round(float(row.get("amount_zscore", 0)), 2),
            "amount_pct_rank_personal": round(float(row.get("amount_pct_rank_personal", 0)), 3),
        }
        if row["vertical"] in BENFORD_DISABLED_VERTICALS:
            signals["benford_reliability_note"] = (
                "Benford's Law does not discriminate fraud in this vertical (measured "
                "AUC ~0.50, see evaluation report) - do not cite benford_flag as evidence."
            )
        return signals

    def get_use_case_context(self, transaction_id):
        """Mentor-aligned business use-case context (use_cases.py), if any applies to
        this transaction. Returns None when no use case fired - the agent must not
        infer or invent one."""
        row = self.scored.loc[transaction_id]
        if "use_case" not in row.index or pd.isna(row.get("use_case")):
            return None
        return {
            "use_case": row["use_case"],
            "reasons": list(row["use_case_reasons"]) if row.get("use_case_reasons") is not None else [],
        }

    def get_account_history(self, transaction_id, limit=5):
        txn = self.scored.loc[transaction_id]
        hist = self.scored[
            (self.scored["account_id"] == txn["account_id"]) &
            (self.scored["transaction_time"] < txn["transaction_time"])
        ].sort_values("transaction_time", ascending=False).head(limit)
        return hist[["transaction_id", "amount", "transaction_time"]].to_dict("records")

    def search_evidence(self, transaction_id, retrospective=False):
        own = self.store.retrieve_own_transaction_docs(transaction_id)
        related = self.store.retrieve(transaction_id, retrospective=retrospective)
        return {"own_documents": own, "related_evidence": related}


# ---------------------------------------------------------------------------
# Deterministic fallback investigation (no LLM required) - runs the same
# evidence-gathering steps and produces the same schema.
# ---------------------------------------------------------------------------

def deterministic_investigate(transaction_id, tools: SentinelTools) -> Investigation:
    txn = tools.get_transaction(transaction_id)
    signals = tools.get_risk_signals(transaction_id)
    history = tools.get_account_history(transaction_id)
    evidence = tools.search_evidence(transaction_id)
    use_case_context = tools.get_use_case_context(transaction_id)

    drivers = []
    if use_case_context:
        drivers.append(f"Mentor-aligned business use case: {use_case_context['use_case']}")
        drivers.extend(use_case_context["reasons"])
    if signals["isoforest_score"] > 0.7:
        drivers.append(f"isolation-forest anomaly score {signals['isoforest_score']} (high)")
    if signals["autoencoder_score"] > 0.5:
        drivers.append(f"autoencoder reconstruction error {signals['autoencoder_score']} (elevated)")
    if signals["rules_triggered"]:
        drivers.append("rule triggers: " + ", ".join(signals["rules_triggered"]))
    if signals["benford_flag"] and "benford_reliability_note" not in signals:
        drivers.append("Benford digit-distribution deviation on this cohort")
    if not drivers:
        drivers.append("elevated composite score without a single dominant driver")

    # supporting evidence: prior history showing this amount is far outside the norm
    supporting = []
    if history:
        max_hist = max(h["amount"] for h in history)
        if txn["amount"] > max_hist * 1.5:
            ratio = txn["amount"] / max_hist if max_hist > 0 else float("inf")
            supporting.append(EvidenceItem(
                document_id=evidence["own_documents"][0]["document_id"] if evidence["own_documents"] else "N/A",
                statement=f"Amount is {ratio:.1f}x the largest of the last {len(history)} prior "
                          f"transactions on this account (max {max_hist:.2f})",
                stance="supports",
            ))
    for d in evidence["related_evidence"][:3]:
        supporting.append(EvidenceItem(
            document_id=d["document_id"],
            statement=f"Comparable transaction found via {d['reason_for_retrieval']} "
                      f"(relevance {d['relevance_score']}): amount {d.get('metadata', {}).get('amount', 'n/a')}",
            stance="neutral",
        ))

    # counter-evidence: MANDATORY check - look for a matching approval record
    counter = []
    approval_docs = [d for d in evidence["own_documents"] if d["source_type"] == "approval_record"]
    for d in approval_docs:
        counter.append(EvidenceItem(
            document_id=d["document_id"],
            statement=f"A prior approval record exists for this transaction: {d['text']}",
            stance="contradicts",
        ))

    # sufficiency + risk level + recommended action
    has_direct_history = len(history) > 0
    sufficiency = "SUFFICIENT" if (has_direct_history or approval_docs) else "INSUFFICIENT"

    score = signals["composite_score"]
    if counter:  # counter-evidence pulls the rating down regardless of raw score
        risk_level = "LOW" if score < 50 else "MEDIUM"
        action = "DISMISS" if score < 60 else "REQUEST_MORE_EVIDENCE"
    elif score >= 70:
        risk_level = "CRITICAL" if score >= 90 else "HIGH"
        action = "ESCALATE"
    elif score >= 40:
        risk_level = "MEDIUM"
        action = "REQUEST_MORE_EVIDENCE" if sufficiency == "INSUFFICIENT" else "ESCALATE"
    else:
        risk_level = "LOW"
        action = "DISMISS"

    confidence = 0.85 if sufficiency == "SUFFICIENT" else 0.45
    if counter:
        confidence = min(confidence, 0.6)  # conflicting evidence caps confidence

    finding = (
        f"Transaction {transaction_id} scored {score:.1f}/100 ({txn['vertical']} vertical), "
        f"driven by: {'; '.join(drivers)}."
    )
    if counter:
        finding += f" However, {len(counter)} counter-evidence item(s) were found that weigh against escalation."

    inv = Investigation(
        transaction_id=transaction_id, risk_score=score, risk_level=risk_level, finding=finding,
        anomaly_drivers=drivers, supporting_evidence=supporting, counter_evidence=counter,
        evidence_sufficiency=sufficiency, recommended_action=action, confidence=round(confidence, 2),
    )
    return inv


# ---------------------------------------------------------------------------
# Live-LLM path (used only if ANTHROPIC_API_KEY is set)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are an audit investigation agent for Sentinel AI. You must use the provided \
tools to gather facts - never invent transaction details, history, or evidence. For the given \
transaction, gather risk signals, account history, and evidence, then produce a structured \
investigation with BOTH supporting_evidence and counter_evidence (counter-evidence is mandatory \
to check for, even if you find none). Distinguish FACT (grounded in a specific tool result) from \
INFERENCE (your reasoning) from UNCERTAINTY (things you cannot determine). Output must validate \
against the Investigation schema. If evidence is insufficient to support a conclusion, say so \
explicitly rather than guessing. If use_case_context is present, treat it as a business-relevant \
starting scenario (e.g. "New Device + High-Value Transaction", "Fan-Out Network", "Near-Threshold \
Structuring") to investigate against - it is a prioritization hint, not a fraud determination; \
still gather and weigh supporting and counter-evidence independently."""

def call_agent(transaction_id, tools: SentinelTools, model="claude-sonnet-4-6") -> Investigation:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return deterministic_investigate(transaction_id, tools)

    from anthropic import Anthropic
    client = Anthropic(api_key=api_key)
    context = {
        "transaction": tools.get_transaction(transaction_id),
        "risk_signals": tools.get_risk_signals(transaction_id),
        "use_case_context": tools.get_use_case_context(transaction_id),
        "account_history": tools.get_account_history(transaction_id),
        "evidence": tools.search_evidence(transaction_id),
    }
    resp = client.messages.create(
        model=model, max_tokens=1200, system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": json.dumps(context, indent=2, default=str)}],
    )
    text = "".join(b.text for b in resp.content if b.type == "text")
    try:
        data = json.loads(text)
        return Investigation(**data)
    except Exception as e:
        # schema validation failed - fall back rather than let bad output reach the app
        print(f"Agent output failed schema validation ({e}), falling back to deterministic investigation")
        return deterministic_investigate(transaction_id, tools)


if __name__ == "__main__":
    scored = pd.read_parquet("scored_transactions.parquet")
    evidence_df = pd.read_parquet("evidence_documents.parquet")
    store = EvidenceStore(evidence_df, scored)
    tools = SentinelTools(scored, store)

    flagged = scored[scored["review_tier"] != "auto_clear"].sort_values("composite_score", ascending=False)
    sample_ids = flagged["transaction_id"].head(3).tolist()
    for tid in sample_ids:
        inv = call_agent(tid, tools)
        print(f"\n=== {tid} ===")
        print(inv.model_dump_json(indent=2))
