"""
Sentinel AI v2 - deterministic rule engine.
All thresholds come from config.py - nothing here is hardcoded business logic.
"""
import pandas as pd
from config import APPROVAL_LIMIT, RULE_PARAMS, HAS_INTRADAY_TIMESTAMPS

def add_rule_flags(df):
    df = df.copy()
    p = RULE_PARAMS
    limit = df["vertical"].map(APPROVAL_LIMIT)

    df["flag_just_under_limit"] = (
        (df["amount"] >= p["just_under_limit_ratio"] * limit) & (df["amount"] < limit)
    ).astype(int)

    df["flag_round_number"] = (
        df["is_round_number"] & (df.groupby("vertical")["amount"].rank(pct=True) >= p["round_number_percentile"])
    ).astype(int)

    df["flag_velocity_spike"] = (df["velocity_spike_ratio"] >= p["velocity_spike_multiplier"]).astype(int)

    df["flag_new_counterparty_high_value"] = (
        (df["is_new_counterparty"] == 1) &
        (df.groupby("vertical")["amount"].rank(pct=True) >= p["new_counterparty_percentile"])
    ).astype(int)

    df["flag_balance_depletion"] = (df["balance_depletion_ratio"] > p["balance_depletion_threshold"]).astype(int)

    # off-hours/weekend rule only means anything where the source data has real intraday
    # timestamps (config.HAS_INTRADAY_TIMESTAMPS) - corporate/aml timestamps are date-only
    # (always 00:00:00), so the rule would otherwise fire on every row there.
    has_intraday = df["vertical"].isin(HAS_INTRADAY_TIMESTAMPS)
    df["flag_off_hours_weekend"] = (
        has_intraday & ((df["is_off_hours"] == 1) | (df["is_weekend"] == 1))
    ).astype(int)

    df["flag_dormant_reactivation"] = (df["days_since_last_txn"] > p["dormant_reactivation_days"]).astype(int)

    rule_cols = [c for c in df.columns if c.startswith("flag_") and not c.startswith("flag_shared")
                 and not c.startswith("flag_hub")]
    df["rule_flag_count"] = df[rule_cols].sum(axis=1)
    return df

if __name__ == "__main__":
    full = pd.read_parquet("normalized_features_network.parquet")
    full = add_rule_flags(full)
    for v, sub in full.groupby("vertical"):
        print(v, "avg rules triggered:", round(sub["rule_flag_count"].mean(), 2),
              "| pct with >=1 rule:", f"{(sub['rule_flag_count']>=1).mean():.1%}")
    full.to_parquet("normalized_features_rules.parquet", index=False)
    print("Saved normalized_features_rules.parquet:", full.shape)
