"""Portable Sentinel AI model bundle and online scoring boundary.

This module packages the exact trained Isolation Forest + bottleneck MLP
pipeline used by model.py, together with frozen score calibration, composite
weights, and review-tier thresholds. It deliberately accepts engineered
canonical features rather than silently recomputing history from one row.
History/feature generation remains the responsibility of prep.py or a serving
feature store.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler

from config import BENFORD_DISABLED_VERTICALS, RANDOM_SEED, SPLIT_MONTHS, tier_for_score
from model import FEATURES, ASSUMED_REVIEW_CAPACITY_PCT, minmax_apply, minmax_fit, three_way_split

ROOT = Path(__file__).resolve().parent
DEFAULT_BUNDLE_DIR = ROOT / "model_bundle"
BUNDLE_VERSION = "bundle-2026-09-12-v1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(name: str) -> dict:
    with (ROOT / name).open() as handle:
        return json.load(handle)


def _fit_vertical(train_frame: pd.DataFrame, vertical: str) -> dict[str, Any]:
    train, _, _ = three_way_split(train_frame)
    scaler = StandardScaler()
    x_train = scaler.fit_transform(train[FEATURES])

    contamination = ASSUMED_REVIEW_CAPACITY_PCT / 100.0
    iso = IsolationForest(contamination=contamination, random_state=RANDOM_SEED, n_estimators=200)
    iso.fit(x_train)
    iso_raw = -iso.decision_function(x_train)
    iso_lo, iso_span = minmax_fit(pd.Series(iso_raw))

    autoencoder = MLPRegressor(
        hidden_layer_sizes=(8, 3, 8),
        max_iter=300,
        random_state=RANDOM_SEED,
        early_stopping=True,
        n_iter_no_change=10,
    )
    autoencoder.fit(x_train, x_train)
    reconstructed = autoencoder.predict(x_train)
    ae_raw = np.mean((x_train - reconstructed) ** 2, axis=1)
    ae_lo, ae_span = minmax_fit(pd.Series(ae_raw))

    return {
        "vertical": vertical,
        "scaler": scaler,
        "isoforest": iso,
        "autoencoder": autoencoder,
        "calibration": {
            "isoforest_raw_min": float(iso_lo),
            "isoforest_raw_span": float(iso_span),
            "autoencoder_raw_min": float(ae_lo),
            "autoencoder_raw_span": float(ae_span),
        },
        "training": {
            "rows": int(len(train)),
            "start": str(train["transaction_time"].min()),
            "end": str(train["transaction_time"].max()),
            "contamination_assumed_review_capacity_pct": ASSUMED_REVIEW_CAPACITY_PCT,
        },
    }


def build_bundle(bundle_dir: Path = DEFAULT_BUNDLE_DIR) -> dict:
    """Fit and persist the portable bundle from the frozen feature artifact."""
    bundle_dir.mkdir(parents=True, exist_ok=True)
    source = ROOT / "normalized_features_benford.parquet"
    if not source.exists():
        raise FileNotFoundError(f"Missing required feature artifact: {source}")
    frame = pd.read_parquet(source)
    frame["transaction_time"] = pd.to_datetime(frame["transaction_time"])

    weights = _load_json("calibrated_composite_weights.json")
    thresholds = _load_json("calibrated_thresholds.json")
    registry = _load_json("feature_registry.json")
    model_file = ROOT / "model.py"

    vertical_files = {}
    vertical_metadata = {}
    for vertical, subset in frame.groupby("vertical", sort=True):
        filename = f"{vertical}.joblib"
        artifact_path = bundle_dir / filename
        payload = _fit_vertical(subset.reset_index(drop=True), vertical)
        joblib.dump(payload, artifact_path, compress=3)
        vertical_files[vertical] = filename
        vertical_metadata[vertical] = payload["training"]

    manifest = {
        "bundle_version": BUNDLE_VERSION,
        "model_version": "v2.0",
        "feature_registry_version": registry["schema_version"],
        "features": FEATURES,
        "source_feature_artifact": source.name,
        "source_feature_artifact_sha256": _sha256(source),
        "model_source_sha256": _sha256(model_file),
        "random_seed": RANDOM_SEED,
        "split_months": SPLIT_MONTHS,
        "vertical_files": vertical_files,
        "vertical_training": vertical_metadata,
        "calibrated_weights": weights,
        "calibrated_thresholds": thresholds,
        "benford_disabled_verticals": sorted(BENFORD_DISABLED_VERTICALS),
        "fraud_label_used_for_fit": False,
        "created_by": "model_bundle.py",
    }
    (bundle_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


@dataclass
class ModelBundle:
    directory: Path
    manifest: dict
    models: dict[str, dict]

    @classmethod
    def load(cls, directory: Path = DEFAULT_BUNDLE_DIR) -> "ModelBundle":
        directory = Path(directory)
        manifest_path = directory / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"Model bundle manifest not found: {manifest_path}")
        manifest = json.loads(manifest_path.read_text())
        if manifest.get("features") != FEATURES:
            raise ValueError("Model bundle feature order does not match model.FEATURES")
        models = {}
        for vertical, filename in manifest["vertical_files"].items():
            path = directory / filename
            if not path.exists():
                raise FileNotFoundError(f"Missing model artifact for {vertical}: {path}")
            models[vertical] = joblib.load(path)
        return cls(directory, manifest, models)

    def _validate_row(self, row: Mapping[str, Any], vertical: str) -> None:
        if vertical not in self.models:
            raise ValueError(f"Unsupported vertical: {vertical}")
        missing = [feature for feature in self.manifest["features"] if feature not in row]
        if missing:
            raise ValueError(f"Missing required engineered features: {missing}")
        bad = [feature for feature in self.manifest["features"] if not np.isfinite(float(row[feature]))]
        if bad:
            raise ValueError(f"Non-finite feature values: {bad}")

    def score_one(self, row: Mapping[str, Any]) -> dict[str, Any]:
        """Score one already-engineered canonical transaction deterministically."""
        vertical = str(row.get("vertical", ""))
        self._validate_row(row, vertical)
        artifact = self.models[vertical]
        values = pd.DataFrame([[float(row[feature]) for feature in FEATURES]], columns=FEATURES)
        x = artifact["scaler"].transform(values)
        iso_raw = float(-artifact["isoforest"].decision_function(x)[0])
        reconstruction = artifact["autoencoder"].predict(x)
        ae_raw = float(np.mean((x - reconstruction) ** 2, axis=1)[0])
        calibration = artifact["calibration"]
        iso_score = float(np.clip((iso_raw - calibration["isoforest_raw_min"]) / calibration["isoforest_raw_span"], 0, 1))
        ae_score = float(np.clip((ae_raw - calibration["autoencoder_raw_min"]) / calibration["autoencoder_raw_span"], 0, 1))

        rule_score = float(row.get("rule_score", 0.0))
        benford_score = float(row.get("benford_score", 0.0))
        weights_entry = self.manifest["calibrated_weights"].get(vertical, {})
        weights = weights_entry.get("weights", weights_entry)
        total = sum(float(value) for value in weights.values()) or 1.0
        composite = (
            float(weights.get("isoforest", 0)) * iso_score * 100
            + float(weights.get("autoencoder", 0)) * ae_score * 100
            + float(weights.get("rules", 0)) * rule_score
            + float(weights.get("benford", 0)) * benford_score
        ) / total
        tier_rows = self.manifest["calibrated_thresholds"]["tiers_by_vertical"][vertical]
        tiers = [(float(cutoff), label) for cutoff, label in tier_rows]

        return {
            "transaction_id": row.get("transaction_id"),
            "vertical": vertical,
            "model_version": self.manifest["model_version"],
            "bundle_version": self.manifest["bundle_version"],
            "feature_registry_version": self.manifest["feature_registry_version"],
            "isoforest_score": round(iso_score, 6),
            "autoencoder_score": round(ae_score, 6),
            "reconstruction_error": round(ae_raw, 6),
            "rule_score": round(rule_score, 6),
            "benford_score": round(benford_score, 6),
            "composite_score": round(float(np.clip(composite, 0, 100)), 6),
            "review_tier": tier_for_score(composite, tiers),
            "fraud_probability": None,
            "warnings": ["Score is relative investigation priority, not a probability of fraud."],
        }


if __name__ == "__main__":
    manifest = build_bundle()
    print(json.dumps({"status": "PASS", "bundle_version": manifest["bundle_version"], "verticals": sorted(manifest["vertical_files"])}, indent=2))
