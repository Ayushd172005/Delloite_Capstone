"""
Sentinel AI v2 - SQLite persistence.

Tables: transactions, risk_scores, cases, investigations, auditor_decisions,
audit_events, model_versions. SQLite chosen per master prompt item 21 ("use SQLite for
simple local reproducibility... do not require enterprise infrastructure merely for
appearance"). Everything here is designed so that restarting the FastAPI app does NOT
lose any case, decision, or audit trail entry - it's all read back from this file.
"""
import sqlite3
import json
import os
from datetime import datetime, timezone

DB_PATH = os.getenv("SENTINEL_DB_PATH") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "sentinel.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id TEXT PRIMARY KEY,
    vertical TEXT, amount REAL, transaction_time TEXT,
    account_id TEXT, counterparty_id TEXT
);

CREATE TABLE IF NOT EXISTS risk_scores (
    transaction_id TEXT PRIMARY KEY,
    composite_score REAL, review_tier TEXT,
    isoforest_score REAL, autoencoder_score REAL, benford_score REAL, rule_score REAL,
    model_version TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE TABLE IF NOT EXISTS investigations (
    transaction_id TEXT PRIMARY KEY,
    investigation_json TEXT,   -- full Investigation Pydantic model, serialized
    created_at TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE TABLE IF NOT EXISTS cases (
    case_id TEXT PRIMARY KEY,
    transaction_id TEXT,
    risk_score REAL, risk_level TEXT, finding TEXT,
    ai_recommendation TEXT,
    auditor_decision TEXT,       -- NULL until decided
    auditor_reason TEXT,
    created_at TEXT, updated_at TEXT,
    model_version TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE TABLE IF NOT EXISTS audit_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT, case_id TEXT,
    event_type TEXT,             -- 'model_scored' | 'investigated' | 'decision' | 'override'
    payload_json TEXT,
    actor TEXT, timestamp TEXT
);

CREATE TABLE IF NOT EXISTS model_versions (
    model_version TEXT PRIMARY KEY,
    dataset_version TEXT, feature_version TEXT,
    training_date TEXT, thresholds_json TEXT, evaluation_metrics_json TEXT
);

CREATE TABLE IF NOT EXISTS use_case_signals (
    transaction_id TEXT PRIMARY KEY,
    use_case TEXT,                      -- human-readable label(s), e.g. "Fan-Out Network"
    use_case_reasons_json TEXT,         -- JSON list of reason strings
    uc_new_device_high_value INTEGER,
    uc_fan_in_fan_out INTEGER,          -- 0=none, 1=fan-in, 2=fan-out, 3=both
    uc_near_threshold_structuring INTEGER,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);
"""

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()

def now():
    return datetime.now(timezone.utc).isoformat()

def upsert_transaction(conn, row):
    conn.execute(
        "INSERT OR REPLACE INTO transactions (transaction_id, vertical, amount, transaction_time, account_id, counterparty_id) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (row["transaction_id"], row["vertical"], float(row["amount"]), str(row["transaction_time"]),
         row["account_id"], row["counterparty_id"]),
    )

def upsert_risk_score(conn, row, model_version):
    conn.execute(
        "INSERT OR REPLACE INTO risk_scores (transaction_id, composite_score, review_tier, "
        "isoforest_score, autoencoder_score, benford_score, rule_score, model_version) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (row["transaction_id"], float(row["composite_score"]), row["review_tier"],
         float(row["isoforest_score"]), float(row["autoencoder_score"]),
         float(row.get("benford_score", 0)), float(row.get("rule_score", 0)), model_version),
    )
    log_audit_event(conn, row["transaction_id"], None, "model_scored",
                     {"composite_score": float(row["composite_score"]), "review_tier": row["review_tier"]},
                     actor="system")

def upsert_use_case_signals(conn, row):
    """Persists the mentor-aligned business-use-case signals (use_cases.py) for a
    transaction. Additive to the existing schema - does not touch risk_scores or any
    other table. use_case/use_case_reasons are NULL/empty when no use case applies."""
    reasons_raw = row.get("use_case_reasons")
    # use_case_reasons round-trips through parquet as a numpy array, not a Python list -
    # `x or []` is invalid for numpy arrays (ambiguous truth value), so check explicitly.
    if reasons_raw is None:
        reasons = []
    else:
        reasons = list(reasons_raw)
    conn.execute(
        "INSERT OR REPLACE INTO use_case_signals (transaction_id, use_case, use_case_reasons_json, "
        "uc_new_device_high_value, uc_fan_in_fan_out, uc_near_threshold_structuring) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (row["transaction_id"], row.get("use_case"), json.dumps(reasons, default=str),
         int(row.get("uc_new_device_high_value", 0)), int(row.get("uc_fan_in_fan_out", 0)),
         int(row.get("uc_near_threshold_structuring", 0))),
    )

def upsert_investigation_and_case(conn, transaction_id, investigation_dict, model_version):
    conn.execute(
        "INSERT OR REPLACE INTO investigations (transaction_id, investigation_json, created_at) VALUES (?, ?, ?)",
        (transaction_id, json.dumps(investigation_dict), now()),
    )
    case_id = f"CASE_{transaction_id}"
    existing = conn.execute("SELECT * FROM cases WHERE case_id = ?", (case_id,)).fetchone()
    if existing is None:
        conn.execute(
            "INSERT INTO cases (case_id, transaction_id, risk_score, risk_level, finding, "
            "ai_recommendation, auditor_decision, auditor_reason, created_at, updated_at, model_version) "
            "VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, ?)",
            (case_id, transaction_id, investigation_dict["risk_score"], investigation_dict["risk_level"],
             investigation_dict["finding"], investigation_dict["recommended_action"], now(), now(), model_version),
        )
    else:
        conn.execute(
            "UPDATE cases SET risk_score=?, risk_level=?, finding=?, ai_recommendation=?, updated_at=? WHERE case_id=?",
            (investigation_dict["risk_score"], investigation_dict["risk_level"], investigation_dict["finding"],
             investigation_dict["recommended_action"], now(), case_id),
        )
    log_audit_event(conn, transaction_id, case_id, "investigated", investigation_dict, actor="agent")
    return case_id

def record_decision(conn, transaction_id, action, reason, auditor):
    case_id = f"CASE_{transaction_id}"
    row = conn.execute("SELECT * FROM cases WHERE case_id = ?", (case_id,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO cases (case_id, transaction_id, risk_score, risk_level, finding, "
            "ai_recommendation, auditor_decision, auditor_reason, created_at, updated_at, model_version) "
            "VALUES (?, ?, NULL, NULL, NULL, NULL, ?, ?, ?, ?, ?)",
            (case_id, transaction_id, action, reason, now(), now(), "v2.0"),
        )
        log_audit_event(conn, transaction_id, case_id, "decision",
                         {"action": action, "reason": reason, "previous_state": None, "new_state": action},
                         actor=auditor)
        return case_id
    previous_state = row["auditor_decision"]
    conn.execute(
        "UPDATE cases SET auditor_decision=?, auditor_reason=?, updated_at=? WHERE case_id=?",
        (action, reason, now(), case_id),
    )
    event_type = "override" if previous_state and previous_state != action else "decision"
    log_audit_event(conn, transaction_id, case_id, event_type,
                     {"action": action, "reason": reason, "previous_state": previous_state, "new_state": action},
                     actor=auditor)
    return case_id

def log_audit_event(conn, transaction_id, case_id, event_type, payload, actor):
    conn.execute(
        "INSERT INTO audit_events (transaction_id, case_id, event_type, payload_json, actor, timestamp) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (transaction_id, case_id, event_type, json.dumps(payload, default=str), actor, now()),
    )

def get_audit_trail(conn, transaction_id):
    rows = conn.execute(
        "SELECT * FROM audit_events WHERE transaction_id = ? ORDER BY timestamp ASC", (transaction_id,)
    ).fetchall()
    return [dict(r) for r in rows]

def record_model_version(conn, model_version, dataset_version, feature_version, thresholds, eval_metrics):
    conn.execute(
        "INSERT OR REPLACE INTO model_versions (model_version, dataset_version, feature_version, "
        "training_date, thresholds_json, evaluation_metrics_json) VALUES (?, ?, ?, ?, ?, ?)",
        (model_version, dataset_version, feature_version, now(),
         json.dumps(thresholds, default=str), json.dumps(eval_metrics, default=str)),
    )

if __name__ == "__main__":
    init_db()
    print(f"Initialized database at {DB_PATH}")
    conn = get_connection()
    tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    print("Tables:", [t["name"] for t in tables])
    conn.close()
