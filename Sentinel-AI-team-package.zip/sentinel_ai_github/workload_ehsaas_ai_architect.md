# Ehsaas: Complete Execution Manual

**Role:** Generative AI, Cloud & Database Architect
**Tech Stack:** Scikit-Learn (MLPRegressor), LangChain, Google Gemini API, HuggingFace (DeBERTa), MongoDB Atlas, Render, W&B

---

## Task 1: Deep Learning (Autoencoder)
**Goal:** Detect complex, non-linear anomalies that the Isolation Forest misses.

**What is an Autoencoder doing here?**
An Autoencoder is a neural network that learns to compress normal transactions into a tiny bottleneck and then reconstruct them. When a fraudulent transaction comes in, the network struggles to reconstruct it accurately, producing a high "Reconstruction Error" (MSE). We use that error as a fraud score.

### 1.1 Architecture
```python
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
import numpy as np

FEATURES = [
    "amount", "amount_zscore", "velocity_7d", "velocity_30d",
    "velocity_spike_ratio", "balance_depletion_ratio",
    "amount_to_balance_ratio", "days_since_last_txn",
    "transaction_frequency", "is_new_counterparty",
    "amount_pct_rank_personal", "amount_pct_rank_peer_group",
    "cumulative_amount", "merchant_concentration",
]

# 1. Scale features (TRAIN ONLY - no data leakage)
scaler = StandardScaler()
X_train = scaler.fit_transform(train[FEATURES])

# 2. Build Autoencoder with strict bottleneck: 14 inputs -> 8 -> 3 -> 8 -> 14 outputs
#    The "3" forces the network to learn only the 3 most important patterns
ae = MLPRegressor(
    hidden_layer_sizes=(8, 3, 8),
    activation='relu',
    max_iter=300,
    random_state=42,
    early_stopping=True,     # Stop training when validation loss stops improving
    n_iter_no_change=10      # Wait 10 epochs before stopping
)

# 3. Train: Target is the input itself (self-reconstruction)
ae.fit(X_train, X_train)

# 4. Score: Calculate Mean Squared Error (Reconstruction Error)
def get_ae_scores(X):
    reconstructed = ae.predict(X)
    mse = np.mean((X - reconstructed) ** 2, axis=1)
    return mse

# 5. Min-Max normalize MSE to 0-1 range
ae_train_raw = get_ae_scores(X_train)
ae_lo, ae_span = ae_train_raw.min(), (ae_train_raw.max() - ae_train_raw.min())
ae_normalized = ((ae_train_raw - ae_lo) / ae_span).clip(0, 1)
```

### 1.2 How to score Validation & Holdout
```python
# IMPORTANT: Use the scaler fitted on TRAIN. Never refit.
X_val = scaler.transform(validation[FEATURES])
X_holdout = scaler.transform(holdout[FEATURES])

# Use the same ae_lo and ae_span from TRAIN
val_scores = ((get_ae_scores(X_val) - ae_lo) / ae_span).clip(0, 1)
holdout_scores = ((get_ae_scores(X_holdout) - ae_lo) / ae_span).clip(0, 1)
```

---

## Task 2: Database Architecture (MongoDB Atlas)
**Goal:** Set up the cloud database that stores everything.

### 2.1 Provision the Cluster
1. Go to `cloud.mongodb.com` and create a free account.
2. Create a **Free M0 Cluster** (512MB, always-on, never expires).
3. Under "Database Access", create a user with read/write permissions.
4. Under "Network Access", add `0.0.0.0/0` (allow all IPs for development).
5. Copy the connection string. It looks like: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/sentinel_ai`
6. Save it in your `.env` file as `MONGO_URI`.

### 2.2 Collection Schemas

**Collection 1: `transactions`**
Stores every transaction from all 3 datasets.
```json
{
    "transaction_id": "TXN_7597B6EC6D4C",
    "transaction_time": "2025-03-17T15:00:00",
    "amount": 86.93,
    "transaction_type": "Transfer",
    "customer_id": "CUST_04557",
    "counterparty_id": "MERCH_0749",
    "vertical": "retail",
    "composite_score": 78.4,
    "review_tier": "priority_review",
    "isoforest_score": 0.82,
    "autoencoder_score": 0.71,
    "benford_score": 0.65,
    "rule_flags": ["flag_just_under_limit", "flag_new_device"]
}
```

**Collection 2: `case_files`**
Stores the AI-generated investigation reports.
```json
{
    "transaction_id": "TXN_7597B6EC6D4C",
    "llm_provider": "gemini-2.5-flash",
    "explanation": "Transaction flagged due to new device login...",
    "severity": "HIGH",
    "cited_document_id": "DOC_RETAIL_POLICY_042",
    "confidence_score": 0.92,
    "hallucination_check": "PASSED",
    "created_at": "2025-03-17T15:02:00"
}
```

**Collection 3: `audit_logs`**
Stores the tamper-proof Hash Chain logs (built by Ayush).
```json
{
    "action": "AI_INVESTIGATION_COMPLETE",
    "transaction_id": "TXN_7597B6EC6D4C",
    "user": "system",
    "timestamp": "2025-03-17T15:02:01",
    "prev_hash": "a3f2b8c9...",
    "current_hash": "7d4e1f0a..."
}
```

### 2.3 Python Connection
```python
from pymongo import MongoClient
import os

client = MongoClient(os.getenv("MONGO_URI"))
db = client["sentinel_ai"]
transactions_col = db["transactions"]
case_files_col = db["case_files"]
audit_logs_col = db["audit_logs"]
```

---

## Task 3: Agentic AI Pipeline (Gemini Orchestration)
**Goal:** When a transaction is flagged, automatically generate an explanation.

### 3.1 The Full Pipeline Flow
```
Flagged Transaction -> Aaditya's FAISS search -> Top 3 Documents -> Gemini Prompt -> JSON Report
```

### 3.2 LangChain + Gemini Integration
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
import json

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.1  # Low temperature = less creativity = fewer hallucinations
)

SYSTEM_PROMPT = """You are a senior financial auditor at a Big Four firm.
You are investigating a flagged transaction. You MUST:
1. Reference ONLY the evidence provided in the RETRIEVED DOCUMENT below.
2. Never invent numbers, dates, or policy names that are not in the document.
3. Output ONLY valid JSON in this exact format:
{{"explanation": "...", "severity": "HIGH|MEDIUM|LOW", "cited_evidence": "..."}}

TRANSACTION DATA:
{transaction_data}

RETRIEVED DOCUMENT:
{retrieved_document}
"""

prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)
chain = prompt | llm
```

### 3.3 The Deterministic Fallback (CRITICAL)
If Gemini crashes, rate-limits, or returns garbage JSON, the demo must NEVER break:

```python
def investigate_transaction(tx_data, retrieved_doc):
    try:
        response = chain.invoke({
            "transaction_data": json.dumps(tx_data),
            "retrieved_document": retrieved_doc
        })
        result = json.loads(response.content)
        return result
    except Exception as e:
        # FALLBACK: Generate a safe, deterministic report
        return deterministic_investigate(tx_data)

def deterministic_investigate(tx_data):
    """Rule-based fallback. No LLM needed. Always works."""
    flags = tx_data.get("rule_flags", [])
    if "flag_just_under_limit" in flags:
        explanation = (f"Transaction of ${tx_data['amount']:.2f} is within 5% of the "
                       f"reporting threshold. Pattern consistent with structuring.")
        severity = "HIGH"
    elif "flag_hub_counterparty" in flags:
        explanation = (f"Counterparty {tx_data['counterparty_id']} receives funds from "
                       f"an unusually high number of distinct sources. Fan-in pattern detected.")
        severity = "HIGH"
    else:
        explanation = (f"Transaction flagged by ML ensemble with composite score "
                       f"{tx_data.get('composite_score', 'N/A')}. Manual review recommended.")
        severity = "MEDIUM"
    return {"explanation": explanation, "severity": severity, "cited_evidence": "N/A - Deterministic Fallback"}
```

---

## Task 4: Hallucination Guard (DeBERTa NLP)
**Goal:** Mathematically verify Gemini didn't make up facts.

```python
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# 1. Load the NLI model
tokenizer = AutoTokenizer.from_pretrained("cross-encoder/nli-deberta-v3-small")
nli_model = AutoModelForSequenceClassification.from_pretrained("cross-encoder/nli-deberta-v3-small")

def check_hallucination(premise: str, hypothesis: str) -> dict:
    """
    premise = The raw text of the retrieved invoice/policy document.
    hypothesis = The explanation text that Gemini generated.
    Returns: {"entailment": 0.92, "neutral": 0.05, "contradiction": 0.03, "passed": True}
    """
    inputs = tokenizer(premise, hypothesis, return_tensors="pt", truncation=True, max_length=512)
    with torch.no_grad():
        logits = nli_model(**inputs).logits
    
    # DeBERTa NLI outputs: [Contradiction, Neutral, Entailment]
    probs = torch.softmax(logits, dim=1)[0].tolist()
    
    result = {
        "contradiction": round(probs[0], 4),
        "neutral": round(probs[1], 4),
        "entailment": round(probs[2], 4),
    }
    
    # SAFETY THRESHOLD: If contradiction > 15%, block the report
    result["passed"] = result["contradiction"] < 0.15
    return result
```

### 4.1 How to use it in the pipeline
```python
# After Gemini generates a report:
gemini_output = investigate_transaction(tx_data, retrieved_doc)
hallucination_check = check_hallucination(
    premise=retrieved_doc,
    hypothesis=gemini_output["explanation"]
)

if hallucination_check["passed"]:
    # Safe to show to auditor
    case_files_col.insert_one({**gemini_output, "hallucination_check": "PASSED"})
else:
    # BLOCKED - AI hallucinated. Use deterministic fallback instead.
    fallback = deterministic_investigate(tx_data)
    case_files_col.insert_one({**fallback, "hallucination_check": "BLOCKED"})
```

---

## Task 5: Cloud MLOps & Deployment

### 5.1 Weights & Biases (W&B) Integration
```python
import wandb

wandb.init(project="sentinel-ai", name="autoencoder-v2")
wandb.log({
    "train_mse_mean": ae_train_raw.mean(),
    "train_mse_std": ae_train_raw.std(),
    "contamination": 0.03,
    "holdout_auc": roc_auc_score(holdout["fraud_label"], holdout["composite_score"])
})
wandb.finish()
```

### 5.2 Render Deployment
1. Create a `Procfile` in the project root: `web: gunicorn app:app --bind 0.0.0.0:$PORT`
2. Create a `render.yaml` for auto-deploy configuration.
3. Push to GitHub. Connect the repo to Render.
4. Add environment variables in Render Dashboard: `MONGO_URI`, `GEMINI_API_KEY`.
