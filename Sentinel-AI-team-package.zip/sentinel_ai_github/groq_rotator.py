"""
Sentinel AI - Groq API Key Rotator & High-Availability Connection Manager

Handles:
1. Automatic 6-hour background key rotation across multiple Groq API keys.
   Every 6 hours, the system deterministically switches the active primary key
   in the background without requiring user intervention or restart.
2. Seamless failover / rate-limit mitigation:
   If the active key encounters a 429 RateLimitError or quota issue during its
   active window, the secondary standby key is immediately utilized to ensure
   100% uninterrupted forensic investigations.
3. Cooldown management:
   Temporarily marks rate-limited keys so concurrent or immediate subsequent
   requests don't suffer delay attempting a known rate-limited key.
4. Privacy & Secret hygiene:
   Keys are masked (e.g. gsk_aCcV...5Bn8) in all logging and diagnostic telemetry.
"""

import os
import time
import logging
import asyncio
from typing import List, Tuple, Optional, Dict, Any

logger = logging.getLogger("sentinel.groq_rotator")

# In-memory cooldown tracking for keys that hit rate limits: key -> cooldown_expiry_timestamp
_KEY_COOLDOWNS: Dict[str, float] = {}


def mask_key(key: Optional[str]) -> str:
    """Masks an API key for safe logging (e.g. 'gsk_aCcV...5Bn8')."""
    if not key or not isinstance(key, str):
        return "<none>"
    key = key.strip()
    if len(key) <= 12:
        return "***"
    return f"{key[:8]}...{key[-4:]}"


def get_groq_api_keys() -> List[str]:
    """
    Parses and returns all configured Groq API keys in order.
    Supports:
      - GROQ_API_KEYS (comma-separated list)
      - GROQ_API_KEY, GROQ_API_KEY_1, GROQ_API_KEY_2, GROQ_API_KEY_3...
    Duplicates are filtered while preserving configuration order.
    """
    keys: List[str] = []

    # 1. Comma-separated list in GROQ_API_KEYS
    raw_list = os.environ.get("GROQ_API_KEYS", "").strip()
    if raw_list:
        for k in raw_list.split(","):
            cleaned = k.strip()
            if cleaned and cleaned not in keys:
                keys.append(cleaned)

    # 2. Individual environment variable slots
    env_slots = ["GROQ_API_KEY", "GROQ_API_KEY_1", "GROQ_API_KEY_2", "GROQ_API_KEY_3"]
    for slot in env_slots:
        val = os.environ.get(slot, "").strip()
        if val and val not in keys:
            keys.append(val)

    return keys


def get_rotation_interval_seconds() -> float:
    """Returns the rotation interval in seconds (default: 6 hours = 21,600s)."""
    try:
        hours = float(os.environ.get("GROQ_KEY_ROTATION_HOURS", "6"))
    except (ValueError, TypeError):
        hours = 6.0
    return max(1.0, hours * 3600.0)


def mark_key_rate_limited(key: str, cooldown_seconds: float = 60.0, now: Optional[float] = None) -> None:
    """Marks a key as temporarily rate-limited with a cooldown expiration."""
    if not key:
        return
    current_time = now if now is not None else time.time()
    expiry = current_time + max(5.0, cooldown_seconds)
    _KEY_COOLDOWNS[key] = expiry
    logger.warning(
        "Groq key %s rate-limited; placing on cooldown for %.0fs until %s.",
        mask_key(key),
        cooldown_seconds,
        time.strftime("%H:%M:%S", time.localtime(expiry)),
    )


def is_key_cooling_down(key: str, now: Optional[float] = None) -> bool:
    """Returns True if the key is currently on cooldown."""
    if not key or key not in _KEY_COOLDOWNS:
        return False
    current_time = now if now is not None else time.time()
    if current_time >= _KEY_COOLDOWNS[key]:
        del _KEY_COOLDOWNS[key]
        return False
    return True


def get_groq_rotation_status(now: Optional[float] = None) -> Dict[str, Any]:
    """
    Computes current 6-hour slot, active key index, time remaining, and rotation state.
    Calculation is purely deterministic based on system clock (or provided timestamp).
    """
    current_time = now if now is not None else time.time()
    keys = get_groq_api_keys()
    interval = get_rotation_interval_seconds()

    if not keys:
        return {
            "total_keys": 0,
            "active_index": -1,
            "active_key": None,
            "active_key_masked": "<none>",
            "rotation_hours": interval / 3600.0,
            "seconds_remaining": 0.0,
            "period": 0,
            "cooling_down_count": 0,
        }

    period = int(current_time // interval)
    active_index = period % len(keys)
    seconds_remaining = interval - (current_time % interval)

    cooling = sum(1 for k in keys if is_key_cooling_down(k, current_time))

    return {
        "total_keys": len(keys),
        "active_index": active_index,
        "active_key": keys[active_index],
        "active_key_masked": mask_key(keys[active_index]),
        "rotation_hours": interval / 3600.0,
        "seconds_remaining": seconds_remaining,
        "period": period,
        "cooling_down_count": cooling,
    }


def get_ordered_groq_keys(now: Optional[float] = None) -> List[Tuple[int, str]]:
    """
    Returns keys prioritized for the current request.
    Order logic:
      1. Scheduled key for current 6-hour window (unless currently on 429 cooldown
         and another healthy key is ready).
      2. Standby/fallback key(s) in rotation order.
    Returns:
      List of tuples: (original_index, key_str)
    """
    current_time = now if now is not None else time.time()
    keys = get_groq_api_keys()
    if not keys:
        return []

    interval = get_rotation_interval_seconds()
    period = int(current_time // interval)
    scheduled_index = period % len(keys)

    # Base rotation order starting from scheduled primary
    base_order = [( (scheduled_index + i) % len(keys), keys[(scheduled_index + i) % len(keys)] )
                  for i in range(len(keys))]

    if len(keys) <= 1:
        return base_order

    # Check if scheduled key is cooling down
    primary_idx, primary_key = base_order[0]
    if is_key_cooling_down(primary_key, current_time):
        # Look for a standby key not cooling down
        healthy = [item for item in base_order if not is_key_cooling_down(item[1], current_time)]
        cooling = [item for item in base_order if is_key_cooling_down(item[1], current_time)]
        if healthy:
            logger.info(
                "Primary Groq key slot #%d (%s) is on cooldown; prioritizing standby slot #%d (%s).",
                primary_idx + 1,
                mask_key(primary_key),
                healthy[0][0] + 1,
                mask_key(healthy[0][1]),
            )
            return healthy + cooling

    return base_order


async def background_key_rotation_monitor(interval_check_seconds: float = 30.0) -> None:
    """
    Background worker that runs continuously and logs when a 6-hour window transition occurs.
    """
    last_period: Optional[int] = None
    logger.info("Groq API Key 6-Hour Background Rotation Monitor started.")

    while True:
        try:
            status = get_groq_rotation_status()
            curr_period = status["period"]

            if last_period is not None and curr_period != last_period:
                logger.info(
                    "GROQ KEY ROTATION [Background]: Switched active key to slot #%d (%s) for the next %.1f hours. "
                    "(Total pool: %d keys)",
                    status["active_index"] + 1,
                    status["active_key_masked"],
                    status["rotation_hours"],
                    status["total_keys"],
                )
            elif last_period is None and status["total_keys"] > 0:
                hours_left = status["seconds_remaining"] / 3600.0
                logger.info(
                    "Groq Key Rotator initialized: Active slot #%d (%s) with %.2f hours remaining in current 6h window. "
                    "(Total pool: %d keys)",
                    status["active_index"] + 1,
                    status["active_key_masked"],
                    hours_left,
                    status["total_keys"],
                )

            last_period = curr_period

            # Sleep either check interval or remaining seconds + 0.5
            sleep_time = min(interval_check_seconds, max(1.0, status["seconds_remaining"] + 0.5))
            await asyncio.sleep(sleep_time)

        except asyncio.CancelledError:
            logger.info("Groq Key Rotation Monitor cancelled.")
            break
        except Exception as e:
            logger.warning("Error in background_key_rotation_monitor: %s", e)
            await asyncio.sleep(interval_check_seconds)
