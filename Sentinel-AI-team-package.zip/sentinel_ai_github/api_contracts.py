"""Validated request contracts shared by Sentinel AI online endpoints."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EngineeredScoreRequest(BaseModel):
    """Canonical engineered row; model features are checked by ModelBundle."""

    model_config = ConfigDict(extra="allow")

    transaction_id: str | None = None
    vertical: str
    rule_score: float = Field(default=0.0, ge=0.0, le=100.0)
    benford_score: float = Field(default=0.0, ge=0.0, le=100.0)


class CanonicalScoreRequest(BaseModel):
    """Raw transaction accepted by the causal online feature-serving boundary."""

    model_config = ConfigDict(extra="allow")

    transaction_id: str = Field(min_length=1, max_length=200)
    transaction_time: datetime
    vertical: str
    account_id: str = Field(min_length=1, max_length=200)
    customer_id: str | None = Field(default=None, max_length=200)
    counterparty_id: str = Field(min_length=1, max_length=200)
    amount: float = Field(gt=0)
    balance_before: float = Field(ge=0)
    balance_after: float | None = Field(default=None, ge=0)
    rule_score: float = Field(default=0.0, ge=0.0, le=100.0)
    benford_score: float = Field(default=0.0, ge=0.0, le=100.0)

    @field_validator("amount", "balance_before", "rule_score", "benford_score")
    @classmethod
    def finite_number(cls, value: float) -> float:
        if not isinstance(value, (int, float)) or value != value or value in (float("inf"), float("-inf")):
            raise ValueError("numeric values must be finite")
        return float(value)


class DecisionRequest(BaseModel):
    auditor: str = Field(min_length=1, max_length=200)
    action: str
    reason: str | None = Field(default=None, max_length=2000)

    @field_validator("action")
    @classmethod
    def valid_action(cls, value: str) -> str:
        allowed = {"APPROVE", "ACCEPT", "ESCALATE", "SAR", "DISMISS", "REQUEST_MORE_EVIDENCE", "OVERRIDE"}
        if value not in allowed:
            raise ValueError(f"action must be one of {sorted(allowed)}")
        return value


def model_payload(model: BaseModel) -> dict[str, Any]:
    """Return a JSON-compatible mapping while retaining permitted extra fields."""
    return model.model_dump(mode="json")
