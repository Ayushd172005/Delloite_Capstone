"""Generate a content-addressed manifest for Sentinel AI ML/data artifacts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
ARTIFACTS = [
    "feature_registry.json",
    "score_contract.json",
    "data_contract.md",
    "model_metadata.json",
    "calibrated_composite_weights.json",
    "calibrated_thresholds.json",
    "scored_transactions.parquet",
    "risk_scored_train.parquet",
    "risk_scored_validation.parquet",
    "risk_scored_holdout.parquet",
    "evidence_documents.parquet",
    "reports/model_card.md",
    "reports/evaluation_report.md",
    "reports/ablation_report.md",
    "reports/drift_report.md",
    "reports/workload_report.md",
    "model_bundle/manifest.json",
    "model_bundle/aml.joblib",
    "model_bundle/corporate.joblib",
    "model_bundle/retail.joblib",
]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_manifest() -> dict:
    files = {}
    missing = []
    for relative in ARTIFACTS:
        path = ROOT / relative
        if not path.exists():
            missing.append(relative)
            continue
        files[relative] = {
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    return {
        "manifest_version": "artifact-manifest-2026-09-12-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "project": "sentinel-ai",
        "synthetic_benchmark_disclosure": True,
        "files": files,
        "missing_expected_files": missing,
        "status": "PASS" if not missing else "INCOMPLETE",
    }


if __name__ == "__main__":
    output = ROOT / "artifact_manifest.json"
    manifest = build_manifest()
    output.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": manifest["status"], "files": len(manifest["files"]), "missing": manifest["missing_expected_files"]}, indent=2))
