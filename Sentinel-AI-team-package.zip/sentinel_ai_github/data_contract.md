# Sentinel AI Canonical Data Contract

**Contract version:** `data-contract-2026-09-12-v1`

This contract describes the currently implemented Sentinel AI benchmark pipeline. The three provided datasets are synthetic and share a common generator. Metrics are benchmark evidence only, not real-world fraud-detection performance.

## Canonical record

Every normalized transaction must contain `transaction_id`, `transaction_time`, `amount`, `transaction_type`, `customer_id`, `account_id`, `counterparty_id`, `vertical`, `fraud_label`, `balance_before`, `balance_after`, `device_id`, `location`, `payment_method`, and `transaction_frequency`. `fraud_label` is evaluation-only and must never be used by the unsupervised fit or operating-threshold calibration.

The implementation normalizes the source field `merchant_id` to `counterparty_id`. AML grouping uses `customer_id`, because AML `account_id` values are near-unique per-transaction references. Corporate and retail use `account_id` as their behavioral entity.

## Dataset policy

| Vertical | Rows | Timestamp characteristics | Meaningful fields | Known limitations |
|---|---:|---|---|---|
| Retail | 115,000 | Intraday datetime | Device, location, off-hours | Synthetic balance warnings exist; retail threshold pattern is structurally sparse |
| Corporate | 115,000 | Date-only at midnight | Amount, account, counterparty | Device/location are constant placeholders; off-hours and location signals are disabled |
| AML | 115,000 | Date-only at midnight | Customer, counterparty, location | Device is constant; account ID is not a recurring entity; off-hours is disabled |

## Feature and leakage policy

Feature history is computed in stable chronological order within the configured entity. Current-row and future-row information is excluded from causal history features. Peer-group amount percentile is computed against a frozen training-period reference distribution. Dataset labels are used only for post-hoc evaluation.

## Provenance requirements

Synthetic fields must be marked as synthetic in dataset metadata. Any future real-data adapter must state which fields are source-provided, derived, imputed, or synthetic. A production deployment must not silently mix synthetic and real records.

## Required validation gates

The data validation step must report nulls, duplicate transaction IDs, non-positive amounts, timestamp parse failures, balance anomalies, label distribution, date range, and constant-field warnings. Warnings must remain visible in the data-quality report even when the pipeline continues.
