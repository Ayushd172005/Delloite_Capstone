"""
Sentinel AI v2 - FastAPI backend.

Endpoints (master prompt item 22):
  GET  /health
  GET  /queue
  GET  /case/{transaction_id}
  POST /case/{transaction_id}/investigate
  POST /case/{transaction_id}/decision
  GET  /audit_trail/{transaction_id}
  GET  /metrics
  GET  /model-info

Decisions and investigations persist to SQLite (db.py) - restarting this process does
NOT lose case state; every response below is read back from the database, not from
in-memory globals (the earlier version of this code kept CASES in a Python dict, which
is exactly what item 23 in the master prompt flags as a problem: "refreshing the
browser must NOT erase decisions").
"""
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Any, Dict, Literal, Optional
import pandas as pd
import numpy as np
import json
import math
import os
import logging
import time
from collections import defaultdict, deque
import asyncio
from dotenv import load_dotenv

load_dotenv()

import db
from retrieval import EvidenceStore
from agent import SentinelTools, call_agent
from groq_rotator import background_key_rotation_monitor, get_groq_rotation_status
from model_bundle import ModelBundle
from serving_features import FeatureStore
from api_contracts import CanonicalScoreRequest, DecisionRequest, EngineeredScoreRequest, model_payload

app = FastAPI(title="Sentinel AI API", version="2.0")
logger = logging.getLogger("sentinel.api")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
_request_counts: dict[str, deque[float]] = defaultdict(deque)
_request_total = 0
_request_failures = 0
RATE_LIMIT = int(os.getenv("SENTINEL_RATE_LIMIT_PER_MINUTE", "120"))
API_KEY = os.getenv("SENTINEL_API_KEY")
allowed_origins = [origin.strip() for origin in os.getenv("SENTINEL_ALLOWED_ORIGINS", "*").split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=allowed_origins, allow_methods=["*"], allow_headers=["*"])

@app.middleware("http")
async def request_telemetry(request: Request, call_next):
    global _request_total, _request_failures
    started = time.perf_counter()
    _request_total += 1
    response = await call_next(request)
    if response.status_code >= 400:
        _request_failures += 1
    response.headers["X-Process-Time-Ms"] = f"{(time.perf_counter() - started) * 1000:.2f}"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response

def require_api_key(request: Request) -> None:
    """Optional deployment auth; local development remains open unless configured."""
    if not API_KEY:
        return
    supplied = request.headers.get("x-api-key") or request.headers.get("authorization", "").removeprefix("Bearer ")
    if supplied != API_KEY:
        raise HTTPException(status_code=401, detail="valid API key required")

def enforce_rate_limit(request: Request) -> None:
    now = time.monotonic()
    bucket = _request_counts[request.client.host if request.client else "unknown"]
    while bucket and now - bucket[0] >= 60:
        bucket.popleft()
    if len(bucket) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="rate limit exceeded; retry after one minute")
    bucket.append(now)

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
_state = {}

def load_state():
    scored = pd.read_parquet(os.path.join(DATA_DIR, "scored_transactions.parquet"))
    evidence_path = os.path.join(DATA_DIR, "evidence_documents.parquet")
    if os.path.exists(evidence_path):
        evidence_df = pd.read_parquet(evidence_path)
        store = EvidenceStore(evidence_df, scored)
        tools = SentinelTools(scored, store)
    else:
        store, tools = None, None
    _state["scored"] = scored
    _state["tools"] = tools
    bundle_dir = os.path.join(DATA_DIR, "model_bundle")
    _state["model_bundle"] = ModelBundle.load(bundle_dir) if os.path.exists(os.path.join(bundle_dir, "manifest.json")) else None
    feature_path = os.path.join(DATA_DIR, "normalized_features_benford.parquet")
    _state["feature_store"] = FeatureStore(pd.read_parquet(feature_path)) if os.path.exists(feature_path) else None
    db.init_db()

@app.on_event("startup")
async def startup():
    load_state()
    asyncio.create_task(background_key_rotation_monitor())

Decision = DecisionRequest

@app.get("/health")
def health():
    rot_status = get_groq_rotation_status()
    payload = {
        "status": "ok",
        "transactions_loaded": len(_state.get("scored", [])),
    }
    if rot_status.get("total_keys", 0) > 0:
        payload["groq_rotation"] = {
            "keys_configured": rot_status["total_keys"],
            "active_slot": rot_status["active_index"] + 1,
            "active_key": rot_status["active_key_masked"],
            "rotation_hours": rot_status["rotation_hours"],
            "hours_remaining": round(rot_status["seconds_remaining"] / 3600.0, 2),
        }
    return payload

@app.get("/queue")
def get_queue(vertical: Optional[str] = None, tier: Optional[str] = None, limit: int = 50):
    df = _state["scored"]
    df = df[df["review_tier"] != "auto_clear"]
    if vertical:
        df = df[df["vertical"] == vertical]
    if tier:
        df = df[df["review_tier"] == tier]
    df = df.sort_values("composite_score", ascending=False).head(limit)

    conn = db.get_connection()
    decided = {r["transaction_id"]: r["auditor_decision"] for r in
               conn.execute("SELECT transaction_id, auditor_decision FROM cases").fetchall()}
    conn.close()

    cols = ["transaction_id", "vertical", "amount", "composite_score", "review_tier", "rule_flag_count"]
    has_use_cases = "use_case" in df.columns
    if has_use_cases:
        cols += ["use_case"]
    records = df[cols].to_dict("records")
    for r in records:
        r["auditor_decision"] = decided.get(r["transaction_id"])
        if not has_use_cases or pd.isna(r.get("use_case")):
            r["use_case"] = None
        if pd.isna(r.get("rule_flag_count")):
            r["rule_flag_count"] = 0
        else:
            r["rule_flag_count"] = int(r["rule_flag_count"])
        for k, v in list(r.items()):
            if isinstance(v, float) and (pd.isna(v) or math.isnan(v)):
                r[k] = None
    return records

@app.get("/case/{transaction_id}")
def get_case(transaction_id: str):
    df = _state["scored"]
    row = df[df["transaction_id"] == transaction_id]
    if row.empty:
        raise HTTPException(404, "transaction not found")
    row = row.iloc[0]

    conn = db.get_connection()
    inv_row = conn.execute(
        "SELECT investigation_json FROM investigations WHERE transaction_id = ?", (transaction_id,)
    ).fetchone()
    case_row = conn.execute("SELECT * FROM cases WHERE transaction_id = ?", (transaction_id,)).fetchone()
    conn.close()

    val_bf = row.get("benford_flag")
    raw_comp = float(row["composite_score"])
    amt = float(row["amount"]) if "amount" in row.index and pd.notna(row["amount"]) else None
    vert = str(row["vertical"]) if "vertical" in row.index and pd.notna(row["vertical"]) else None
    acc_id = str(row["account_id"]) if "account_id" in row.index and pd.notna(row["account_id"]) else None
    cp_id = str(row["counterparty_id"]) if "counterparty_id" in row.index and pd.notna(row["counterparty_id"]) else None
    tx_time = str(row["transaction_time"]) if "transaction_time" in row.index and pd.notna(row["transaction_time"]) else None

    signals = {
        "composite_score": round(raw_comp, 1),
        "review_tier": str(row["review_tier"]),
        "isoforest_score": round(float(row["isoforest_score"]), 3),
        "autoencoder_score": round(float(row["autoencoder_score"]), 3),
        "benford_flag": bool(val_bf) if pd.notna(val_bf) else False,
        "rules_triggered": [c.replace("flag_", "") for c in row.index
                             if c.startswith("flag_") and row[c] == 1 and "shared" not in c and "hub" not in c],
        "amount": amt,
        "vertical": vert,
        "account_id": acc_id,
        "counterparty_id": cp_id,
    }
    if "use_case" in row.index:
        signals["use_case"] = row["use_case"] if pd.notna(row["use_case"]) else None
        raw_reasons = row.get("use_case_reasons")
        if isinstance(raw_reasons, (list, tuple, np.ndarray)):
            signals["use_case_reasons"] = list(raw_reasons)
        else:
            signals["use_case_reasons"] = []
        val_nd = row.get("uc_new_device_high_value")
        signals["uc_new_device_high_value"] = bool(val_nd) if pd.notna(val_nd) else False
        val_fifo = row.get("uc_fan_in_fan_out")
        signals["uc_fan_in_fan_out"] = int(val_fifo) if pd.notna(val_fifo) else 0
        val_nts = row.get("uc_near_threshold_structuring")
        signals["uc_near_threshold_structuring"] = bool(val_nts) if pd.notna(val_nts) else False
    else:
        signals["use_case"] = None
        signals["use_case_reasons"] = []
    investigation = json.loads(inv_row["investigation_json"]) if inv_row else None
    case = dict(case_row) if case_row else None
    transaction = {
        "transaction_id": transaction_id,
        "amount": amt,
        "vertical": vert,
        "account_id": acc_id,
        "counterparty_id": cp_id,
        "transaction_time": tx_time,
    }
    return {"signals": signals, "investigation": investigation, "case": case, "transaction": transaction}

@app.post("/case/{transaction_id}/investigate")
def investigate(transaction_id: str, force_refresh: bool = False, _: None = Depends(require_api_key)):
    if _state["tools"] is None:
        raise HTTPException(503, "evidence store not loaded - run evidence.py and retrieval.py first")
    df = _state["scored"]
    if df[df["transaction_id"] == transaction_id].empty:
        raise HTTPException(404, "transaction not found")

    inv = call_agent(transaction_id, _state["tools"], force_refresh=force_refresh)
    inv_dict = inv.model_dump()

    conn = db.get_connection()
    case_id = db.upsert_investigation_and_case(conn, transaction_id, inv_dict, model_version="v2.0")
    conn.commit()
    conn.close()
    return {"case_id": case_id, "investigation": inv_dict}

@app.post("/case/{transaction_id}/decision")
def decision(transaction_id: str, decision: Decision, _: None = Depends(require_api_key)):
    df = _state["scored"]
    if df[df["transaction_id"] == transaction_id].empty:
        raise HTTPException(404, "transaction not found")
    conn = db.get_connection()
    case_id = db.record_decision(conn, transaction_id, decision.action, decision.reason, decision.auditor)
    conn.commit()
    conn.close()
    return {"status": "recorded", "case_id": case_id, "action": decision.action}

@app.get("/audit_trail/{transaction_id}")
def audit_trail(transaction_id: str):
    conn = db.get_connection()
    trail = db.get_audit_trail(conn, transaction_id)
    conn.close()
    return trail

@app.get("/metrics")
def metrics():
    path = os.path.join(DATA_DIR, "workload_metrics.json")
    if not os.path.exists(path):
        raise HTTPException(503, "workload_metrics.json not found - run workload_metrics.py first")
    with open(path) as f:
        return json.load(f)

@app.get("/model-info")
def model_info():
    conn = db.get_connection()
    rows = conn.execute("SELECT * FROM model_versions").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/score/engineered")
def score_engineered(payload: EngineeredScoreRequest, request: Request, _: None = Depends(require_api_key)):
    """Score one canonical transaction after the serving feature layer has engineered history features.

    This endpoint intentionally does not fabricate account history from one row. The
    caller must provide the exact ordered feature set from feature_registry.json;
    ModelBundle validates presence and finiteness before inference.
    """
    bundle = _state.get("model_bundle")
    if bundle is None:
        raise HTTPException(503, "model bundle unavailable - run model_bundle.py first")
    enforce_rate_limit(request)
    try:
        return bundle.score_one(model_payload(payload))
    except (TypeError, ValueError, KeyError) as exc:
        raise HTTPException(422, str(exc)) from exc

@app.post("/score")
def score_canonical(payload: CanonicalScoreRequest, request: Request, _: None = Depends(require_api_key)):
    """Engineer causal history features and score one new canonical transaction."""
    bundle = _state.get("model_bundle")
    feature_store = _state.get("feature_store")
    if bundle is None or feature_store is None:
        raise HTTPException(503, "online scoring artifacts unavailable")
    enforce_rate_limit(request)
    try:
        raw_dict = model_payload(payload)
        if payload.vertical == "aml" and not raw_dict.get("customer_id"):
            raw_dict["customer_id"] = raw_dict.get("account_id")
        engineered = feature_store.engineer_one(raw_dict)
        return bundle.score_one(engineered)
    except (TypeError, ValueError, KeyError) as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/score/pipeline")
def score_and_investigate_pipeline(payload: CanonicalScoreRequest, request: Request, _: None = Depends(require_api_key)):
    """Full end-to-end pipeline:
    1. FeatureStore engineers point-in-time causal features
    2. ModelBundle executes ensemble scoring (Isolation Forest + Autoencoder + MLP + Benford)
    3. Persists transaction & risk scores to SQLite
    4. Updates in-memory queue & tools
    5. Sentinel Intelligence Engine executes forensic investigation & evidence synthesis
    6. Persists case & investigation to SQLite
    7. Returns complete scores, features, and forensic investigation report.
    """
    bundle = _state.get("model_bundle")
    feature_store = _state.get("feature_store")
    if bundle is None or feature_store is None:
        raise HTTPException(503, "online scoring artifacts unavailable")
    enforce_rate_limit(request)
    try:
        raw_dict = model_payload(payload)
        if payload.vertical == "aml" and not raw_dict.get("customer_id"):
            raw_dict["customer_id"] = raw_dict.get("account_id")
        engineered = feature_store.engineer_one(raw_dict)
        scores = bundle.score_one(engineered)

        # Persist to SQLite
        conn = db.get_connection()
        tx_row = {
            "transaction_id": payload.transaction_id,
            "vertical": payload.vertical,
            "amount": float(payload.amount),
            "transaction_time": str(payload.transaction_time),
            "account_id": payload.account_id,
            "counterparty_id": payload.counterparty_id,
        }
        db.upsert_transaction(conn, tx_row)
        score_row = {
            "transaction_id": payload.transaction_id,
            "composite_score": float(scores["composite_score"]),
            "review_tier": str(scores["review_tier"]),
            "isoforest_score": float(scores.get("isoforest_score") or 0.0),
            "autoencoder_score": float(scores.get("autoencoder_score") or 0.0),
            "benford_score": float(scores.get("benford_score") or 0.0),
            "rule_score": float(scores.get("rule_score") or 0.0),
        }
        db.upsert_risk_score(conn, score_row, model_version="v2.0")
        conn.commit()

        # Sync with in-memory scored df & tools so Sentinel agent can investigate
        full_row = {**raw_dict, **engineered, **scores}
        full_row["transaction_time"] = pd.to_datetime(full_row["transaction_time"])
        full_row["rule_flag_count"] = int(bool(scores.get("rule_score", 0.0) > 0)) + int(bool(scores.get("benford_score", 0.0) > 0))
        full_row["use_case"] = "simulated_pipeline_case"
        full_row["use_case_reasons"] = ["Interactive pipeline scoring", f"Review tier: {scores['review_tier']}"]
        new_row_df = pd.DataFrame([full_row])

        current_scored = _state.get("scored", pd.DataFrame())
        if not current_scored.empty and not current_scored[current_scored["transaction_id"] == payload.transaction_id].empty:
            current_scored = current_scored[current_scored["transaction_id"] != payload.transaction_id]

        updated_scored = pd.concat([new_row_df, current_scored], ignore_index=True)
        _state["scored"] = updated_scored

        # Re-index tools with updated dataframe
        evidence_path = os.path.join(DATA_DIR, "evidence_documents.parquet")
        if os.path.exists(evidence_path):
            evidence_df = pd.read_parquet(evidence_path)
            store = EvidenceStore(evidence_df, updated_scored)
            tools = SentinelTools(updated_scored, store)
            _state["tools"] = tools
        else:
            tools = _state.get("tools")

        # Run Sentinel agent investigation
        inv = call_agent(payload.transaction_id, tools, force_refresh=True)
        inv_dict = inv.model_dump()

        # Upsert case in SQLite
        case_id = db.upsert_investigation_and_case(conn, payload.transaction_id, inv_dict, model_version="v2.0")
        conn.commit()
        conn.close()

        clean_features = {k: v for k, v in engineered.items() if isinstance(v, (int, float, str, bool))}

        return {
            "transaction_id": payload.transaction_id,
            "scores": scores,
            "engineered_features": clean_features,
            "investigation": inv_dict,
            "case_id": case_id,
            "llm_provider": "Sentinel Neural Core v2.4 (Self-Hosted)",
            "status": "success",
        }
    except (TypeError, ValueError, KeyError) as exc:
        raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        logger.exception("Pipeline execution failed: %s", exc)
        raise HTTPException(500, f"Pipeline execution failed: {str(exc)}") from exc


@app.get("/observability")
def observability(_: None = Depends(require_api_key)):
    """Deployment-safe telemetry surface; no transaction data is exposed."""
    return {
        "requests_total": _request_total,
        "request_failures": _request_failures,
        "rate_limit_per_minute": RATE_LIMIT,
        "api_key_configured": bool(API_KEY),
        "model_bundle_loaded": _state.get("model_bundle") is not None,
        "feature_store_loaded": _state.get("feature_store") is not None,
    }
