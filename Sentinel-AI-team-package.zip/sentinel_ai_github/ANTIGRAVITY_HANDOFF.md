# Sentinel AI — Remaining Work and Antigravity Handoff

## Current status

The repository is code-complete for the local production-style prototype. The React website consumes the real FastAPI queue, case, investigation, decision, and audit APIs by default. SQLite persistence, the versioned model bundle, causal online scoring, request validation, optional API-key authentication, rate limiting, observability, and the frontend build are implemented.

The website does **not** currently provide a manual raw-transaction entry screen for `POST /score`. The online scoring endpoints are integrated at the backend boundary and are ready for an upstream transaction producer. The existing website workflow is a review console for the scored queue, not a transaction-ingestion console. Adding a manual scoring screen is a product-scope choice, not a missing bug fix.

## Completed and verified by code

| Area | Status | Evidence |
|---|---|---|
| ML/data pipeline | Complete prototype | Generated artifacts, leakage tests, holdout evaluation, reports |
| Versioned model bundle | Complete | `model_bundle/`, manifest, strict loading |
| Causal online feature serving | Complete | `FeatureStore`, `POST /score` |
| Engineered scoring boundary | Complete | `POST /score/engineered` |
| Request validation | Complete | `api_contracts.py`, HTTP 422 checks |
| Auditor workflow | Complete | Queue → case → investigate → decision → audit trail |
| Persistence | Complete prototype | SQLite restart persistence tests |
| Website API integration | Complete for review workflow | Real fetch modules and API-driven pages |
| Frontend build | Complete | Vite production build passes |
| Fabricated UI fallbacks | Removed | Missing signals now render neutral values |
| Unsupported compliance claims | Removed/reworded | Prototype/local audit language is used |
| Auth/rate limiting/telemetry | Implemented as configurable hooks | `SENTINEL_API_KEY`, rate limit, `/observability` |

## Items that cannot be completed purely in repository code

### 1. Visual browser acceptance test
Open the running website in Chrome at the configured local/API URL and check the following manually:

1. Risk Queue loads without console errors.
2. Open a case and confirm its displayed amount, vertical, risk tier, and model signals match the API response.
3. Run an investigation and confirm supporting and counter-evidence render.
4. Record a decision, refresh the page, and confirm the decision persists.
5. Open Audit Ledger and confirm events are loaded from the API.
6. Check desktop, tablet, and mobile layouts.
7. Check light/dark theme transitions and keyboard navigation.
8. Confirm failed API states show an error state rather than fabricated data.

This requires a real browser session and visual judgment. Antigravity is appropriate only if it is the available browser-automation/visual-review environment.

### 2. Deployment security choices
The repository provides configuration hooks, but the deploying team must choose and supply:

- A real `SENTINEL_API_KEY` secret through a secret manager.
- A restricted `SENTINEL_ALLOWED_ORIGINS` value instead of `*`.
- HTTPS/TLS termination.
- Reverse proxy authentication, if required.
- Production database and backup/retention policy.
- RBAC identity mapping for auditor names.
- Rate-limit values based on expected traffic.

These are environment and governance decisions, not code-only tasks.

### 3. Real data and regulatory approval
The repository uses synthetic benchmark data and templated evidence. Before any real operational use, the team must provide:

- Approved real transaction and evidence sources.
- Data-retention and privacy review.
- Validated rule thresholds and cost assumptions.
- Legal/compliance review of any regulatory terminology.
- A production model-validation and monitoring process.

### 4. Optional live LLM path
The deterministic investigation path is complete and tested. A live LLM investigation call requires an approved provider credential, model choice, budget, network access, and human review. This should be a controlled smoke test only; do not add credentials to the repository.

### 5. Production-scale substitutions
SQLite, TF-IDF retrieval, and the shallow MLP autoencoder are deliberate prototype choices. Replacing them with PostgreSQL, managed vector retrieval/embeddings, or a deep autoencoder requires infrastructure, benchmarking, and approval. Antigravity is not inherently required for these tasks; it is only useful if it is being used as the team's deployment or browser environment.

## Recommended Antigravity execution order

1. Start FastAPI and the frontend with the repository's documented commands.
2. Perform the browser acceptance checklist above.
3. Capture screenshots/video of Queue, Investigation, Decision persistence, and Audit Ledger.
4. Record any visual or runtime defects with route, browser size, console error, and reproduction steps.
5. Do not change compliance labels or model claims during visual polish without checking them against the backend and project limitations.
6. If a manual online scoring screen is desired, first confirm the product fields and whether it is for auditor testing or real ingestion; then implement it as a separate route using `POST /score`.

## What still belongs to Aaditya's review

Aaditya should decide whether the website needs a manual `POST /score` screen, approve the deployment security values, and approve the honest prototype limitation wording. No further ML implementation is required for the currently defined review-console scope.
