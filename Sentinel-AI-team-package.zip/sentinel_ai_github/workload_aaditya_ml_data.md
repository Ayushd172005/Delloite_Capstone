# Aaditya: Complete Execution Manual

**Role:** Machine Learning & Data Engineer
**Tech Stack:** Python, Pandas, Numpy, Scikit-Learn, FAISS, SentenceTransformers

---

## IMPORTANT: Train/Test Strategy
- **Training Data:** Sparkov (`fraudTrain.csv` + `fraudTest.csv`) and PaySim (`PS_*.csv`) from Kaggle
- **Testing Data:** Teammate's 3 synthetic datasets (`pro_dataset_retail.csv`, `pro_dataset_corporate.csv`, `pro_dataset_aml.csv`)
- The Kaggle data must be mapped to our 14-column target schema before training

---

## Part A: Sparkov Dataset Mapping

### A.1 Raw Sparkov Columns (23 columns)
Sparkov contains two files: `fraudTrain.csv` (~1.3M rows) and `fraudTest.csv` (~555K rows). Concatenate them into one dataframe.

Columns: `trans_date_trans_time`, `cc_num`, `merchant`, `category`, `amt`, `first`, `last`, `gender`, `street`, `city`, `state`, `zip`, `lat`, `long`, `city_pop`, `job`, `dob`, `trans_num`, `unix_time`, `merch_lat`, `merch_long`, `is_fraud`

### A.2 Direct Column Mapping (Sparkov → Our Schema)

| Our Target Column | Sparkov Source | Mapping Logic |
|-------------------|---------------|---------------|
| `transaction_id` | `trans_num` | Direct copy. Already unique per transaction. |
| `transaction_time` | `trans_date_trans_time` | Direct copy. Already has real datetime with hours (e.g., `2019-01-01 00:00:18`). Convert to pandas datetime. |
| `amount` | `amt` | Direct copy. Real dollar amounts (e.g., `4.97`, `107.23`). |
| `transaction_type` | `category` | Direct copy. Has values like `grocery_pos`, `misc_net`, `entertainment`, `personal_care`. |
| `customer_id` | `cc_num` | Direct copy. Credit card number uniquely identifies a customer. |
| `merchant_id` | `merchant` | Direct copy. Has real merchant names like `fraud_Rippin, Kub and Mann`. |
| `fraud_label` | `is_fraud` | Direct copy. Already 0/1 binary. |
| `location` | `city` + `state` | Concatenate city and state into one string (e.g., `"New York, NY"`). |
| `balance_before` | ❌ Not present | Must synthesize. |
| `balance_after` | ❌ Not present | Must synthesize. |
| `account_id` | ❌ Not present | Must synthesize. |
| `device_id` | ❌ Not present | Must synthesize. |
| `payment_method` | ❌ Not present | Must synthesize. |
| `transaction_frequency` | ❌ Computed | Calculate from customer_id + transaction_time. |

### A.3 How to Synthesize Missing Sparkov Columns

**`device_id`:**
The `category` column has a critical clue. Categories ending in `_pos` are physical point-of-sale transactions (customer swiped their card at a store). Categories ending in `_net` are online transactions (customer used a browser or app).

- For each unique customer, generate 1-2 stable device fingerprints using a hash of their `cc_num`. POS transactions get a device ID like `POS_TERMINAL_xxxx`. Online transactions get a device ID like `BROWSER_xxxx`.
- For approximately 2% of fraud transactions, replace the device with a completely new, never-before-seen device ID (e.g., `UNKNOWN_DEV_xxxx`). This directly simulates **Use Case 1 (Account Takeover)** where a criminal uses stolen credentials from their own computer.
- **Why this is realistic:** In the real world, legitimate customers always use the same 1-2 phones. Fraudsters who steal card details always appear on a brand new device.

**`balance_before` and `balance_after`:**
Sparkov does not have account balances. Simulate them using a running balance approach:
- Assign each unique customer a random starting balance between $5,000 and $100,000.
- Sort each customer's transactions chronologically.
- For each transaction, subtract the `amt` from the running balance to get `balance_after`.
- If the balance drops below $1,000, add a random top-up of $5,000-$20,000 (simulating a salary deposit).

**`account_id`:**
Generate a stable account ID per customer by hashing their `cc_num`. Format: `ACC_` followed by 8 hex characters.

**`payment_method`:**
Map from the category suffix. If the category ends in `_pos`, assign "Debit Card" or "Credit Card". If it ends in `_net`, assign "Credit Card" or "Digital Wallet".

**`transaction_frequency`:**
Sort by customer and time. Then do a cumulative count of transactions per customer. The first transaction = 1, the second = 2, etc.

---

## Part B: PaySim Dataset Mapping

### B.1 Raw PaySim Columns (11 columns)
`step`, `type`, `amount`, `nameOrig`, `oldbalanceOrg`, `newbalanceOrig`, `nameDest`, `oldbalanceDest`, `newbalanceDest`, `isFraud`, `isFlaggedFraud`

### B.2 Key Facts About PaySim
- `step` = 1 hour of simulated time. Total 744 steps = 30 days.
- `type` = CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER.
- Names starting with `C` = Customer. Names starting with `M` = Merchant.
- **Fraud in this dataset specifically simulates ACCOUNT TAKEOVER.** Fraudsters take control of customer accounts and transfer funds out. This is perfect for Use Case 1.
- `isFlaggedFraud` = flags transfers exceeding $200,000. Relevant for Use Case 3 (Structuring).
- **WARNING:** The balance columns (`oldbalanceOrg`, `newbalanceOrig`, etc.) should NOT be used as ML features for fraud detection. Fraudulent transactions are cancelled in the simulation, making these columns unreliable for fraud rows. Keep them only for schema completeness.

### B.3 Direct Column Mapping (PaySim → Our Schema)

| Our Target Column | PaySim Source | Mapping Logic |
|-------------------|-------------|---------------|
| `transaction_id` | ❌ Not present | Generate by adding a prefix + row index (e.g., `PAY_0000001`). |
| `transaction_time` | `step` | Convert: Pick a base date like January 1, 2025. Add the `step` value as hours. Step 0 = Jan 1 00:00, Step 24 = Jan 2 00:00, etc. |
| `amount` | `amount` | Direct copy. |
| `transaction_type` | `type` | Direct copy. Already has CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER. |
| `customer_id` | `nameOrig` | Direct copy. The customer who initiated the transaction. |
| `merchant_id` | `nameDest` | Direct copy. The recipient of the money. |
| `fraud_label` | `isFraud` | Direct copy. 0/1 binary. |
| `balance_before` | `oldbalanceOrg` | Direct copy. But do NOT use as ML feature (see warning above). |
| `balance_after` | `newbalanceOrig` | Direct copy. Same warning. |
| `account_id` | ❌ Not present | Must synthesize. |
| `location` | ❌ Not present | Must synthesize. |
| `device_id` | ❌ Not present | Must synthesize. |
| `payment_method` | ❌ Not present | Must synthesize. |
| `transaction_frequency` | ❌ Computed | Cumulative count per customer. |

### B.4 How to Synthesize Missing PaySim Columns

**`device_id`:**
PaySim's fraud specifically simulates account takeover (criminals stealing accounts and emptying funds). Use this knowledge:
- For each unique customer (`nameOrig`), generate a stable device fingerprint by hashing their name. Format: `DEV_` followed by 8 hex characters.
- For **80% of fraud transactions**, replace the device with a completely new unknown device ID. This is justified because the Kaggle description explicitly says fraud = account takeover, meaning the criminal is on their own device, not the victim's phone.

**`location`:**
PaySim's Kaggle description explicitly states it simulates "mobile money transactions from an African country." Assign each customer a home city from a list of African cities (Lagos, Nairobi, Accra, Dar es Salaam, Kampala, etc.) by hashing their name to get a stable mapping. For approximately 30% of fraud transactions, change the location to a different city (simulating the criminal being in a different physical location than the victim).

**`account_id`:**
Generate a stable account ID per customer by hashing `nameOrig`. Format: `ACC_` followed by 8 hex characters.

**`payment_method`:**
Map from PaySim's `type` column:
- CASH-IN → "Cash Deposit"
- CASH-OUT → "Cash Withdrawal"
- DEBIT → "Debit Card"
- PAYMENT → "Mobile Money"
- TRANSFER → "Bank Transfer"

**`transaction_frequency`:**
Sort by customer and transaction_time, then do a cumulative count per customer.

---

## Part C: Testing Data (Teammate's 3 Datasets)

These datasets already have the exact 14-column schema. No mapping needed. They are used strictly for testing and evaluation.

| Dataset | Reporting Threshold | `device_id` Useful? | `location` Useful? | Timestamps |
|---------|-------------------|--------------------|--------------------|------------|
| Retail | $10,000 | ✅ Yes (unique per customer) | ✅ Yes (real cities) | Full datetime with hours |
| Corporate | $150,000 | ❌ No (constant: `ERP_SYSTEM_01`) | ❌ No (constant: `Corporate HQ`) | Date only (midnight) |
| AML | $500,000 | ❌ No (constant: `SWIFT_GATEWAY`) | ✅ Yes (country codes) | Date only (midnight) |

**CRITICAL per-dataset warnings:**
- **Corporate:** `device_id` and `location` are the same value for every single row. Do NOT use them as features. Timestamps are date-only (always midnight), so "off-hours" detection is meaningless.
- **AML:** `device_id` is constant (`SWIFT_GATEWAY`). `account_id` is a per-transaction SWIFT reference (nearly unique per row), NOT a recurring bank account. For all groupby operations on AML data, group by `customer_id` instead of `account_id`.

---

## Part D: Feature Engineering (The 3 Use Cases)

### Use Case 1: Account Takeover (New Device + High Value)
Only applicable to Retail dataset (and Sparkov/PaySim after synthesis).
- For each customer, track all historically seen `device_id` values. If the current transaction's device has never been seen before for this customer, flag it as `is_new_device = 1`.
- Calculate the customer's personal amount percentile (how large is this transaction compared to their own history?).
- If `is_new_device == 1` AND the amount is in the top 10% for this customer, set `flag_account_takeover = 1`.

### Use Case 2: Money Laundering (Fan-In / Fan-Out)
Most relevant for AML dataset, also useful for Retail.
- **Fan-In:** For each counterparty (merchant/beneficiary), count how many distinct customers send money to them. If one counterparty receives from more sources than 95% of all other counterparties, flag it as `flag_hub_counterparty = 1`.
- **Merchant Concentration:** For each customer, calculate what percentage of their total transactions go to their single most-used counterparty. If it's extremely high, it indicates a suspicious tunnel.

### Use Case 3: Structuring (Near-Threshold)
Applicable to ALL datasets with different thresholds.
- Retail threshold: $10,000. Flag transactions between $9,500 and $9,999.
- Corporate threshold: $150,000. Flag transactions between $142,500 and $149,999.
- AML threshold: $500,000. Flag transactions between $475,000 and $499,999.
- If a transaction falls within 95-100% of the limit, set `flag_just_under_limit = 1`.

### General Features (All Use Cases)
- **Velocity:** Count the number of transactions per customer in the last 7 days and 30 days using a rolling time window.
- **Balance Depletion:** Calculate what fraction of the account balance was drained by this single transaction.
- **Amount Z-Score:** How many standard deviations is this transaction from the customer's historical average?
- **Time Flags:** Is this a weekend transaction? Is it during off-hours (before 8 AM or after 8 PM)? Only meaningful for datasets with real intraday timestamps (Retail and Sparkov).

---

## Part E: Isolation Forest Training
- Train ONLY on the normalized Kaggle data (Sparkov + PaySim).
- Use a strictly time-based split: first 70% of rows (by date) for training, next 15% for validation, final 15% for holdout.
- Set `contamination = 0.03` based on assumed business review capacity. NEVER use the `fraud_label` to set this value.
- Use `StandardScaler` to normalize the feature matrix before fitting. Fit the scaler on training data ONLY, then transform validation and holdout using the same frozen scaler.
- After scoring, multiply the raw `decision_function()` output by -1 and apply Min-Max scaling to get scores from 0.0 to 1.0.

---

## Part F: FAISS Vector Database
- Load the synthetic text documents generated by Ayush from the `/data/documents/` folder.
- Initialize the `SentenceTransformer('all-MiniLM-L6-v2')` embedding model.
- Encode all documents into 384-dimensional numpy arrays.
- Normalize the vectors (required for Cosine Similarity).
- Create a `faiss.IndexFlatIP(384)` index (Inner Product = Cosine Similarity after normalization).
- Add all vectors and save the index to disk as `index.faiss`.
- Write a `search_documents(query_text, top_k=3)` function that encodes a query, searches the index, and returns the top 3 matching document IDs with their similarity scores.

---

## Part G: Evaluation Metrics
- Compare the final composite model scores against the true `fraud_label` on the HOLDOUT set ONLY.
- Calculate and report: Precision, Recall, F1-Score, and ROC-AUC.
- Generate ROC curves for the Deloitte presentation slides.
