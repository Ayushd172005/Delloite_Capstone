"""Leakage-safe feature serving for one new canonical transaction.

The offline pipeline remains the source of truth for batch feature generation.
This module provides the missing online boundary: given a new transaction and
historical rows strictly before its timestamp, compute the exact model feature
names without using the current row as history or reading future rows.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np
import pandas as pd

from config import ENTITY_COL
from model import FEATURES


@dataclass
class FeatureStore:
    history: pd.DataFrame

    def __post_init__(self):
        self.history = self.history.copy()
        self.history["transaction_time"] = pd.to_datetime(self.history["transaction_time"])
        self.history = self.history.sort_values(["vertical", "transaction_time"], kind="stable")
        self._peer_amounts = {
            vertical: np.sort(group["amount"].astype(float).to_numpy())
            for vertical, group in self.history.groupby("vertical")
        }

    @staticmethod
    def _prior(history: pd.DataFrame, entity: str, value: Any, timestamp: pd.Timestamp) -> pd.DataFrame:
        prior = history[(history[entity] == value) & (history["transaction_time"] < timestamp)]
        return prior.sort_values("transaction_time", kind="stable")

    def engineer_one(self, transaction: Mapping[str, Any]) -> dict[str, Any]:
        required = ["transaction_id", "transaction_time", "vertical", "amount", "counterparty_id", "account_id", "balance_before"]
        missing = [key for key in required if key not in transaction]
        if missing:
            raise ValueError(f"Missing serving fields: {missing}")
        vertical = str(transaction["vertical"])
        if vertical not in ENTITY_COL:
            raise ValueError(f"Unsupported vertical: {vertical}")
        timestamp = pd.Timestamp(transaction["transaction_time"])
        if pd.isna(timestamp):
            raise ValueError("transaction_time must be parseable")
        if timestamp.tzinfo is not None:
            timestamp = timestamp.tz_convert("UTC").tz_localize(None)
        amount = float(transaction["amount"])
        if not np.isfinite(amount) or amount <= 0:
            raise ValueError("amount must be a positive finite number")
        entity_col = ENTITY_COL[vertical]
        entity_value = transaction.get(entity_col) or transaction.get("account_id") or transaction.get("customer_id")
        if entity_value is None:
            raise ValueError(f"Missing entity identifier for vertical '{vertical}': provide either '{entity_col}' or 'account_id'")
        if entity_col not in transaction and isinstance(transaction, dict):
            transaction[entity_col] = entity_value
        prior = self._prior(self.history[self.history["vertical"] == vertical], entity_col, entity_value, timestamp)
        prior_amounts = prior["amount"].astype(float)
        prior_count = len(prior)
        prior_mean = float(prior_amounts.mean()) if prior_count else amount
        prior_std = float(prior_amounts.std()) if prior_count > 1 else 0.0
        amount_zscore = 0.0 if prior_std == 0 else float(np.clip((amount - prior_mean) / prior_std, -10, 10))
        cumulative_amount = float(prior_amounts.sum()) if prior_count else 0.0
        last_7d = prior[prior["transaction_time"] >= timestamp - pd.Timedelta(days=7)]
        last_30d = prior[prior["transaction_time"] >= timestamp - pd.Timedelta(days=30)]
        velocity_7d = float(len(last_7d))
        velocity_30d = float(len(last_30d))
        if prior_count:
            historical_velocities = []
            for _, row in prior.iterrows():
                t = row["transaction_time"]
                historical_velocities.append(float(len(prior[(prior["transaction_time"] >= t - pd.Timedelta(days=30)) & (prior["transaction_time"] < t)])))
            hist_avg = float(np.mean(historical_velocities)) if historical_velocities else 0.0
        else:
            hist_avg = 0.0
        velocity_spike_ratio = float(np.clip(velocity_30d / hist_avg, 0, 20)) if hist_avg else 1.0
        balance_before = float(transaction["balance_before"])
        balance_after = float(transaction.get("balance_after", balance_before - amount))
        depletion = float(np.clip((balance_before - balance_after) / balance_before, -5, 5)) if balance_before else 0.0
        amount_balance = float(np.clip(amount / balance_before, 0, 50)) if balance_before else 0.0
        last_time = prior["transaction_time"].iloc[-1] if prior_count else None
        days_since = float((timestamp - last_time).total_seconds() / 86400) if last_time is not None else 999.0
        peer = self._peer_amounts.get(vertical, np.array([]))
        peer_rank = float(np.searchsorted(peer, amount, side="left") / len(peer)) if len(peer) else 0.5
        counterparty = transaction["counterparty_id"]
        is_new_counterparty = int(not (prior["counterparty_id"] == counterparty).any()) if prior_count else 1
        if prior_count:
            counterparty_counts = prior["counterparty_id"].value_counts()
            concentration = float(counterparty_counts.max() / prior_count)
        else:
            concentration = 0.0
        personal_rank = float((prior_amounts < amount).mean()) if prior_count else 0.5
        return {
            "transaction_id": transaction["transaction_id"],
            "vertical": vertical,
            "transaction_time": timestamp.isoformat(),
            "amount": amount,
            "amount_zscore": amount_zscore,
            "velocity_7d": velocity_7d,
            "velocity_30d": velocity_30d,
            "velocity_spike_ratio": velocity_spike_ratio,
            "balance_depletion_ratio": depletion,
            "amount_to_balance_ratio": amount_balance,
            "days_since_last_txn": days_since,
            "transaction_frequency": float(prior_count),
            "is_new_counterparty": is_new_counterparty,
            "amount_pct_rank_personal": personal_rank,
            "amount_pct_rank_peer_group": peer_rank,
            "cumulative_amount": cumulative_amount,
            "merchant_concentration": concentration,
            "rule_score": float(transaction.get("rule_score", 0.0)),
            "benford_score": float(transaction.get("benford_score", 0.0)),
        }
