import os
import sqlite3
import pytest
import db as db_module

@pytest.fixture
def temp_db(tmp_path, monkeypatch):
    test_db_path = str(tmp_path / "test_sentinel.db")
    monkeypatch.setattr(db_module, "DB_PATH", test_db_path)
    db_module.init_db()
    conn = db_module.get_connection()
    yield conn
    conn.close()

def test_db_schema_creates_all_tables(temp_db):
    tables = {r["name"] for r in temp_db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    expected = {"transactions", "risk_scores", "cases", "investigations", "auditor_decisions" if False else "audit_events", "model_versions"}
    # auditor_decisions is folded into cases.auditor_decision + audit_events per schema design
    assert {"transactions", "risk_scores", "cases", "investigations", "audit_events", "model_versions"}.issubset(tables)

def test_decision_persists_and_survives_reconnect(temp_db, tmp_path, monkeypatch):
    conn = temp_db
    conn.execute("INSERT INTO transactions VALUES (?,?,?,?,?,?)",
                 ("T1", "retail", 100.0, "2025-01-01", "A1", "C1"))
    conn.commit()
    inv = {"risk_score": 80, "risk_level": "HIGH", "finding": "test", "recommended_action": "ESCALATE"}
    case_id = db_module.upsert_investigation_and_case(conn, "T1", inv, "v_test")
    conn.commit()
    db_module.record_decision(conn, "T1", "ESCALATE", "test reason", "auditor1")
    conn.commit()
    conn.close()

    # reconnect fresh - simulating app restart
    conn2 = db_module.get_connection()
    row = conn2.execute("SELECT auditor_decision, auditor_reason FROM cases WHERE transaction_id=?", ("T1",)).fetchone()
    assert row["auditor_decision"] == "ESCALATE"
    assert row["auditor_reason"] == "test reason"
    conn2.close()

def test_audit_trail_records_every_step(temp_db):
    conn = temp_db
    conn.execute("INSERT INTO transactions VALUES (?,?,?,?,?,?)",
                 ("T2", "retail", 50.0, "2025-01-01", "A2", "C2"))
    conn.commit()
    inv = {"risk_score": 60, "risk_level": "MEDIUM", "finding": "f", "recommended_action": "REQUEST_MORE_EVIDENCE"}
    db_module.upsert_investigation_and_case(conn, "T2", inv, "v_test")
    db_module.record_decision(conn, "T2", "DISMISS", "reason", "auditor2")
    conn.commit()
    trail = db_module.get_audit_trail(conn, "T2")
    event_types = [e["event_type"] for e in trail]
    assert "investigated" in event_types
    assert "decision" in event_types

def test_override_is_logged_as_override_not_decision(temp_db):
    conn = temp_db
    conn.execute("INSERT INTO transactions VALUES (?,?,?,?,?,?)",
                 ("T3", "retail", 50.0, "2025-01-01", "A3", "C3"))
    conn.commit()
    inv = {"risk_score": 60, "risk_level": "MEDIUM", "finding": "f", "recommended_action": "ESCALATE"}
    db_module.upsert_investigation_and_case(conn, "T3", inv, "v_test")
    db_module.record_decision(conn, "T3", "ACCEPT", "first pass", "auditor1")
    db_module.record_decision(conn, "T3", "DISMISS", "changed my mind", "auditor2")
    conn.commit()
    trail = db_module.get_audit_trail(conn, "T3")
    event_types = [e["event_type"] for e in trail]
    assert "override" in event_types, "second decision on the same case should log as an override"

def test_primary_actions_persist_and_direct_decision_creates_case(temp_db):
    conn = temp_db
    # Test all 4 required primary actions: APPROVE, ESCALATE, SAR, DISMISS
    actions = ["APPROVE", "ESCALATE", "SAR", "DISMISS"]
    for i, act in enumerate(actions, start=10):
        tid = f"T_{act}_{i}"
        conn.execute("INSERT INTO transactions VALUES (?,?,?,?,?,?)",
                     (tid, "corporate", float(i * 1000), "2025-01-01", f"ACC_{i}", f"BEN_{i}"))
        conn.commit()
        # Direct decision without prior investigation
        case_id = db_module.record_decision(conn, tid, act, f"Direct triage: {act}", f"auditor_{act}")
        conn.commit()
        assert case_id == f"CASE_{tid}"

        row = conn.execute("SELECT auditor_decision, auditor_reason FROM cases WHERE transaction_id=?", (tid,)).fetchone()
        assert row["auditor_decision"] == act
        assert row["auditor_reason"] == f"Direct triage: {act}"

        trail = db_module.get_audit_trail(conn, tid)
        assert len(trail) == 1
        assert trail[0]["event_type"] == "decision"
        assert trail[0]["actor"] == f"auditor_{act}"

def test_decision_request_schema_validation():
    from api_contracts import DecisionRequest
    for action in ["APPROVE", "ESCALATE", "SAR", "DISMISS", "ACCEPT", "REQUEST_MORE_EVIDENCE", "OVERRIDE"]:
        req = DecisionRequest(auditor="auditor@sentinel", action=action, reason="Valid reason")
        assert req.action == action

    with pytest.raises(ValueError):
        DecisionRequest(auditor="auditor@sentinel", action="INVALID_ACTION", reason="Invalid")
