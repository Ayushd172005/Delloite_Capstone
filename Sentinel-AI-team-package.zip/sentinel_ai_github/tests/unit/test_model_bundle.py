import json
from pathlib import Path

import pandas as pd
import pytest

from model import FEATURES
from model_bundle import ModelBundle

ROOT = Path(__file__).resolve().parents[2]


def test_bundle_manifest_is_complete_and_feature_ordered():
    manifest = json.loads((ROOT / "model_bundle" / "manifest.json").read_text())
    assert manifest["features"] == FEATURES
    assert manifest["fraud_label_used_for_fit"] is False
    assert set(manifest["vertical_files"]) == {"aml", "corporate", "retail"}


def test_bundle_scores_real_engineered_rows():
    bundle = ModelBundle.load(ROOT / "model_bundle")
    frame = pd.read_parquet(ROOT / "scored_transactions.parquet")
    for vertical in ("aml", "corporate", "retail"):
        row = frame[frame["vertical"] == vertical].iloc[0].to_dict()
        result = bundle.score_one(row)
        assert result["vertical"] == vertical
        assert 0 <= result["isoforest_score"] <= 1
        assert 0 <= result["autoencoder_score"] <= 1
        assert 0 <= result["composite_score"] <= 100
        assert result["fraud_probability"] is None
        assert result["bundle_version"].startswith("bundle-")


def test_bundle_rejects_missing_engineered_feature():
    bundle = ModelBundle.load(ROOT / "model_bundle")
    frame = pd.read_parquet(ROOT / "scored_transactions.parquet")
    row = frame.iloc[0].to_dict()
    row.pop(FEATURES[0])
    with pytest.raises(ValueError, match="Missing required engineered features"):
        bundle.score_one(row)


def test_bundle_rejects_non_finite_feature():
    bundle = ModelBundle.load(ROOT / "model_bundle")
    frame = pd.read_parquet(ROOT / "scored_transactions.parquet")
    row = frame.iloc[0].to_dict()
    row[FEATURES[0]] = float("nan")
    with pytest.raises(ValueError, match="Non-finite feature values"):
        bundle.score_one(row)
