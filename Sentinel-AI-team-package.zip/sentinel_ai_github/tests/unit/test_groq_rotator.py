"""
Unit tests for Groq API key rotation, scheduling, masking, and failover.
"""
import os
import time
import pytest
from unittest.mock import patch

from groq_rotator import (
    get_groq_api_keys,
    mask_key,
    get_rotation_interval_seconds,
    mark_key_rate_limited,
    is_key_cooling_down,
    get_groq_rotation_status,
    get_ordered_groq_keys,
    _KEY_COOLDOWNS,
)


def test_mask_key_hygiene():
    """Verify keys are safely masked and secrets are never exposed."""
    assert mask_key("gsk_1234567890abcdef12345678") == "gsk_1234...5678"
    assert mask_key("short") == "***"
    assert mask_key("") == "<none>"
    assert mask_key(None) == "<none>"


def test_get_groq_api_keys_comma_separated():
    """Verify parsing of comma-separated GROQ_API_KEYS."""
    env = {
        "GROQ_API_KEYS": "key_alpha, key_beta, key_alpha , key_gamma ",
        "GROQ_API_KEY": "",
    }
    with patch.dict(os.environ, env, clear=True):
        keys = get_groq_api_keys()
        assert keys == ["key_alpha", "key_beta", "key_gamma"]


def test_get_groq_api_keys_slots_fallback():
    """Verify parsing across slot variables GROQ_API_KEY, GROQ_API_KEY_1, GROQ_API_KEY_2."""
    env = {
        "GROQ_API_KEY": "key_one",
        "GROQ_API_KEY_2": "key_two",
    }
    with patch.dict(os.environ, env, clear=True):
        keys = get_groq_api_keys()
        assert keys == ["key_one", "key_two"]


def test_deterministic_6_hour_rotation_cycle():
    """
    Simulate exact 6-hour period transitions across 48 hours to guarantee
    alternation across consecutive 6-hour windows.
    """
    env = {
        "GROQ_API_KEYS": "key_1,key_2",
        "GROQ_KEY_ROTATION_HOURS": "6",
    }
    with patch.dict(os.environ, env, clear=True):
        interval = 6 * 3600  # 21,600s
        # Start at an even period boundary
        base_epoch = 0

        # Check across 8 periods (48 hours)
        expected_indices = [0, 1, 0, 1, 0, 1, 0, 1]
        for period_idx, expected_slot in enumerate(expected_indices):
            test_time = base_epoch + (period_idx * interval) + 120  # 2 minutes into the window
            status = get_groq_rotation_status(now=test_time)
            ordered = get_ordered_groq_keys(now=test_time)

            assert status["active_index"] == expected_slot, f"Period {period_idx} should have active slot {expected_slot}"
            assert ordered[0][0] == expected_slot, f"Period {period_idx} primary key should be slot {expected_slot}"
            other_slot = 1 - expected_slot
            assert ordered[1][0] == other_slot


def test_failover_when_primary_is_rate_limited():
    """
    When primary key hits a 429 RateLimitError, the rotator must automatically
    prioritize the standby healthy key so API requests never fail.
    """
    _KEY_COOLDOWNS.clear()
    env = {
        "GROQ_API_KEYS": "key_primary,key_standby",
        "GROQ_KEY_ROTATION_HOURS": "6",
    }
    with patch.dict(os.environ, env, clear=True):
        interval = 6 * 3600
        # Start at epoch 0 so slot 0 is primary
        base_epoch = 0

        # In slot 0: key_primary is first
        ordered_normal = get_ordered_groq_keys(now=base_epoch + 10)
        assert ordered_normal[0] == (0, "key_primary")
        assert ordered_normal[1] == (1, "key_standby")

        # Simulate 429 rate limit on primary
        mark_key_rate_limited("key_primary", cooldown_seconds=60, now=base_epoch + 10)
        assert is_key_cooling_down("key_primary", now=base_epoch + 10)

        # Now standby key MUST be prioritized first
        ordered_failover = get_ordered_groq_keys(now=base_epoch + 15)
        assert ordered_failover[0] == (1, "key_standby")
        assert ordered_failover[1] == (0, "key_primary")

        # After cooldown expires, primary key resumes its scheduled slot
        ordered_restored = get_ordered_groq_keys(now=base_epoch + 80)
        assert ordered_restored[0] == (0, "key_primary")

    _KEY_COOLDOWNS.clear()
