import pandas as pd
import pytest

from serving_features import FeatureStore
from model import FEATURES


def test_serving_features_exclude_current_and_future_rows():
    history = pd.DataFrame([
        {"transaction_id": "A", "transaction_time": "2025-01-01", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP1", "amount": 10.0, "balance_before": 100.0, "balance_after": 90.0},
        {"transaction_id": "B", "transaction_time": "2025-01-02", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP2", "amount": 20.0, "balance_before": 90.0, "balance_after": 70.0},
        {"transaction_id": "FUTURE", "transaction_time": "2025-01-04", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP3", "amount": 999999.0, "balance_before": 70.0, "balance_after": 0.0},
    ])
    store = FeatureStore(history)
    result = store.engineer_one({"transaction_id": "NEW", "transaction_time": "2025-01-03", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP1", "amount": 30.0, "balance_before": 70.0})
    assert result["transaction_frequency"] == 2
    assert result["cumulative_amount"] == 30.0
    assert result["is_new_counterparty"] == 0
    assert result["amount_pct_rank_peer_group"] < 1
    assert all(feature in result for feature in FEATURES)


def test_serving_features_reject_invalid_amount():
    store = FeatureStore(pd.DataFrame([{"transaction_time": "2025-01-01", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP", "amount": 1.0}]))
    with pytest.raises(ValueError, match="positive finite"):
        store.engineer_one({"transaction_id": "NEW", "transaction_time": "2025-01-03", "vertical": "retail", "account_id": "ACC", "counterparty_id": "CP", "amount": 0, "balance_before": 10})


def test_serving_features_aml_entity_fallback():
    history = pd.DataFrame([
        {"transaction_id": "AML_1", "transaction_time": "2025-01-01", "vertical": "aml", "account_id": "ACC_1", "customer_id": "INST_100", "counterparty_id": "CP_1", "amount": 50000.0, "balance_before": 200000.0, "balance_after": 150000.0},
        {"transaction_id": "AML_2", "transaction_time": "2025-01-02", "vertical": "aml", "account_id": "ACC_2", "customer_id": "INST_100", "counterparty_id": "CP_2", "amount": 75000.0, "balance_before": 150000.0, "balance_after": 75000.0},
    ])
    store = FeatureStore(history)

    # With explicit customer_id
    res1 = store.engineer_one({
        "transaction_id": "NEW_AML_1", "transaction_time": "2025-01-03", "vertical": "aml",
        "account_id": "ACC_SWIFT_3", "customer_id": "INST_100", "counterparty_id": "CP_1",
        "amount": 100000.0, "balance_before": 300000.0
    })
    assert res1["transaction_frequency"] == 2
    assert res1["is_new_counterparty"] == 0

    # With account_id fallback (where customer_id omitted)
    res2 = store.engineer_one({
        "transaction_id": "NEW_AML_2", "transaction_time": "2025-01-03", "vertical": "aml",
        "account_id": "INST_100", "counterparty_id": "CP_99",
        "amount": 20000.0, "balance_before": 100000.0
    })
    assert res2["transaction_frequency"] == 2
    assert res2["is_new_counterparty"] == 1

