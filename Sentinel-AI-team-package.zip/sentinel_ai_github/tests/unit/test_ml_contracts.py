import json
from pathlib import Path

import model

ROOT = Path(__file__).resolve().parents[2]


def test_feature_registry_matches_model_feature_order():
    registry = json.loads((ROOT / "feature_registry.json").read_text())
    names = [item["name"] for item in registry["features"] if item["role"] == "model_input"]
    assert names == model.FEATURES
    assert "fraud_label" not in names


def test_score_contract_requires_all_backend_score_fields():
    contract = json.loads((ROOT / "score_contract.json").read_text())
    required = set(contract["required_response_fields"])
    assert {"transaction_id", "composite_score", "review_tier", "model_version"}.issubset(required)
    assert contract["score_range"] == [0, 100]
    assert contract["composite"]["holdout_used_for_calibration"] is False


def test_data_contract_and_artifact_manifest_exist():
    assert (ROOT / "data_contract.md").stat().st_size > 0
    manifest_path = ROOT / "artifact_manifest.json"
    assert manifest_path.exists()
    manifest = json.loads(manifest_path.read_text())
    assert manifest["status"] == "PASS"
    assert manifest["synthetic_benchmark_disclosure"] is True
    assert "scored_transactions.parquet" in manifest["files"]
