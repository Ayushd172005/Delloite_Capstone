import pandas as pd
from fastapi.testclient import TestClient

import app
from model_bundle import ModelBundle


def test_engineered_score_endpoint_returns_contract():
    frame = pd.read_parquet("scored_transactions.parquet")
    row = frame.iloc[0].to_dict()
    bundle = ModelBundle.load("model_bundle")
    payload = {key: row[key] for key in bundle.manifest["features"]}
    payload.update({"transaction_id": row["transaction_id"], "vertical": row["vertical"], "rule_score": row["rule_score"], "benford_score": row["benford_score"]})
    with TestClient(app.app) as client:
        response = client.post("/score/engineered", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["transaction_id"] == row["transaction_id"]
    assert body["vertical"] == row["vertical"]
    assert 0 <= body["composite_score"] <= 100
    assert body["fraud_probability"] is None


def test_engineered_score_endpoint_rejects_missing_features():
    frame = pd.read_parquet("scored_transactions.parquet")
    row = frame.iloc[0].to_dict()
    payload = {"vertical": row["vertical"], "transaction_id": row["transaction_id"]}
    with TestClient(app.app) as client:
        response = client.post("/score/engineered", json=payload)
    assert response.status_code == 422
    assert "Missing required engineered features" in response.json()["detail"]


def test_canonical_score_endpoint_engineers_history():
    frame = pd.read_parquet("normalized_features_benford.parquet")
    row = frame[frame["vertical"] == "retail"].iloc[-1].to_dict()
    payload = {
        "transaction_id": "ONLINE_TEST_001",
        "transaction_time": "2026-01-02T12:00:00",
        "vertical": "retail",
        "account_id": row["account_id"],
        "counterparty_id": row["counterparty_id"],
        "amount": float(row["amount"]),
        "balance_before": float(row["balance_before"]),
        "balance_after": float(row["balance_after"]),
    }
    with TestClient(app.app) as client:
        response = client.post("/score", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["transaction_id"] == "ONLINE_TEST_001"
    assert 0 <= body["composite_score"] <= 100


def test_score_and_investigate_pipeline_endpoint():
    frame = pd.read_parquet("normalized_features_benford.parquet")
    row = frame[frame["vertical"] == "retail"].iloc[-1].to_dict()
    payload = {
        "transaction_id": "ONLINE_PIPELINE_TEST_001",
        "transaction_time": "2026-01-02T12:00:00",
        "vertical": "retail",
        "account_id": row["account_id"],
        "counterparty_id": row["counterparty_id"],
        "amount": float(row["amount"]),
        "balance_before": float(row["balance_before"]),
        "balance_after": float(row["balance_after"]),
    }
    with TestClient(app.app) as client:
        response = client.post("/score/pipeline", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["transaction_id"] == "ONLINE_PIPELINE_TEST_001"
    assert "scores" in body
    assert "engineered_features" in body
    assert "investigation" in body
    assert 0 <= body["scores"]["composite_score"] <= 100
    assert body["case_id"] == "CASE_ONLINE_PIPELINE_TEST_001"
