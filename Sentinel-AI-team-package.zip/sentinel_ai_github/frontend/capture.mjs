import puppeteer from "puppeteer-core";
import fs from "node:fs";
import path from "node:path";

const CHROME_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const OUTPUT_DIR = "/Users/aaditya/.gemini/antigravity/brain/de6efaf1-bab3-42fe-b315-37a355330eea";

async function capture() {
  const browser = await puppeteer.launch({
    executablePath: CHROME_PATH,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    headless: true,
  });

  const targets = [
    { name: "queue", path: "/" },
    { name: "investigation", path: "/investigation/TRF_46631F673703" },
    { name: "audit", path: "/audit-trail" },
    { name: "governance", path: "/model-health" },
  ];

  const themes = ["dark", "light"];

  for (const t of targets) {
    for (const th of themes) {
      const page = await browser.newPage();
      await page.setViewport({ width: 1512, height: 982, deviceScaleFactor: 2 });
      await page.goto(`http://localhost:5173${t.path}`, { waitUntil: "networkidle0" });
      
      await page.evaluate((theme) => {
        localStorage.setItem("sentinel-theme", theme);
        if (theme === "dark") {
          document.documentElement.classList.add("dark");
        } else {
          document.documentElement.classList.remove("dark");
        }
      }, th);
      
      await new Promise((r) => setTimeout(r, 600));

      const outPath = path.join(OUTPUT_DIR, `shot_reset_${t.name}_${th}.png`);
      await page.screenshot({ path: outPath, fullPage: false });
      console.log(`Captured: ${outPath}`);
      await page.close();
    }
  }

  for (const t of [{ name: "queue_mobile", path: "/" }, { name: "investigation_mobile", path: "/investigation/TRF_46631F673703" }]) {
    const page = await browser.newPage();
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true });
    await page.goto(`http://localhost:5173${t.path}`, { waitUntil: "networkidle0" });
    await page.evaluate(() => {
      localStorage.setItem("sentinel-theme", "dark");
      document.documentElement.classList.add("dark");
    });
    await new Promise((r) => setTimeout(r, 600));
    const outPath = path.join(OUTPUT_DIR, `shot_reset_${t.name}_dark.png`);
    await page.screenshot({ path: outPath, fullPage: false });
    console.log(`Captured mobile: ${outPath}`);
    await page.close();
  }

  await browser.close();
}

capture().catch((err) => {
  console.error("Capture failed:", err);
  process.exit(1);
});
