import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: "0.0.0.0",
    allowedHosts: true,
    proxy: {
      "^/(queue|case|audit_trail|model-info|health|metrics|score)": {
        target: "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
  build: {
    // No source maps in production — prevents source exposure
    sourcemap: false,
    // Chunk size warning threshold (bytes)
    chunkSizeWarningLimit: 500,
    rollupOptions: {
      output: {
        manualChunks: {
          // Vendor chunk: stable libraries that change rarely
          vendor: ["react", "react-dom", "react-router-dom"],
          // Icons in their own chunk — loaded lazily after core
          icons: ["lucide-react"],
        },
      },
    },
  },
});
