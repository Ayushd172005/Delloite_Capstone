import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { getQueue } from "../api/transactions";
import { useSystemStatus } from "../context/SystemStatusContext";
import { useDocumentTitle } from "../hooks/useDocumentTitle";
import TransactionTable from "../components/TransactionTable";
import MobileCaseCard from "../components/MobileCaseCard";
import ForensicWorkbenchDossier from "../components/ForensicWorkbenchDossier";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { SkeletonQueue } from "../components/Skeleton";
import BatchActionDock from "../components/BatchActionDock";
import { submitAuditorDecision } from "../api/investigations";
import { compactCaseId } from "../utils/caseId";
import { playTick } from "../utils/audio";
import { MagnifyingGlass, ArrowsClockwise, X } from "@phosphor-icons/react";

// Toast component — inline to avoid extra file for now
function Toast({ message, onDismiss }) {
  if (!message) return null;
  return (
    <div
      className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom)+12px)] md:bottom-6 right-3 sm:right-6 z-50 flex items-center gap-3 rounded-panel px-4 py-3 font-mono text-xs animate-toast-in"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--risk-success-border)",
        boxShadow: "var(--shadow-raised)",
        color: "var(--risk-success)",
        maxWidth: "360px",
      }}
      role="status"
      aria-live="polite"
      aria-atomic="true"
    >
      <span
        className="h-2 w-2 shrink-0 rounded-full"
        style={{ background: "var(--risk-success)" }}
        aria-hidden
      />
      <span className="flex-1 text-text-primary">{message}</span>
      <button
        onClick={onDismiss}
        className="ml-2 inline-flex h-6 w-6 items-center justify-center rounded text-text-muted hover:bg-surface hover:text-text-primary focus-visible:outline-none"
        aria-label="Dismiss notification"
        title="Dismiss notification"
      >
        <X className="h-3.5 w-3.5" weight="bold" aria-hidden />
      </button>
    </div>
  );
}

// ─── Stale threshold: 60 seconds (institutional tolerance) ─────
const STALE_THRESHOLD_MS = 60_000;

export default function RiskQueue() {
  useDocumentTitle("Case Queue — Sentinel AI");

  const { isMock } = useSystemStatus();
  const [rows, setRows] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const [search, setSearch] = useState("");
  const [vertical, setVertical] = useState(null);
  const [tier, setTier] = useState(null);
  const [amountLimit, setAmountLimit] = useState(null);
  const [density, setDensity] = useState("standard");
  const [viewMode, setViewMode] = useState("split");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [activeRiskBin, setActiveRiskBin] = useState(null);
  const [toastMsg, setToastMsg] = useState(null);
  const [selectedIds, setSelectedIds] = useState(new Set());

  // Stale data tracking
  const [lastFreshAt, setLastFreshAt] = useState(null);
  const [isStale, setIsStale] = useState(false);
  const staleTimerRef = useRef(null);

  // ── Selection batch handlers ──
  const handleToggleSelect = useCallback((id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const handleSelectAll = useCallback((ids) => {
    setSelectedIds((prev) => {
      const allSelected = ids.every((id) => prev.has(id));
      if (allSelected) return new Set();
      return new Set(ids);
    });
  }, []);

  const handleClearSelection = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  const handleBatchAction = useCallback(async (actionType, selectedRowsToAct) => {
    for (const r of selectedRowsToAct) {
      await submitAuditorDecision(r.transaction_id, {
        auditor: "Batch Auditor",
        action: actionType,
        reason: `Batch triage: ${actionType}`,
      }).catch(() => null);
    }
    setRows((prev) =>
      prev?.map((r) =>
        selectedIds.has(r.transaction_id) ? { ...r, auditor_decision: actionType } : r
      )
    );
    setSelectedIds(new Set());
    showToast(`Recorded ${actionType} for ${selectedRowsToAct.length} case${selectedRowsToAct.length > 1 ? "s" : ""}`);
  }, [selectedIds]);

  // ── Load queue ──
  const load = useCallback(async (silent = false) => {
    if (!silent) setRefreshing(true);
    else setRefreshing(true);

    // Clear stale timer
    clearTimeout(staleTimerRef.current);
    setIsStale(false);

    try {
      const data = await getQueue({ vertical, tier, limit: 100 });
      setRows(data);
      setError(null);
      const now = Date.now();
      setLastFreshAt(now);

      // Set stale timer
      staleTimerRef.current = setTimeout(() => setIsStale(true), STALE_THRESHOLD_MS);
    } catch (e) {
      setError(e?.message ?? "Unknown error");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [vertical, tier]);

  useEffect(() => {
    load();
    return () => clearTimeout(staleTimerRef.current);
  }, [load]);

  // ── V key: toggle view mode ──
  useEffect(() => {
    function handleGlobalKeys(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
      if (e.key === "v" || e.key === "V") {
        e.preventDefault();
        playTick("toggle");
        setViewMode((prev) => (prev === "split" ? "grid" : "split"));
      }
    }
    window.addEventListener("keydown", handleGlobalKeys);
    return () => window.removeEventListener("keydown", handleGlobalKeys);
  }, []);

  // ── Toast helper ──
  const toastTimerRef = useRef(null);
  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastMsg(null), 4000);
  }, []);

  // ── Filtering ──
  const filtered = useMemo(() => {
    if (!rows) return [];
    let res = rows;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      res = res.filter((r) => {
        const haystack = [
          r.transaction_id,
          r.originator_account,
          r.beneficiary_account,
          r.counterparty_name,
          r.use_case,
          r.vertical,
          ...(Array.isArray(r.rules_triggered) ? r.rules_triggered : []),
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return haystack.includes(q);
      });
    }
    if (activeRiskBin) {
      res = res.filter((r) => {
        const s = Number(r.composite_score ?? 0);
        return s >= activeRiskBin.min && s < activeRiskBin.max;
      });
    }
    if (amountLimit === "high_value") {
      res = res.filter((r) => Number(r.amount ?? 0) >= 100000);
    } else if (amountLimit === "statutory_limit") {
      res = res.filter((r) => Number(r.amount ?? 0) >= 250000);
    }
    return res;
  }, [rows, search, activeRiskBin, amountLimit]);

  // Clamp selectedIndex when filtered list shrinks
  useEffect(() => {
    if (filtered.length > 0 && selectedIndex >= filtered.length) {
      setSelectedIndex(filtered.length - 1);
    }
  }, [filtered.length, selectedIndex]);

  const activeRow = useMemo(() => {
    if (!filtered || filtered.length === 0) return null;
    return filtered[selectedIndex] || filtered[0] || null;
  }, [filtered, selectedIndex]);

  // ── Disposition success ──
  const handleDispositionSuccess = (txId, action, reason) => {
    setRows((prev) => {
      if (!prev) return prev;
      return prev.map((r) =>
        r.transaction_id === txId
          ? { ...r, auditor_decision: action, decision_reason: reason }
          : r
      );
    });
    showToast(`${compactCaseId(txId)} attested as ${action}`);
    setSelectedIndex((prev) => Math.min(filtered.length - 1, prev + 1));
  };

  // ── KPIs for HealthSummaryRow ──
  const kpis = useMemo(() => {
    if (!rows) return null;
    const flagged    = rows.length;
    const highRisk   = rows.filter((r) => r.review_tier === "immediate_escalation").length;
    const decided    = rows.filter((r) => r.auditor_decision).length;
    const attestPct  = flagged > 0 ? Math.round((decided / flagged) * 100) : 0;
    return { flagged, highRisk, attestPct };
  }, [rows]);

  const isFilterActive = !!(vertical || tier || amountLimit || search.trim());

  // Re-anchor the review cursor when the result set changes.
  useEffect(() => {
    setSelectedIndex(0);
  }, [search, vertical, tier, amountLimit, activeRiskBin]);

  const clearFilters = () => {
    playTick("toggle");
    setSearch("");
    setVertical(null);
    setTier(null);
    setAmountLimit(null);
  };

  return (
    <div className="h-full flex flex-col select-none overflow-hidden" style={{ background: "var(--canvas)" }}>
      {/* ── Precision Single-Line Command Bar (42px) ── */}
      <div
        className="h-10.5 px-3 sm:px-4 flex items-center justify-between gap-3 border-b shrink-0 bg-surface z-10"
        style={{ borderColor: "var(--divider)" }}
      >
        {/* Left: Desk Title & Telemetry */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-baseline gap-2">
            <span className="font-sans font-semibold text-xs text-text-primary tracking-tight">
              Case queue
            </span>
            <span className="text-text-muted text-[11px] font-sans">/</span>
            <span className="font-sans text-xs text-text-secondary">
              Buffer: <span className="font-mono font-medium text-text-primary">{filtered.length}</span> items
            </span>
          </div>

          <span
            className={`h-1.5 w-1.5 rounded-full ${
              isStale ? "bg-warning" : isMock ? "bg-warning" : "bg-success"
            }`}
            title={isStale ? "Feed Stale (Re-syncing)" : "Feed Synchronized"}
          />
        </div>

        {/* Center: Search & Concise Filters */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
          {/* Search box */}
          <div className="relative w-36 sm:w-44 shrink-0">
            <MagnifyingGlass
              className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-text-muted pointer-events-none"
              weight="bold"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search cases…"
              aria-label="Search cases, counterparties, and typologies"
              className="w-full h-7 pl-7 pr-5 text-xs font-sans rounded bg-surface-subtle border border-divider text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/40"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-1 top-1/2 -translate-y-1/2 h-5 w-5 inline-flex items-center justify-center rounded text-text-muted hover:text-text-primary hover:bg-surface focus-visible:outline-none"
                aria-label="Clear case search"
                title="Clear search"
              >
                <X className="h-3 w-3" weight="bold" aria-hidden />
              </button>
            )}
          </div>

          {/* Typology / Vertical Filters */}
          <div className="hidden sm:flex items-center rounded border border-divider p-0.5 bg-surface-subtle text-[11px] font-sans">
            {[
              { id: null, label: "All" },
              { id: "aml", label: "AML" },
              { id: "corporate", label: "Corp" },
              { id: "retail", label: "Retail" },
            ].map((v) => (
              <button
                key={v.label}
                onClick={() => { playTick("toggle"); setVertical(v.id); }}
                aria-pressed={vertical === v.id}
                className={`px-2 py-0.5 rounded transition-colors ${
                  vertical === v.id
                    ? "bg-surface text-text-primary font-semibold border border-divider shadow-xs"
                    : "text-text-muted hover:text-text-primary"
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>

          {/* Review Tier Filters */}
          <div className="hidden md:flex items-center rounded border border-divider p-0.5 bg-surface-subtle text-[11px] font-sans">
            {[
              { id: null, label: "All" },
              { id: "immediate_escalation", label: "Escalation" },
              { id: "priority_review", label: "Priority" },
              { id: "standard_review", label: "Standard" },
            ].map((t) => (
              <button
                key={t.label}
                onClick={() => { playTick("toggle"); setTier(t.id); }}
                aria-pressed={tier === t.id}
                className={`px-2 py-0.5 rounded transition-colors ${
                  tier === t.id
                    ? "bg-surface text-text-primary font-semibold border border-divider shadow-xs"
                    : "text-text-muted hover:text-text-primary"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Threshold Limit Filters */}
          <div className="hidden xl:flex items-center rounded border border-divider p-0.5 bg-surface-subtle text-[11px] font-sans">
            {[
              { id: null, label: "All" },
              { id: "high_value", label: ">₹100k" },
              { id: "statutory_limit", label: ">₹250k" },
            ].map((l) => (
              <button
                key={l.label}
                onClick={() => { playTick("toggle"); setAmountLimit(l.id); }}
                aria-pressed={amountLimit === l.id}
                className={`px-2 py-0.5 rounded transition-colors ${
                  amountLimit === l.id
                    ? "bg-surface text-text-primary font-semibold border border-divider shadow-xs"
                    : "text-text-muted hover:text-text-primary"
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>

          {isFilterActive && (
            <button
              onClick={clearFilters}
              className="text-[11px] font-sans text-accent hover:text-accent-strong flex items-center gap-1 shrink-0 ml-1 rounded px-1 py-0.5 focus-visible:outline-none"
              aria-label="Clear all queue filters"
            >
              <X className="h-3 w-3" /> Clear
            </button>
          )}
        </div>

        {/* Right: View Ergonomics & Keyboard Prompts */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Hotkey prompt hints */}
          <div className="hidden 2xl:flex items-center gap-1.5 font-mono text-[10px] text-text-muted pr-2 border-r border-divider">
            <span>[J/K] Nav</span>
            <span>·</span>
            <span>[A] Approve</span>
            <span>·</span>
            <span>[E] Escalate</span>
            <span>·</span>
            <span>[S] SAR</span>
          </div>

          {/* View Mode Toggle: Split vs Table */}
          <div className="hidden sm:flex items-center rounded border border-divider p-0.5 bg-surface-subtle text-[11px] font-sans">
            <button
              onClick={() => { playTick("toggle"); setViewMode("split"); }}
              className={`px-2 py-0.5 rounded transition-colors ${
                viewMode === "split"
                  ? "bg-surface text-text-primary font-semibold border border-divider"
                  : "text-text-muted hover:text-text-primary"
              }`}
              title="Split View: Queue & Dossier (V)"
            >
              Split
            </button>
            <button
              onClick={() => { playTick("toggle"); setViewMode("grid"); }}
              className={`px-2 py-0.5 rounded transition-colors ${
                viewMode === "grid"
                  ? "bg-surface text-text-primary font-semibold border border-divider"
                  : "text-text-muted hover:text-text-primary"
              }`}
              title="Ledger View: Full Width Table (V)"
            >
              Ledger
            </button>
          </div>

          {/* Density Toggle */}
          <button
            onClick={() => {
              playTick("toggle");
              setDensity((d) => (d === "standard" ? "compact" : "standard"));
            }}
            className="hidden sm:flex h-7 items-center gap-1 rounded px-2 text-[11px] font-sans text-text-secondary hover:text-text-primary border border-divider bg-surface-subtle"
            title={`Toggle row density (currently ${density})`}
          >
            <span>{density === "standard" ? "Comfort" : "Dense"}</span>
          </button>

          {/* Refresh button */}
          <button
            onClick={() => { playTick("action"); load(); }}
            disabled={refreshing}
            className="h-7 w-7 flex items-center justify-center rounded border border-divider bg-surface-subtle text-text-muted hover:text-text-primary"
            title="Refresh feed"
            aria-label={refreshing ? "Refreshing case queue" : "Refresh case queue"}
          >
            <ArrowsClockwise className={`h-3.5 w-3.5 ${refreshing ? "animate-spin text-accent" : ""}`} />
          </button>
        </div>
      </div>

      {/* ── Main Workspace Body (Takes remaining 100% height) ── */}
      <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
        {loading && (
          <div className="p-4">
            <SkeletonQueue />
          </div>
        )}

        {!loading && error && (
          <div className="p-6 m-4 rounded border border-divider bg-surface">
            <ErrorState
              title="Queue Unavailable"
              message={`Could not refresh queue: ${error}`}
              onRetry={load}
              lastFreshAt={lastFreshAt}
            />
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div className="p-8 m-4 rounded border border-divider bg-surface">
            <EmptyState
              title={isFilterActive ? "No matching cases" : "Queue is clear"}
              description={
                isFilterActive
                  ? "No cases match the active filters. Adjust or clear your filters to see all records."
                  : "There are no active alerts in the surveillance buffer."
              }
              action={isFilterActive ? {
                label: "Clear filters",
                onClick: clearFilters,
              } : {
                label: "Refresh",
                onClick: load,
              }}
            />
          </div>
        )}

        {!loading && !error && filtered.length > 0 && (
          <>
            {/* Mobile Case Stream (< md) */}
            <div className="block md:hidden flex-1 overflow-y-auto p-3 space-y-2">
              <div className="flex items-center justify-between text-meta-xs text-text-muted px-1 pb-1">
                <span>Active Queue · {filtered.length} cases</span>
                {selectedIds.size > 0 ? (
                  <button onClick={handleClearSelection} className="text-accent font-semibold underline">
                    Clear {selectedIds.size}
                  </button>
                ) : (
                  <button
                    onClick={() => handleSelectAll(filtered.map((r) => r.transaction_id))}
                    className="text-text-muted hover:text-text-primary"
                  >
                    Select all
                  </button>
                )}
              </div>
              {filtered.map((r) => (
                <MobileCaseCard
                  key={r.transaction_id}
                  row={r}
                  isSelected={selectedIds.has(r.transaction_id)}
                  onToggleSelect={handleToggleSelect}
                />
              ))}
            </div>

            {/* Desktop Split or Ledger (≥ md) */}
            <div className="hidden md:flex flex-1 min-h-0 overflow-hidden">
              {viewMode === "split" ? (
                <div className="flex w-full h-full divide-x divide-divider overflow-hidden">
                  {/* Left Column: Continuous Borderless Ledger Table */}
                  <div className="w-[46%] xl:w-[42%] 2xl:w-[38%] flex flex-col min-h-0 bg-surface overflow-hidden">
                    <div className="flex-1 overflow-y-auto scrollbar-thin">
                      <TransactionTable
                        rows={filtered}
                        density={density}
                        selectedIndex={selectedIndex}
                        onSelectIndex={setSelectedIndex}
                        layoutMode="split"
                        selectedIds={selectedIds}
                        onToggleSelect={handleToggleSelect}
                        onSelectAll={handleSelectAll}
                      />
                    </div>
                  </div>

                  {/* Right Column: Continuous Borderless Forensic Dossier */}
                  <div className="flex-1 min-w-0 flex flex-col min-h-0 bg-surface overflow-hidden">
                    <ForensicWorkbenchDossier
                      row={activeRow}
                      onDispositionSuccess={handleDispositionSuccess}
                      queueList={filtered}
                    />
                  </div>
                </div>
              ) : (
                /* Ledger View: Full-width Table */
                <div className="w-full h-full flex flex-col min-h-0 bg-surface overflow-hidden">
                  <div className="flex-1 overflow-y-auto scrollbar-thin">
                    <TransactionTable
                      rows={filtered}
                      density={density}
                      selectedIndex={selectedIndex}
                      onSelectIndex={setSelectedIndex}
                      layoutMode="grid"
                      selectedIds={selectedIds}
                      onToggleSelect={handleToggleSelect}
                      onSelectAll={handleSelectAll}
                    />
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* Batch selection action dock */}
        <BatchActionDock
          selectedRows={filtered.filter((r) => selectedIds.has(r.transaction_id))}
          onClearSelection={handleClearSelection}
          onBatchAction={handleBatchAction}
        />
      </div>

      {/* Toast */}
      <Toast message={toastMsg} onDismiss={() => setToastMsg(null)} />
    </div>
  );
}
