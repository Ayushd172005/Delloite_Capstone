import { useState, useMemo, useEffect } from "react";
import {
  Cpu,
  Activity,
  Sliders,
  ShieldCheck,
  TrendingDown,
  Layers,
  Database,
  CheckCircle2,
  AlertTriangle,
  Info,
  Scale,
  DollarSign,
  ArrowRight,
  Sparkles,
} from "../components/PhosphorIcons";
import {
  MODEL_META,
  VERTICAL_METRICS,
  FEATURE_DRIFT_REPORT,
  DATA_QUALITY_CERTIFICATE,
  calculateSimulatedTradeoff,
} from "../data/governanceData";
import { useCurrency } from "../context/CurrencyContext";
import { playTick } from "../utils/audio";
import CryptographicSeal from "../components/CryptographicSeal";
import { getMetrics } from "../api/transactions";

export default function ModelGovernance() {
  const [selectedVertical, setSelectedVertical] = useState("aml");
  const [simulatedThreshold, setSimulatedThreshold] = useState(25);
  const [liveMetrics, setLiveMetrics] = useState(null);
  const { formatAmount, isUSD } = useCurrency();

  useEffect(() => {
    let active = true;
    getMetrics().then((data) => {
      if (active && data) setLiveMetrics(data);
    }).catch(() => {
      // Benchmark telemetry remains visible if the optional metrics endpoint is unavailable.
    });
    return () => { active = false; };
  }, []);

  const benchmarkVert = VERTICAL_METRICS[selectedVertical] || VERTICAL_METRICS.aml;
  const liveVert = liveMetrics?.[selectedVertical];
  const vert = liveVert ? {
    ...benchmarkVert,
    transactions_analyzed: liveVert.transactions_analyzed,
    flagged_for_review: liveVert.transactions_flagged_for_review,
    workload_reduction_pct: liveVert.workload_reduction_pct,
    capture_rate_pct: liveVert.total_fraud_in_holdout > 0
      ? Math.round((liveVert.fraud_caught_in_flagged_queue / liveVert.total_fraud_in_holdout) * 1000) / 10
      : benchmarkVert.capture_rate_pct,
    fraud_caught_in_queue: liveVert.fraud_caught_in_flagged_queue,
    total_fraud_in_holdout: liveVert.total_fraud_in_holdout,
    top_1pct_capture_rate: Math.round(liveVert.top_1pct_capture_rate * 10000) / 100,
    top_5pct_capture_rate: Math.round(liveVert.top_5pct_capture_rate * 10000) / 100,
    _isLive: true,
  } : benchmarkVert;
  const driftFeatures =
    FEATURE_DRIFT_REPORT.find((d) => d.vertical === selectedVertical)?.features || [];

  const simulation = useMemo(
    () => calculateSimulatedTradeoff(selectedVertical, simulatedThreshold),
    [selectedVertical, simulatedThreshold]
  );

  return (
    <div className="governance-page w-full px-3 sm:px-6 py-3 sm:py-6 max-w-[1680px] mx-auto space-y-4 sm:space-y-5 select-none">
      {/* Top Header & Model Status Ribbon */}
      <div className="flex flex-col gap-3 pb-3 sm:pb-5 md:flex-row md:items-center md:justify-between" style={{ borderBottom: "1px solid var(--divider)" }}>
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <div
              className="flex h-7 w-7 items-center justify-center rounded-control shrink-0"
              style={{ background: "var(--accent-dim)", border: "1px solid color-mix(in srgb, var(--accent) 30%, transparent)" }}
            >
              <Cpu className="h-4 w-4 text-accent" />
            </div>
            <h1 className="text-[1.35rem] leading-7 font-bold tracking-tight text-text-primary">
              Model health
            </h1>
            <div className="flex items-center gap-2 font-mono text-meta-xs">
              <span className="text-text-secondary">Model {MODEL_META.version}</span>
              <span className="text-divider">·</span>
              <span className="flex items-center gap-1.5 text-success font-medium">
                <span className="h-1.5 w-1.5 rounded-full bg-success live-pulse-dot" />
                {liveVert ? "Live API Calibration Telemetry" : (MODEL_META.status === "CALIBRATED_STABLE" ? "Calibrated Benchmark" : MODEL_META.status)}
              </span>
            </div>
          </div>
          <p className="mt-1 font-mono text-2xs text-text-muted">
            Population drift monitoring · ensemble attribution · cost-sensitive threshold calibration · dataset integrity
          </p>
        </div>

        {/* Vertical Switcher Tabs */}
        <div className="flex items-center gap-1 rounded-lg border border-border bg-panel-dock p-1 shadow-xs overflow-x-auto max-w-full pb-1 sm:pb-1 scrollbar-none">
          {[
            { id: "aml", label: "AML / PMLA" },
            { id: "corporate", label: "Corporate Treasury" },
            { id: "retail", label: "Retail Payments" },
          ].map((tab) => {
            const active = selectedVertical === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  playTick("toggle");
                  setSelectedVertical(tab.id);
                }}
                className={`flex items-center shrink-0 rounded-md px-2.5 sm:px-3 py-1.5 text-xs font-medium transition-all ${
                  active
                    ? "bg-panel text-ink shadow-xs font-semibold border border-border"
                    : "text-ink-muted hover:text-ink hover:bg-panel/50"
                }`}
                aria-pressed={active}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Consolidated Sovereign Telemetry Strip */}
      <div
        className="rounded-panel border border-border divide-y sm:divide-y-0 sm:divide-x divide-border/60 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 overflow-hidden"
        style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}
      >
        {/* Metric 1: Validation ROC-AUC */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Validation ROC-AUC</span>
            <Activity className="h-3.5 w-3.5 text-accent" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-xl font-bold tracking-tight text-text-primary">
              {(vert.roc_auc * 100).toFixed(2)}%
            </span>
            <span className="inline-flex items-center gap-1 font-mono text-meta-xs font-medium text-success">
              <span className="h-1.5 w-1.5 rounded-full bg-success shrink-0" />
              {vert.roc_auc >= 0.9 ? "Exemplary" : vert.roc_auc >= 0.75 ? "Robust" : "Satisfactory"}
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Holdout sample size</span>
            <span className="font-mono font-medium text-text-primary">{vert.transactions_analyzed.toLocaleString()}</span>
          </div>
        </div>

        {/* Metric 2: Workload Reduction */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Workload Reduction</span>
            <TrendingDown className="h-3.5 w-3.5 text-low" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-xl font-bold tracking-tight text-low">
              {vert.workload_reduction_pct.toFixed(1)}%
            </span>
            <span className="text-xs text-text-muted">auto-cleared</span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Manual queue burden</span>
            <span className="font-mono font-medium text-text-primary">
              {vert.flagged_for_review.toLocaleString()} cases
            </span>
          </div>
        </div>

        {/* Metric 3: Top-Tier Fraud Capture Rate */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Queue Capture Rate</span>
            <ShieldCheck className="h-3.5 w-3.5 text-accent" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-xl font-bold tracking-tight text-text-primary">
              {vert.capture_rate_pct.toFixed(1)}%
            </span>
            <span className="font-mono text-3xs text-text-muted">
              ({vert.fraud_caught_in_queue} / {vert.total_fraud_in_holdout})
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Top 1% / 5% Capture</span>
            <span className="font-mono font-medium text-accent">
              {vert.top_1pct_capture_rate}% / {vert.top_5pct_capture_rate}%
            </span>
          </div>
        </div>

        {/* Metric 4: Net Expected Cost Savings */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Net Loss Reduction</span>
            <DollarSign className="h-3.5 w-3.5 text-low" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-xl font-bold tracking-tight text-text-primary">
              {vert.cost_evaluation.savings_pct}%
            </span>
            <span className="inline-flex items-center gap-1 font-mono text-meta-xs font-medium text-success">
              <span className="h-1.5 w-1.5 rounded-full bg-success shrink-0" />
              Net Saved
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Financial savings</span>
            <span className="font-mono font-medium text-low tabular-nums">
              {formatAmount(vert.cost_evaluation.savings_inr)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Dual-Column Section */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Left 6 Cols: Ensemble Architecture & Cost-Sensitive Trade-off Simulator */}
        <div className="space-y-5 lg:col-span-6">
          {/* Card: Multi-Engine Ensemble Attribution Weights */}
          <div className="rounded-panel border border-border p-4 sm:p-5 space-y-3.5" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
            <div className="flex items-center justify-between border-b border-border/50 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-accent" />
                <h2 className="text-sm font-semibold text-text-primary">
                  Ensemble Architecture & Attribution Weights
                </h2>
              </div>
              <span className="text-xs text-text-muted">
                Holdout validation benchmark
              </span>
            </div>

            {/* Stacked Attribution Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-text-muted">
                <span>Component Allocation</span>
                <span className="font-mono text-3xs">Total Weight: 1.00</span>
              </div>
              <div className="flex h-3.5 w-full overflow-hidden rounded-control border border-border">
                <div
                  style={{ width: `${vert.weights.isoforest * 100}%` }}
                  className="bg-accent/80 transition-all"
                  title={`Isolation Forest: ${(vert.weights.isoforest * 100).toFixed(0)}%`}
                />
                <div
                  style={{ width: `${vert.weights.autoencoder * 100}%` }}
                  className="bg-steel/80 transition-all"
                  title={`Deep Autoencoder: ${(vert.weights.autoencoder * 100).toFixed(0)}%`}
                />
                <div
                  style={{ width: `${vert.weights.rules * 100}%` }}
                  className="bg-spark/80 transition-all"
                  title={`Deterministic Rules: ${(vert.weights.rules * 100).toFixed(0)}%`}
                />
                <div
                  style={{ width: `${vert.weights.benford * 100}%` }}
                  className="bg-text-muted/40 transition-all"
                  title={`Benford Law: ${(vert.weights.benford * 100).toFixed(0)}%`}
                />
              </div>

              {/* Attribution Grid (hairline segmented) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-border/50 rounded-control overflow-hidden border border-border/70 mt-2">
                <div className="p-2.5 space-y-1" style={{ background: "var(--surface)" }}>
                  <div className="flex items-center gap-1.5 text-xs text-text-muted">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                    <span className="truncate">Isolation Forest</span>
                  </div>
                  <div className="font-mono text-sm font-semibold text-text-primary">
                    {(vert.weights.isoforest * 100).toFixed(0)}%
                  </div>
                  <div className="text-3xs text-text-muted">Unsupervised partition</div>
                </div>

                <div className="p-2.5 space-y-1" style={{ background: "var(--surface)" }}>
                  <div className="flex items-center gap-1.5 text-xs text-text-muted">
                    <span className="h-1.5 w-1.5 rounded-full bg-steel" />
                    <span className="truncate">Deep Autoencoder</span>
                  </div>
                  <div className="font-mono text-sm font-semibold text-text-primary">
                    {(vert.weights.autoencoder * 100).toFixed(0)}%
                  </div>
                  <div className="text-3xs text-text-muted">Latent reconstruction</div>
                </div>

                <div className="p-2.5 space-y-1" style={{ background: "var(--surface)" }}>
                  <div className="flex items-center gap-1.5 text-xs text-text-muted">
                    <span className="h-1.5 w-1.5 rounded-full bg-spark" />
                    <span className="truncate">Expert Rules</span>
                  </div>
                  <div className="font-mono text-sm font-semibold text-text-primary">
                    {(vert.weights.rules * 100).toFixed(0)}%
                  </div>
                  <div className="text-3xs text-text-muted">Typology heuristics</div>
                </div>

                <div className="p-2.5 space-y-1" style={{ background: "var(--surface)" }}>
                  <div className="flex items-center gap-1.5 text-xs text-text-muted">
                    <span className="h-1.5 w-1.5 rounded-full bg-text-muted" />
                    <span className="truncate">Benford & Causal</span>
                  </div>
                  <div className="font-mono text-sm font-semibold text-text-primary">
                    {(vert.weights.benford * 100).toFixed(0)}%
                  </div>
                  <div className="text-3xs text-text-muted">Digit distribution</div>
                </div>
              </div>
            </div>
          </div>

          {/* Card: Interactive Cost-Benefit Threshold Simulator */}
          <div className="rounded-panel border border-border p-4 sm:p-5 space-y-3.5" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
            <div className="flex items-center justify-between border-b border-border/50 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="h-4 w-4 text-accent" />
                <h2 className="text-sm font-semibold text-text-primary">
                  Interactive Cost-Sensitive Threshold Simulator
                </h2>
              </div>
              <span className="text-xs text-text-muted">
                Interactive Cutoff
              </span>
            </div>

            <p className="text-xs text-text-secondary leading-relaxed">
              Adjust the composite surveillance cut-off score to observe how operational manual review expenditure ({isUSD ? "$6.02" : "₹500"} / case baseline) trades off against fraud loss slippage ({isUSD ? "$2,410" : "₹2,00,000"} / case average fraud loss).
            </p>

            {/* Slider Control */}
            <div className="rounded-control border border-border bg-panel-dock/40 p-3.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-text-secondary">Simulated Review Threshold:</span>
                <span className="font-mono text-base font-bold text-accent">
                  {simulatedThreshold} / 100
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="75"
                step="1"
                value={simulatedThreshold}
                onChange={(e) => {
                  playTick("toggle");
                  setSimulatedThreshold(Number(e.target.value));
                }}
                className="mt-3 w-full accent-accent cursor-pointer"
              />
              <div className="mt-1 flex justify-between font-mono text-3xs text-text-muted">
                <span>5 (Aggressive Review)</span>
                <span>Calibrated Cutoff: {vert.fpr_threshold}</span>
                <span>75 (Lean Queue)</span>
              </div>
            </div>

            {/* Live Simulation Results Grid (hairline segmented) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-border/50 rounded-control overflow-hidden border border-border/70">
              <div className="p-3 space-y-1" style={{ background: "var(--surface)" }}>
                <div className="text-xs text-text-muted">Review Queue</div>
                <div className="font-mono text-base font-semibold text-text-primary">
                  {simulation.queueCases.toLocaleString()}
                </div>
                <div className="font-mono text-3xs text-text-muted">
                  {simulation.reviewPct}% of traffic
                </div>
              </div>

              <div className="p-3 space-y-1" style={{ background: "var(--surface)" }}>
                <div className="text-xs text-text-muted">Fraud Captured</div>
                <div className="font-mono text-base font-semibold text-low">
                  {simulation.caughtFraud} cases
                </div>
                <div className="font-mono text-3xs text-low">
                  {simulation.captureRatePct}% capture
                </div>
              </div>

              <div className="p-3 space-y-1" style={{ background: "var(--surface)" }}>
                <div className="text-xs text-text-muted">Fraud Slippage</div>
                <div className="font-mono text-base font-semibold text-critical">
                  {simulation.missedFraud} cases
                </div>
                <div className="font-mono text-3xs text-critical">
                  {formatAmount(simulation.fraudLossINR)} loss
                </div>
              </div>

              <div className="p-3 space-y-1" style={{ background: "var(--surface)" }}>
                <div className="text-xs text-text-muted">Simulated Savings</div>
                <div className="font-mono text-base font-semibold text-low">
                  {simulation.savingsPct}%
                </div>
                <div className="font-mono text-3xs text-low">
                  {formatAmount(simulation.savingsVsEverythingINR)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 6 Cols: Population Drift & Data Quality Shield */}
        <div className="space-y-5 lg:col-span-6">
          {/* Card: Population Stability Index & Feature Drift */}
          <div className="rounded-panel border border-border p-4 sm:p-5 space-y-3.5" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
            <div className="flex items-center justify-between border-b border-border/50 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-accent" />
                <h2 className="text-sm font-semibold text-text-primary">
                  Feature Drift & PSI Telemetry
                </h2>
              </div>
              <span className="font-mono text-meta-xs text-low flex items-center gap-1 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" />
                All Drift &lt; 0.05
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-border/70 text-3xs text-text-muted uppercase">
                    <th className="py-2 pr-2 text-left font-medium">Feature</th>
                    <th className="py-2 px-1.5 text-right font-medium">Base</th>
                    <th className="py-2 px-1.5 text-right font-medium">Current</th>
                    <th className="py-2 px-1.5 text-right font-medium">Δ%</th>
                    <th className="py-2 px-1.5 text-right font-medium">PSI</th>
                    <th className="py-2 pl-2 text-right font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {driftFeatures.map((f) => (
                    <tr key={f.metric} className="hover:bg-panel-dock/30 transition-colors">
                      <td className="py-2 pr-2 font-medium text-text-primary whitespace-nowrap">{f.metric}</td>
                      <td className="py-2 px-1.5 text-right text-text-muted tabular-nums whitespace-nowrap">{f.baseline.toLocaleString()}</td>
                      <td className="py-2 px-1.5 text-right text-text-primary font-medium tabular-nums whitespace-nowrap">{f.current.toLocaleString()}</td>
                      <td
                        className={`py-2 px-1.5 text-right font-medium tabular-nums whitespace-nowrap ${
                          f.pct_change > 0 ? "text-accent" : "text-text-muted"
                        }`}
                      >
                        {f.pct_change > 0 ? `+${f.pct_change}%` : `${f.pct_change}%`}
                      </td>
                      <td className="py-2 px-1.5 text-right text-text-muted tabular-nums whitespace-nowrap">{f.psi}</td>
                      <td className="py-2 pl-2 text-right whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 font-mono text-meta-xs font-medium text-success">
                          <span className="h-1.5 w-1.5 rounded-full bg-success shrink-0" />
                          {f.status === "STABLE" ? "Stable" : f.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Card: Data Quality & Schema Integrity Certification */}
          <div className="rounded-panel border border-border p-4 sm:p-5 space-y-3.5" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
            <div className="flex items-center justify-between border-b border-border/50 pb-3">
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-accent" />
                <h2 className="text-sm font-semibold text-text-primary">
                  Dataset Hygiene Certification
                </h2>
              </div>
              <span className="text-xs text-text-muted">
                345,000 Records Checked
              </span>
            </div>

            <div className="divide-y divide-border/40">
              {DATA_QUALITY_CERTIFICATE.map((cert) => (
                <div
                  key={cert.vertical}
                  className="py-2.5 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-medium text-text-primary flex items-center gap-1.5">
                      <span>{cert.vertical}</span>
                      <span className="font-mono text-3xs text-text-muted">
                        ({cert.n_rows.toLocaleString()} rows)
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center gap-3 font-mono text-3xs text-text-muted">
                      <span>Null Rate: {cert.null_rate}</span>
                      <span>•</span>
                      <span>Duplicates: {cert.duplicate_ids}</span>
                      <span>•</span>
                      <span>Violations: {cert.non_positive_amounts}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 font-mono text-meta-xs font-medium text-success">
                    <CheckCircle2 className="h-3.5 w-3.5 text-success shrink-0" />
                    <span>Passed</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-border/50 pt-2.5 flex items-center justify-between text-xs text-text-muted">
              <span>Attestation Authority:</span>
              <span className="text-text-primary font-medium flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                <span>Automated Schema & Pipeline Check Passed</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
