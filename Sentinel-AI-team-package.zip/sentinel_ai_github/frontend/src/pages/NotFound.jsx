import { Link } from "react-router-dom";
import { ShieldOff, ArrowLeft } from "../components/PhosphorIcons";
import { useDocumentTitle } from "../hooks/useDocumentTitle";

export default function NotFound() {
  useDocumentTitle("404 — Page Not Found | Sentinel AI");

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-canvas px-6 text-center">
      {/* Shield illustration — CSS only, no image dependency */}
      <div className="relative mb-8">
        <ShieldOff
          className="h-20 w-20 text-text-muted opacity-40"
          strokeWidth={0.75}
          aria-hidden="true"
        />
        <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-mono text-2xl font-bold text-accent">
          404
        </span>
      </div>

      {/* Heading */}
      <h1 className="text-display-sm font-bold text-text-primary">Case Not Found</h1>

      {/* Subtext */}
      <p className="mt-2 max-w-xs text-sm leading-relaxed text-text-secondary">
        This transaction ID or route does not exist in Sentinel's records. It may
        have been reassigned or the URL is incorrect.
      </p>

      {/* Divider */}
      <div className="my-6 h-px w-16" style={{ background: "var(--divider)" }} />

      {/* CTA */}
      <Link
        to="/"
        className="inline-flex items-center gap-2 rounded-control border border-accent/40 bg-accent-dim px-4 py-2 text-xs font-semibold text-accent transition-colors hover:border-accent hover:bg-accent-dim/80"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2} />
        Return to Risk Queue
      </Link>

      {/* Wordmark footer */}
      <p className="mt-12 font-mono text-meta-xs text-text-muted">
        Sentinel AI · Intelligence Terminal
      </p>
    </div>
  );
}
