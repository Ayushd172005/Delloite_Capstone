import React, { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { ARCHETYPES, MOCK_CASES, QUEUE_STREAM } from "../components/studio/studioData";
import TerminalMonolith from "../components/studio/TerminalMonolith";
import LinearTitanium from "../components/studio/LinearTitanium";
import PalantirGotham from "../components/studio/PalantirGotham";
import SwissBrutalist from "../components/studio/SwissBrutalist";
import StripeRadar from "../components/studio/StripeRadar";
import BraunConsole from "../components/studio/BraunConsole";
import MonocleDossier from "../components/studio/MonocleDossier";
import CyberSpectrogram from "../components/studio/CyberSpectrogram";
import CadBlueprint from "../components/studio/CadBlueprint";
import SovereignApex from "../components/studio/SovereignApex";

export default function DesignConcepts() {
  const [searchParams, setSearchParams] = useSearchParams();
  const rawConcept = searchParams.get("dir") || "terminal-monolith";
  const [activeConceptId, setActiveConceptId] = useState(rawConcept);
  const [selectedCaseId, setSelectedCaseId] = useState("TRF_46631F673703");
  const [currency, setCurrency] = useState("INR");
  const [toastMessage, setToastMessage] = useState(null);

  // Sync with URL search params
  useEffect(() => {
    if (searchParams.get("dir")) {
      setActiveConceptId(searchParams.get("dir"));
    }
  }, [searchParams]);

  const selectConcept = (id) => {
    setActiveConceptId(id);
    setSearchParams({ dir: id });
  };

  // Keyboard shortcut listener (1-9 and 0 for 10, arrow keys)
  useEffect(() => {
    const handleKeyDown = (e) => {
      // If typing in input, ignore
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;

      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 9) {
        selectConcept(ARCHETYPES[num - 1].id);
      } else if (e.key === "0") {
        selectConcept(ARCHETYPES[9].id);
      } else if (e.key === "ArrowRight") {
        const currentIdx = ARCHETYPES.findIndex((a) => a.id === activeConceptId);
        const nextIdx = (currentIdx + 1) % ARCHETYPES.length;
        selectConcept(ARCHETYPES[nextIdx].id);
      } else if (e.key === "ArrowLeft") {
        const currentIdx = ARCHETYPES.findIndex((a) => a.id === activeConceptId);
        const prevIdx = (currentIdx - 1 + ARCHETYPES.length) % ARCHETYPES.length;
        selectConcept(ARCHETYPES[prevIdx].id);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeConceptId]);

  const activeArchetype = ARCHETYPES.find((a) => a.id === activeConceptId) || ARCHETYPES[0];
  const activeCase = MOCK_CASES.find((c) => c.transaction_id === selectedCaseId) || MOCK_CASES[0];

  const handleAction = (actionName, caseId) => {
    const hash = "0x" + Math.random().toString(16).slice(2, 10) + "..." + Math.random().toString(16).slice(2, 6);
    setToastMessage({
      action: actionName,
      caseId: caseId,
      hash: hash,
      time: new Date().toLocaleTimeString(),
    });
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#08080a] text-[#f4f4f5] font-sans antialiased">
      {/* ─── Master Design Studio Navigation Bar ─────────────────────────── */}
      <header className="sticky top-0 z-50 border-b border-[#22242a] bg-[#0c0d10]/95 backdrop-blur-md px-4 py-2.5 shadow-xl">
        <div className="max-w-[1700px] mx-auto flex flex-col gap-2.5">
          {/* Top Row: Title, Case Switcher, Currency & Keys */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-sm tracking-tight text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse"></span>
                Sentinel AI Design Studio
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-[#1e2025] text-[#a1a1aa] border border-[#2c2e36]">
                10 High-Variance Dark Archetypes
              </span>
            </div>

            {/* Global Controls */}
            <div className="flex items-center gap-3">
              {/* Test Case Picker */}
              <div className="flex items-center gap-1.5 bg-[#14151a] p-1 rounded-lg border border-[#22242a]">
                <span className="text-[10px] uppercase font-bold text-[#71717a] px-1.5">Case:</span>
                {MOCK_CASES.map((c) => (
                  <button
                    key={c.transaction_id}
                    onClick={() => setSelectedCaseId(c.transaction_id)}
                    className={`px-2 py-0.5 rounded text-[11px] font-mono transition-all ${
                      selectedCaseId === c.transaction_id
                        ? "bg-[#252833] text-white font-bold border border-[#3b4052]"
                        : "text-[#71717a] hover:text-[#cbd5e1]"
                    }`}
                  >
                    {c.transaction_id.slice(0, 10)}
                  </button>
                ))}
              </div>

              {/* Currency Toggle */}
              <div className="flex items-center bg-[#14151a] p-0.5 rounded-lg border border-[#22242a]">
                <button
                  onClick={() => setCurrency("INR")}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-all ${
                    currency === "INR" ? "bg-[#252833] text-white" : "text-[#71717a] hover:text-[#a1a1aa]"
                  }`}
                >
                  ₹ INR
                </button>
                <button
                  onClick={() => setCurrency("USD")}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-all ${
                    currency === "USD" ? "bg-[#252833] text-white" : "text-[#71717a] hover:text-[#a1a1aa]"
                  }`}
                >
                  $ USD
                </button>
              </div>

              <div className="hidden xl:flex items-center gap-1 text-[11px] font-mono text-[#71717a]">
                <span>Keys:</span>
                <kbd className="px-1 py-0.5 rounded bg-[#1e2025] text-[#a1a1aa]">1-0</kbd>
                <kbd className="px-1 py-0.5 rounded bg-[#1e2025] text-[#a1a1aa]">← →</kbd>
              </div>
            </div>
          </div>

          {/* Bottom Row: 10 Distinct Archetype Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {ARCHETYPES.map((arch, idx) => {
              const isCurrent = arch.id === activeConceptId;
              return (
                <button
                  key={arch.id}
                  onClick={() => selectConcept(arch.id)}
                  className={`px-3 py-1.5 rounded-lg shrink-0 flex items-center gap-2 text-xs font-semibold transition-all ${
                    isCurrent
                      ? "bg-white text-black shadow-md"
                      : "bg-[#14151a] hover:bg-[#1c1d24] text-[#a1a1aa] hover:text-white border border-[#22242a]"
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded flex items-center justify-center font-mono text-[10px] font-bold ${
                      isCurrent ? "bg-black text-white" : "bg-[#22242a] text-[#71717a]"
                    }`}
                  >
                    {arch.key}
                  </span>
                  <span>{arch.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* ─── Archetype Thesis & Spec Ribbon ─────────────────────────────── */}
      <div className="border-b border-[#1f2026] bg-[#0f1014] px-6 py-3">
        <div className="max-w-[1700px] mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="space-y-0.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">{activeArchetype.name}</span>
              <span className="text-[#71717a]">·</span>
              <span className="text-[#a1a1aa]">{activeArchetype.subtitle}</span>
            </div>
            <p className="text-xs text-[#71717a] leading-relaxed">{activeArchetype.thesis}</p>
          </div>

          {/* Archetype Spec Chips */}
          <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono">
            {/* Palette Swatches */}
            <div className="flex items-center gap-1.5">
              <span className="text-[#71717a]">Palette:</span>
              <span className="w-3.5 h-3.5 rounded-full border border-white/20" style={{ background: activeArchetype.palette.bg }} title="Canvas"></span>
              <span className="w-3.5 h-3.5 rounded-full border border-white/20" style={{ background: activeArchetype.palette.surface }} title="Surface"></span>
              <span className="w-3.5 h-3.5 rounded-full border border-white/20" style={{ background: activeArchetype.palette.accent }} title="Accent"></span>
              <span className="w-3.5 h-3.5 rounded-full border border-white/20" style={{ background: activeArchetype.palette.accentAlt }} title="Accent Alt"></span>
            </div>

            <div className="hidden md:flex items-center gap-1 text-[#a1a1aa]">
              <span className="text-[#71717a]">Density:</span>
              <span>{activeArchetype.density}</span>
            </div>

            <div className="hidden lg:flex items-center gap-1 text-[#a1a1aa]">
              <span className="text-[#71717a]">Type Anchor:</span>
              <span>{activeArchetype.typography}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Active Archetype Full Viewport ──────────────────────────────── */}
      <main className="flex-1 flex flex-col min-h-[700px] relative">
        {activeConceptId === "terminal-monolith" && (
          <TerminalMonolith activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "linear-titanium" && (
          <LinearTitanium activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "palantir-gotham" && (
          <PalantirGotham activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "swiss-brutalist" && (
          <SwissBrutalist activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "stripe-radar" && (
          <StripeRadar activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "braun-console" && (
          <BraunConsole activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "monocle-dossier" && (
          <MonocleDossier activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "cyber-spectrogram" && (
          <CyberSpectrogram activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "cad-blueprint" && (
          <CadBlueprint activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}
        {activeConceptId === "sovereign-apex" && (
          <SovereignApex activeCase={activeCase} queue={QUEUE_STREAM} onSelectCase={setSelectedCaseId} onAction={handleAction} currency={currency} />
        )}

        {/* ─── Real-Time Attestation Toast Notification ───────────────────── */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 bg-[#16181f] border border-[#2e3240] text-white p-4 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in">
            <div className="w-8 h-8 rounded-full bg-[#10b981]/20 text-[#10b981] flex items-center justify-center font-bold text-sm">
              ✓
            </div>
            <div className="text-xs space-y-0.5">
              <div className="font-semibold text-white">Action Attested: {toastMessage.action}</div>
              <div className="text-[11px] font-mono text-[#94a3b8]">
                Case: {toastMessage.caseId} · Hash: {toastMessage.hash}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
