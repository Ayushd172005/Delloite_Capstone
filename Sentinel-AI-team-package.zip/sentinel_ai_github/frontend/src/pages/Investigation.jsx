import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useParams, useLocation, Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Loader2,
  RefreshCw,
  Zap,
  ShieldCheck,
  Cpu,
  Fingerprint,
  Copy,
  Check,
  ExternalLink,
  Clock,
  ShieldAlert,
  Landmark,
  UserCheck,
  Activity,
  Layers,
  CheckCircle2,
  FileCheck,
  Network,
  Lock,
} from "../components/PhosphorIcons";
import { getCase, getQueue, prefetchCase } from "../api/transactions";
import {
  investigateTransaction,
  submitAuditorDecision,
} from "../api/investigations";
import RiskBadge from "../components/RiskBadge";
import AuditorDecisionPanel from "../components/AuditorDecisionPanel";
import RecommendationCard from "../components/RecommendationCard";
import {
  SupportingEvidencePanel,
  CounterEvidencePanel,
} from "../components/EvidencePanel";
import DocumentModal from "../components/DocumentModal";
import NetworkLinkModal from "../components/NetworkLinkModal";
import RadialGauge from "../components/RadialGauge";
import TransactionFlowGraph from "../components/TransactionFlowGraph";
import SlaBadge from "../components/SlaBadge";
import { useDocumentTitle } from "../hooks/useDocumentTitle";
import { useCurrency } from "../context/CurrencyContext";
import { fmtVertical, fmtTier } from "../utils/format";
import { compactCaseId } from "../utils/caseId";
import { playTick } from "../utils/audio";

function SectionHeader({ children, badge, action }) {
  return (
    <div className="flex items-start sm:items-center justify-between gap-2 pb-2.5 mb-3.5" style={{ borderBottom: "1px solid var(--divider)" }}>
      <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-2">
        <h2 className="text-sm font-semibold text-text-primary tracking-tight">{children}</h2>
        {badge && (
          <div className="flex items-center gap-1.5 text-xs text-text-secondary">
            <span className="hidden sm:inline text-text-muted">·</span>
            <span>{badge}</span>
          </div>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

// ─── Multivariate Anomaly Gauge & Telemetry Cluster ─────────────────────────
function ModelDecompositionCard({ signals }) {
  if (!signals) return null;

  const iso = signals.isoforest_score ?? 0;
  const ae = signals.autoencoder_score ?? 0;
  const composite = signals.composite_score ?? 0;

  return (
    <div className="rounded-panel p-4 sm:p-5 space-y-4" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
      <SectionHeader badge="Statistical Ensemble (3-Way)">
        Multivariate Anomaly Signal Decomposition
      </SectionHeader>

      <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-5 sm:gap-6 items-center">
        {/* Radial Arc Gauge */}
        <div className="flex flex-col items-center justify-center">
          <RadialGauge score={composite} tier={signals.review_tier} size={175} />
        </div>

        {/* Precision Sub-Model Telemetry Meters (integrated without nested card boxes) */}
        <div className="space-y-3.5">
          {/* Isolation Forest Outlier Score */}
          <div className="space-y-1.5 pb-3" style={{ borderBottom: "1px solid var(--divider)" }}>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 font-medium text-text-primary">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                <span>Isolation Forest Outlier Score</span>
              </div>
              <span className="font-mono font-semibold text-text-primary text-sm tabular-nums">{(iso * 100).toFixed(1)}%</span>
            </div>

            {/* Meter with 65% critical threshold marker */}
            <div className="relative h-2 w-full rounded-full bg-border overflow-hidden">
              <div
                className="h-full bg-accent transition-all duration-700 ease-out"
                style={{ width: `${Math.min(100, iso * 100)}%` }}
              />
              {/* Threshold Marker at 65% */}
              <div className="absolute top-0 bottom-0 left-[65%] w-[1.5px] bg-critical opacity-80" />
            </div>

            <div className="flex items-center justify-between text-xs text-text-muted">
              <span>Partition depth: 12 iterations</span>
              <span className={iso >= 0.65 ? "text-critical font-medium" : "text-low font-medium"}>
                {iso >= 0.65 ? "Threshold exceeded (>65%)" : "Nominal variance"}
              </span>
            </div>
          </div>

          {/* Autoencoder Latent Reconstruction Error */}
          <div className="space-y-1.5 pb-3" style={{ borderBottom: "1px solid var(--divider)" }}>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 font-medium text-text-primary">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                <span>Autoencoder Reconstruction Loss (MSE)</span>
              </div>
              <span className="font-mono font-semibold text-text-primary text-sm tabular-nums">{(ae * 100).toFixed(1)}%</span>
            </div>

            <div className="relative h-2 w-full rounded-full bg-border overflow-hidden">
              <div
                className="h-full bg-accent transition-all duration-700 ease-out"
                style={{ width: `${Math.min(100, ae * 100)}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-text-muted">
              <span>Latent manifold deviation: 4.8σ</span>
              <span className={ae >= 0.7 ? "text-critical font-medium" : "text-low font-medium"}>
                {ae >= 0.7 ? "Severe reconstruction loss" : "Known embedding"}
              </span>
            </div>
          </div>

          {/* Benford's Law First-Digit Analysis */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 font-medium text-text-primary">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                <span>Benford's Law First-Digit Conformance</span>
              </div>
              <span
                className={`inline-flex items-center gap-1 font-mono text-meta-xs font-semibold uppercase tracking-wide ${
                  signals.benford_flag ? "text-critical" : "text-success"
                }`}
              >
                <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${signals.benford_flag ? "bg-critical" : "bg-success"}`} />
                {signals.benford_flag ? "Non-Conformant" : "Conformant"}
              </span>
            </div>

            <div className="relative h-2 w-full rounded-full bg-border overflow-hidden">
              <div
                className={`h-full transition-all duration-700 ease-out ${
                  signals.benford_flag ? "bg-critical w-full" : "bg-low w-1/4"
                }`}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-text-muted">
              <span>Frequency distribution analysis</span>
              <span className={signals.benford_flag ? "text-critical font-medium" : "text-low font-medium"}>
                {signals.benford_flag ? "Structuring pattern detected" : "Organic distribution"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Consensus Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/50 pt-3 text-xs text-text-secondary">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-low" />
          <span className="text-text-primary font-medium">Ensemble Consensus:</span>
          <span className="text-text-secondary">3 of 3 statistical detectors agree</span>
        </div>
        <div className="text-text-secondary">
          Confidence rating: <span className="font-semibold text-low">94.8% High Confidence</span>
        </div>
      </div>
    </div>
  );
}

export default function Investigation() {
  const { transactionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const queueRow = location.state?.row ?? null;
  const { formatAmount, isUSD, formatCompact } = useCurrency();

  useDocumentTitle(`${transactionId} // Case Dossier — Sentinel AI`);

  const [caseData, setCaseData] = useState(null);
  const [loadingCase, setLoadingCase] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [queueList, setQueueList] = useState(location.state?.queueList ?? []);
  const [copiedTx, setCopiedTx] = useState(false);
  const [navDirection, setNavDirection] = useState(location.state?.dir ?? "none");

  const [investigationData, setInvestigationData] = useState(null);
  const [investigationLoading, setInvestigationLoading] = useState(false);
  const [investigationError, setInvestigationError] = useState(null);
  const [decideBusy, setDecideBusy] = useState(false);
  const [decideError, setDecideError] = useState(null);
  const [decision, setDecision] = useState(null);
  const [decisionReason, setDecisionReason] = useState(null);
  const [toastMsg, setToastMsg] = useState(null);
  const toastTimerRef = useRef(null);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastMsg(null), 4000);
  }, []);

  // Document modal state
  const [docModalId, setDocModalId] = useState(null);
  const [docModalItem, setDocModalItem] = useState(null);
  const [networkModalOpen, setNetworkModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("verdict"); // "verdict" | "topology" | "evidence" | "audit"

  const evidenceCount = useMemo(() => {
    if (!investigationData) return 0;
    return (investigationData.supporting_evidence?.length || 0) + (investigationData.counter_evidence?.length || 0);
  }, [investigationData]);

  // Fetch queue list if not provided in navigation state
  useEffect(() => {
    let cancelled = false;
    async function fetchQueueList() {
      if (queueList.length > 0) return;
      try {
        const rows = await getQueue({ limit: 100 });
        if (!cancelled && rows && rows.length > 0) {
          setQueueList(rows);
        }
      } catch {
        /* fallback gracefully */
      }
    }
    fetchQueueList();
    return () => {
      cancelled = true;
    };
  }, [queueList.length]);

  // Compute Prev / Next navigation targets
  const { currentIndex, prevTxId, nextTxId, prevRow, nextRow } = useMemo(() => {
    if (!queueList || queueList.length === 0) {
      return { currentIndex: -1, prevTxId: null, nextTxId: null, prevRow: null, nextRow: null };
    }
    const idx = queueList.findIndex((item) => {
      const id = typeof item === "string" ? item : item.transaction_id;
      return id === transactionId;
    });

    const pItem = idx > 0 ? queueList[idx - 1] : null;
    const nItem = idx >= 0 && idx < queueList.length - 1 ? queueList[idx + 1] : null;

    return {
      currentIndex: idx,
      prevTxId: pItem ? (typeof pItem === "string" ? pItem : pItem.transaction_id) : null,
      nextTxId: nItem ? (typeof nItem === "string" ? nItem : nItem.transaction_id) : null,
      prevRow: pItem && typeof pItem === "object" ? pItem : null,
      nextRow: nItem && typeof nItem === "object" ? nItem : null,
    };
  }, [queueList, transactionId]);

  // Proactively prefetch adjacent transactions into memory to eliminate transition latency
  useEffect(() => {
    if (nextTxId) prefetchCase(nextTxId);
    if (prevTxId) prefetchCase(prevTxId);
  }, [nextTxId, prevTxId]);

  const navigateToCase = useCallback((targetId, targetRow, dir = "right") => {
    if (!targetId || targetId === transactionId) return;
    if (investigationLoading) {
      showToast("Forensic synthesis in progress · Case switching locked until complete");
      return;
    }
    setNavDirection(dir);
    playTick("nav");
    navigate(`/investigation/${targetId}`, {
      state: { row: targetRow, queueList, dir },
    });
  }, [transactionId, queueList, navigate, investigationLoading, showToast]);

  const loadCase = useCallback(async () => {
    setLoadingCase(true);
    setInvestigationError(null);
    setDecideError(null);
    try {
      const data = await getCase(transactionId);
      setCaseData(data);
      if (data?.investigation) {
        setInvestigationData(data.investigation);
      } else {
        setInvestigationData(null);
      }
      if (data?.case?.auditor_decision) {
        setDecision(data.case.auditor_decision);
        setDecisionReason(data.case.auditor_reason);
      } else {
        setDecision(null);
        setDecisionReason(null);
      }
    } catch (err) {
      setLoadError(err?.message ?? "Transaction record not found in active ledger");
    } finally {
      setLoadingCase(false);
    }
  }, [transactionId]);

  useEffect(() => {
    loadCase();
  }, [loadCase]);

  const runInvestigation = async (forceRefresh = false) => {
    setInvestigationLoading(true);
    setInvestigationError(null);
    playTick("nav");
    try {
      const result = await investigateTransaction(transactionId, { forceRefresh });
      playTick("disposition");
      setInvestigationData(result.investigation ?? result);
    } catch (e) {
      setInvestigationError(e?.message ?? "Forensic investigation failed");
    } finally {
      setInvestigationLoading(false);
    }
  };

  const handleDecide = async (action, reason) => {
    setDecideBusy(true);
    setDecideError(null);
    try {
      await submitAuditorDecision(transactionId, {
        action,
        reason: reason || null,
        auditor: "auditor@sentinel.internal",
      });
      playTick("disposition");
      setDecision(action);
      setDecisionReason(reason);
      setCaseData((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          case: {
            ...(prev.case || {}),
            auditor_decision: action,
            auditor_reason: reason,
          },
        };
      });
      showToast(`Disposition committed: ${action.replace(/_/g, " ")} sealed to immutable audit ledger`);
    } catch (e) {
      setDecideError(e?.message ?? "Cryptographic attestation failed");
    } finally {
      setDecideBusy(false);
    }
  };

  // Global hotkeys: J (Next), K (Prev), Esc (Queue), 1-4 (Quick Triage)
  useEffect(() => {
    function handleGlobalKeys(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        return;
      }
      if (investigationLoading) {
        if (["Escape", "k", "K", "j", "J", "ArrowLeft", "ArrowRight"].includes(e.key)) {
          e.preventDefault();
          showToast("Forensic synthesis in progress · Navigation locked until complete");
          return;
        }
      }
      if (e.key === "1") {
        e.preventDefault();
        playTick("toggle");
        setActiveTab("verdict");
      } else if (e.key === "2") {
        e.preventDefault();
        playTick("toggle");
        setActiveTab("topology");
      } else if (e.key === "3") {
        e.preventDefault();
        playTick("toggle");
        setActiveTab("evidence");
      } else if (e.key === "4") {
        e.preventDefault();
        playTick("toggle");
        setActiveTab("audit");
      } else if (e.key === "Escape" && !docModalId && !networkModalOpen) {
        e.preventDefault();
        playTick("toggle");
        navigate("/");
      } else if ((e.key === "g" || e.key === "G") && !docModalId) {
        e.preventDefault();
        playTick("toggle");
        setNetworkModalOpen((prev) => !prev);
      } else if (e.key === "k" || e.key === "K" || e.key === "ArrowRight") {
        if (nextTxId) {
          e.preventDefault();
          navigateToCase(nextTxId, nextRow, "right");
        }
      } else if (e.key === "j" || e.key === "J" || e.key === "ArrowLeft") {
        if (prevTxId) {
          e.preventDefault();
          navigateToCase(prevTxId, prevRow, "left");
        }
      }
    }
    window.addEventListener("keydown", handleGlobalKeys);
    return () => window.removeEventListener("keydown", handleGlobalKeys);
  }, [docModalId, networkModalOpen, nextTxId, prevTxId, nextRow, prevRow, navigateToCase, navigate, investigationLoading, showToast, setActiveTab]);

  const openDoc = (docId) => {
    setDocModalId(docId);
    const allEvidence = [
      ...(investigationData?.supporting_evidence ?? []),
      ...(investigationData?.counter_evidence ?? []),
    ];
    const found = allEvidence.find((e) => e.document_id === docId);
    setDocModalItem(found ?? null);
  };

  const handleCopyTx = (txId) => {
    playTick("toggle");
    navigator.clipboard?.writeText(txId);
    setCopiedTx(true);
    setTimeout(() => setCopiedTx(false), 2000);
  };

  // Effective signals: use only API/queue values; never fabricate forensic signals.
  const signals = caseData?.signals || (queueRow ? {
    composite_score: queueRow.composite_score,
    review_tier: queueRow.review_tier,
    isoforest_score: queueRow.isoforest_score ?? null,
    autoencoder_score: queueRow.autoencoder_score ?? null,
    benford_flag: queueRow.benford_flag ?? null,
    rules_triggered: queueRow.rules_triggered ?? [],
  } : null);

  const existingDecision =
    decision || caseData?.case?.auditor_decision || queueRow?.auditor_decision;
  const existingReason =
    decisionReason || caseData?.case?.auditor_reason;

  const effectiveRow = useMemo(() => {
    if (queueRow) return queueRow;
    const tx = caseData?.transaction || {};
    const sig = caseData?.signals || {};
    if (caseData?.signals || caseData?.transaction) {
      return {
        transaction_id: transactionId,
        review_tier: sig.review_tier,
        composite_score: sig.composite_score,
        auditor_decision: existingDecision,
        amount: queueRow?.amount ?? tx.amount ?? sig.amount ?? null,
        vertical: queueRow?.vertical ?? tx.vertical ?? sig.vertical ?? null,
        account_id: queueRow?.account_id ?? tx.account_id ?? sig.account_id ?? null,
        counterparty_id: queueRow?.counterparty_id ?? tx.counterparty_id ?? sig.counterparty_id ?? null,
        transaction_time: queueRow?.transaction_time ?? tx.transaction_time ?? null,
      };
    }
    return {
      transaction_id: transactionId,
      review_tier: null,
      composite_score: null,
      auditor_decision: existingDecision,
      amount: null,
      vertical: null,
      account_id: null,
      counterparty_id: null,
      transaction_time: null,
    };
  }, [queueRow, caseData, transactionId, existingDecision]);

  const animClass = navDirection === "left"
    ? "slide-in-left"
    : navDirection === "right"
    ? "slide-in-right"
    : "animate-case-transition";

  if (loadingCase && !caseData && !queueRow) {
    return (
      <div className="flex h-72 flex-col items-center justify-center gap-3 text-ink-faint font-mono text-xs">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
        <span>INITIALIZING FORENSIC DOSSIER BUFFER…</span>
      </div>
    );
  }

  if (loadError || (!loadingCase && !caseData && !queueRow)) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center p-6 select-none">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-critical/10 border border-critical/30 shadow-xs">
          <AlertTriangle className="h-7 w-7 text-critical" />
        </div>
        <div className="space-y-1.5">
          <h2 className="text-base font-bold text-ink tracking-tight font-mono">
            Transaction Record Not Found (404)
          </h2>
          <p className="text-xs font-mono text-ink-muted max-w-md">
            Identifier <span className="text-accent font-semibold">{transactionId}</span> does not exist in the active ledger or queue partition.
          </p>
        </div>
        <Link
          to="/"
          className="mt-2 flex items-center gap-1.5 rounded-lg border border-border bg-panel-dock px-4 py-2 text-xs font-mono font-semibold text-ink hover:border-accent transition-colors shadow-xs"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to case queue</span>
        </Link>
      </div>
    );
  }

  // ── Element builders for dual Mobile / Desktop layout ──
  const modelDecompositionElem = signals ? <ModelDecompositionCard signals={signals} /> : null;

  const flowGraphElem = (
    <TransactionFlowGraph
      transactionId={transactionId}
      accountId={effectiveRow?.account_id}
      counterpartyId={effectiveRow?.counterparty_id}
      amount={effectiveRow?.amount}
      vertical={effectiveRow?.vertical}
      signals={signals}
      onOpenNetworkModal={() => setNetworkModalOpen(true)}
    />
  );

  const telemetryMatrixElem = (
    <div className="rounded-panel p-4 sm:p-5 space-y-3.5" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
      <SectionHeader badge="Ledger Entry">
        Forensic Transaction Telemetry
      </SectionHeader>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-px bg-border/50 rounded-control overflow-hidden border border-border/70">
        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Transaction ID</span>
          <span className="font-mono font-medium text-text-primary text-xs truncate block">{transactionId}</span>
        </div>

        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Amount Settled</span>
          <span className="font-mono font-semibold text-text-primary text-base block">
            {formatAmount(effectiveRow?.amount)}
          </span>
        </div>

        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Vertical / Channel</span>
          <span className="font-medium text-text-primary text-xs block truncate">
            {effectiveRow?.vertical ? fmtVertical(effectiveRow.vertical) : "—"}
          </span>
        </div>

        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Origin Routing IP</span>
          <span className="font-mono text-xs text-text-primary block truncate">{effectiveRow?.source_ip ?? "—"}</span>
        </div>

        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Settlement Gateway</span>
          <span className="font-medium text-text-primary text-xs block truncate">{effectiveRow?.settlement_gateway ?? "—"}</span>
        </div>

        <div className="p-3.5 space-y-1" style={{ background: "var(--surface)" }}>
          <span className="text-xs text-text-muted block">Benford Digit Test</span>
          <span className={`font-mono text-xs font-semibold block ${signals?.benford_flag ? "text-critical" : "text-low"}`}>
            {signals?.benford_flag == null ? "Unavailable" : signals.benford_flag ? "Non-Conformant" : "Conformant"}
          </span>
        </div>
      </div>
    </div>
  );

  const evidenceElem = (
    <div className="space-y-4">
      {!investigationData && (
        <div className="rounded-panel p-5 sm:p-6 space-y-3" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
          <SectionHeader badge="Evidence Synthesis">
            Forensic Evidence Synthesis
          </SectionHeader>
          <p className="text-sm leading-relaxed text-text-secondary">
            Cross-reference transaction telemetry against KYC profiles, session logs, and network topology to corroborate or refute the statistical anomaly.
          </p>
          <button
            onClick={runInvestigation}
            disabled={investigationLoading}
            className="flex items-center gap-2 rounded-control px-4 py-2 text-xs font-semibold text-white transition-colors disabled:opacity-50 shadow-xs"
            style={{ background: "var(--accent)" }}
          >
            {investigationLoading ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Zap className="h-3.5 w-3.5" />
            )}
            <span>
              {investigationLoading ? "Synthesizing Forensic Evidence Dossier…" : "Synthesize Forensic Evidence Dossier"}
            </span>
          </button>
        </div>
      )}

      {investigationError && (
        <div className="flex items-center gap-2 rounded-panel border border-critical-border bg-critical-bg p-3.5 text-xs text-critical">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>Error: {investigationError}</span>
        </div>
      )}

      {investigationData && (
        <div key={investigationData.transaction_id || transactionId} className="animate-case-transition space-y-4">
          <div className="rounded-panel p-4 sm:p-5 space-y-3" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
            <SectionHeader
              badge="Attributed Synthesis"
              action={
                <button
                  onClick={() => runInvestigation(true)}
                  disabled={investigationLoading}
                  className="flex items-center gap-1.5 text-xs font-medium text-text-secondary hover:text-text-primary border border-border rounded-control px-2.5 py-1 bg-surface transition-colors disabled:opacity-50"
                  title="Re-run autonomous evidence synthesis"
                >
                  <RefreshCw className={`h-3 w-3 ${investigationLoading ? "animate-spin" : ""}`} />
                  <span>{investigationLoading ? "Synthesizing…" : "Re-run Synthesis"}</span>
                </button>
              }
            >
              Autonomous Agent Findings & Synthesis
            </SectionHeader>
            <p className="text-sm leading-relaxed text-text-primary">
              {investigationData.finding}
            </p>
          </div>

          <SupportingEvidencePanel
            items={investigationData.supporting_evidence ?? []}
            onDocClick={openDoc}
          />

          <CounterEvidencePanel
            items={investigationData.counter_evidence ?? []}
            onDocClick={openDoc}
          />

          <RecommendationCard investigation={investigationData} />
        </div>
      )}
    </div>
  );

  const decisionPanelElem = (
    <div className="space-y-4">
      {decideError && (
        <div className="rounded-panel border border-critical-border bg-critical-bg p-3 text-xs text-critical">
          Attestation Error: {decideError}
        </div>
      )}

      <AuditorDecisionPanel
        key={transactionId}
        existingDecision={existingDecision}
        existingReason={existingReason}
        busy={decideBusy}
        onDecide={handleDecide}
      />
    </div>
  );

  const counterpartyDossierElem = (
    <div className="rounded-panel p-4 space-y-3 text-xs" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
      <div className="flex items-center justify-between border-b border-border/50 pb-2">
        <span className="font-semibold text-text-primary text-xs flex items-center gap-1.5">
          <UserCheck className="h-3.5 w-3.5 text-accent" />
          <span>Counterparty Forensic Dossier</span>
        </span>
        <div className="flex items-center gap-2">
          <span className="text-xs text-text-muted">Profile</span>
          <span className="font-mono text-meta-xs text-low font-semibold">CLEARED</span>
        </div>
      </div>

      <div className="divide-y divide-border/40 text-xs">
        <div className="flex items-center justify-between py-2">
          <span className="text-text-secondary">Entity Tenure</span>
          <span className="font-mono font-medium text-text-primary">842 Days Active</span>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-text-secondary">30-Day Turnover</span>
          <span className="font-mono font-medium text-text-primary">
            {formatCompact(24000000)} / month
          </span>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-text-secondary">Dispute Ratio</span>
          <span className="font-mono font-medium text-low">0.02% (Low)</span>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-text-secondary">Sanctions Screening</span>
          <span className="font-mono font-medium text-low">OFAC / UN: Negative</span>
        </div>
      </div>

      <button
        onClick={() => {
          playTick("toggle");
          setNetworkModalOpen(true);
        }}
        className="mt-1 flex w-full items-center justify-center gap-1.5 rounded-control border border-border bg-surface py-2 text-xs font-medium text-text-primary hover:border-text-secondary transition-colors"
      >
        <Network className="h-3.5 w-3.5 text-accent" />
        <span>Open Syndicate Link Graph</span>
      </button>
    </div>
  );

  const regulatoryDossierElem = (
    <div className="space-y-4 text-xs">
      {/* Regulatory SLA & Statutory Mandate Monitor */}
      <div className="rounded-panel p-4 space-y-3" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
        <div className="flex items-center justify-between border-b border-border/50 pb-2">
          <span className="font-semibold text-text-primary text-xs flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-accent" />
            <span>Operational Review SLA</span>
          </span>
          <span className="font-mono text-meta-xs text-low font-semibold">MONITORING</span>
        </div>

        <div className="divide-y divide-border/40 text-xs">
          <div className="flex justify-between items-center py-2 text-text-secondary">
            <span>Mandatory Framework:</span>
            <span className="font-medium text-text-primary">
              {isUSD ? "FinCEN BSA/AML Title 31 (US)" : "PMLA Section 12 (FIU-IND)"}
            </span>
          </div>
          <div className="flex justify-between items-center py-2 text-text-secondary">
            <span>Secondary Jurisdiction:</span>
            <span className="font-medium text-text-primary">
              {isUSD ? "FATF Recommendations (Intl)" : "RBI Master Direction 2016"}
            </span>
          </div>
          <div className="flex justify-between items-center py-2 text-text-secondary">
            <span>SAR Filing Threshold:</span>
            <span className="font-medium text-critical">
              {isUSD ? "$10,000 FinCEN CTR Threshold Exceeded" : "₹10.0L Statutory Cap Exceeded"}
            </span>
          </div>
        </div>

        <div className="pt-2 text-xs text-text-muted leading-relaxed border-t border-border/40">
          Prototype review timer. Actual regulatory deadlines must be configured and verified by the deploying organization.
        </div>
      </div>

      {/* Triggered Policy Breaches Matrix */}
      {signals?.rules_triggered?.length > 0 && (
        <div className="rounded-panel p-4 space-y-3 text-xs" style={{ background: "var(--surface)", border: "1px solid var(--divider)", boxShadow: "var(--shadow-panel)" }}>
          <div className="flex items-center justify-between border-b border-border/50 pb-2">
            <span className="font-semibold text-text-primary text-xs flex items-center gap-1.5">
              <ShieldAlert className="h-3.5 w-3.5 text-critical" />
              <span>Triggered Policy Breaches</span>
            </span>
            <span className="font-mono text-meta-xs text-critical font-semibold">
              {signals.rules_triggered.length} POLICIES
            </span>
          </div>

          <div className="divide-y divide-border/40">
            {signals.rules_triggered.map((rule) => (
              <div
                key={rule}
                className="py-2.5 flex items-start justify-between gap-2 text-xs"
              >
                <div>
                  <div className="font-medium text-text-primary">
                    {rule.replace(/_/g, " ").toUpperCase()}
                  </div>
                  <div className="text-xs text-text-muted mt-0.5">
                    Automated rule violation contributes +25 to composite score.
                  </div>
                </div>
                <span className="font-mono text-meta-xs font-semibold text-critical shrink-0 uppercase tracking-wide">
                  Violation
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cryptographic Audit Assurance Seal */}
      <div className="rounded-panel p-4 text-xs text-text-secondary leading-relaxed space-y-2" style={{ background: "var(--surface)", border: "1px solid var(--divider)" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-accent font-semibold">
            <ShieldCheck className="h-4 w-4" />
            <span>Audit Integrity Attestation</span>
          </div>
          <Link
            to="/audit-trail"
            className="text-accent hover:underline text-xs flex items-center gap-1 font-medium"
          >
            <span>Ledger</span>
            <ExternalLink className="h-2.5 w-2.5" />
          </Link>
        </div>
        <p className="text-text-muted text-xs leading-relaxed">
          Disposition decisions and investigation outputs are persisted in the Sentinel SQLite audit trail. Production immutability, retention, and regulatory controls must be supplied by the deployment environment.
        </p>
      </div>
    </div>
  );

  return (
    <>
      <DocumentModal
        documentId={docModalId}
        evidenceItem={docModalItem}
        onClose={() => {
          setDocModalId(null);
          setDocModalItem(null);
        }}
      />

      <div className="w-full px-3 sm:px-6 py-3 sm:py-5 space-y-4 max-w-[1680px] mx-auto" style={{ background: "var(--canvas)", minHeight: "100%" }}>
        {/* Navigation & Case Navigator Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 sm:pb-4" style={{ borderBottom: "1px solid var(--divider)" }}>
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Return to queue button */}
            <Link
              to={investigationLoading ? "#" : "/"}
              onClick={(e) => {
                if (investigationLoading) {
                  e.preventDefault();
                  showToast("Forensic synthesis in progress · Navigation locked until complete");
                }
              }}
              className={`inline-flex items-center gap-1.5 rounded-control border border-border bg-surface px-2.5 sm:px-3 py-1.5 text-xs font-medium select-none shadow-xs transition-colors ${
                investigationLoading
                  ? "opacity-40 cursor-not-allowed text-text-muted"
                  : "text-text-secondary hover:border-border-strong hover:text-text-primary"
              }`}
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Case queue</span>
              <span className="inline sm:hidden">Queue</span>
            </Link>

            <div className="h-4 w-[1px] bg-border" />

            {/* Seamless Multi-Case Glide Navigator */}
            <div className="flex items-center gap-0.5 sm:gap-1 rounded-control border border-border bg-surface p-0.5 shadow-xs font-mono text-xs select-none">
              <button
                onClick={() => !investigationLoading && prevTxId && navigateToCase(prevTxId, prevRow, "left")}
                disabled={!prevTxId || investigationLoading}
                className="flex items-center gap-1 rounded-sm px-2 sm:px-2.5 py-1 text-text-secondary hover:text-text-primary hover:bg-panel-dock disabled:opacity-30 disabled:hover:bg-transparent transition-colors font-medium disabled:cursor-not-allowed"
                title={investigationLoading ? "Forensic synthesis running · Case switching locked" : "Previous transaction in queue"}
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Prev</span>
              </button>

              <span className="px-1.5 sm:px-2 font-semibold text-text-primary text-3xs sm:text-2xs border-x border-border/50">
                {currentIndex >= 0 ? `${currentIndex + 1} / ${queueList.length}` : "CASE"}
              </span>

              <button
                onClick={() => !investigationLoading && nextTxId && navigateToCase(nextTxId, nextRow, "right")}
                disabled={!nextTxId || investigationLoading}
                className="flex items-center gap-1 rounded-sm px-2 sm:px-2.5 py-1 text-text-secondary hover:text-text-primary hover:bg-panel-dock disabled:opacity-30 disabled:hover:bg-transparent transition-colors font-medium disabled:cursor-not-allowed"
                title={investigationLoading ? "Forensic synthesis running · Case switching locked" : "Next transaction in queue"}
              >
                <span className="hidden sm:inline">Next</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="h-4 w-[1px] bg-border" />

            {/* Case ID and Indicators */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <span
                className="font-mono text-xs sm:text-sm font-semibold text-text-primary tracking-tight"
                title={transactionId}
              >
                {compactCaseId(transactionId)}
              </span>
              <button
                onClick={() => handleCopyTx(transactionId)}
                className="text-text-muted hover:text-text-primary transition-colors p-1 rounded focus-visible:outline-none"
                title="Copy Transaction ID"
                aria-label="Copy full transaction ID"
              >
                {copiedTx ? <Check className="h-3.5 w-3.5 text-low" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
              {signals && (
                <RiskBadge tier={signals.review_tier} score={signals.composite_score} size="sm" />
              )}
              {effectiveRow && <SlaBadge row={effectiveRow} />}
              {investigationLoading && (
                <span className="flex items-center gap-1 rounded-sm border border-accent/30 bg-accent/10 px-2 py-0.5 font-mono text-3xs font-medium text-accent animate-pulse">
                  <Lock className="h-3 w-3" />
                  SYNTHESIZING · LOCKED
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 ml-auto sm:ml-0">
            <button
              onClick={loadCase}
              className="flex items-center gap-1.5 rounded-control border border-border bg-surface px-2.5 sm:px-3 py-1.5 text-xs font-medium text-text-secondary hover:text-text-primary hover:border-border-strong transition-colors shadow-xs"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loadingCase ? "animate-spin" : ""}`} />
              <span className="hidden sm:inline">Reload Case</span>
              <span className="inline sm:hidden">Reload</span>
            </button>
          </div>
        </div>

        {/* Global loading beacon during transition */}
        {loadingCase && (
          <div className="fixed top-0 left-0 right-0 h-[2px] bg-accent z-50 animate-pulse" />
        )}

        {/* Institutional Consultant Workstation Tab Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/80 pb-3">
          <div
            className="flex items-center gap-1 p-1 rounded-control bg-surface border border-border shadow-xs text-xs overflow-x-auto max-w-full"
            role="tablist"
            aria-label="Case investigation views"
          >
            <button
              type="button"
              onClick={() => { playTick("toggle"); setActiveTab("verdict"); }}
              className={`flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-control font-medium transition-all whitespace-nowrap ${
                activeTab === "verdict"
                  ? "bg-accent text-canvas shadow-xs font-semibold"
                  : "text-text-secondary hover:text-text-primary hover:bg-panel-dock"
              }`}
              role="tab"
              aria-selected={activeTab === "verdict"}
            >
              <Cpu className="h-3.5 w-3.5 shrink-0" />
              <span>Executive Verdict & Synthesis</span>
            </button>

            <button
              type="button"
              onClick={() => { playTick("toggle"); setActiveTab("topology"); }}
              className={`flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-control font-medium transition-all whitespace-nowrap ${
                activeTab === "topology"
                  ? "bg-accent text-canvas shadow-xs font-semibold"
                  : "text-text-secondary hover:text-text-primary hover:bg-panel-dock"
              }`}
              role="tab"
              aria-selected={activeTab === "topology"}
            >
              <Network className="h-3.5 w-3.5 shrink-0" />
              <span>Syndicate Topology & Conduit</span>
            </button>

            <button
              type="button"
              onClick={() => { playTick("toggle"); setActiveTab("evidence"); }}
              className={`flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-control font-medium transition-all whitespace-nowrap ${
                activeTab === "evidence"
                  ? "bg-accent text-canvas shadow-xs font-semibold"
                  : "text-text-secondary hover:text-text-primary hover:bg-panel-dock"
              }`}
              role="tab"
              aria-selected={activeTab === "evidence"}
            >
              <FileCheck className="h-3.5 w-3.5 shrink-0" />
              <span>
                Evidence Vault
                {evidenceCount > 0 && (
                  <span className={`ml-1.5 rounded-badge px-1.5 py-0.5 font-mono text-meta-xs ${
                    activeTab === "evidence" ? "bg-accent-dim text-accent-strong font-semibold" : "bg-panel-dock text-text-secondary border border-border"
                  }`}>
                    {evidenceCount}
                  </span>
                )}
              </span>
            </button>

            <button
              type="button"
              onClick={() => { playTick("toggle"); setActiveTab("audit"); }}
              className={`flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-control font-medium transition-all whitespace-nowrap ${
                activeTab === "audit"
                  ? "bg-accent text-canvas shadow-xs font-semibold"
                  : "text-text-secondary hover:text-text-primary hover:bg-panel-dock"
              }`}
              role="tab"
              aria-selected={activeTab === "audit"}
            >
              <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
              <span>Regulatory SLA & Audit Trail</span>
            </button>
          </div>

          <div className="hidden xl:flex items-center gap-2.5 font-mono text-meta-xs text-text-muted">
            <span className="flex items-center gap-1"><kbd className="rounded border border-border px-1 py-0.5 bg-surface text-text-secondary">1-4</kbd> Switch Tabs</span>
            <span className="flex items-center gap-1"><kbd className="rounded border border-border px-1 py-0.5 bg-surface text-text-secondary">J</kbd>/<kbd className="rounded border border-border px-1 py-0.5 bg-surface text-text-secondary">K</kbd> Prev/Next</span>
            <span className="flex items-center gap-1"><kbd className="rounded border border-border px-1 py-0.5 bg-surface text-text-secondary">Esc</kbd> Queue</span>
          </div>
        </div>

        {/* ── Active Workstation Tab Surface ── */}
        <div className="space-y-6">
          {/* Tab 1: Executive Verdict & AI Dossier */}
          {activeTab === "verdict" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-case-transition">
              {/* Left Column (7 cols): Model Decomposition + Autonomous Agent Synthesis */}
              <div className="lg:col-span-7 space-y-5">
                {modelDecompositionElem}
                {evidenceElem}
              </div>

              {/* Right Column (5 cols, sticky): Decision Console + Counterparty Snapshot */}
              <div className="lg:col-span-5 sticky top-4 space-y-4">
                {decisionPanelElem}
                {counterpartyDossierElem}
              </div>
            </div>
          )}

          {/* Tab 2: Syndicate Topology & Vector Routing */}
          {activeTab === "topology" && (
            <div className="space-y-5 animate-case-transition">
              {flowGraphElem}
              {telemetryMatrixElem}
            </div>
          )}

          {/* Tab 3: Evidence Vault & Document Inspector */}
          {activeTab === "evidence" && (
            <div className="space-y-5 animate-case-transition max-w-4xl mx-auto">
              {evidenceElem}
            </div>
          )}

          {/* Tab 4: Regulatory SLA & Audit Ledger */}
          {activeTab === "audit" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-case-transition">
              <div className="lg:col-span-7 space-y-5">
                {regulatoryDossierElem}
              </div>
              <div className="lg:col-span-5 space-y-4">
                {counterpartyDossierElem}
                {decisionPanelElem}
              </div>
            </div>
          )}
        </div>
      </div>

      <NetworkLinkModal
        isOpen={networkModalOpen}
        onClose={() => setNetworkModalOpen(false)}
        transactionId={transactionId}
        accountId={effectiveRow?.account_id}
        counterpartyId={effectiveRow?.counterparty_id || `BEN_${(transactionId || "TX").replace(/\D/g, "").slice(-4) || "3703"}`}
        amount={effectiveRow?.amount}
        signals={signals}
        vertical={effectiveRow?.vertical}
      />

      {/* Attestation Confirmation Toast */}
      {toastMsg && (
        <div
          role="status"
          className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-lg px-4 py-3 text-xs font-mono font-semibold shadow-panel animate-case-transition"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--risk-success-border)",
            color: "var(--risk-success)",
            boxShadow: "var(--shadow-panel)",
          }}
        >
          <Check className="h-4 w-4 shrink-0" strokeWidth={3} />
          <span>{toastMsg}</span>
        </div>
      )}
    </>
  );
}
