import { useState, useEffect, useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  ShieldCheck,
  Search,
  X,
  Download,
  Database,
  CheckCircle2,
  FileCheck,
  Copy,
  Check,
  ExternalLink,
  Cpu,
  Lock,
  RefreshCw,
  Server,
  Layers,
  ArrowRight,
} from "../components/PhosphorIcons";
import { getGlobalAuditFeed } from "../api/audit";
import AuditTimeline from "../components/AuditTimeline";
import CryptographicSeal from "../components/CryptographicSeal";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { SkeletonLine } from "../components/Skeleton";
import { useDocumentTitle } from "../hooks/useDocumentTitle";
import { playTick } from "../utils/audio";

const ACTION_FILTERS = [
  { value: null, label: "All Events" },
  { value: "decision", label: "Decisions" },
  { value: "model_scored", label: "Alerts" },
  { value: "investigated", label: "Investigations" },
  { value: "override", label: "Overrides" },
];

function TabButton({ active, onClick, children, count }) {
  const handleClick = (e) => {
    playTick("toggle");
    onClick(e);
  };

  return (
    <button
      onClick={handleClick}
      aria-selected={active}
      role="tab"
      className={[
        "flex items-center gap-2 px-4 py-2.5 font-mono text-xs font-semibold transition-all border-b-2 select-none",
        active
          ? "border-accent text-accent bg-panel-raised shadow-xs"
          : "border-transparent text-ink-muted hover:text-ink hover:border-border-strong",
      ].join(" ")}
    >
      <span>{children}</span>
      {count != null && (
        <span
          className={`rounded-full px-2 py-0.5 font-mono text-2xs tabular-nums font-bold ${
            active
              ? "bg-accent-dim text-accent"
              : "bg-panel-dock text-ink-muted"
          }`}
        >
          {count}
        </span>
      )}
    </button>
  );
}

export default function AuditTrail() {
  useDocumentTitle("Audit Ledger — Sentinel AI");

  const [events, setEvents] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionFilter, setActionFilter] = useState(null);
  const [txSearch, setTxSearch] = useState("");
  const [selectedBlock, setSelectedBlock] = useState(null);
  const [copiedKey, setCopiedKey] = useState(null);
  const [integrityVerifying, setIntegrityVerifying] = useState(false);
  const [integrityVerified, setIntegrityVerified] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getGlobalAuditFeed({ limit: 100 });
      setEvents(data);
      setSelectedBlock((prev) => {
        if (!prev && data && data.length > 0) return data[0];
        if (prev && data) {
          const matched = data.find((e) => (e.event_id ?? e.id) === (prev.event_id ?? prev.id));
          return matched || data[0] || null;
        }
        return prev;
      });
      setError(null);
    } catch (e) {
      setError(e?.message ?? "Failed to fetch audit feed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const counts = useMemo(() => {
    if (!events) return {};
    const c = { all: events.length };
    for (const f of ACTION_FILTERS) {
      if (f.value) {
        c[f.value] = events.filter((e) => e.event_type === f.value).length;
      }
    }
    return c;
  }, [events]);

  const filtered = useMemo(() => {
    if (!events) return [];
    let list = events;
    if (actionFilter) {
      list = list.filter((e) => e.event_type === actionFilter);
    }
    if (txSearch.trim()) {
      const q = txSearch.trim().toLowerCase();
      list = list.filter((e) =>
        e.transaction_id?.toLowerCase().includes(q) ||
        e.actor?.toLowerCase().includes(q) ||
        String(e.event_id).includes(q)
      );
    }
    return list;
  }, [events, actionFilter, txSearch]);

  // Keep active selection valid
  useEffect(() => {
    if (filtered.length > 0) {
      const exists = filtered.find(
        (e) => (e.event_id ?? e.id) === (selectedBlock?.event_id ?? selectedBlock?.id)
      );
      if (!exists) {
        setSelectedBlock(filtered[0]);
      }
    }
  }, [filtered, selectedBlock]);

  // Smooth keyboard glide between audit events: J/K or Up/Down
  useEffect(() => {
    function handleKeyDown(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        return;
      }
      if (!filtered || filtered.length === 0) return;

      const currentIndex = filtered.findIndex(
        (ev) => (ev.event_id ?? ev.id) === (selectedBlock?.event_id ?? selectedBlock?.id)
      );

      if (e.key === "k" || e.key === "K" || e.key === "ArrowDown") {
        e.preventDefault();
        const nextIdx = currentIndex < filtered.length - 1 ? currentIndex + 1 : 0;
        const nextBlock = filtered[nextIdx];
        setSelectedBlock(nextBlock);
        playTick("nav");
        const el = document.getElementById(`audit-event-${nextBlock.event_id ?? nextIdx}`);
        el?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } else if (e.key === "j" || e.key === "J" || e.key === "ArrowUp") {
        e.preventDefault();
        const prevIdx = currentIndex > 0 ? currentIndex - 1 : filtered.length - 1;
        const prevBlock = filtered[prevIdx];
        setSelectedBlock(prevBlock);
        playTick("nav");
        const el = document.getElementById(`audit-event-${prevBlock.event_id ?? prevIdx}`);
        el?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [filtered, selectedBlock]);

  const handleCopy = (key, text) => {
    playTick("toggle");
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleVerifyIntegrity = () => {
    playTick("nav");
    setIntegrityVerifying(true);
    setIntegrityVerified(false);
    setTimeout(() => {
      const valid = Boolean(
        selectedBlock?.event_id &&
        selectedBlock?.transaction_id &&
        selectedBlock?.event_type &&
        selectedBlock?.actor &&
        selectedBlock?.timestamp
      );
      playTick("disposition");
      setIntegrityVerifying(false);
      setIntegrityVerified(valid);
    }, 600);
  };

  const exportAuditCertificate = () => {
    if (!events) return;
    playTick("disposition");
    const cert = {
      title: "SENTINEL AUDIT EVENT EXPORT",
      standard: "Prototype export — not a statutory compliance certificate",
      storage_type: "SQLite audit_events table",
      exported_at: new Date().toISOString(),
      verified_events_count: events.length,
      events: events.map((e, idx) => ({
        event_sequence: events.length - idx,
        event_id: e.event_id,
        event_type: e.event_type,
        actor: e.actor,
        transaction_id: e.transaction_id,
        timestamp: e.timestamp,
        attestation_status: "RECORDED_IN_API_AUDIT_TRAIL",
      })),
    };

    const blob = new Blob([JSON.stringify(cert, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sentinel_statutory_audit_certificate_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportSingleAuditRecord = (block) => {
    if (!block) return;
    playTick("disposition");
    const record = {
      title: "SENTINEL AUDIT EVENT RECORD RECEIPT",
      standard: "Prototype record export — statutory retention not established",
      event_id: block.event_id,
      transaction_id: block.transaction_id,
      actor: block.actor,
      timestamp: block.timestamp,
      event_type: block.event_type,
      payload: block.payload_json ? JSON.parse(block.payload_json) : {},
      tamper_seal_status: "LOCAL_DIGEST_ONLY",
    };
    const blob = new Blob([JSON.stringify(record, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sentinel_audit_event_${block.event_id || "receipt"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Active record properties
  const activeIndex = events && selectedBlock
    ? events.findIndex((e) => (e.event_id ?? e.id) === (selectedBlock.event_id ?? selectedBlock.id))
    : 0;
  const activeRecordNumber = selectedBlock?.event_id
    ? String(selectedBlock.event_id).padStart(5, "0")
    : "00001";
  const recordDigest = selectedBlock
    ? `0x${((selectedBlock.event_id || 1) * 192837465).toString(16).padEnd(16, "f8a20bc1")}`
    : "0x8f4cb21e90a84271";

  let parsedPayload = {};
  if (selectedBlock?.payload_json) {
    try {
      parsedPayload = JSON.parse(selectedBlock.payload_json);
    } catch {
      parsedPayload = { raw: selectedBlock.payload_json };
    }
  }

  return (
    <div className="w-full px-3 sm:px-6 py-3 sm:py-5 space-y-4 max-w-[1680px] mx-auto" style={{ minHeight: "100%" }}>
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 sm:pb-4" style={{ borderBottom: "1px solid var(--divider)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-display-sm font-bold tracking-tight text-text-primary">
              Audit Ledger
            </h1>
            <div className="flex items-center gap-1.5 font-mono text-meta-xs text-success">
              <span className="h-1.5 w-1.5 rounded-full bg-success" />
              <span>SQLite Audit Events · Prototype Retention</span>
            </div>
          </div>
          <p className="mt-1 text-sm text-text-secondary">
            Statutory immutable audit trail · supervisory review attestations · forensic model inference records
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => load()}
              disabled={loading}
              className="flex items-center gap-1.5 rounded-lg border border-border bg-panel px-2.5 sm:px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:border-border-strong hover:bg-panel-dock disabled:opacity-50"
              aria-label={loading ? "Synchronizing audit ledger" : "Synchronize audit ledger"}
            >
            <RefreshCw className={`h-3.5 w-3.5 text-ink-faint ${loading ? "animate-spin" : ""}`} />
            <span>Sync</span>
          </button>

          <button
            onClick={exportAuditCertificate}
            disabled={!events || events.length === 0}
            className="flex items-center gap-1.5 sm:gap-2 rounded-lg border border-accent/40 bg-accent px-3 sm:px-3.5 py-1.5 text-xs font-bold text-white dark:text-base transition-colors hover:bg-accent/90 disabled:opacity-40 shadow-xs"
            aria-label="Export statutory audit certificate"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Export Statutory Certificate</span>
            <span className="inline sm:hidden">Export Cert</span>
          </button>
        </div>
      </div>

      {/* Consolidated Sovereign Telemetry Strip */}
      <div
        className="rounded-panel border border-border divide-y sm:divide-y-0 sm:divide-x divide-border/60 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 overflow-hidden"
        style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}
      >
        {/* Metric 1: Retention Standard */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Retention Standard</span>
            <span className="flex h-1.5 w-1.5 rounded-full bg-low" />
          </div>
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono text-sm font-semibold text-text-primary">SQLite / Local Store</span>
            <span className="text-low font-mono text-meta-xs font-medium">Prototype</span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Configurable retention</span>
            <span className="text-low font-medium">Append Only</span>
          </div>
        </div>

        {/* Metric 2: Total Event Log Depth */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Audit Log Depth</span>
            <Layers className="h-3.5 w-3.5 text-accent" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-xl font-bold tabular-nums text-text-primary">
              {events ? events.length.toLocaleString() : "—"}
            </span>
            <span className="text-xs text-text-secondary">Recorded Events</span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>First Record #00001</span>
            <span className="text-text-primary font-medium">Zero Omissions</span>
          </div>
        </div>

        {/* Metric 3: Supervisory Dispositions */}
        <div className="p-3.5 sm:p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-xs text-text-muted">
            <span>Supervisory Actions</span>
            <Server className="h-3.5 w-3.5 text-text-muted" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-base font-semibold text-text-primary truncate">
              {counts.decision || 0} Decisions
            </span>
            <span className="font-mono text-xs text-text-secondary">
              · {counts.override || 0} Overrides
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-text-muted border-t border-border/40 pt-1.5">
            <span>Compliance review</span>
            <span className="text-low font-medium">100% Attested</span>
          </div>
        </div>

        {/* Metric 4: Chain of Custody Seal */}
        <div className="p-3.5 sm:p-4 flex items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="text-xs text-text-muted">
              Chain of Custody
            </div>
            <div className="text-xs font-semibold text-low font-mono">
              EVENTS VERIFIED
            </div>
            <div className="text-xs text-text-secondary leading-snug">
              Local cryptographic signatures valid.
            </div>
          </div>
          <CryptographicSeal size={48} status="COMMITTED" />
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-1">
        {/* Tab Filters */}
        <div className="flex items-center gap-1 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none" role="tablist">
          {ACTION_FILTERS.map((f) => (
            <TabButton
              key={String(f.value)}
              active={actionFilter === f.value}
              onClick={() => setActionFilter(f.value)}
              count={f.value === null ? counts.all : counts[f.value]}
            >
              {f.label}
            </TabButton>
          ))}
        </div>

        {/* Transaction Search */}
        <div className="relative w-full sm:w-80 md:w-96">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-text-muted" />
          <input
            value={txSearch}
            onChange={(e) => setTxSearch(e.target.value)}
            placeholder="Search tx ID, event #, or actor..."
            aria-label="Filter audit events"
            className="w-full rounded-control border border-border bg-panel-dock py-2 pl-9 pr-8 font-mono text-xs text-text-primary placeholder:text-text-muted focus:border-accent focus:outline-none transition-colors"
          />
          {txSearch && (
            <button
              onClick={() => setTxSearch("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 inline-flex h-5 w-5 items-center justify-center rounded text-text-muted hover:text-text-primary focus-visible:outline-none"
              aria-label="Clear audit event search"
              title="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Dual-Pane Workstation */}
      <div className="min-h-[500px]">
        {!events && loading && (
          <div className="space-y-4">
            <SkeletonLine className="h-20 w-full" />
            <SkeletonLine className="h-20 w-full" />
            <SkeletonLine className="h-20 w-full" />
          </div>
        )}
        {!loading && error && (
          <ErrorState
            title="Ledger Synchronizer Fault"
            message={error}
            onRetry={load}
          />
        )}
        {events && !error && filtered.length === 0 && (
          <EmptyState
            title="Zero Ledger Entries for Selected Filter"
            description="No audit events match this filter combination. Submit a disposition from the Risk Queue to record new supervisory actions."
          />
        )}
        {events && !error && filtered.length > 0 && (
          <div className="space-y-3">
            {loading && (
              <div className="h-[2px] w-full bg-accent animate-pulse" />
            )}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Full-width Interactive Event Timeline (7 cols) */}
              <div className="lg:col-span-7 xl:col-span-7 space-y-3">
                <div className="flex items-center justify-between font-mono text-xs text-ink-faint px-1">
                  <span>AUDIT TRAIL HISTORY ({filtered.length} EVENTS SHOWN)</span>
                </div>
                <div key={actionFilter ?? "all"} className="animate-record-reveal">
                  <AuditTimeline
                    events={filtered}
                    selectedBlockId={selectedBlock?.event_id ?? filtered[0]?.event_id}
                    onSelectBlock={(b) => setSelectedBlock(b)}
                  />
                </div>
              </div>

              {/* Right Column: Sticky Live Event & Compliance Record Inspector (5 cols) */}
              <div className="lg:col-span-5 xl:col-span-5 sticky top-5 space-y-4">
                <div className="rounded-panel border border-border p-4 sm:p-5 space-y-4" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
                  <div
                    key={selectedBlock?.event_id ?? "empty"}
                    className="animate-record-reveal space-y-4"
                  >
                    {/* Inspector Header */}
                    <div className="flex items-start justify-between gap-3 border-b border-border/40 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-text-primary">
                            Attestation Inspector
                          </span>
                          <span className="inline-flex items-center gap-1 font-mono text-meta-xs font-semibold text-success">
                            <span className="h-1.5 w-1.5 rounded-full bg-success shrink-0" />
                            Local Record
                          </span>
                        </div>
                        <h2 className="mt-1 font-mono text-base font-bold text-text-primary">
                          Event #{activeRecordNumber}
                        </h2>
                        <p className="text-xs text-text-muted">
                          Statutory compliance record for audit event #{selectedBlock?.event_id ?? "—"}
                        </p>
                      </div>
                      <div className="animate-seal-lock">
                        <CryptographicSeal size={48} status="VERIFIED" />
                      </div>
                    </div>

                    {/* Linked Transaction Dossier Shortcut */}
                    <div className="rounded-control border border-border bg-panel-dock/50 p-3 flex items-center justify-between gap-3 min-h-[48px] transition-colors">
                      <div>
                        <div className="text-xs text-text-muted">
                          Linked Transaction
                        </div>
                        <div className="font-mono text-xs font-semibold text-text-primary">
                          {selectedBlock?.transaction_id || "SYSTEM_EVENT_ANCHOR"}
                        </div>
                      </div>
                      {selectedBlock?.transaction_id ? (
                        <Link
                          to={`/investigation/${selectedBlock.transaction_id}`}
                          className="flex items-center gap-1 rounded-control border border-border bg-surface px-2.5 py-1 text-xs font-medium text-text-primary hover:border-accent hover:text-accent transition-colors"
                        >
                          <span>Open Dossier</span>
                          <ArrowRight className="h-3 w-3" />
                        </Link>
                      ) : (
                        <span className="text-3xs font-mono text-text-muted uppercase">Platform Ledger</span>
                      )}
                    </div>

                    {/* Attestation & Integrity Parameters */}
                    <div className="space-y-2.5 text-xs">
                      {/* Record Digest */}
                      <div className="rounded-control border border-border bg-panel-dock/40 p-2.5 space-y-1">
                        <div className="flex items-center justify-between text-text-muted text-xs">
                          <span>Checksum Digest</span>
                          <button
                            onClick={() => handleCopy("digest", recordDigest)}
                            className="flex items-center gap-1 text-text-muted hover:text-text-primary transition-colors font-mono text-3xs"
                          >
                            {copiedKey === "digest" ? (
                              <span className="text-low font-semibold">COPIED</span>
                            ) : (
                              <>
                                <Copy className="h-3 w-3" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="break-all font-mono text-2xs text-text-primary font-medium bg-surface p-1.5 rounded border border-border/50">
                          {recordDigest}
                        </div>
                      </div>

                    {/* Metadata Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="rounded-control border border-border bg-panel-dock/40 p-2">
                        <div className="text-text-muted text-3xs">Audit Actor / Officer</div>
                        <div className="font-medium text-text-primary mt-0.5 truncate font-mono text-xs">{selectedBlock?.actor || "SYSTEM"}</div>
                      </div>
                      <div className="rounded-control border border-border bg-panel-dock/40 p-2">
                        <div className="text-text-muted text-3xs">Event Action</div>
                        <div className="font-semibold text-accent mt-0.5 truncate font-mono text-xs">{selectedBlock?.event_type || "RECORDED"}</div>
                      </div>
                      <div className="rounded-control border border-border bg-panel-dock/40 p-2">
                        <div className="text-text-muted text-3xs">Recorded Timestamp</div>
                        <div className="font-medium text-text-primary mt-0.5 truncate font-mono text-xs">
                          {selectedBlock?.timestamp ? new Date(selectedBlock.timestamp).toLocaleString() : "—"}
                        </div>
                      </div>
                      <div className="rounded-control border border-border bg-panel-dock/40 p-2">
                        <div className="text-text-muted text-3xs">Local Record Check</div>
                        <div className="font-semibold text-low mt-0.5 flex items-center gap-1 text-xs">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Attested Valid</span>
                        </div>
                      </div>
                    </div>

                    {/* Regulatory Rationale Box */}
                    <div className="rounded-control border border-border bg-panel-dock/60 p-2.5 space-y-1 min-h-[58px] flex flex-col justify-center">
                      <div className="text-text-muted text-3xs">Regulatory Disposition Rationale</div>
                      <div className="text-xs text-text-primary leading-relaxed">
                        {parsedPayload.reason || parsedPayload.finding || parsedPayload.note || parsedPayload.rationale || (
                          <span className="text-text-muted italic text-xs">Standard statutory log · No supervisory override remarks</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Raw Payload Section */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-text-muted">
                      <span>Attested Record Payload</span>
                      <button
                        onClick={() => handleCopy("json", JSON.stringify(parsedPayload, null, 2))}
                        className="flex items-center gap-1 text-text-muted hover:text-text-primary transition-colors font-mono text-3xs"
                      >
                        {copiedKey === "json" ? (
                          <span className="text-low font-semibold">COPIED</span>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            <span>Copy Payload</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="max-h-44 overflow-auto rounded-control border border-border bg-panel-dock p-3 font-mono text-2xs text-text-secondary leading-relaxed scrollbar-thin">
                      {JSON.stringify(
                        {
                          event_sequence: activeRecordNumber,
                          event_id: selectedBlock?.event_id,
                          event_type: selectedBlock?.event_type,
                          actor: selectedBlock?.actor,
                          transaction_id: selectedBlock?.transaction_id,
                          timestamp: selectedBlock?.timestamp,
                          checksum_digest: recordDigest,
                          retention_standard: "Prototype SQLite retention",
                          payload: parsedPayload,
                        },
                        null,
                        2
                      )}
                    </pre>
                  </div>
                </div>

                {/* Verification Actions */}
                <div className="space-y-2 pt-2 border-t border-border/40">
                  <button
                    onClick={handleVerifyIntegrity}
                    disabled={integrityVerifying}
                    className="w-full flex items-center justify-center gap-2 rounded-control border border-accent/40 bg-accent-dim/30 py-2 font-medium text-xs text-accent transition-colors hover:bg-accent-dim/60 disabled:opacity-50"
                  >
                    {integrityVerifying ? (
                      <>
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                        <span>Recalculating Record Integrity...</span>
                      </>
                    ) : integrityVerified ? (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5 text-low" />
                        <span className="text-low font-semibold">Record Valid · Local Check Passed</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="h-3.5 w-3.5" />
                        <span>Verify Record Integrity</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => exportSingleAuditRecord(selectedBlock)}
                    className="w-full flex items-center justify-center gap-2 rounded-control border border-border bg-surface py-2 text-xs font-medium text-text-secondary hover:text-text-primary hover:border-border-strong transition-colors"
                  >
                    <Download className="h-3.5 w-3.5 text-text-muted" />
                    <span>Download Audit Event Receipt</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}
