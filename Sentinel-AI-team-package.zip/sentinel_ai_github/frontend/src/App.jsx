import { Routes, Route } from "react-router-dom";
import { SystemStatusProvider } from "./context/SystemStatusContext";
import { ThemeProvider } from "./context/ThemeContext";
import { CurrencyProvider } from "./context/CurrencyContext";
import AppShell from "./layout/AppShell";
import RiskQueue from "./pages/RiskQueue";
import Investigation from "./pages/Investigation";
import AuditTrail from "./pages/AuditTrail";
import ModelGovernance from "./pages/ModelGovernance";
import DesignConcepts from "./pages/DesignConcepts";
import NotFound from "./pages/NotFound";

import ErrorBoundary from "./components/ErrorBoundary";

export default function App() {
  const isPort5174 = typeof window !== "undefined" && window.location.port === "5174";

  return (
    <ThemeProvider>
      <CurrencyProvider>
        <SystemStatusProvider>
          <ErrorBoundary>
            <Routes>
              {/* When accessed on port 5174, root directly renders the 10 Design Studio */}
              {isPort5174 ? (
                <>
                  <Route path="/" element={<DesignConcepts />} />
                  <Route path="/concepts" element={<DesignConcepts />} />
                  <Route element={<AppShell />}>
                    <Route path="/queue" element={<RiskQueue />} />
                    <Route path="/investigation/:transactionId" element={<Investigation />} />
                    <Route path="/audit-trail" element={<AuditTrail />} />
                    <Route path="/model-health" element={<ModelGovernance />} />
                  </Route>
                </>
              ) : (
                <>
                  <Route path="/concepts" element={<DesignConcepts />} />
                  <Route element={<AppShell />}>
                    <Route path="/" element={<RiskQueue />} />
                    <Route path="/investigation/:transactionId" element={<Investigation />} />
                    <Route path="/audit-trail" element={<AuditTrail />} />
                    <Route path="/model-health" element={<ModelGovernance />} />
                  </Route>
                </>
              )}
              {/* Catch-all 404 — outside AppShell so it can have its own layout */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </ErrorBoundary>
        </SystemStatusProvider>
      </CurrencyProvider>
    </ThemeProvider>
  );
}
