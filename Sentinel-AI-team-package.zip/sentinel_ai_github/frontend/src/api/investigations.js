import { apiFetch, USE_MOCK } from "./client";
import { mockInvestigation } from "../mocks/data";
import { invalidateCase } from "./transactions";

export async function investigateTransaction(transactionId, { forceRefresh = false } = {}) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600));
    return { case_id: `CASE_${transactionId}`, investigation: mockInvestigation(transactionId) };
  }
  const url = `/case/${transactionId}/investigate${forceRefresh ? "?force_refresh=true" : ""}`;
  const result = await apiFetch(url, { method: "POST" });
  invalidateCase(transactionId);
  return result;
}

export async function submitAuditorDecision(transactionId, { auditor, action, reason }) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 300));
    return { status: "recorded", case_id: `CASE_${transactionId}`, action, _isMock: true };
  }
  const result = await apiFetch(`/case/${transactionId}/decision`, {
    method: "POST",
    body: JSON.stringify({ auditor, action, reason: reason || null }),
  });
  invalidateCase(transactionId);
  return result;
}

export async function executePipelineScore(payload) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600));
    return {
      transaction_id: payload.transaction_id,
      scores: {
        composite_score: 88.5,
        review_tier: "immediate_escalation",
        isoforest_score: 0.92,
        autoencoder_score: 0.88,
        benford_score: 75.0,
        rule_score: 25.0,
      },
      engineered_features: {
        amount_zscore: 4.8,
        velocity_7d: 12,
        velocity_30d: 38,
        balance_depletion_ratio: 0.85,
        amount_to_balance_ratio: 0.85,
        amount_pct_rank_personal: 0.99,
        amount_pct_rank_peer_group: 0.97,
      },
      investigation: mockInvestigation(payload.transaction_id),
      case_id: `CASE_${payload.transaction_id}`,
      llm_provider: "Sentinel Neural Core v2.4 (Self-Hosted)",
      status: "success",
    };
  }
  const result = await apiFetch("/score/pipeline", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  invalidateCase(payload.transaction_id);
  return result;
}

