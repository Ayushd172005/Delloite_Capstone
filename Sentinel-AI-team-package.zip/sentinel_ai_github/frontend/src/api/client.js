// Thin fetch wrapper shared by every API module. Nothing else in the app
// touches fetch/axios directly (spec item 39) - components call the
// functions in transactions.js / investigations.js / audit.js instead.

export const API_BASE =
  import.meta.env.VITE_API_BASE_URL ||
  (typeof window !== "undefined" &&
  window.location.hostname !== "localhost" &&
  window.location.hostname !== "127.0.0.1"
    ? ""
    : "http://localhost:8000");

export const USE_MOCK = import.meta.env.VITE_USE_MOCK_DATA === "true";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

export async function apiFetch(path, options = {}) {
  let res;
  try {
    res = await fetch(API_BASE + path, {
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
        ...(options.headers || {}),
      },
      ...options,
    });
  } catch (e) {
    throw new ApiError(`Could not reach ${API_BASE}${path}`, 0);
  }
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new ApiError(`${res.status} ${res.statusText}: ${body.slice(0, 200)}`, res.status);
  }
  if (res.status === 204) return null;
  return res.json();
}
