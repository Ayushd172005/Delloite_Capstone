import { apiFetch, USE_MOCK } from "./client";
import { MOCK_QUEUE, mockCase } from "../mocks/data";

export async function getQueue({ vertical, tier, limit = 50 } = {}) {
  if (USE_MOCK) {
    let rows = MOCK_QUEUE;
    if (vertical) rows = rows.filter((r) => r.vertical === vertical);
    if (tier) rows = rows.filter((r) => r.review_tier === tier);
    return rows.slice(0, limit);
  }
  const params = new URLSearchParams();
  if (vertical) params.set("vertical", vertical);
  if (tier) params.set("tier", tier);
  params.set("limit", String(limit));
  return apiFetch(`/queue?${params.toString()}`);
}

const _caseCache = new Map();

export async function getCase(transactionId, { forceRefresh = false } = {}) {
  if (!forceRefresh && _caseCache.has(transactionId)) {
    return _caseCache.get(transactionId);
  }
  if (USE_MOCK) return mockCase(transactionId);

  try {
    const data = await apiFetch(`/case/${transactionId}`);
    _caseCache.set(transactionId, data);
    return data;
  } catch (err) {
    _caseCache.delete(transactionId);
    throw err;
  }
}

export function prefetchCase(transactionId) {
  if (!transactionId || _caseCache.has(transactionId) || USE_MOCK) return;
  apiFetch(`/case/${transactionId}`)
    .then((data) => {
      _caseCache.set(transactionId, data);
    })
    .catch(() => {
      /* ignore prefetch errors */
    });
}

export function invalidateCase(transactionId) {
  if (transactionId) {
    _caseCache.delete(transactionId);
  } else {
    _caseCache.clear();
  }
}

export async function checkHealth() {
  if (USE_MOCK) return { status: "ok", transactions_loaded: MOCK_QUEUE.length, _isMock: true };
  return apiFetch("/health");
}

export async function getMetrics() {
  if (USE_MOCK) return null;
  return apiFetch("/metrics");
}
