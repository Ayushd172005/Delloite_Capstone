import { InboxIcon, SearchX, WifiOff } from "./PhosphorIcons";

/**
 * EmptyState — differentiated for 3 scenarios:
 * - "no-records": queue is genuinely empty (no data)
 * - "no-match": filters active, nothing matches
 * - "unavailable": data could not be retrieved
 */
export default function EmptyState({ title, description, action, variant = "no-match" }) {
  const iconMap = {
    "no-records":    InboxIcon,
    "no-match":      SearchX,
    "unavailable":   WifiOff,
  };
  const Icon = iconMap[variant] || SearchX;

  return (
    <div
      className="flex flex-col items-center justify-center py-16 text-center"
    >
      <div
        className="flex h-12 w-12 items-center justify-center rounded-full mb-4"
        style={{
          background: "var(--surface-subtle)",
          border: "1px solid var(--divider)",
        }}
      >
        <Icon className="h-5 w-5" style={{ color: "var(--text-muted)" }} aria-hidden />
      </div>
      <div className="font-mono text-sm font-semibold text-text-primary">{title}</div>
      {description && (
        <div className="mt-1.5 max-w-sm text-2xs font-mono" style={{ color: "var(--text-secondary)" }}>
          {description}
        </div>
      )}
      {action && (
        <div className="mt-4">
          <button
            onClick={action.onClick}
            className="rounded-control px-3 py-1.5 font-mono text-2xs font-medium transition-colors"
            style={{
              background: "var(--surface-raised)",
              border: "1px solid var(--divider)",
              color: "var(--text-primary)",
            }}
          >
            {action.label}
          </button>
        </div>
      )}
    </div>
  );
}
