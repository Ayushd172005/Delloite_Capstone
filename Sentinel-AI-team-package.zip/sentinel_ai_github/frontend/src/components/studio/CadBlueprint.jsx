import React from "react";

export default function CadBlueprint({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col bg-[#041325] text-[#e0f2fe] font-mono text-xs select-none relative">
      {/* Blueprint Grid Background Pattern */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: "linear-gradient(to right, #38bdf8 1px, transparent 1px), linear-gradient(to bottom, #38bdf8 1px, transparent 1px)",
          backgroundSize: "20px 20px",
        }}
      ></div>

      {/* ─── Blueprint Title Header ──────────────────────────────────────── */}
      <div className="relative z-10 h-10 border-b border-[#0e3563] bg-[#061e3b]/80 backdrop-blur-sm px-6 flex items-center justify-between text-xs text-[#7dd3fc]">
        <div className="flex items-center gap-3">
          <span className="text-[#38bdf8] font-bold">⌖ AUTOCAD/SENTINEL BLUEPRINT</span>
          <span className="text-[#0e3563]">|</span>
          <span>DWG NO: SENTINEL-AML-2026-REV4</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>SCALE: 1:1 VECTOR</span>
          <span className="text-[#facc15]">STATUS: ANOMALY BREACH</span>
        </div>
      </div>

      {/* ─── CAD Multi-Pane View ─────────────────────────────────────────── */}
      <div className="relative z-10 flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left: Component Index (3 cols) */}
        <div className="lg:col-span-3 border-r border-[#0e3563] flex flex-col bg-[#051830]/90">
          <div className="p-3 border-b border-[#0e3563] text-[11px] font-bold uppercase tracking-wider text-[#7dd3fc]">
            DRAWING SCHEDULE [12 TXNS]
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#092b52] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-2.5 text-left border transition-all ${
                    isSelected
                      ? "bg-[#092d57] border-[#38bdf8] text-[#38bdf8]"
                      : "border-transparent hover:bg-[#072242] text-[#7dd3fc]"
                  }`}
                >
                  <div className="flex justify-between font-bold text-[11px]">
                    <span>{item.id.slice(0, 15)}</span>
                    <span className={item.score >= 90 ? "text-[#f87171]" : "text-[#facc15]"}>
                      {item.score.toFixed(1)}
                    </span>
                  </div>
                  <div className="text-[10px] text-[#0284c7] mt-0.5">{item.amount}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center: Vector Schematic (6 cols) */}
        <div className="lg:col-span-6 border-r border-[#0e3563] flex flex-col overflow-y-auto p-6 space-y-6 bg-[#041325]/80">
          {/* Dimension Callout Banner */}
          <div className="border border-[#0e3563] bg-[#08213f] p-4 relative">
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-[10px] text-[#38bdf8] uppercase font-bold">SCHEMATIC COMPONENT: {activeCase.transaction_id}</span>
              <span className="text-xs text-[#facc15] font-bold">COMPOSITE: {activeCase.composite_score.toFixed(1)}</span>
            </div>

            {/* Dimension Lines */}
            <div className="py-2 text-center text-[#facc15] font-bold text-xs tracking-wider border-y border-dashed border-[#0e3563] my-2">
              |← EXPOSURE QUANTUM: {displayAmount} (DEVIATION: 4.8σ) →|
            </div>

            <p className="text-xs text-[#bae6fd] leading-relaxed pt-2">
              {activeCase.narrative}
            </p>
          </div>

          {/* Isometric Route Conduit Diagram */}
          <div className="border border-[#0e3563] bg-[#08213f] p-4 space-y-3">
            <span className="text-[10px] text-[#38bdf8] font-bold uppercase block">⌖ VECTOR FLOW SPECIFICATION</span>
            <div className="flex items-center justify-between text-xs text-center">
              <div className="border border-[#38bdf8] p-2 bg-[#051830] flex-1">
                <div className="text-[10px] text-[#7dd3fc]">ORIGIN NODE</div>
                <div className="font-bold text-white mt-0.5">{activeCase.originator.name}</div>
                <div className="text-[9px] text-[#0284c7]">{activeCase.originator.jurisdiction}</div>
              </div>

              <div className="px-3 text-[#facc15] font-bold text-sm">
                ════►
              </div>

              <div className="border border-[#ef4444] p-2 bg-[#1b0a12] flex-1">
                <div className="text-[10px] text-[#f87171]">TERMINAL NODE</div>
                <div className="font-bold text-white mt-0.5">{activeCase.beneficiary.name}</div>
                <div className="text-[9px] text-[#f87171]">{activeCase.beneficiary.jurisdiction}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Architectural Title Block & Actions (3 cols) */}
        <div className="lg:col-span-3 flex flex-col justify-between bg-[#051830] p-4">
          <div className="space-y-3">
            <span className="text-[10px] text-[#38bdf8] font-bold uppercase tracking-wider block">
              ENGINEERING DISPOSITIONS
            </span>
            <button
              onClick={() => onAction("Approved CAD Blueprint", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold text-xs transition-colors text-left"
            >
              [SIGNOFF & CLEAR]
            </button>
            <button
              onClick={() => onAction("Escalated CAD Alert", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#facc15] hover:bg-[#eab308] text-black font-bold text-xs transition-colors text-left"
            >
              [ISSUE REVISION NOTICE]
            </button>
            <button
              onClick={() => onAction("Filed SAR Blueprint", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#ef4444] hover:bg-[#dc2626] text-white font-bold text-xs transition-colors text-left"
            >
              [ORDER WORK STOPPAGE (SAR)]
            </button>
          </div>

          {/* Architectural Drawing Title Block (Corner Plate) */}
          <div className="border-2 border-[#0e3563] bg-[#08213f] p-2.5 space-y-1 text-[9px] text-[#7dd3fc]">
            <div className="border-b border-[#0e3563] pb-1 font-bold text-white uppercase">
              DRAWING SHEET: SENTINEL SURVEILLANCE
            </div>
            <div className="flex justify-between">
              <span>PROJECT: AI AML SUITE</span>
              <span>REV: 4.2.0</span>
            </div>
            <div className="flex justify-between">
              <span>DATE: 2026-09-12</span>
              <span>DRAWN BY: AGENT_01</span>
            </div>
            <div className="text-[#38bdf8] font-bold pt-1 border-t border-[#0e3563]">
              CERTIFIED AS ACCURATE BLUEPRINT
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
