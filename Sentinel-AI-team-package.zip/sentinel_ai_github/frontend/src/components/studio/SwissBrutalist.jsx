import React from "react";

export default function SwissBrutalist({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col bg-[#050505] text-[#ffffff] font-sans select-none">
      {/* ─── Heavy Swiss Typographic Masthead ────────────────────────────── */}
      <div className="border-b-2 border-white/20 p-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-xs font-black tracking-widest uppercase text-[#ff4500] block mb-1">
            01 / INTERNATIONAL SURVEILLANCE MATRIX
          </span>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tighter uppercase">
            SENTINEL // SWISS BRUTALIST
          </h1>
        </div>
        <div className="text-right font-mono text-xs text-[#888888]">
          <div>CASE REF: <strong className="text-white">{activeCase.transaction_id}</strong></div>
          <div>SLA TIMER: <span className="text-[#ff4500] font-bold">{activeCase.sla_remaining}</span></div>
        </div>
      </div>

      {/* ─── Stark Asymmetrical Grid ────────────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Column: Dense Numeric Index (3 cols) */}
        <div className="lg:col-span-3 border-r-2 border-white/20 flex flex-col bg-[#080808]">
          <div className="p-4 border-b-2 border-white/20 text-xs font-black tracking-wider uppercase text-[#888888]">
            INDEX // TRANSACTIONS (12)
          </div>
          <div className="flex-1 overflow-y-auto divide-y-2 divide-white/10">
            {queue.map((item, idx) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-4 text-left transition-none flex items-baseline justify-between ${
                    isSelected ? "bg-[#ff4500] text-black" : "hover:bg-white/10 text-white"
                  }`}
                >
                  <div>
                    <span className="text-[10px] font-mono block opacity-60">#{String(idx + 1).padStart(2, "0")}</span>
                    <span className="font-bold text-xs font-mono">{item.id.slice(0, 16)}</span>
                  </div>
                  <span className="text-lg font-black font-mono tabular-nums">{item.score.toFixed(1)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center Column: Monolithic Typographic Hero (6 cols) */}
        <div className="lg:col-span-6 border-r-2 border-white/20 flex flex-col overflow-y-auto p-8 space-y-8 bg-[#050505]">
          {/* Gigantic 72px Risk Numeral Banner */}
          <div className="border-2 border-white/20 p-6 space-y-4">
            <div className="flex justify-between items-baseline">
              <span className="text-xs font-black uppercase tracking-widest text-[#ff4500]">STATISTICAL ANOMALY FACTOR</span>
              <span className="text-xs font-mono text-[#888888]">{activeCase.timestamp}</span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-4">
              <span className="text-7xl sm:text-8xl font-black tracking-tighter text-white font-mono leading-none">
                {activeCase.composite_score.toFixed(1)}
              </span>
              <div className="bg-[#ff4500] text-black font-black text-xs px-3 py-1 uppercase tracking-wider self-start sm:self-center">
                CRITICAL VIOLATION BREACH
              </div>
            </div>

            <div className="text-sm font-bold uppercase text-[#888888] pt-2 border-t-2 border-white/10 flex justify-between">
              <span>FINANCIAL SUM AT RISK</span>
              <span className="text-white text-xl font-mono">{displayAmount}</span>
            </div>
          </div>

          {/* Stark 2-Row Signal Decomp */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="border-2 border-white/20 p-4 space-y-2">
              <span className="text-[11px] font-black uppercase text-[#888888] block">01 / ISOLATION FOREST</span>
              <div className="text-3xl font-black font-mono text-white">{(activeCase.isoforest_score * 100).toFixed(1)}%</div>
              <p className="text-xs text-[#888888]">12 Iterations. Variance deviates beyond normal commercial distribution.</p>
            </div>

            <div className="border-2 border-[#ff4500] p-4 space-y-2 bg-[#ff4500]/10">
              <span className="text-[11px] font-black uppercase text-[#ff4500] block">02 / AUTOENCODER MSE</span>
              <div className="text-3xl font-black font-mono text-[#ff4500]">{(activeCase.autoencoder_score * 100).toFixed(1)}%</div>
              <p className="text-xs text-[#888888]">Latent manifold reconstruction failure. 4.8σ severe anomaly.</p>
            </div>
          </div>

          {/* Editorial Findings */}
          <div className="border-2 border-white/20 p-6 space-y-2">
            <span className="text-xs font-black uppercase tracking-widest text-[#ff4500] block">
              FINDINGS SUMMARY // NO COMPROMISE
            </span>
            <p className="text-sm text-[#cccccc] leading-relaxed font-medium">
              {activeCase.narrative}
            </p>
          </div>
        </div>

        {/* Right Column: Stark Action Command Deck (3 cols) */}
        <div className="lg:col-span-3 flex flex-col p-6 space-y-6 bg-[#080808]">
          <div>
            <span className="text-xs font-black tracking-widest uppercase text-[#888888] block mb-4">
              MANDATORY SUPERVISORY ACTIONS
            </span>
            <div className="space-y-3">
              <button
                onClick={() => onAction("Escalate to Authority", activeCase.transaction_id)}
                className="w-full py-4 px-4 bg-[#ff4500] hover:bg-[#e03e00] text-black font-black text-sm uppercase tracking-wider transition-none text-left flex justify-between items-center"
              >
                <span>ESCALATE NOW</span>
                <span>→</span>
              </button>

              <button
                onClick={() => onAction("File Statutory SAR", activeCase.transaction_id)}
                className="w-full py-4 px-4 bg-white hover:bg-[#dddddd] text-black font-black text-sm uppercase tracking-wider transition-none text-left flex justify-between items-center"
              >
                <span>SUBMIT SAR</span>
                <span>→</span>
              </button>

              <button
                onClick={() => onAction("Dismiss", activeCase.transaction_id)}
                className="w-full py-3 px-4 border-2 border-white/30 hover:border-white text-white font-bold text-xs uppercase tracking-wider transition-none text-left"
              >
                DISMISS WITH NOTE
              </button>
            </div>
          </div>

          <div className="border-2 border-white/10 p-4 space-y-2 text-xs font-mono text-[#888888]">
            <span className="text-white font-bold block uppercase">ATTESTATION PROTOCOL</span>
            <div>HASH: 0x8841F93A...</div>
            <div>STATUS: UNMODIFIED TRUTH</div>
          </div>
        </div>
      </div>
    </div>
  );
}
