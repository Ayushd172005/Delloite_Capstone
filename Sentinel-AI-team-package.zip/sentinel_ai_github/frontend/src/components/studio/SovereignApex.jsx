import React from "react";
import { ShieldCheck, ArrowUpRight, CheckCircle, Warning, LockKey, Sparkle } from "../PhosphorIcons";

export default function SovereignApex({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col bg-[#09090b] text-[#fafafa] font-sans select-none">
      {/* ─── Executive Gold Trim Header ─────────────────────────────────── */}
      <div className="h-14 border-b border-[#2e2b20] bg-gradient-to-r from-[#141418] via-[#121110] to-[#141418] px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-2.5 h-2.5 rounded-full bg-[#d4af37] shadow-[0_0_10px_#d4af37]"></div>
          <h1 className="text-sm font-bold tracking-wider uppercase text-[#d4af37]">
            SENTINEL // SOVEREIGN APEX EXECUTIVE SUITE
          </h1>
        </div>
        <div className="flex items-center gap-6 text-xs text-[#a1a1aa]">
          <div>PRIVATE WEALTH & C-SUITE RISK BOARD</div>
          <span className="w-px h-4 bg-[#2e2b20]"></span>
          <span className="text-[#d4af37] font-semibold">DIRECTIVE: MANDATORY RESOLUTION</span>
        </div>
      </div>

      {/* ─── Executive Board Presentation Grid ──────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden p-8 gap-8">
        {/* Left: High-Net-Worth Docket (4 cols) */}
        <div className="lg:col-span-4 rounded-xl border border-[#2e2b20] bg-[#121216] p-4 flex flex-col overflow-hidden shadow-2xl">
          <div className="pb-3 mb-3 border-b border-[#2e2b20] flex items-center justify-between text-xs text-[#a1a1aa] uppercase tracking-wider">
            <span>Executive Risk Docket</span>
            <span className="text-[#d4af37]">12 High-Value Cases</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#1e1d1a] space-y-1 pr-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-3.5 rounded-lg text-left transition-all ${
                    isSelected
                      ? "bg-[#1f1d17] border border-[#d4af37]/60 shadow-lg text-[#d4af37]"
                      : "hover:bg-[#16161b] border border-transparent text-[#a1a1aa]"
                  }`}
                >
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-bold text-xs text-[#f4f4f5]">{item.id}</span>
                    <span className={`font-mono text-xs font-bold ${item.score >= 90 ? "text-[#f87171]" : "text-[#d4af37]"}`}>
                      {item.score.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs text-[#71717a]">
                    <span>{item.amount}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#201e18] text-[#d4af37] border border-[#d4af37]/20">
                      {item.vertical}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Executive Impact Hero Deck (8 cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-6 overflow-y-auto pr-2">
          {/* Executive Liability & Exposure Card */}
          <div className="rounded-xl border border-[#2e2b20] bg-gradient-to-b from-[#181714] to-[#121216] p-8 relative overflow-hidden shadow-2xl">
            {/* Ambient Gold Halo */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative z-10 flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
              <div>
                <span className="text-xs font-semibold tracking-widest uppercase text-[#d4af37] block mb-1">
                  BOARD-LEVEL EXPOSURE BRIEFING
                </span>
                <h2 className="text-3xl font-bold tracking-tight text-white">{activeCase.transaction_id}</h2>
                <p className="text-xs text-[#a1a1aa] mt-1">{activeCase.originator.name} → {activeCase.beneficiary.name}</p>
              </div>
              <div className="text-left sm:text-right">
                <span className="text-xs text-[#a1a1aa] block uppercase tracking-wider">AGGREGATE AT RISK</span>
                <span className="text-3xl font-bold font-mono text-[#d4af37]">{displayAmount}</span>
              </div>
            </div>

            {/* Impact Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-[#2e2b20] pt-6">
              <div className="p-4 rounded-lg bg-[#0d0d0f] border border-[#2e2b20]">
                <span className="text-[11px] text-[#a1a1aa] block uppercase">Financial Sanctions Risk</span>
                <span className="text-xl font-bold font-mono text-[#f87171] mt-1 block">300% Penalty</span>
                <span className="text-[10px] text-[#71717a] mt-0.5 block">Statutory liability if unaddressed</span>
              </div>
              <div className="p-4 rounded-lg bg-[#0d0d0f] border border-[#2e2b20]">
                <span className="text-[11px] text-[#a1a1aa] block uppercase">Ensemble Confidence</span>
                <span className="text-xl font-bold font-mono text-[#d4af37] mt-1 block">{activeCase.composite_score.toFixed(1)} / 100</span>
                <span className="text-[10px] text-[#71717a] mt-0.5 block">Unanimous 3-model agreement</span>
              </div>
              <div className="p-4 rounded-lg bg-[#0d0d0f] border border-[#2e2b20]">
                <span className="text-[11px] text-[#a1a1aa] block uppercase">Legal SLA Horizon</span>
                <span className="text-xl font-bold font-mono text-white mt-1 block">{activeCase.sla_remaining}</span>
                <span className="text-[10px] text-[#71717a] mt-0.5 block">Until regulatory breach deadline</span>
              </div>
            </div>
          </div>

          {/* Narrative Finding */}
          <div className="rounded-xl border border-[#2e2b20] bg-[#121216] p-6 space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#d4af37]">Chief Compliance Officer Briefing</h3>
            <p className="text-sm text-[#d4d4d8] leading-relaxed">
              {activeCase.narrative}
            </p>
          </div>

          {/* C-Suite Authority Execution Panel */}
          <div className="rounded-xl border border-[#2e2b20] bg-[#141419] p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="font-bold text-sm text-white">Directive: Exercise Institutional Authority</h4>
              <p className="text-xs text-[#a1a1aa] mt-0.5">Decision is cryptographically counter-signed into the permanent audit ledger.</p>
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => onAction("C-Suite Signed: Escalate to Board & FIU", activeCase.transaction_id)}
                className="flex-1 sm:flex-initial px-6 py-3 rounded-lg bg-gradient-to-r from-[#d4af37] to-[#b38f28] hover:opacity-90 text-black font-bold text-xs uppercase tracking-wider shadow-lg transition-all"
              >
                Sign & Escalate
              </button>
              <button
                onClick={() => onAction("C-Suite Signed: File SAR", activeCase.transaction_id)}
                className="flex-1 sm:flex-initial px-6 py-3 rounded-lg bg-[#24211a] hover:bg-[#2d2920] border border-[#d4af37]/40 text-[#d4af37] font-bold text-xs uppercase tracking-wider transition-all"
              >
                Submit SAR
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
