import React from "react";
import { Pulse, ShieldCheck, Crosshair, Lightning } from "../PhosphorIcons";

export default function CyberSpectrogram({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  // Spectrogram bars (simulated 24 frequency bands)
  const bands = [45, 60, 75, 90, 100, 95, 80, 65, 50, 40, 70, 88, 98, 92, 78, 60, 45, 30, 85, 94, 99, 82, 60, 40];

  return (
    <div className="flex-1 flex flex-col bg-[#020409] text-[#e2e8f0] font-mono text-xs select-none">
      {/* ─── Streaming Spectral Header ──────────────────────────────────── */}
      <div className="h-8 border-b border-[#111c33] bg-[#070c18] px-4 flex items-center justify-between text-[11px] text-[#64748b]">
        <div className="flex items-center gap-3">
          <span className="text-[#10b981] font-bold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#10b981] animate-ping"></span>
            SIGINT//SPECTRAL_STREAM: 4.88 GHz
          </span>
          <span className="text-[#06b6d4]">CH_ID: TRF_46631</span>
          <span className="hidden md:inline text-[#475569]">FOURIER TRANSFORM: ACTIVE</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-[#8b5cf6]">ENTROPY: 0.9984</span>
          <span className="text-[#10b981]">NOISE FLOOR: -84dBm</span>
        </div>
      </div>

      {/* ─── Spectral Workstation ───────────────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Column: Frequency Feed (3 cols) */}
        <div className="lg:col-span-3 border-r border-[#111c33] flex flex-col bg-[#030611]">
          <div className="p-3 border-b border-[#111c33] bg-[#070c18] text-[10px] uppercase font-bold text-[#64748b] flex justify-between">
            <span>Signal Spectrum [12]</span>
            <span className="text-[#10b981]">SYNC</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#0a1224] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-2 text-left transition-colors flex items-center justify-between ${
                    isSelected
                      ? "bg-[#0c1833] text-[#06b6d4] border-l-2 border-[#06b6d4]"
                      : "hover:bg-[#070e1e] text-[#64748b]"
                  }`}
                >
                  <div>
                    <div className="font-bold text-[11px] text-[#e2e8f0]">{item.id.slice(0, 15)}</div>
                    <div className="text-[10px] text-[#64748b]">{item.amount}</div>
                  </div>
                  <span className={`font-bold ${item.score >= 90 ? "text-[#ef4444]" : "text-[#10b981]"}`}>
                    {item.score.toFixed(1)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center Column: Live Spectrogram Visualizer (6 cols) */}
        <div className="lg:col-span-6 border-r border-[#111c33] flex flex-col overflow-y-auto p-5 space-y-5 bg-[#020409]">
          {/* Target Metadata Banner */}
          <div className="border border-[#111c33] bg-[#070c18] p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#06b6d4] uppercase tracking-widest block mb-1">
                SPECTROGRAM SIGNAL DECOMPOSITION
              </span>
              <h2 className="text-xl font-bold text-white">{activeCase.transaction_id}</h2>
              <span className="text-[10px] text-[#64748b]">{displayAmount} · SWIFT MT103 WIRE</span>
            </div>
            <div className="text-right">
              <span className="text-3xl font-black text-[#10b981]">{activeCase.composite_score.toFixed(1)}</span>
              <span className="text-[9px] text-[#ef4444] block font-bold">▲ ANOMALY DETECTED</span>
            </div>
          </div>

          {/* Audio-Style Frequency Spectrogram Waterfall Visual */}
          <div className="border border-[#111c33] bg-[#040813] p-4 space-y-3">
            <div className="flex justify-between text-[10px] text-[#64748b]">
              <span>FREQUENCY BANDS [20Hz - 20kHz]</span>
              <span className="text-[#06b6d4]">PEAK MAGNITUDE: +18.4 dB</span>
            </div>

            {/* Spectrogram Bar Columns */}
            <div className="h-32 flex items-end justify-between gap-1 pt-4 border-b border-[#111c33]">
              {bands.map((val, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                  <div
                    className={`w-full rounded-t transition-all duration-500 ${
                      val >= 90
                        ? "bg-gradient-to-t from-[#ef4444] to-[#f59e0b]"
                        : val >= 70
                        ? "bg-gradient-to-t from-[#06b6d4] to-[#10b981]"
                        : "bg-[#111c33]"
                    }`}
                    style={{ height: `${val}%` }}
                  ></div>
                </div>
              ))}
            </div>

            <div className="flex justify-between text-[9px] text-[#475569]">
              <span>LOW HARMONICS (RETAIL)</span>
              <span className="text-[#ef4444]">RESONANCE SPIKE: CORRESPONDENT ESCROW</span>
              <span>HIGH (SMURFING)</span>
            </div>
          </div>

          {/* Hexadecimal Memory Dump Ticker */}
          <div className="border border-[#111c33] bg-[#070c18] p-3 space-y-1 text-[10px]">
            <span className="text-[#8b5cf6] font-bold block uppercase">// RAW TELEMETRY MEMORY DUMP</span>
            <div className="text-[#10b981] overflow-x-auto whitespace-nowrap opacity-80">
              0x004F: 4A 61 76 61 73 63 72 69 70 74 20 53 45 4E 54 49 4E 45 4C 5F 41 49 5F 32 30 32 36
            </div>
            <div className="text-[#06b6d4] overflow-x-auto whitespace-nowrap opacity-80">
              0x0060: 53 57 49 46 54 20 4D 54 31 30 33 20 53 47 5F 44 42 53 53 47 53 47 58 58 58 00 00
            </div>
          </div>
        </div>

        {/* Right Column: Signal Intercept (3 cols) */}
        <div className="lg:col-span-3 flex flex-col bg-[#030611] p-4 space-y-4">
          <span className="text-[10px] text-[#10b981] font-bold uppercase tracking-wider block">
            SIGNAL INTERCEPT ORDERS
          </span>

          <div className="space-y-2">
            <button
              onClick={() => onAction("Interception Escalate", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#ef4444]/20 hover:bg-[#ef4444]/30 border border-[#ef4444] text-[#ef4444] font-bold text-xs transition-colors text-left"
            >
              [KILL SWITCH: ESCALATE]
            </button>
            <button
              onClick={() => onAction("Logged SAR Signal", activeCase.transaction_id)}
              className="w-full py-2 px-3 bg-[#06b6d4]/20 hover:bg-[#06b6d4]/30 border border-[#06b6d4] text-[#06b6d4] font-bold text-xs transition-colors text-left"
            >
              [DUMP TO FIU SAR]
            </button>
            <button
              onClick={() => onAction("Suppressed Noise", activeCase.transaction_id)}
              className="w-full py-2 px-3 bg-[#111c33] hover:bg-[#1a2847] text-[#64748b] text-xs transition-colors text-left"
            >
              [SUPPRESS SIGNAL]
            </button>
          </div>

          <div className="border border-[#111c33] p-3 bg-[#070c18] space-y-1 text-[9px] text-[#64748b]">
            <span className="text-white font-bold block">SPECTRAL CHECKSUM</span>
            <div>SHA256: 4f88c12a...09be</div>
            <div className="text-[#10b981]">PHASE LOCK: ACHIEVED</div>
          </div>
        </div>
      </div>
    </div>
  );
}
