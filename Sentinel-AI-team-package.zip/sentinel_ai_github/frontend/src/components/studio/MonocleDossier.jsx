import React from "react";

export default function MonocleDossier({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col bg-[#101114] text-[#f3f2ee] font-serif select-none">
      {/* ─── Editorial Broadsheet Masthead ───────────────────────────────── */}
      <div className="border-b border-[#2b2c34] p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#8e8d88] font-sans block mb-1">
            Tokyo Forensic Bureau · Case Record
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#f3f2ee]">
            The Sentinel Dossier // No. {activeCase.transaction_id}
          </h1>
        </div>

        {/* Red Cinnabar Wax Seal Hanko */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full border-2 border-[#dc2626] text-[#dc2626] flex flex-col items-center justify-center text-center p-1 leading-none font-sans font-black text-[8px] uppercase tracking-tighter shadow-sm transform rotate-[-6deg]">
            <span>ATTESTED</span>
            <span className="text-[10px] font-mono font-bold">2026</span>
            <span>VERIFIED</span>
          </div>
          <div className="text-right font-sans text-xs text-[#8e8d88]">
            <div>SLA WINDOW: <strong className="text-[#f3f2ee]">{activeCase.sla_remaining}</strong></div>
            <div>STATUS: <span className="text-[#dc2626] font-semibold">{activeCase.supervisory_status}</span></div>
          </div>
        </div>
      </div>

      {/* ─── Two-Column Investigative Broadsheet ────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden p-6 gap-8">
        {/* Left Column: Roll of Cases (4 cols) */}
        <div className="lg:col-span-4 border-r border-[#2b2c34] pr-6 flex flex-col font-sans">
          <div className="pb-3 mb-3 border-b border-[#2b2c34] flex items-center justify-between text-xs text-[#8e8d88] uppercase tracking-wider">
            <span>Roll of Inquiries</span>
            <span>12 Entries</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#202128]">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full py-3 px-2 text-left transition-colors flex items-baseline justify-between ${
                    isSelected ? "bg-[#18191e] text-[#f3f2ee]" : "hover:bg-[#14151a] text-[#8e8d88]"
                  }`}
                >
                  <div>
                    <div className="font-mono text-xs font-semibold">{item.id}</div>
                    <div className="text-[11px] text-[#8e8d88]">{item.amount}</div>
                  </div>
                  <span className={`font-mono text-xs font-bold ${item.score >= 90 ? "text-[#dc2626]" : "text-[#d97706]"}`}>
                    {item.score.toFixed(1)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Editorial Narrative & Evidence (8 cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-6 overflow-y-auto pr-2">
          {/* Headline Finding Block */}
          <div className="border-b border-[#2b2c34] pb-6 space-y-2">
            <span className="font-sans text-xs uppercase tracking-widest text-[#dc2626] font-semibold">
              Executive Investigative Finding
            </span>
            <div className="text-3xl font-bold tracking-tight text-[#f3f2ee]">
              Suspicious Offshore Escrow Routing: {displayAmount}
            </div>
            <p className="text-sm text-[#bab8b0] leading-relaxed italic pt-2">
              "{activeCase.narrative}"
            </p>
          </div>

          {/* Statistical Ledger Table */}
          <div className="font-sans text-xs border border-[#2b2c34] rounded bg-[#15161b] p-4 space-y-3">
            <span className="text-[11px] uppercase tracking-wider text-[#8e8d88] font-bold block">
              Statistical Signal Attributions
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-[#2b2c34] pt-3">
              <div>
                <span className="text-[#8e8d88] block text-[10px]">Isolation Forest</span>
                <span className="text-lg font-mono font-bold text-[#f3f2ee]">{(activeCase.isoforest_score * 100).toFixed(1)}%</span>
                <span className="text-[#dc2626] block text-[10px]">Variance Anomaly</span>
              </div>
              <div>
                <span className="text-[#8e8d88] block text-[10px]">Autoencoder Loss</span>
                <span className="text-lg font-mono font-bold text-[#dc2626]">{(activeCase.autoencoder_score * 100).toFixed(1)}%</span>
                <span className="text-[#8e8d88] block text-[10px]">4.8σ Projection</span>
              </div>
              <div>
                <span className="text-[#8e8d88] block text-[10px]">Benford's First Digit</span>
                <span className="text-lg font-mono font-bold text-[#10b981]">Conformant</span>
                <span className="text-[#8e8d88] block text-[10px]">Natural Scale</span>
              </div>
            </div>
          </div>

          {/* Editorial Sign-off Controls */}
          <div className="font-sans pt-4 border-t border-[#2b2c34] flex flex-wrap items-center justify-between gap-4">
            <div className="text-xs text-[#8e8d88]">
              Senior Inspector Sign-off: <strong className="text-[#f3f2ee]">Officer Hiroshi Tanaka</strong>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onAction("Dismissed with Inspector Note", activeCase.transaction_id)}
                className="px-4 py-2 border border-[#2b2c34] hover:bg-[#18191e] text-[#8e8d88] text-xs font-medium rounded transition-colors"
              >
                Dismiss Inquiry
              </button>
              <button
                onClick={() => onAction("Escalated to Tokyo Board", activeCase.transaction_id)}
                className="px-4 py-2 bg-[#dc2626] hover:bg-[#b91c1c] text-white text-xs font-semibold rounded shadow-sm transition-colors"
              >
                Escalate to Board
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
