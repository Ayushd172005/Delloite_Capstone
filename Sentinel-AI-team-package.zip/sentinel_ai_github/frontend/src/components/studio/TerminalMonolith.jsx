import React from "react";
import { ShieldCheck, Warning, WarningOctagon, CheckCircle, ArrowUpRight, ArrowsClockwise } from "../PhosphorIcons";

export default function TerminalMonolith({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col font-mono text-xs bg-[#0c0d0e] text-[#f8fafc] select-none">
      {/* ─── Ticker Tape Bar ────────────────────────────────────────────── */}
      <div className="h-7 border-b border-[#26272b] bg-[#141518] px-3 flex items-center justify-between text-[11px] text-[#94a3b8] tracking-wider">
        <div className="flex items-center gap-4">
          <span className="text-[#f59e0b] font-bold flex items-center gap-1">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#f59e0b] animate-pulse"></span>
            SENTINEL//MONOLITH.V4
          </span>
          <span className="hidden md:inline text-[#64748b]">|</span>
          <span className="hidden md:inline">NY: 14:19:55</span>
          <span className="hidden md:inline">LDN: 19:19:55</span>
          <span className="text-[#f8fafc] font-semibold">BOM: 23:49:55</span>
          <span className="hidden lg:inline text-[#64748b]">|</span>
          <span className="hidden lg:inline text-[#10b981]">FEED: 345,002 MSG/S</span>
          <span className="hidden lg:inline text-[#38bdf8]">LATENCY: 11.4MS</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#e2e8f0]">HOLD: ₹4,92,000</span>
          <span className="bg-[#26272b] px-1.5 py-0.5 text-[#f59e0b] font-semibold">PMLA STATUTORY CEILING</span>
        </div>
      </div>

      {/* ─── Command Prompt Ribbon ──────────────────────────────────────── */}
      <div className="h-8 border-b border-[#26272b] bg-[#0c0d0e] px-3 flex items-center justify-between text-[12px]">
        <div className="flex items-center gap-2 flex-1">
          <span className="text-[#f59e0b] font-bold">&gt;</span>
          <span className="text-[#64748b]">SYS//CMD:</span>
          <span className="text-[#f8fafc] font-semibold tracking-wide">EXECUTE_SURVEILLANCE_TRIAGE --CASE={activeCase.transaction_id} --CONFIDENCE=MAX</span>
          <span className="w-2 h-3.5 bg-[#f59e0b] inline-block animate-pulse"></span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-[#64748b]">
          <span>TAB: TOGGLE</span>
          <span>ENTER: COMMIT</span>
          <span>ESC: ABORT</span>
        </div>
      </div>

      {/* ─── Main 4-Column Terminal Matrix ──────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
        {/* Column 1: Queue Stream (3 cols) */}
        <div className="md:col-span-3 border-r border-[#26272b] flex flex-col bg-[#0c0d0e]">
          <div className="h-7 border-b border-[#26272b] bg-[#141518] px-3 flex items-center justify-between text-[10px] font-bold tracking-wider text-[#94a3b8] uppercase">
            <span>Surveillance Queue [12]</span>
            <span>Risk Score</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#1e2024]">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full px-3 py-2 text-left flex items-center justify-between transition-colors ${
                    isSelected ? "bg-[#26272b] text-[#f59e0b]" : "hover:bg-[#141518] text-[#cbd5e1]"
                  }`}
                >
                  <div className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-[11px]">{item.id.slice(0, 16)}</span>
                      <span className="text-[9px] px-1 bg-[#1c1d22] text-[#94a3b8]">{item.vertical}</span>
                    </div>
                    <span className="text-[10px] text-[#64748b]">{item.amount} · {item.time}</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className={`font-bold text-[12px] tabular-nums ${item.score >= 90 ? "text-[#ef4444]" : item.score >= 75 ? "text-[#f59e0b]" : "text-[#10b981]"}`}>
                      {item.score.toFixed(1)}
                    </span>
                    <span className="text-[9px] text-[#64748b]">{item.tier}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Column 2: Statistical Signal Decomp (3 cols) */}
        <div className="md:col-span-3 border-r border-[#26272b] flex flex-col bg-[#101114]">
          <div className="h-7 border-b border-[#26272b] bg-[#141518] px-3 flex items-center justify-between text-[10px] font-bold tracking-wider text-[#94a3b8] uppercase">
            <span>Model Signals</span>
            <span>Threshold: 65.0%</span>
          </div>
          <div className="p-3 space-y-4 overflow-y-auto flex-1">
            {/* Composite Hero Metric */}
            <div className="border border-[#26272b] bg-[#141518] p-3 text-center space-y-1">
              <span className="text-[10px] text-[#94a3b8] uppercase tracking-wider block">COMPOSITE ANOMALY RATING</span>
              <div className="text-3xl font-black text-[#f59e0b] tabular-nums tracking-tight">
                {activeCase.composite_score.toFixed(1)} <span className="text-xs text-[#94a3b8]">/ 100</span>
              </div>
              <div className="text-[10px] text-[#ef4444] font-bold tracking-wide">
                ▲ IMMEDIATE SUPERVISORY INTERVENTION MANDATED
              </div>
            </div>

            {/* Isolation Forest ASCII Meter */}
            <div className="space-y-1 border-t border-[#1e2024] pt-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#cbd5e1]">ISOLATION FOREST (OUTLIER)</span>
                <span className="text-[#f59e0b] font-bold">{(activeCase.isoforest_score * 100).toFixed(1)}%</span>
              </div>
              <div className="text-[#f59e0b] font-mono tracking-widest text-[11px]">
                [██████████████████░░] EXCEEDED
              </div>
              <span className="text-[10px] text-[#64748b]">12 Partition splits // z-score: 8.77</span>
            </div>

            {/* Autoencoder MSE ASCII Meter */}
            <div className="space-y-1 border-t border-[#1e2024] pt-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#cbd5e1]">AUTOENCODER RECONSTRUCTION</span>
                <span className="text-[#ef4444] font-bold">{(activeCase.autoencoder_score * 100).toFixed(1)}%</span>
              </div>
              <div className="text-[#ef4444] font-mono tracking-widest text-[11px]">
                [████████████████████] SEVERE 4.8σ
              </div>
              <span className="text-[10px] text-[#64748b]">Manifold projection loss out-of-bounds</span>
            </div>

            {/* Benford Law */}
            <div className="space-y-1 border-t border-[#1e2024] pt-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#cbd5e1]">BENFORD 1ST DIGIT TEST</span>
                <span className={activeCase.benford_flag ? "text-[#f59e0b] font-bold" : "text-[#10b981] font-bold"}>
                  {activeCase.benford_flag ? "ANOMALOUS (p<0.01)" : "CONFORMANT"}
                </span>
              </div>
              <div className="text-[#64748b] text-[10px]">
                First digit distribution conforms to chi-sq critical boundary.
              </div>
            </div>

            {/* Triggered Rule Flags */}
            <div className="border border-[#26272b] p-2 space-y-1 bg-[#0c0d0e]">
              <span className="text-[9px] text-[#94a3b8] uppercase font-bold block">TRIGGERED HEURISTICS</span>
              {activeCase.rules_triggered.map((rule, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-[10px] text-[#cbd5e1]">
                  <span className="text-[#ef4444]">►</span>
                  <span>{rule}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Column 3: Forensic Dossier & Routing (4 cols) */}
        <div className="md:col-span-4 border-r border-[#26272b] flex flex-col bg-[#0c0d0e]">
          <div className="h-7 border-b border-[#26272b] bg-[#141518] px-3 flex items-center justify-between text-[10px] font-bold tracking-wider text-[#94a3b8] uppercase">
            <span>Forensic Dossier // Entity Conduit</span>
            <span>SLA: {activeCase.sla_remaining}</span>
          </div>
          <div className="p-3 space-y-4 overflow-y-auto flex-1">
            {/* Target Value Box */}
            <div className="border border-[#26272b] bg-[#141518] p-3 space-y-1">
              <div className="flex justify-between items-baseline">
                <span className="text-[10px] text-[#94a3b8] uppercase">TRANSACTION VALUE</span>
                <span className="text-[10px] text-[#f59e0b] font-semibold">{activeCase.vertical.toUpperCase()} CORRIDOR</span>
              </div>
              <div className="text-2xl font-bold text-[#f8fafc] tabular-nums">{displayAmount}</div>
              <div className="text-[10px] text-[#64748b]">{activeCase.timestamp}</div>
            </div>

            {/* Hop Conduit Matrix */}
            <div className="border border-[#26272b] p-3 space-y-2 bg-[#101114]">
              <span className="text-[10px] text-[#94a3b8] font-bold uppercase tracking-wider block">CONDUIT TOPOLOGY (HOP 0 → HOP 1)</span>
              
              <div className="p-2 border border-[#1e2024] bg-[#0c0d0e] space-y-0.5">
                <div className="flex justify-between text-[10px]">
                  <span className="text-[#38bdf8] font-bold">HOP 0: DEBTOR</span>
                  <span className="text-[#10b981]">KYC LEVEL 3</span>
                </div>
                <div className="text-[11px] font-bold text-[#f8fafc]">{activeCase.originator.name}</div>
                <div className="text-[10px] text-[#64748b]">{activeCase.originator.id} · {activeCase.originator.jurisdiction}</div>
              </div>

              <div className="text-center text-[#f59e0b] font-bold text-[10px] tracking-widest">
                ▼ WIRE TRANSFER SWIFT [MT103] ▼
              </div>

              <div className="p-2 border border-[#ef4444]/40 bg-[#1c1214] space-y-0.5">
                <div className="flex justify-between text-[10px]">
                  <span className="text-[#ef4444] font-bold">HOP 1: BENEFICIARY</span>
                  <span className="text-[#f59e0b]">OFFSHORE ESCROW</span>
                </div>
                <div className="text-[11px] font-bold text-[#f8fafc]">{activeCase.beneficiary.name}</div>
                <div className="text-[10px] text-[#94a3b8]">{activeCase.beneficiary.id} · {activeCase.beneficiary.jurisdiction}</div>
                <div className="text-[9px] text-[#ef4444] font-semibold pt-1">WARNING: Entity incorporated 42 days ago. Turnover mismatch.</div>
              </div>
            </div>

            {/* Narrative Findings */}
            <div className="border border-[#26272b] p-2.5 bg-[#141518] space-y-1">
              <span className="text-[10px] text-[#94a3b8] font-bold uppercase block">FORENSIC SYNTHESIS</span>
              <p className="text-[11px] text-[#cbd5e1] leading-relaxed">
                {activeCase.narrative}
              </p>
            </div>
          </div>
        </div>

        {/* Column 4: Command Action Terminal (2 cols) */}
        <div className="md:col-span-2 flex flex-col bg-[#141518]">
          <div className="h-7 border-b border-[#26272b] bg-[#1a1c22] px-3 flex items-center justify-between text-[10px] font-bold tracking-wider text-[#94a3b8] uppercase">
            <span>Actions [F-KEYS]</span>
          </div>
          <div className="p-3 flex flex-col gap-2.5 flex-1 justify-between">
            <div className="space-y-2">
              <button
                onClick={() => onAction("Approve Transfer", activeCase.transaction_id)}
                className="w-full py-2 px-2.5 bg-[#1e2024] hover:bg-[#2a2d33] border border-[#383a42] text-left text-[#cbd5e1] font-bold flex items-center justify-between group transition-colors"
              >
                <span>[F1] APPROVE</span>
                <span className="text-[9px] text-[#10b981] group-hover:translate-x-0.5 transition-transform">✓</span>
              </button>

              <button
                onClick={() => onAction("Escalate to FIU", activeCase.transaction_id)}
                className="w-full py-2 px-2.5 bg-[#2d1b10] hover:bg-[#3d2616] border border-[#f59e0b]/50 text-left text-[#f59e0b] font-bold flex items-center justify-between group transition-colors"
              >
                <span>[F2] ESCALATE</span>
                <span className="text-[9px] text-[#f59e0b] group-hover:translate-x-0.5 transition-transform">▲</span>
              </button>

              <button
                onClick={() => onAction("File Suspicious Activity Report (SAR)", activeCase.transaction_id)}
                className="w-full py-2 px-2.5 bg-[#2d1215] hover:bg-[#3d181c] border border-[#ef4444]/60 text-left text-[#ef4444] font-bold flex items-center justify-between group transition-colors"
              >
                <span>[F3] FILE SAR</span>
                <span className="text-[9px] text-[#ef4444] group-hover:translate-x-0.5 transition-transform">⚡</span>
              </button>

              <button
                onClick={() => onAction("Dismiss Alert", activeCase.transaction_id)}
                className="w-full py-2 px-2.5 bg-[#18191c] hover:bg-[#222327] border border-[#26272b] text-left text-[#64748b] font-bold flex items-center justify-between transition-colors"
              >
                <span>[F4] DISMISS</span>
                <span className="text-[9px]">✕</span>
              </button>
            </div>

            {/* Cryptographic Ledger Seal */}
            <div className="border border-[#26272b] p-2 bg-[#0c0d0e] space-y-1 text-[9px] text-[#64748b]">
              <span className="text-[#94a3b8] font-bold uppercase block">CHAIN OF CUSTODY</span>
              <div>SIG: 0x8F92...B310</div>
              <div>ACTOR: OFFICER_IN_99</div>
              <div className="text-[#10b981]">ATTESTATION VERIFIED</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
