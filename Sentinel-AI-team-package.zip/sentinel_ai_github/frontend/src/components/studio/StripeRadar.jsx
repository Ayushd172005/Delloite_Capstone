import React, { useState } from "react";
import { ShieldCheck, WarningCircle, CheckCircle, Clock, ChartLine, ArrowUpRight } from "../PhosphorIcons";

export default function StripeRadar({ activeCase, queue, onSelectCase, onAction, currency }) {
  const [activeTab, setActiveTab] = useState("overview");
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col bg-[#0a0f1d] text-[#f8fafc] font-sans select-none">
      {/* ─── Modern Polished Radar Header ───────────────────────────────── */}
      <div className="h-14 border-b border-[#1e2942] bg-[#0d1427]/80 backdrop-blur-md px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00e599]"></span>
            <span className="font-bold text-sm tracking-tight text-white">Radar High-Risk Evaluation</span>
          </div>
          <span className="text-xs text-[#64748b]">|</span>
          <span className="text-xs font-mono text-[#94a3b8]">{activeCase.transaction_id}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#ef4444]/15 text-[#f87171] border border-[#ef4444]/30">
            Critical Risk Score: {activeCase.composite_score.toFixed(1)}
          </span>
          <button
            onClick={() => onAction("Escalate to Review", activeCase.transaction_id)}
            className="px-3.5 py-1.5 rounded-lg bg-[#3b82f6] hover:bg-[#2563eb] text-white font-medium text-xs shadow-sm transition-all"
          >
            Review Case
          </button>
        </div>
      </div>

      {/* ─── Main Content Grid ──────────────────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden p-6 gap-6">
        {/* Left Column: Transaction Feed (4 cols) */}
        <div className="lg:col-span-4 flex flex-col rounded-2xl border border-[#1e2942] bg-[#11192e] overflow-hidden">
          <div className="p-4 border-b border-[#1e2942] flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#94a3b8]">Live Transactions</span>
            <span className="text-xs text-[#00e599] font-medium">Auto-Refreshing</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#18233c] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-3 rounded-xl text-left transition-all ${
                    isSelected
                      ? "bg-[#182442] border border-[#3b82f6]/40 shadow-sm"
                      : "hover:bg-[#152038] border border-transparent"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-white">{item.id}</span>
                    <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded-full ${
                      item.score >= 90 ? "bg-[#ef4444]/20 text-[#f87171]" : "bg-[#f59e0b]/20 text-[#fbbf24]"
                    }`}>
                      {item.score.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-[#94a3b8]">
                    <span className="font-medium text-[#cbd5e1]">{item.amount}</span>
                    <span>{item.vertical} · {item.time}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Case Deep-Dive & Sparklines (8 cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-6 overflow-y-auto">
          {/* Hero Risk Summary Card */}
          <div className="rounded-2xl border border-[#1e2942] bg-[#11192e] p-6 relative overflow-hidden shadow-xl">
            <div className="flex items-start justify-between mb-6">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#00e599] block mb-1">
                  Radar AI Risk Attribution
                </span>
                <h2 className="text-2xl font-bold tracking-tight text-white">{activeCase.transaction_id}</h2>
                <span className="text-xs text-[#94a3b8]">{activeCase.originator.name} → {activeCase.beneficiary.name}</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-[#94a3b8] block">Total Amount</span>
                <span className="text-2xl font-bold font-mono text-white">{displayAmount}</span>
              </div>
            </div>

            {/* Sparkline Curve SVG (Simulated 30-Day Velocity) */}
            <div className="p-4 rounded-xl bg-[#0d1427] border border-[#1e2942] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-[#cbd5e1]">30-Day Cumulative Exposure Velocity</span>
                <span className="text-[#f87171] font-bold">+340% Spike Detected</span>
              </div>
              <div className="h-20 w-full relative">
                <svg className="w-full h-full" viewBox="0 0 400 80" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 0 65 Q 50 60, 100 58 T 200 55 T 280 50 T 340 30 T 400 10 L 400 80 L 0 80 Z"
                    fill="url(#sparkGrad)"
                  />
                  <path
                    d="M 0 65 Q 50 60, 100 58 T 200 55 T 280 50 T 340 30 T 400 10"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="2.5"
                  />
                  <circle cx="400" cy="10" r="4" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                </svg>
              </div>
            </div>

            {/* Model Confidence Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-[#1e2942]">
              <div className="p-3 rounded-xl bg-[#0d1427] border border-[#1e2942]">
                <span className="text-[11px] text-[#94a3b8] block">Isolation Forest</span>
                <span className="text-lg font-bold font-mono text-[#3b82f6]">{(activeCase.isoforest_score * 100).toFixed(1)}%</span>
                <span className="text-[10px] text-[#94a3b8] block mt-0.5">Partition deviation</span>
              </div>
              <div className="p-3 rounded-xl bg-[#0d1427] border border-[#1e2942]">
                <span className="text-[11px] text-[#94a3b8] block">Autoencoder MSE</span>
                <span className="text-lg font-bold font-mono text-[#f87171]">{(activeCase.autoencoder_score * 100).toFixed(1)}%</span>
                <span className="text-[10px] text-[#94a3b8] block mt-0.5">4.8σ Reconstruction loss</span>
              </div>
              <div className="p-3 rounded-xl bg-[#0d1427] border border-[#1e2942]">
                <span className="text-[11px] text-[#94a3b8] block">Benford Conformity</span>
                <span className="text-lg font-bold font-mono text-[#00e599]">Natural</span>
                <span className="text-[10px] text-[#94a3b8] block mt-0.5">Digit distribution valid</span>
              </div>
            </div>
          </div>

          {/* Action Decision Dock */}
          <div className="rounded-2xl border border-[#1e2942] bg-[#11192e] p-6 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-white">Recommended Directive: File SAR</h3>
              <p className="text-xs text-[#94a3b8] mt-0.5">Case meets FinCEN/FIU mandatory reporting threshold.</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onAction("Dismissed as False Positive", activeCase.transaction_id)}
                className="px-4 py-2 rounded-xl bg-[#18233c] hover:bg-[#202e4d] text-[#94a3b8] text-xs font-semibold transition-all"
              >
                Dismiss
              </button>
              <button
                onClick={() => onAction("Submitted SAR Filing to Authority", activeCase.transaction_id)}
                className="px-5 py-2 rounded-xl bg-[#ef4444] hover:bg-[#dc2626] text-white text-xs font-semibold shadow-md transition-all"
              >
                File Mandatory SAR
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
