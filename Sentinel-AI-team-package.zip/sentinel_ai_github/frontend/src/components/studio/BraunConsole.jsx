import React from "react";

export default function BraunConsole({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  // Angle for analog needle: 0% = -50deg, 100% = +50deg
  const needleDeg = -50 + (activeCase.composite_score / 100) * 100;

  return (
    <div className="flex-1 flex flex-col bg-[#1a1a1c] text-[#e5e7eb] font-sans select-none">
      {/* ─── Industrial Hardware Faceplate Header ───────────────────────── */}
      <div className="h-12 border-b border-[#37383f] bg-[#222327] px-6 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-[#d97706] shadow-[0_0_8px_#d97706]"></div>
          <span className="font-mono text-xs font-bold uppercase tracking-widest text-[#e5e7eb]">
            BRAUN SYSTEM // UNIT 04-DISCRIMINATOR
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-[#9ca3af]">
          <span>SERIAL: SN-46631-IN</span>
          <span>CALIBRATION: 99.8%</span>
        </div>
      </div>

      {/* ─── Modular Equipment Rack ─────────────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden p-6 gap-6">
        {/* Unit A: Queue Bay (4 cols) */}
        <div className="lg:col-span-4 rounded-lg border border-[#37383f] bg-[#222327] flex flex-col overflow-hidden shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]">
          <div className="p-3 border-b border-[#37383f] bg-[#28292f] flex items-center justify-between text-xs font-mono font-bold uppercase text-[#9ca3af]">
            <span>BAY 01 // INPUT CHANNELS</span>
            <span>12 SIGNALS</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#2c2d35] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-2.5 text-left rounded transition-colors flex items-center justify-between ${
                    isSelected
                      ? "bg-[#18191c] border border-[#d97706]/60 text-[#d97706]"
                      : "hover:bg-[#28292f] border border-transparent text-[#9ca3af]"
                  }`}
                >
                  <div className="font-mono text-xs font-semibold">
                    <div>{item.id.slice(0, 16)}</div>
                    <div className="text-[10px] text-[#6b7280]">{item.amount}</div>
                  </div>
                  <div className="text-right font-mono font-bold text-xs">
                    <span className={item.score >= 90 ? "text-[#ef4444]" : "text-[#d97706]"}>
                      {item.score.toFixed(1)}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Unit B: Analog VU Meter & Signal Panel (8 cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-6 overflow-y-auto">
          {/* Main Mechanical Analog Dial Gauge */}
          <div className="rounded-lg border border-[#37383f] bg-[#222327] p-6 shadow-[inset_0_2px_6px_rgba(0,0,0,0.6)]">
            <div className="flex items-center justify-between border-b border-[#37383f] pb-3 mb-6">
              <span className="font-mono text-xs uppercase tracking-wider text-[#9ca3af]">ANALOG DEFLECTION INDICATOR</span>
              <span className="font-mono text-xs text-[#d97706]">RANGE: 0 - 100 INDEX</span>
            </div>

            {/* Dial Face Visual */}
            <div className="flex flex-col items-center justify-center py-4">
              <div className="relative w-72 h-36 border-t-4 border-l-4 border-r-4 border-[#4b4d56] rounded-t-full bg-[#18191c] overflow-hidden flex items-end justify-center shadow-inner">
                {/* Dial Arc Scale Marks */}
                <div className="absolute top-2 w-full text-center font-mono text-[10px] text-[#6b7280] tracking-widest">
                  0 · · · 25 · · · 50 · · · 75 · · · 100
                </div>

                {/* Mechanical Needle */}
                <div
                  className="absolute bottom-0 w-1 h-32 bg-[#ef4444] origin-bottom transition-transform duration-700 ease-out"
                  style={{ transform: `rotate(${needleDeg}deg)` }}
                >
                  <div className="w-2 h-2 rounded-full bg-[#ef4444] -ml-0.5 -mt-1 shadow-sm"></div>
                </div>

                {/* Needle Pivot Cap */}
                <div className="w-8 h-8 rounded-full bg-[#37383f] border-2 border-[#18191c] z-10 -mb-4 shadow-md"></div>
              </div>

              {/* Digital Readout Sub-Plate */}
              <div className="mt-6 text-center">
                <div className="text-3xl font-mono font-bold text-[#e5e7eb] tracking-tight">
                  {activeCase.composite_score.toFixed(1)} <span className="text-xs text-[#9ca3af]">DEVIATION</span>
                </div>
                <div className="text-xs font-mono text-[#d97706] mt-1 font-semibold uppercase">
                  ▲ LIMIT SWITCH TRIPPED: IMMEDIATE ESCALATION
                </div>
              </div>
            </div>
          </div>

          {/* Machine Controls & Rocker Toggles */}
          <div className="rounded-lg border border-[#37383f] bg-[#222327] p-6 shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]">
            <span className="font-mono text-xs uppercase tracking-wider text-[#9ca3af] block mb-4">
              MECHANICAL DISPOSITION SWITCHGEAR
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                onClick={() => onAction("Engaged Relay: Escalate", activeCase.transaction_id)}
                className="py-3 px-4 rounded bg-[#33353c] hover:bg-[#3d3f47] active:translate-y-0.5 border-t border-l border-[#4b4d56] border-b border-r border-[#1a1b1e] text-center font-mono text-xs font-bold text-[#d97706] shadow-sm transition-all"
              >
                [SWITCH A] ESCALATE
              </button>

              <button
                onClick={() => onAction("Engaged Relay: File SAR", activeCase.transaction_id)}
                className="py-3 px-4 rounded bg-[#33353c] hover:bg-[#3d3f47] active:translate-y-0.5 border-t border-l border-[#4b4d56] border-b border-r border-[#1a1b1e] text-center font-mono text-xs font-bold text-[#ef4444] shadow-sm transition-all"
              >
                [SWITCH B] FILE SAR
              </button>

              <button
                onClick={() => onAction("Engaged Relay: Clear", activeCase.transaction_id)}
                className="py-3 px-4 rounded bg-[#33353c] hover:bg-[#3d3f47] active:translate-y-0.5 border-t border-l border-[#4b4d56] border-b border-r border-[#1a1b1e] text-center font-mono text-xs font-bold text-[#9ca3af] shadow-sm transition-all"
              >
                [SWITCH C] RELEASE
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
