import React from "react";
import { Crosshair, WarningOctagon, ShieldCheck, ArrowRight, LockKey, Clock } from "../PhosphorIcons";

export default function PalantirGotham({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col font-mono text-xs bg-[#060b13] text-[#e2e8f0] select-none">
      {/* ─── Classification Security Banner ─────────────────────────────── */}
      <div className="h-8 border-b border-[#1e293b] bg-[#0b1320] px-4 flex items-center justify-between text-[11px] text-[#64748b]">
        <div className="flex items-center gap-3">
          <span className="px-2 py-0.5 bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/40 font-bold tracking-widest text-[10px]">
            RESTRICTED // FININT LEVEL-4
          </span>
          <span className="text-[#00f0ff] tracking-wider font-semibold">SIG-GRID: MUMBAI-SG CORRIDOR</span>
          <span className="hidden md:inline text-[#475569]">LAT: 18°58'30"N // LON: 72°49'33"E</span>
        </div>
        <div className="flex items-center gap-3 text-[10px] text-[#00f0ff]">
          <span className="animate-pulse">● RADAR SWEEP ACTIVE</span>
          <span className="text-[#94a3b8]">THREAT VECTOR: 8.77σ</span>
        </div>
      </div>

      {/* ─── Main Tactical Workstation Grid ─────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Column: Target Queue (3 cols) */}
        <div className="lg:col-span-3 border-r border-[#1e293b] flex flex-col bg-[#070d18]">
          <div className="p-3 border-b border-[#1e293b] bg-[#0b1320] flex items-center justify-between text-[10px] text-[#94a3b8] uppercase tracking-wider font-bold">
            <span className="flex items-center gap-1.5">
              <Crosshair size={13} className="text-[#00f0ff]" />
              Tracked Targets [12]
            </span>
            <span className="text-[#00f0ff]">LOCK ON</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#131e33] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-2.5 text-left border transition-all relative ${
                    isSelected
                      ? "bg-[#0f1d38] border-[#00f0ff]/60 text-[#00f0ff] shadow-sm"
                      : "bg-[#091222] border-[#1e293b]/60 hover:border-[#38bdf8]/40 text-[#94a3b8]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[11px] tracking-wide">{item.id}</span>
                    <span className={`font-bold text-[11px] tabular-nums ${item.score >= 90 ? "text-[#ef4444]" : "text-[#fbbf24]"}`}>
                      [{item.score.toFixed(1)}]
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] mt-1 text-[#64748b]">
                    <span>{item.amount}</span>
                    <span className="text-[#38bdf8]">{item.vertical}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center Column: Topological Link Graph & Telemetry (6 cols) */}
        <div className="lg:col-span-6 border-r border-[#1e293b] flex flex-col overflow-y-auto bg-[#060b13] p-5 space-y-5">
          {/* Target Identification Box */}
          <div className="border border-[#1e293b] bg-[#0b1320] p-4 relative">
            <div className="absolute top-1 left-1 text-[8px] text-[#00f0ff]/60">[+</div>
            <div className="absolute top-1 right-1 text-[8px] text-[#00f0ff]/60">+]</div>
            <div className="absolute bottom-1 left-1 text-[8px] text-[#00f0ff]/60">[+</div>
            <div className="absolute bottom-1 right-1 text-[8px] text-[#00f0ff]/60">+]</div>

            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] text-[#00f0ff] font-bold tracking-widest uppercase block mb-1">// TARGET PRIMARY DOSSIER</span>
                <h1 className="text-xl font-bold tracking-wider text-[#f8fafc]">{activeCase.transaction_id}</h1>
                <p className="text-[10px] text-[#64748b] mt-0.5">TIMESTAMP: {activeCase.timestamp}</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-[#64748b] uppercase block">EXPOSURE SUM</span>
                <span className="text-xl font-bold text-[#00f0ff] tabular-nums">{displayAmount}</span>
              </div>
            </div>

            {/* Score & Tier Callout */}
            <div className="mt-4 pt-4 border-t border-[#1e293b] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl font-black text-[#ef4444] tabular-nums">{activeCase.composite_score.toFixed(1)}</span>
                <div className="text-[10px] leading-tight">
                  <span className="text-[#ef4444] font-bold block">THREAT INDEX CRITICAL</span>
                  <span className="text-[#64748b]">PROBABILITY 0.998</span>
                </div>
              </div>
              <div className="text-right text-[10px]">
                <span className="text-[#fbbf24] font-bold block">SLA BREACH WINDOW</span>
                <span className="text-[#f8fafc] font-mono">{activeCase.sla_remaining}</span>
              </div>
            </div>
          </div>

          {/* Tactical Topological Node Conduit */}
          <div className="border border-[#1e293b] bg-[#091222] p-4 space-y-3">
            <span className="text-[10px] text-[#00f0ff] font-bold tracking-widest uppercase block">// MULTI-HOP ENTITY LINK CONDUIT</span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[10px]">
              <div className="border border-[#1e293b] bg-[#060b13] p-2.5 space-y-1">
                <span className="text-[#38bdf8] font-bold block">NODE-0: ORIGIN</span>
                <div className="font-bold text-[#f8fafc]">{activeCase.originator.name}</div>
                <div className="text-[#64748b]">{activeCase.originator.jurisdiction}</div>
                <div className="text-[#10b981]">KYC: {activeCase.originator.kyc_status}</div>
              </div>

              <div className="border border-[#fbbf24]/30 bg-[#161408] p-2.5 flex flex-col justify-center text-center space-y-1">
                <span className="text-[#fbbf24] font-bold">VECTOR HOP</span>
                <div className="text-[11px] text-[#f8fafc] font-bold">SWIFT MT103</div>
                <div className="text-[#64748b]">VELOCITY: SPIKE</div>
              </div>

              <div className="border border-[#ef4444]/40 bg-[#17090b] p-2.5 space-y-1">
                <span className="text-[#ef4444] font-bold block">NODE-1: TARGET</span>
                <div className="font-bold text-[#f8fafc]">{activeCase.beneficiary.name}</div>
                <div className="text-[#64748b]">{activeCase.beneficiary.jurisdiction}</div>
                <div className="text-[#ef4444] font-bold">AGE: {activeCase.beneficiary.incorporation_age}</div>
              </div>
            </div>
          </div>

          {/* Tactical Telemetry Gauges */}
          <div className="border border-[#1e293b] bg-[#0b1320] p-4 space-y-3">
            <span className="text-[10px] text-[#00f0ff] font-bold tracking-widest uppercase block">// ANOMALY SENSOR ARRAYS</span>
            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#94a3b8]">ISOLATION FOREST [SIG-1]</span>
                <span className="text-[#00f0ff] font-bold">{(activeCase.isoforest_score * 100).toFixed(1)}% OUTLIER</span>
              </div>
              <div className="h-1.5 w-full bg-[#1e293b]">
                <div className="h-full bg-[#00f0ff]" style={{ width: `${activeCase.isoforest_score * 100}%` }}></div>
              </div>

              <div className="flex justify-between pt-1">
                <span className="text-[#94a3b8]">AUTOENCODER MSE [SIG-2]</span>
                <span className="text-[#ef4444] font-bold">{(activeCase.autoencoder_score * 100).toFixed(1)}% LOSS</span>
              </div>
              <div className="h-1.5 w-full bg-[#1e293b]">
                <div className="h-full bg-[#ef4444]" style={{ width: `${activeCase.autoencoder_score * 100}%` }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Intercept Orders & Actions (3 cols) */}
        <div className="lg:col-span-3 flex flex-col bg-[#070d18] p-4 space-y-4">
          <span className="text-[10px] text-[#00f0ff] font-bold tracking-widest uppercase block">// INTERCEPT DIRECTIVES</span>
          <div className="space-y-2">
            <button
              onClick={() => onAction("Escalate to FIU Direct", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#ef4444]/20 hover:bg-[#ef4444]/30 border border-[#ef4444] text-[#ef4444] font-bold text-xs tracking-wider uppercase transition-colors"
            >
              [ORDER ESCALATION]
            </button>
            <button
              onClick={() => onAction("File Statutory SAR", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 bg-[#fbbf24]/20 hover:bg-[#fbbf24]/30 border border-[#fbbf24] text-[#fbbf24] font-bold text-xs tracking-wider uppercase transition-colors"
            >
              [FILE SAR RECORD]
            </button>
            <button
              onClick={() => onAction("Clear Target", activeCase.transaction_id)}
              className="w-full py-2 px-3 bg-[#1e293b] hover:bg-[#334155] border border-[#475569] text-[#94a3b8] font-bold text-xs tracking-wider uppercase transition-colors"
            >
              [DISMISS TARGET]
            </button>
          </div>

          <div className="border border-[#1e293b] p-3 bg-[#0b1320] space-y-1.5 text-[9px] text-[#64748b]">
            <span className="text-[#00f0ff] font-bold uppercase block">// CHAIN VERIFICATION</span>
            <div>CLEARANCE: TOP SECRET / FININT</div>
            <div>STAMP: 20260912-GOTHAM-09</div>
            <div className="text-[#10b981]">SYSTEM INTEGRITY: VERIFIED 100%</div>
          </div>
        </div>
      </div>
    </div>
  );
}
