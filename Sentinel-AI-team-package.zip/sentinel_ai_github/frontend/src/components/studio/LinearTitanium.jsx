import React from "react";
import { ShieldCheck, Warning, ArrowUpRight, CheckCircle, Clock, Sparkle, LockKey } from "../PhosphorIcons";

export default function LinearTitanium({ activeCase, queue, onSelectCase, onAction, currency }) {
  const isINR = currency === "INR";
  const displayAmount = isINR ? `₹${activeCase.amountINR.toLocaleString("en-IN")}` : `$${activeCase.amountUSD.toLocaleString("en-US")}`;

  return (
    <div className="flex-1 flex flex-col font-sans bg-[#08090a] text-[#f4f4f5] select-none">
      {/* ─── Top Floating Minimal Command Bar ────────────────────────────── */}
      <div className="h-12 border-b border-[#1f2024] bg-[#0c0d0f]/80 backdrop-blur-md px-6 flex items-center justify-between text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-[#a1a1aa]">
            <span className="text-[#71717a]">Surveillance</span>
            <span className="text-[#3f3f46]">/</span>
            <span className="text-[#f4f4f5] font-medium">{activeCase.transaction_id}</span>
          </div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#6366f1]/10 text-[#818cf8] border border-[#6366f1]/20">
            <span className="w-1.5 h-1.5 rounded-full bg-[#6366f1] animate-pulse"></span>
            Linear Titanium Grade
          </span>
        </div>
        <div className="flex items-center gap-4 text-[#71717a]">
          <div className="flex items-center gap-1.5 text-[11px]">
            <Clock size={13} className="text-[#a1a1aa]" />
            <span>SLA: <strong className="text-[#f4f4f5] font-mono">{activeCase.sla_remaining}</strong></span>
          </div>
          <span className="w-px h-3.5 bg-[#27272a]"></span>
          <span className="font-mono text-[11px] text-[#a1a1aa]">CONFIDENCE: 94.8%</span>
        </div>
      </div>

      {/* ─── 3-Column Fluid Grid ────────────────────────────────────────── */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Column: Quiet Queue (3 cols) */}
        <div className="lg:col-span-3 border-r border-[#1f2024] flex flex-col bg-[#0b0c0e]">
          <div className="px-4 py-3 border-b border-[#1f2024] flex items-center justify-between">
            <span className="text-[11px] font-medium uppercase tracking-wider text-[#71717a]">Queue Stream</span>
            <span className="text-[11px] font-mono text-[#a1a1aa]">12 Cases</span>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-[#18191d] p-2 space-y-1">
            {queue.map((item) => {
              const isSelected = item.id === activeCase.transaction_id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectCase(item.id)}
                  className={`w-full p-3 rounded-lg text-left transition-all relative group ${
                    isSelected
                      ? "bg-[#16171b] border border-[#2e3038] shadow-sm"
                      : "hover:bg-[#121316] border border-transparent text-[#a1a1aa]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`font-mono text-xs font-semibold ${isSelected ? "text-[#f4f4f5]" : "text-[#d4d4d8]"}`}>
                      {item.id}
                    </span>
                    <span className={`text-xs font-mono font-semibold tabular-nums ${item.score >= 90 ? "text-[#f87171]" : "text-[#fbbf24]"}`}>
                      {item.score.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#71717a]">
                    <span>{item.amount}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1f2024] text-[#a1a1aa]">{item.vertical}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center Column: Hero Forensic Dossier (6 cols) */}
        <div className="lg:col-span-6 border-r border-[#1f2024] flex flex-col overflow-y-auto bg-[#08090a] p-6 space-y-6">
          {/* Hero Risk Gauge Card with Ambient Violet Gradient */}
          <div className="relative rounded-xl border border-[#22242a] bg-gradient-to-b from-[#13141a] to-[#0d0e12] p-6 overflow-hidden">
            {/* Ambient Radial Spotlight */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#6366f1]/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative z-10 flex items-start justify-between">
              <div>
                <span className="text-[11px] font-medium tracking-wider uppercase text-[#818cf8] block mb-1">Statistical Anomaly Index</span>
                <h1 className="text-2xl font-bold tracking-tight text-[#f4f4f5]">{activeCase.transaction_id}</h1>
                <p className="text-xs text-[#71717a] mt-0.5">{activeCase.timestamp} · SWIFT Corporate Ingestion</p>
              </div>
              <div className="text-right">
                <span className="text-xs text-[#71717a] block">Gross Amount</span>
                <span className="text-2xl font-bold font-mono text-[#f4f4f5]">{displayAmount}</span>
              </div>
            </div>

            {/* Score Metric Bar */}
            <div className="mt-6 pt-6 border-t border-[#1f2024] flex items-center justify-between">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-extrabold tracking-tight text-[#f4f4f5] font-mono">{activeCase.composite_score.toFixed(1)}</span>
                <span className="text-xs text-[#71717a]">/ 100 Risk</span>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-medium bg-[#ef4444]/15 text-[#f87171] border border-[#ef4444]/30 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#ef4444]"></span>
                Immediate Escalation Tier
              </span>
            </div>
          </div>

          {/* Precision Telemetry Bars */}
          <div className="rounded-xl border border-[#22242a] bg-[#0e0f13] p-5 space-y-4">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[#a1a1aa]">Model Signals Decomposition</h2>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-[#d4d4d8]">Isolation Forest (Partition Dispersion)</span>
                  <span className="font-mono font-medium text-[#f4f4f5]">{(activeCase.isoforest_score * 100).toFixed(1)}%</span>
                </div>
                <div className="h-2 rounded-full bg-[#18191e] overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#6366f1] to-[#818cf8] rounded-full" style={{ width: `${activeCase.isoforest_score * 100}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-[#d4d4d8]">Autoencoder Reconstruction MSE (Latent Manifold)</span>
                  <span className="font-mono font-medium text-[#f87171]">{(activeCase.autoencoder_score * 100).toFixed(1)}%</span>
                </div>
                <div className="h-2 rounded-full bg-[#18191e] overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#f87171] to-[#ef4444] rounded-full" style={{ width: `${activeCase.autoencoder_score * 100}%` }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Attributed Forensic Narrative */}
          <div className="rounded-xl border border-[#22242a] bg-[#0e0f13] p-5 space-y-2">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[#a1a1aa]">Autonomous Agent Findings</h2>
            <p className="text-xs text-[#d4d4d8] leading-relaxed">
              {activeCase.narrative}
            </p>
          </div>
        </div>

        {/* Right Column: Counterparty & Attestation (3 cols) */}
        <div className="lg:col-span-3 flex flex-col bg-[#0b0c0e] p-5 space-y-5 overflow-y-auto">
          <div>
            <span className="text-[11px] font-medium uppercase tracking-wider text-[#71717a] block mb-3">Counterparty Intelligence</span>
            <div className="rounded-lg border border-[#1f2024] bg-[#121316] p-3 space-y-3 text-xs">
              <div>
                <span className="text-[10px] text-[#71717a] uppercase block">Beneficiary Entity</span>
                <span className="font-semibold text-[#f4f4f5] block mt-0.5">{activeCase.beneficiary.name}</span>
                <span className="text-[11px] text-[#71717a] font-mono">{activeCase.beneficiary.swift_bic}</span>
              </div>
              <div className="pt-2 border-t border-[#1f2024] flex justify-between text-[11px]">
                <span className="text-[#71717a]">Jurisdiction</span>
                <span className="text-[#d4d4d8]">{activeCase.beneficiary.jurisdiction}</span>
              </div>
              <div className="pt-2 border-t border-[#1f2024] flex justify-between text-[11px]">
                <span className="text-[#71717a]">Entity Age</span>
                <span className="text-[#f87171] font-medium">{activeCase.beneficiary.incorporation_age}</span>
              </div>
            </div>
          </div>

          {/* Action Decision Pod */}
          <div className="space-y-2.5 pt-4 border-t border-[#1f2024]">
            <span className="text-[11px] font-medium uppercase tracking-wider text-[#71717a] block">Supervisory Decision</span>
            <button
              onClick={() => onAction("Escalate to FIU", activeCase.transaction_id)}
              className="w-full py-2.5 px-3 rounded-lg bg-[#6366f1] hover:bg-[#4f46e5] text-white font-medium text-xs shadow-sm transition-all"
            >
              Escalate to Financial Intelligence Unit
            </button>
            <button
              onClick={() => onAction("File SAR", activeCase.transaction_id)}
              className="w-full py-2 px-3 rounded-lg bg-[#ef4444]/15 hover:bg-[#ef4444]/25 text-[#f87171] border border-[#ef4444]/30 font-medium text-xs transition-all"
            >
              Draft Suspicious Activity Report (SAR)
            </button>
            <button
              onClick={() => onAction("Approve Transfer", activeCase.transaction_id)}
              className="w-full py-2 px-3 rounded-lg bg-[#18191e] hover:bg-[#22242a] text-[#a1a1aa] font-medium text-xs transition-all"
            >
              Approve & Release Hold
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
