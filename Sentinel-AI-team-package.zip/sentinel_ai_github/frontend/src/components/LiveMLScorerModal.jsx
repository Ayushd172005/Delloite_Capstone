import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Sparkles,
  Cpu,
  Bot,
  Layers,
  AlertTriangle,
  CheckCircle2,
  X,
  ExternalLink,
  Loader2,
  ShieldCheck,
  Zap,
  ChevronRight,
  TrendingUp,
  FileCheck2,
} from "./PhosphorIcons";
import { executePipelineScore } from "../api/investigations";
import { useCurrency } from "../context/CurrencyContext";
import { playTick } from "../utils/audio";

const PRESETS = [
  {
    id: "ato",
    label: "🚨 Retail Account Takeover",
    desc: "New device + 9.85k volume surge on retail profile",
    data: {
      vertical: "retail",
      amount: 9850.0,
      account_id: "ACC_RETAIL_881",
      counterparty_id: "MERCH_ELECTRONICS_99",
      balance_before: 14500.0,
      balance_after: 4650.0,
      rule_score: 30.0,
      benford_score: 75.0,
    },
  },
  {
    id: "aml",
    label: "⚠️ AML Fan-Out Structuring",
    desc: "$492k high-velocity wire to offshore counterparty",
    data: {
      vertical: "aml",
      amount: 492000.0,
      account_id: "SWIFT_E75CA70B",
      customer_id: "INST_100",
      counterparty_id: "BENEFICIARY_5493",
      balance_before: 850000.0,
      balance_after: 358000.0,
      rule_score: 45.0,
      benford_score: 90.0,
    },
  },
  {
    id: "corp",
    label: "⚡ Corporate Near-Threshold",
    desc: "$148.5k payment just below $150k compliance ceiling",
    data: {
      vertical: "corporate",
      amount: 148500.0,
      account_id: "ACC_CORP_SUPP_09",
      counterparty_id: "MERCH_RAW_METALS_INTL",
      balance_before: 320000.0,
      balance_after: 171500.0,
      rule_score: 20.0,
      benford_score: 80.0,
    },
  },
  {
    id: "clean",
    label: "🟢 Clean Everyday Card",
    desc: "$42.50 grocery swipe from recurring merchant",
    data: {
      vertical: "retail",
      amount: 42.5,
      account_id: "ACC_REGULAR_101",
      counterparty_id: "MERCH_GROCERY_SAFE",
      balance_before: 3400.0,
      balance_after: 3357.5,
      rule_score: 0.0,
      benford_score: 5.0,
    },
  },
];

export default function LiveMLScorerModal({ isOpen, onClose, onCaseScored }) {
  const navigate = useNavigate();
  const { formatAmount } = useCurrency();

  const [activePreset, setActivePreset] = useState("ato");
  const [formData, setFormData] = useState({
    transaction_id: `TXN-SIM-${Math.floor(10000 + Math.random() * 90000)}`,
    transaction_time: new Date().toISOString().slice(0, 19),
    ...PRESETS[0].data,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  if (!isOpen) return null;

  const handleSelectPreset = (p) => {
    playTick("click");
    setActivePreset(p.id);
    setFormData((prev) => ({
      ...prev,
      transaction_id: `TXN-SIM-${Math.floor(10000 + Math.random() * 90000)}`,
      transaction_time: new Date().toISOString().slice(0, 19),
      ...p.data,
    }));
    setResult(null);
    setError(null);
  };

  const handleFieldChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleRunPipeline = async (e) => {
    e.preventDefault();
    playTick("action");
    setLoading(true);
    setError(null);

    try {
      const payload = {
        ...formData,
        amount: Number(formData.amount),
        balance_before: Number(formData.balance_before),
        balance_after: Number(formData.balance_after),
        rule_score: Number(formData.rule_score || 0),
        benford_score: Number(formData.benford_score || 0),
        ...(formData.vertical === "aml"
          ? { customer_id: formData.customer_id || formData.account_id || "INST_100" }
          : {}),
      };

      const res = await executePipelineScore(payload);
      setResult(res);
      if (onCaseScored) onCaseScored(res);
      playTick("success");
    } catch (err) {
      setError(err?.message || "Pipeline execution failed");
      playTick("error");
    } finally {
      setLoading(false);
    }
  };

  const scores = result?.scores;
  const features = result?.engineered_features;
  const inv = result?.investigation;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-fade-in select-none"
      onClick={onClose}
    >
      <div
        className="relative flex flex-col w-full max-w-4xl max-h-[90vh] rounded-xl overflow-hidden shadow-2xl border border-border bg-panel text-ink"
        onClick={(e) => e.stopPropagation()}
        style={{ background: "var(--color-panel)" }}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-panel-raised/50">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent/15 border border-accent/30 text-accent">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight text-ink">
                  Sentinel Advanced Forensic Pipeline
                </h2>
                <span className="rounded px-2 py-0.5 font-mono text-2xs font-bold uppercase bg-accent-dim text-accent">
                  Live Execution
                </span>
              </div>
              <p className="text-xs text-ink-muted">
                Causal feature serving · Isolation Forest & Autoencoder ensemble · Autonomous neural evidence synthesis
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-ink-muted hover:text-ink hover:bg-panel-dock transition-colors"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 scrollbar-thin">
          {/* Preset Buttons */}
          <div className="space-y-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-ink-faint">
              Choose Test Typology Preset
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {PRESETS.map((p) => {
                const isActive = activePreset === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectPreset(p)}
                    className={`text-left rounded-lg p-3 border transition-all ${
                      isActive
                        ? "border-accent bg-accent/10 shadow-xs ring-1 ring-accent"
                        : "border-border bg-panel-dock hover:border-accent/40 hover:bg-panel-raised"
                    }`}
                  >
                    <div className="font-semibold text-xs text-ink leading-tight">{p.label}</div>
                    <div className="mt-1 text-2xs text-ink-muted leading-snug">{p.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Form Configuration Inputs */}
          <form onSubmit={handleRunPipeline} className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Transaction ID</label>
                <input
                  type="text"
                  value={formData.transaction_id}
                  onChange={(e) => handleFieldChange("transaction_id", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Vertical</label>
                <select
                  value={formData.vertical}
                  onChange={(e) => handleFieldChange("vertical", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                >
                  <option value="retail">Retail</option>
                  <option value="corporate">Corporate</option>
                  <option value="aml">AML Wire</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Amount ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => handleFieldChange("amount", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Balance Before ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.balance_before}
                  onChange={(e) => handleFieldChange("balance_before", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Account ID</label>
                <input
                  type="text"
                  value={formData.account_id}
                  onChange={(e) => handleFieldChange("account_id", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Counterparty ID</label>
                <input
                  type="text"
                  value={formData.counterparty_id}
                  onChange={(e) => handleFieldChange("counterparty_id", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Rule Score (0-100)</label>
                <input
                  type="number"
                  value={formData.rule_score}
                  onChange={(e) => handleFieldChange("rule_score", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs font-semibold uppercase text-ink-muted">Benford Score (0-100)</label>
                <input
                  type="number"
                  value={formData.benford_score}
                  onChange={(e) => handleFieldChange("benford_score", e.target.value)}
                  className="w-full rounded-md border border-border bg-panel-dock px-2.5 py-1.5 font-mono text-xs text-ink focus:border-accent focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-2xs text-ink-faint">
                Invokes <code className="text-accent font-semibold">POST /score/pipeline</code>: Causal FeatureStore → Isolation Forest + Autoencoder → Sentinel Forensic Synthesis Engine
              </span>
              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 rounded-lg border border-accent/40 bg-accent px-5 py-2.5 text-xs font-bold text-white transition-all hover:bg-accent/90 disabled:opacity-50 shadow-sm cursor-pointer"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
                <span>{loading ? "Simulating & Scoring…" : "Simulate & Score Pipeline"}</span>
              </button>
            </div>
          </form>

          {/* Error Notice */}
          {error && (
            <div className="flex items-center gap-2.5 rounded-lg border border-critical-border bg-critical-bg p-3.5 text-xs font-mono text-critical">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>Pipeline Error: {error}</span>
            </div>
          )}

          {/* Live Execution Results */}
          {result && (
            <div className="space-y-4 pt-3 border-t border-border animate-case-transition">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  <span className="text-xs font-bold uppercase tracking-wider text-ink">
                    Pipeline Execution Complete
                  </span>
                  <span className="rounded px-2 py-0.5 text-2xs font-mono font-semibold bg-panel-dock text-ink-muted border border-border">
                    {result.llm_provider || "Sentinel Neural Core v2.4 (Self-Hosted)"}
                  </span>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    navigate(`/investigation/${result.transaction_id}`);
                  }}
                  className="flex items-center gap-1.5 text-xs font-semibold text-accent hover:underline"
                >
                  <span>Open Full Investigation</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Grid 1: ML Ensemble & Risk Tier */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Composite Risk Score */}
                <div className="rounded-lg border border-border bg-panel-dock p-3.5 space-y-1">
                  <div className="flex items-center justify-between text-2xs font-semibold text-ink-muted uppercase">
                    <span>Composite ML Score</span>
                    <span
                      className={`font-bold ${
                        scores?.composite_score >= 80
                          ? "text-critical"
                          : scores?.composite_score >= 50
                          ? "text-warning"
                          : "text-low"
                      }`}
                    >
                      {scores?.review_tier?.replace("_", " ")}
                    </span>
                  </div>
                  <div className="text-2xl font-bold font-mono text-ink">
                    {scores?.composite_score?.toFixed(1)}
                    <span className="text-xs text-ink-faint font-normal"> / 100</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
                    <div
                      className={`h-full ${
                        scores?.composite_score >= 80
                          ? "bg-critical"
                          : scores?.composite_score >= 50
                          ? "bg-warning"
                          : "bg-low"
                      }`}
                      style={{ width: `${Math.min(100, scores?.composite_score || 0)}%` }}
                    />
                  </div>
                </div>

                {/* Isolation Forest Outlier Score */}
                <div className="rounded-lg border border-border bg-panel-dock p-3.5 space-y-1">
                  <div className="flex items-center justify-between text-2xs font-semibold text-ink-muted uppercase">
                    <span>Isolation Forest Outlier</span>
                    <span className="font-mono text-ink font-bold">
                      {((scores?.isoforest_score || 0) * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="text-sm font-semibold font-mono text-ink">
                    {scores?.isoforest_score >= 0.65 ? "Anomaly Confirmed" : "Nominal"}
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
                    <div
                      className="h-full bg-accent"
                      style={{ width: `${Math.min(100, (scores?.isoforest_score || 0) * 100)}%` }}
                    />
                  </div>
                  <span className="text-2xs text-ink-faint block">Unsupervised partition depth anomaly</span>
                </div>

                {/* Autoencoder Reconstruction */}
                <div className="rounded-lg border border-border bg-panel-dock p-3.5 space-y-1">
                  <div className="flex items-center justify-between text-2xs font-semibold text-ink-muted uppercase">
                    <span>Autoencoder MSE Loss</span>
                    <span className="font-mono text-ink font-bold">
                      {((scores?.autoencoder_score || 0) * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="text-sm font-semibold font-mono text-ink">
                    Error: {scores?.reconstruction_error?.toFixed(2) || "0.00"}
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
                    <div
                      className="h-full bg-accent"
                      style={{ width: `${Math.min(100, (scores?.autoencoder_score || 0) * 100)}%` }}
                    />
                  </div>
                  <span className="text-2xs text-ink-faint block">Latent manifold reconstruction error</span>
                </div>
              </div>

              {/* Grid 2: Serving Feature Engineering Values */}
              <div className="rounded-lg border border-border bg-panel-dock p-3.5 space-y-2">
                <span className="text-2xs font-bold uppercase text-ink-muted tracking-wider block">
                  Causal Behavioral Velocity Telemetry
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
                  <div className="rounded bg-panel p-2 border border-border/60">
                    <span className="text-2xs text-ink-faint block">AMOUNT Z-SCORE</span>
                    <span className="font-bold text-ink">{features?.amount_zscore?.toFixed(2)}σ</span>
                  </div>
                  <div className="rounded bg-panel p-2 border border-border/60">
                    <span className="text-2xs text-ink-faint block">7D VELOCITY</span>
                    <span className="font-bold text-ink">{features?.velocity_7d} txns</span>
                  </div>
                  <div className="rounded bg-panel p-2 border border-border/60">
                    <span className="text-2xs text-ink-faint block">30D VELOCITY</span>
                    <span className="font-bold text-ink">{features?.velocity_30d} txns</span>
                  </div>
                  <div className="rounded bg-panel p-2 border border-border/60">
                    <span className="text-2xs text-ink-faint block">DEPLETION RATIO</span>
                    <span className="font-bold text-ink">
                      {((features?.balance_depletion_ratio || 0) * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Grid 3: Sentinel Forensic Findings */}
              {inv && (
                <div className="rounded-lg border border-accent/30 bg-accent/5 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bot className="h-4 w-4 text-accent" />
                      <span className="text-xs font-bold uppercase tracking-wider text-accent">
                        Sentinel Autonomous Forensic Synthesis
                      </span>
                    </div>
                    <span className="rounded-full px-2.5 py-0.5 font-mono text-2xs font-bold bg-accent text-white dark:text-base">
                      Recommendation: {inv.recommended_action}
                    </span>
                  </div>

                  <p className="text-xs font-medium leading-relaxed text-ink">
                    {inv.finding}
                  </p>

                  {inv.anomaly_drivers?.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-2xs font-semibold uppercase text-ink-muted block">
                        Identified Anomaly Drivers:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {inv.anomaly_drivers.map((d, i) => (
                          <span
                            key={i}
                            className="rounded px-2 py-0.5 font-mono text-2xs bg-panel-dock border border-border text-ink"
                          >
                            • {d}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Supporting vs Counter Evidence */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-2xs font-mono">
                    <div className="rounded border border-border bg-panel p-2.5 space-y-1">
                      <span className="text-accent font-bold block">
                        SUPPORTING EVIDENCE ({inv.supporting_evidence?.length || 0})
                      </span>
                      {inv.supporting_evidence?.length > 0 ? (
                        inv.supporting_evidence.map((s, idx) => (
                          <div key={idx} className="text-ink-muted">
                            <span className="text-ink font-semibold">[{s.document_id}]:</span> {s.statement}
                          </div>
                        ))
                      ) : (
                        <span className="text-ink-faint">No corroborating policy documents on file.</span>
                      )}
                    </div>

                    <div className="rounded border border-border bg-panel p-2.5 space-y-1">
                      <span className="text-warning font-bold block">
                        COUNTER-EVIDENCE ({inv.counter_evidence?.length || 0})
                      </span>
                      {inv.counter_evidence?.length > 0 ? (
                        inv.counter_evidence.map((c, idx) => (
                          <div key={idx} className="text-ink-muted">
                            <span className="text-ink font-semibold">[{c.document_id}]:</span> {c.statement}
                          </div>
                        ))
                      ) : (
                        <span className="text-ink-faint">No contradictory evidence identified.</span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-border bg-panel-raised/50">
          <span className="text-2xs text-ink-muted">
            Sentinel AI Forensic Engine · Version {scores?.model_version || "v2.0"}
          </span>
          <button
            onClick={onClose}
            className="rounded-lg border border-border px-4 py-1.5 text-xs font-semibold text-ink hover:bg-panel-dock transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
