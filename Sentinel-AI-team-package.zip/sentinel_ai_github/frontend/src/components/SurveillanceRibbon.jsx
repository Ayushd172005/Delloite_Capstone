import { useState } from "react";
import { ChevronDown, ChevronUp, Activity } from "./PhosphorIcons";
import RiskDistributionStrip from "./RiskDistributionStrip";
import Sparkline from "./Sparkline";
import ForensicRadarScope from "./ForensicRadarScope";

/**
 * SurveillanceRibbon — collapsible secondary telemetry below the main filter bar.
 * Primary viewport shows only RiskDistributionStrip inline with FilterBar.
 * Full telemetry (sparklines, radar) is behind a disclosure for advanced users.
 */
export default function SurveillanceRibbon({
  kpis,
  rows = [],
  density,
  onDensityChange,
  activeRiskBin,
  onSelectRiskBin,
}) {
  const [telemetryOpen, setTelemetryOpen] = useState(false);

  if (!kpis) return null;

  const { flagged, highRisk, priority, decided } = kpis;
  const pending = flagged - decided;
  const resolutionRate = flagged > 0 ? Math.round((decided / flagged) * 100) : 100;

  return (
    <div
      className="rounded-panel overflow-hidden transition-all duration-200"
      style={{
        background: "var(--surface)",
        border: "1px solid var(--divider)",
        boxShadow: "var(--shadow-panel)",
      }}
    >
      {/* ── Collapsible system detail ── */}
      <div>
        <button
          onClick={() => setTelemetryOpen((v) => !v)}
          className="flex w-full items-center gap-2 px-5 py-2.5 text-meta-xs font-mono text-text-muted transition-colors hover:text-text-primary hover:bg-surface-subtle"
          style={{ borderBottom: telemetryOpen ? "1px solid var(--divider)" : undefined }}
          aria-expanded={telemetryOpen}
          aria-controls="system-telemetry-panel"
        >
          <Activity className="h-3.5 w-3.5 text-accent shrink-0" aria-hidden />
          <span className="font-semibold uppercase tracking-wider text-text-secondary">System Telemetry & Health Stream</span>
          {telemetryOpen
            ? <ChevronUp className="h-3.5 w-3.5 ml-auto text-text-muted" aria-hidden />
            : <ChevronDown className="h-3.5 w-3.5 ml-auto text-text-muted" aria-hidden />
          }
        </button>

        {telemetryOpen && (
          <div
            id="system-telemetry-panel"
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 px-5 py-4"
            style={{ background: "var(--surface-subtle)" }}
          >
            {/* Total Ingested */}
            <div
              className="rounded-panel p-3 space-y-2"
              style={{ background: "var(--surface)", border: "1px solid var(--divider)" }}
            >
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-text-secondary">Total Ingested</span>
                <Sparkline
                  data={[28, 32, 40, 38, 48, 52, 60, flagged || 50]}
                  color="var(--accent)"
                  width={50}
                  height={16}
                />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="font-mono text-xl font-bold tabular-nums text-text-primary">
                  {flagged.toLocaleString()}
                </span>
                <span className="font-mono text-meta-xs text-text-muted">cases</span>
              </div>
              <div className="font-mono text-meta-xs text-text-muted">
                Buffer throughput nominal
              </div>
            </div>

            {/* Critical SLA Tier */}
            <div
              className="rounded-panel p-3 space-y-2"
              style={{ background: "var(--surface)", border: "1px solid var(--divider)" }}
            >
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-text-secondary flex items-center gap-1.5">
                  Critical SLA
                  {highRisk > 0 && (
                    <span className="h-1.5 w-1.5 rounded-full bg-critical animate-ping" aria-hidden />
                  )}
                </span>
                <Sparkline
                  data={[2, 3, 5, 4, 8, 6, 7, highRisk || 6]}
                  color="var(--risk-critical)"
                  width={50}
                  height={16}
                />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className={`font-mono text-xl font-bold tabular-nums ${highRisk > 0 ? "text-critical" : "text-text-primary"}`}>
                  {highRisk.toLocaleString()}
                </span>
                <span className="font-mono text-meta-xs text-text-muted">critical</span>
              </div>
              <div className="font-mono text-meta-xs text-text-muted">
                {highRisk > 0 ? "Under 4h statutory SLA" : "No critical pending"}
              </div>
            </div>

            {/* Attestation Rate */}
            <div
              className="rounded-panel p-3 space-y-2"
              style={{ background: "var(--surface)", border: "1px solid var(--divider)" }}
            >
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-text-secondary">Attestation</span>
                <span className="font-mono text-2xs font-bold text-success">{resolutionRate}%</span>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="font-mono text-xl font-bold tabular-nums text-text-primary">
                  {decided}
                </span>
                <span className="font-mono text-meta-xs text-text-muted">/ {flagged}</span>
              </div>
              <div className="font-mono text-meta-xs text-text-muted">
                {pending} awaiting review
              </div>
            </div>

            {/* Live Radar */}
            <div
              className="rounded-panel p-3 flex flex-col items-center justify-center gap-2"
              style={{ background: "var(--surface)", border: "1px solid var(--divider)" }}
            >
              <div className="w-full flex items-center justify-between font-mono text-meta-xs text-text-muted">
                <span>Live Radar</span>
                <span className="text-accent text-meta-xs">Sweep</span>
              </div>
              <ForensicRadarScope rows={rows} size={68} />
              <p className="font-mono text-meta-xs text-text-muted text-center">
                No abnormal throughput deviation
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
