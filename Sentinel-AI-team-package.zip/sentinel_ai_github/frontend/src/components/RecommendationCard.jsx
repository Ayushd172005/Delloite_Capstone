const ACTION_COPY = {
  ACCEPT: {
    label: "Accept — Clear for Settlement",
    tone: "text-low",
  },
  ESCALATE: {
    label: "Escalate for Compliance Review",
    tone: "text-critical",
  },
  DISMISS: {
    label: "Dismiss Flag — Contradictory Evidence",
    tone: "text-text-muted",
  },
  REQUEST_MORE_EVIDENCE: {
    label: "Request Additional Information",
    tone: "text-medium",
  },
};

function ConfidenceBar({ value }) {
  const pct = Math.round((value ?? 0) * 100);

  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-border">
        <div
          className="h-full rounded-full bg-accent transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="w-9 text-right font-mono text-2xs font-semibold tabular-nums text-text-primary">
        {pct}%
      </span>
    </div>
  );
}

export default function RecommendationCard({ investigation }) {
  const cfg =
    ACTION_COPY[investigation.recommended_action] ||
    ACTION_COPY.REQUEST_MORE_EVIDENCE;
  const isSufficient = investigation.evidence_sufficiency === "SUFFICIENT";

  return (
    <div className="rounded-panel border border-border p-4 space-y-3" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
      <div className="flex items-center justify-between border-b border-border/40 pb-2">
        <span className="text-xs font-semibold text-text-primary">
          Agent Recommendation
        </span>
        <span
          className={`inline-flex items-center gap-1 rounded-control border px-2 py-0.5 text-3xs font-medium ${
            isSufficient
              ? "border-low-border bg-low-bg text-low"
              : "border-medium-border bg-medium-bg text-medium"
          }`}
        >
          {isSufficient ? "● Evidence Sufficient" : "▲ Evidence Insufficient"}
        </span>
      </div>

      <div className={`text-sm font-semibold tracking-tight ${cfg.tone}`}>
        {cfg.label}
      </div>

      <p className="text-xs leading-relaxed text-text-secondary">
        {investigation.finding}
      </p>

      {/* Confidence gauge */}
      <div className="rounded-control border border-border bg-panel-dock p-2.5">
        <div className="mb-1 flex items-center justify-between text-3xs text-text-muted">
          <span>Model Confidence</span>
          <span>Internal Consistency</span>
        </div>
        <ConfidenceBar value={investigation.confidence} />
      </div>

      <div className="flex items-center justify-between text-3xs text-text-muted pt-1 border-t border-border/40">
        <span>Statutory Protocol: SEC 4.1</span>
        <span>Supervisory discretion required</span>
      </div>
    </div>
  );
}
