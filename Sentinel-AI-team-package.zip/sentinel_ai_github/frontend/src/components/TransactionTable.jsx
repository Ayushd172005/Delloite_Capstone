import { useState, useMemo, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, ArrowsDownUp, ArrowUp, ArrowDown } from "@phosphor-icons/react";
import RiskBadge from "./RiskBadge";
import StatusBadge from "./StatusBadge";
import SlaBadge from "./SlaBadge";
import SignalMatrix from "./SignalMatrix";
import UseCaseBadge from "./UseCaseBadge";
import { useCurrency } from "../context/CurrencyContext";
import { fmtVertical, rulesTriggeredToUseCase } from "../utils/format";
import { compactCaseId } from "../utils/caseId";
import { playTick } from "../utils/audio";

function UseCaseCell({ row }) {
  const useCase = rulesTriggeredToUseCase(row.rules_triggered);
  if (!useCase) {
    return (
      <span className="font-mono text-meta-xs text-text-muted">
        —
      </span>
    );
  }
  return <UseCaseBadge useCase={useCase} />;
}

function MicroScoreBar({ score }) {
  const s = Math.min(100, Math.max(0, Math.round(score ?? 0)));
  const barColor =
    s >= 80 ? "var(--risk-critical)" : s >= 65 ? "var(--risk-warning)" : "var(--risk-success)";

  return (
    <div className="flex items-center gap-1.5 font-mono text-2xs tabular-nums" style={{ color: "var(--text-primary)" }}>
      <div
        className="h-1 w-8 rounded-full overflow-hidden"
        style={{ background: "var(--divider)" }}
        role="presentation"
      >
        <div
          className="h-full rounded-full"
          style={{ width: `${s}%`, background: barColor }}
        />
      </div>
    </div>
  );
}

function SortIcon({ col, sortKey, sortDir }) {
  if (sortKey !== col) return <ArrowsDownUp className="h-3 w-3 opacity-40 shrink-0" aria-hidden />;
  return sortDir === "asc"
    ? <ArrowUp className="h-3 w-3 text-accent shrink-0" weight="bold" aria-hidden />
    : <ArrowDown className="h-3 w-3 text-accent shrink-0" weight="bold" aria-hidden />;
}

export default function TransactionTable({
  rows,
  density = "standard",
  selectedIndex = null,
  onSelectIndex,
  layoutMode = "grid",
  selectedIds = new Set(),
  onToggleSelect,
  onSelectAll,
}) {
  const navigate = useNavigate();
  const { formatAmount, symbol } = useCurrency();
  const tableRef = useRef(null);
  const selectedRowRef = useRef(null);

  const [sortKey, setSortKey] = useState("risk");
  const [sortDir, setSortDir] = useState("desc");

  const isCompact = density === "compact";
  const isSplit   = layoutMode === "split";

  // Row padding
  const rowPy = isCompact ? "py-2" : "py-3";
  const rowPx = isSplit ? "px-3" : "px-4";
  const rowPadding = `${rowPy} ${rowPx}`;

  const handleSort = (key) => {
    if (sortKey === key) setSortDir((prev) => (prev === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("desc"); }
  };

  const sortedRows = useMemo(() => {
    if (!rows) return [];
    return [...rows].sort((a, b) => {
      let valA = 0, valB = 0;
      if      (sortKey === "risk")    { valA = Number(a.composite_score ?? 0); valB = Number(b.composite_score ?? 0); }
      else if (sortKey === "amount")  { valA = Number(a.amount ?? 0);          valB = Number(b.amount ?? 0); }
      else if (sortKey === "signals") { valA = Number(a.rule_flag_count ?? 0); valB = Number(b.rule_flag_count ?? 0); }
      return sortDir === "asc" ? valA - valB : valB - valA;
    });
  }, [rows, sortKey, sortDir]);

  // Keyboard navigation
  useEffect(() => {
    function handleKeyDown(e) {
      if (["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName)) return;

      if (e.key === "j" || e.key === "ArrowDown") {
        e.preventDefault();
        playTick("nav");
        onSelectIndex?.((prev) => {
          const next = prev === null ? 0 : Math.min(sortedRows.length - 1, prev + 1);
          return next;
        });
      } else if (e.key === "k" || e.key === "ArrowUp") {
        e.preventDefault();
        playTick("nav");
        onSelectIndex?.((prev) => {
          const next = prev === null ? 0 : Math.max(0, prev - 1);
          return next;
        });
      } else if (e.key === "Enter" && selectedIndex !== null && sortedRows[selectedIndex]) {
        e.preventDefault();
        const r = sortedRows[selectedIndex];
        navigate(`/investigation/${r.transaction_id}`, { state: { row: r, queueList: sortedRows } });
      } else if (e.key === "x" && selectedIndex !== null && sortedRows[selectedIndex]) {
        e.preventDefault();
        playTick("toggle");
        onToggleSelect?.(sortedRows[selectedIndex].transaction_id);
      } else if ((e.key === "a" || e.key === "A") && e.shiftKey) {
        e.preventDefault();
        playTick("toggle");
        onSelectAll?.(sortedRows.map((r) => r.transaction_id));
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [sortedRows, selectedIndex, onSelectIndex, navigate, onToggleSelect, onSelectAll]);

  // Auto-scroll selected row into view
  useEffect(() => {
    if (selectedRowRef.current) {
      selectedRowRef.current.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }, [selectedIndex]);

  const thStyle = {
    background:  "var(--surface-subtle)",
    borderBottom:"1px solid var(--divider)",
    color:       "var(--text-muted)",
  };

  const colHeaderClass = `${rowPadding} text-[11px] font-semibold font-sans uppercase tracking-wider text-text-muted whitespace-nowrap`;

  return (
    <div className="overflow-x-auto select-none" ref={tableRef}>
      <table
        className="w-full border-collapse text-left text-xs"
        aria-label="Transaction surveillance queue"
        aria-rowcount={sortedRows.length}
        role="grid"
      >
        <thead>
          <tr style={thStyle}>
            {/* Select all */}
            <th className="w-9 px-3 py-2.5 text-center" style={thStyle}>
              <input
                type="checkbox"
                checked={sortedRows.length > 0 && sortedRows.every((r) => selectedIds?.has(r.transaction_id))}
                onChange={() => onSelectAll?.(sortedRows.map((r) => r.transaction_id))}
                className="h-3.5 w-3.5 rounded cursor-pointer"
                style={{ accentColor: "var(--accent)" }}
                title="Select / Deselect all (Shift+A)"
                aria-label="Select all cases"
              />
            </th>

            {/* Risk */}
            <th
              onClick={() => handleSort("risk")}
              className={`${colHeaderClass} cursor-pointer hover:text-text-primary transition-colors`}
              style={thStyle}
              aria-sort={sortKey === "risk" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}
            >
              <div className="flex items-center gap-1.5">
                <span>Risk</span>
                <SortIcon col="risk" sortKey={sortKey} sortDir={sortDir} />
              </div>
            </th>

            {/* Transaction ID */}
            <th className={colHeaderClass} style={thStyle}>Case ID</th>

            {/* Vertical (grid only) */}
            {!isSplit && <th className={colHeaderClass} style={thStyle}>Vertical</th>}

            {/* Amount */}
            <th
              onClick={() => handleSort("amount")}
              className={`${colHeaderClass} text-right cursor-pointer hover:text-text-primary transition-colors`}
              style={thStyle}
              aria-sort={sortKey === "amount" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}
            >
              <div className="flex items-center justify-end gap-1.5 whitespace-nowrap">
                <span>Amount ({symbol})</span>
                <SortIcon col="amount" sortKey={sortKey} sortDir={sortDir} />
              </div>
            </th>

            {/* Use Case (grid only) */}
            {!isSplit && <th className={colHeaderClass} style={thStyle}>Typology</th>}

            {/* Diagnostics (grid only) */}
            {!isSplit && <th className={colHeaderClass} style={thStyle}>Diagnostics</th>}

            {/* Signals (grid only) */}
            {!isSplit && (
              <th
                onClick={() => handleSort("signals")}
                className={`${colHeaderClass} text-right cursor-pointer hover:text-text-primary transition-colors`}
                style={thStyle}
                aria-sort={sortKey === "signals" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Signals</span>
                  <SortIcon col="signals" sortKey={sortKey} sortDir={sortDir} />
                </div>
              </th>
            )}

            {!isSplit && <th className={colHeaderClass} style={thStyle}>SLA</th>}
            {!isSplit && <th className={colHeaderClass} style={thStyle}>Status</th>}

            {!isSplit && (
              <th className={`${colHeaderClass} w-16 text-right`} style={thStyle} aria-label="Action">
                Action
              </th>
            )}
          </tr>
        </thead>

        <tbody>
          {sortedRows.map((r, idx) => {
            const isSelected = selectedIndex === idx;

            return (
              <tr
                key={r.transaction_id}
                ref={isSelected ? selectedRowRef : null}
                onClick={() => {
                  playTick("nav");
                  onSelectIndex?.(idx);
                }}
                className="group cursor-pointer transition-colors duration-100 outline-none hover:bg-surface/50"
                style={{
                  background:
                    isSelected ? "var(--surface-raised)" : "transparent",
                  borderLeft: isSelected
                    ? "3px solid var(--accent)"
                    : "3px solid transparent",
                  borderBottom: "1px solid var(--divider)",
                }}
                tabIndex={0}
                aria-selected={isSelected}
                role="row"
                aria-label={`Transaction ${r.transaction_id}, ${r.review_tier}, risk score ${Math.round(r.composite_score ?? 0)}`}
                onFocus={() => onSelectIndex?.(idx)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    navigate(`/investigation/${r.transaction_id}`, { state: { row: r, queueList: sortedRows } });
                  }
                }}
              >
                {/* Select checkbox */}
                <td
                  className={`w-9 px-3 ${rowPy} text-center align-middle`}
                  onClick={(e) => e.stopPropagation()}
                >
                  <input
                    type="checkbox"
                    checked={selectedIds?.has(r.transaction_id) ?? false}
                    onChange={() => { playTick("toggle"); onToggleSelect?.(r.transaction_id); }}
                    className="h-3.5 w-3.5 rounded cursor-pointer"
                    style={{ accentColor: "var(--accent)" }}
                    aria-label={`Select case ${r.transaction_id}`}
                  />
                </td>

                {/* Risk score + badge */}
                <td className={`${rowPadding} align-middle whitespace-nowrap`}>
                  <div className="flex items-center gap-1.5">
                    <RiskBadge tier={r.review_tier} score={r.composite_score} size="sm" />
                    {!isSplit && <MicroScoreBar score={r.composite_score} />}
                  </div>
                </td>

                {/* Transaction ID */}
                <td
                  className={`${rowPadding} align-middle whitespace-nowrap text-xs font-semibold`}
                  style={{ fontFamily: "var(--font-mono, 'JetBrains Mono', monospace)", color: "var(--text-primary)" }}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="transition-colors font-semibold"
                      style={{ color: isSelected ? "var(--accent)" : undefined }}
                      title={r.transaction_id}
                    >
                      {compactCaseId(r.transaction_id)}
                    </span>
                    {isSplit && (
                      <span className="font-sans text-[11px] text-text-muted px-1 rounded bg-surface-subtle border border-divider">
                        {fmtVertical(r.vertical)}
                      </span>
                    )}
                  </div>
                </td>

                {/* Vertical (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle whitespace-nowrap`}>
                    <span className="font-sans text-xs text-text-secondary">
                      {fmtVertical(r.vertical)}
                    </span>
                  </td>
                )}

                {/* Amount */}
                <td
                  className={`${rowPadding} align-middle text-right font-mono text-xs sm:text-sm font-semibold tabular-nums whitespace-nowrap`}
                  style={{ color: "var(--text-primary)" }}
                >
                  {formatAmount(r.amount)}
                </td>

                {/* Use Case (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle max-w-xs truncate`}>
                    <UseCaseCell row={r} />
                  </td>
                )}

                {/* Diagnostics (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle`}>
                    <SignalMatrix signals={r.signals} rulesTriggered={r.rules_triggered} />
                  </td>
                )}

                {/* Signal count (grid only) */}
                {!isSplit && (
                  <td
                    className={`${rowPadding} align-middle text-right font-mono tabular-nums text-xs`}
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {r.rule_flag_count}
                  </td>
                )}

                {/* SLA (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle whitespace-nowrap`}>
                    <SlaBadge row={r} compact={isSplit} />
                  </td>
                )}

                {/* Status (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle whitespace-nowrap`}>
                    <StatusBadge status={r.auditor_decision || "PENDING"} size="sm" />
                  </td>
                )}

                {/* Inspect (grid only) */}
                {!isSplit && (
                  <td className={`${rowPadding} align-middle text-right whitespace-nowrap`}>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/investigation/${r.transaction_id}`, { state: { row: r, queueList: sortedRows } });
                      }}
                      className="inline-flex items-center gap-1 rounded-control px-2.5 py-1 text-xs font-sans font-medium transition-colors hover:border-accent/40"
                      style={{
                        background: "var(--surface-subtle)",
                        border: "1px solid var(--divider)",
                        color: "var(--text-secondary)",
                      }}
                      aria-label={`Open full investigation for ${r.transaction_id}`}
                    >
                      <span>Inspect</span>
                      <ArrowRight className="h-3 w-3" weight="bold" aria-hidden />
                    </button>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
