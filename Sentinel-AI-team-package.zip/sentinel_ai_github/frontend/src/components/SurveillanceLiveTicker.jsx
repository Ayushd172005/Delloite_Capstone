import { Database, Warning, CheckCircle, Columns, ListChecks } from "@phosphor-icons/react";
import { playTick } from "../utils/audio";

/**
 * HealthSummaryRow — compact 3-KPI strip above the workbench.
 * Shows: Active Records | Critical SLA | Attestation Rate
 * View mode toggle (Workbench / Full Grid) with hotkey V.
 */
export default function HealthSummaryRow({
  viewMode = "split",
  onViewModeChange,
  totalCases = 0,
  criticalCount = 0,
  attestationPct = 0,
  isStale = false,
  lastFreshAt = null,
}) {
  // Format last-fresh timestamp
  const freshnessLabel = (() => {
    if (!lastFreshAt) return null;
    const diffMs = Date.now() - lastFreshAt;
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 60) return `${diffSec}s ago`;
    const diffMin = Math.floor(diffSec / 60);
    return `${diffMin}m ago`;
  })();

  return (
    <div
      className="flex flex-wrap items-center gap-x-3 sm:gap-x-6 gap-y-2 px-3 sm:px-5 py-2 select-none border-b border-divider"
      style={{
        background: "var(--surface-subtle)",
      }}
      role="status"
      aria-label="Queue health summary"
    >
      {/* ── KPI 1: Active records ── */}
      <div className="flex items-center gap-2">
        <Database className="h-4 w-4 text-accent shrink-0" weight="regular" aria-hidden />
        <div className="flex items-baseline gap-1.5">
          <span className="font-mono text-xs sm:text-sm font-bold tabular-nums text-text-primary">
            {totalCases.toLocaleString()}
          </span>
          <span className="font-sans text-xs text-text-muted">active</span>
        </div>
      </div>

      <span className="hidden sm:inline text-divider" aria-hidden>|</span>

      {/* ── KPI 2: Critical SLA ── */}
      <div className="flex items-center gap-2">
        <Warning
          className={`h-4 w-4 shrink-0 ${criticalCount > 0 ? "text-critical" : "text-text-muted"}`}
          weight={criticalCount > 0 ? "fill" : "regular"}
          aria-hidden
        />
        <div className="flex items-baseline gap-1.5">
          <span
            className={`font-mono text-xs sm:text-sm font-bold tabular-nums ${
              criticalCount > 0 ? "text-critical" : "text-text-primary"
            }`}
          >
            {criticalCount}
          </span>
          <span className="font-sans text-xs text-text-muted">critical SLA</span>
        </div>
      </div>

      <span className="hidden sm:inline text-divider" aria-hidden>|</span>

      {/* ── KPI 3: Attestation ── */}
      <div className="flex items-center gap-2">
        <CheckCircle className="h-4 w-4 text-success shrink-0" weight="regular" aria-hidden />
        <div className="flex items-baseline gap-1.5">
          <span className="font-mono text-xs sm:text-sm font-bold tabular-nums text-text-primary">
            {attestationPct}%
          </span>
          <span className="font-sans text-xs text-text-muted">attested</span>
        </div>
      </div>

      {/* ── Stale indicator ── */}
      {isStale && (
        <div
          className="flex items-center gap-1.5 rounded-badge px-2 py-0.5"
          style={{
            background: "var(--risk-warning-bg)",
            border: "1px solid var(--risk-warning-border)",
          }}
          role="alert"
          aria-live="polite"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-warning shrink-0" />
          <span className="font-sans text-xs text-warning font-medium">
            Stale data{freshnessLabel ? ` · ${freshnessLabel}` : ""}
          </span>
        </div>
      )}

      {/* ── Live dot when fresh ── */}
      {!isStale && (
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-50" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-success" />
          </span>
          <span className="font-sans text-xs text-text-muted">
            {freshnessLabel ? `Updated ${freshnessLabel}` : "Live"}
          </span>
        </div>
      )}

      {/* ── Right: View mode (Desktop only) ── */}
      <div className="ml-auto hidden md:flex items-center gap-2">
        {/* View mode toggle */}
        <div
          className="flex items-center rounded-control p-0.5"
          style={{
            background: "var(--surface)",
            border: "1px solid var(--divider)",
          }}
          role="group"
          aria-label="View mode"
        >
          <button
            onClick={() => { playTick("toggle"); onViewModeChange?.("split"); }}
            className={`flex items-center gap-1.5 rounded px-2.5 py-1 text-xs font-sans font-medium transition-colors ${
              viewMode === "split"
                ? "bg-surface-raised text-text-primary shadow-xs font-semibold"
                : "text-text-muted hover:text-text-primary"
            }`}
            aria-pressed={viewMode === "split"}
            title="Split Workbench view (V)"
          >
            <Columns className="h-3.5 w-3.5" weight="bold" aria-hidden />
            <span>Workbench</span>
          </button>
          <button
            onClick={() => { playTick("toggle"); onViewModeChange?.("grid"); }}
            className={`flex items-center gap-1.5 rounded px-2.5 py-1 text-xs font-sans font-medium transition-colors ${
              viewMode === "grid"
                ? "bg-surface-raised text-text-primary shadow-xs font-semibold"
                : "text-text-muted hover:text-text-primary"
            }`}
            aria-pressed={viewMode === "grid"}
            title="Full Data Grid view (V)"
          >
            <ListChecks className="h-3.5 w-3.5" weight="bold" aria-hidden />
            <span>Full Grid</span>
          </button>
        </div>
      </div>
    </div>
  );
}
