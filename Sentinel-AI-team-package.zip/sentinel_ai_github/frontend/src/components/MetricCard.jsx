export default function MetricCard({ label, value, hint, isMock, trend }) {
  return (
    <div className="group relative overflow-hidden rounded-lg border border-border bg-panel px-5 py-4 shadow-panel transition-shadow hover:shadow-panel-md">
      {/* Subtle left accent bar — adds visual anchor without screaming */}
      <div className="absolute left-0 top-0 h-full w-0.5 bg-accent/20 group-hover:bg-accent/40 transition-colors" />

      <div className="flex items-center justify-between gap-2">
        <div className="text-2xs font-semibold uppercase tracking-wide text-ink-faint">
          {label}
        </div>
        {isMock && (
          <span className="font-mono text-meta-xs font-semibold text-medium">
            mock
          </span>
        )}
      </div>

      <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-ink">
        {value}
      </div>

      {hint && (
        <div className="mt-1 text-2xs text-ink-faint leading-relaxed">{hint}</div>
      )}

      {/* Zero state hint */}
      {value === "0" && !hint && (
        <div className="mt-1 text-2xs text-ink-faint">No items in this tier</div>
      )}
    </div>
  );
}
