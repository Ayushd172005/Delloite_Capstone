import { useMemo, useState } from "react";

export default function ForensicRadarScope({
  rows = [],
  size = 100,
}) {
  const [hoveredBlip, setHoveredBlip] = useState(null);

  // Map the top 6-8 transactions into polar coordinates on the radar scope
  const blips = useMemo(() => {
    if (!rows || rows.length === 0) return [];

    return rows.slice(0, 8).map((r, i) => {
      const score = Number(r.composite_score ?? 0);
      // Distance from center (radius 0 to 38)
      const dist = 8 + (score / 100) * 28;
      // Angle spread based on index and score
      const angle = (i * 47 + score * 3.6) % 360;
      const rad = (angle * Math.PI) / 180;
      const cx = 50 + dist * Math.cos(rad);
      const cy = 50 + dist * Math.sin(rad);

      const isCritical = score >= 85;
      const isHigh = score >= 70 && score < 85;

      return {
        id: r.transaction_id,
        score: Math.round(score),
        tier: r.review_tier,
        cx,
        cy,
        isCritical,
        isHigh,
      };
    });
  }, [rows]);

  return (
    <div className="relative flex flex-col items-center justify-center select-none" style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible"
        aria-label="Real-time forensic radar sweep"
      >
        <defs>
          {/* Conical sweep beam */}
          <linearGradient id="radarSweepBeam" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--color-accent)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="transparent" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Radar Background circle */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="var(--color-panel-dock)"
          stroke="var(--color-border)"
          strokeWidth="1"
        />

        {/* Concentric Range Rings */}
        <circle cx="50" cy="50" r="32" fill="none" stroke="var(--color-border-subtle)" strokeWidth="0.75" strokeDasharray="2 2" />
        <circle cx="50" cy="50" r="20" fill="none" stroke="var(--color-border-subtle)" strokeWidth="0.75" strokeDasharray="2 2" />
        <circle cx="50" cy="50" r="8" fill="none" stroke="var(--color-border-subtle)" strokeWidth="0.75" />

        {/* Crosshair Axes */}
        <line x1="50" y1="5" x2="50" y2="95" stroke="var(--color-border-subtle)" strokeWidth="0.75" />
        <line x1="5" y1="50" x2="95" y2="50" stroke="var(--color-border-subtle)" strokeWidth="0.75" />

        {/* Rotating Radar Sweep Beam */}
        <g className="animate-radar-sweep">
          {/* Sweep Line */}
          <line x1="50" y1="50" x2="50" y2="5" stroke="var(--color-accent)" strokeWidth="1.25" strokeLinecap="round" opacity="0.85" />
          {/* Sweep Wedge */}
          <path
            d="M 50 50 L 50 5 A 45 45 0 0 1 82 18 Z"
            fill="url(#radarSweepBeam)"
          />
        </g>

        {/* Real-Time Anomaly Blips */}
        {blips.map((b) => (
          <g
            key={b.id}
            onMouseEnter={() => setHoveredBlip(b)}
            onMouseLeave={() => setHoveredBlip(null)}
            className="cursor-pointer"
          >
            {/* Blip glow ring if critical */}
            {b.isCritical && (
              <circle
                cx={b.cx}
                cy={b.cy}
                r="3.5"
                fill="none"
                stroke="var(--color-risk-crit)"
                strokeWidth="0.75"
                className="animate-ping opacity-60"
              />
            )}
            {/* Blip core dot */}
            <circle
              cx={b.cx}
              cy={b.cy}
              r={b.isCritical ? 2.5 : b.isHigh ? 2 : 1.75}
              fill={b.isCritical ? "var(--color-risk-crit)" : b.isHigh ? "var(--color-risk-high)" : "var(--color-accent)"}
              className="transition-transform hover:scale-150"
            />
          </g>
        ))}

        {/* Center Reticle Point */}
        <circle cx="50" cy="50" r="1.5" fill="var(--color-accent)" />
      </svg>

      {/* Hovered blip tooltip */}
      {hoveredBlip && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 z-30 whitespace-nowrap rounded border border-border bg-panel-raised px-1.5 py-0.5 font-mono text-3xs text-ink shadow-panel pointer-events-none">
          {hoveredBlip.id} · <span className={hoveredBlip.isCritical ? "text-critical font-bold" : "text-accent"}>{hoveredBlip.score}</span>
        </div>
      )}
    </div>
  );
}
