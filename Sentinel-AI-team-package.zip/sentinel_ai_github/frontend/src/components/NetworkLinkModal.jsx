import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  X,
  Network,
  ShieldAlert,
  Fingerprint,
  Globe,
  Landmark,
  Building2,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Crosshair,
  Download,
  Search,
  CheckCircle2,
  AlertTriangle,
  Zap,
  SlidersHorizontal,
  Copy,
  Check,
} from "./PhosphorIcons";
import { useTheme } from "../context/ThemeContext";
import { useCurrency } from "../context/CurrencyContext";
import { playTick } from "../utils/audio";

// Theme-specific color tokens for SVG & UI rendering
const THEMES = {
  dark: {
    canvas: "#090A0B",
    shell: "#0D0E10",
    panel: "#111214",
    panelRaised: "#18191C",
    panelDock: "#0E0F11",
    gridDot: "rgba(255, 255, 255, 0.10)",
    gridLine: "rgba(255, 255, 255, 0.03)",
    border: "rgba(255, 255, 255, 0.11)",
    borderStrong: "rgba(255, 255, 255, 0.20)",
    ink: "#F5F5F5",
    inkMuted: "#A1A1AA",
    inkFaint: "#71717A",
    steel: "#8EB7E8",
    steelDeep: "#4E6F96",
    spark: "#F47772",
    warning: "#E5B46A",
    success: "#76C69A",
    edgeDefault: "rgba(142, 183, 232, 0.32)",
    edgeHover: "#8EB7E8",
    nodeFill: "#18191C",
    nodeInnerWell: "#0E0F11",
    nodeBorder: "rgba(255, 255, 255, 0.15)",
    nodePillBg: "#0E0F11",
    nodePillBorder: "rgba(255, 255, 255, 0.12)",
    modalBg: "bg-[#0D0E10]",
    modalBorder: "border-white/10",
    topBarBg: "bg-[#0D0E10]",
    controlsBg: "bg-[#0E0F11]",
    cardBg: "bg-[#111214]",
    dockBg: "bg-[#0E0F11]",
    buttonBg: "bg-[#18191C]",
    buttonHover: "hover:bg-[#222328]",
    backdrop: "bg-[#050607]/70",
  },
  light: {
    canvas: "#EEF2F6",
    shell: "#E3EAF1",
    panel: "#FFFFFF",
    panelRaised: "#FFFFFF",
    panelDock: "#F0F4F8",
    gridDot: "rgba(20, 32, 43, 0.12)",
    gridLine: "rgba(20, 32, 43, 0.04)",
    border: "rgba(42, 65, 84, 0.14)",
    borderStrong: "rgba(42, 65, 84, 0.28)",
    ink: "#14202B",
    inkMuted: "#526475",
    inkFaint: "#728393",
    steel: "#087E69",
    steelDeep: "#065F4F",
    spark: "#C43D35",
    warning: "#A56600",
    success: "#16734E",
    edgeDefault: "rgba(8, 126, 105, 0.35)",
    edgeHover: "#087E69",
    nodeFill: "#FFFFFF",
    nodeInnerWell: "#F0F4F8",
    nodeBorder: "rgba(42, 65, 84, 0.22)",
    nodePillBg: "#FFFFFF",
    nodePillBorder: "rgba(42, 65, 84, 0.18)",
    modalBg: "bg-white",
    modalBorder: "border-slate-200",
    topBarBg: "bg-[#F8FAFC]",
    controlsBg: "bg-[#F0F4F8]",
    cardBg: "bg-[#F8FAFC]",
    dockBg: "bg-[#EEF2F6]",
    buttonBg: "bg-white",
    buttonHover: "hover:bg-slate-100",
    backdrop: "bg-slate-950/30",
  },
};

export default function NetworkLinkModal({
  isOpen,
  onClose,
  transactionId = "TRF_46631F673703",
  accountId,
  counterpartyId,
  amount = null,
  signals = null,
  vertical = "aml",
}) {
  const { isDark } = useTheme();
  const P = isDark ? THEMES.dark : THEMES.light;
  const { formatAmount, formatCompact, isUSD, symbol, currencyCode } = useCurrency();

  // Navigation & Viewport State
  const [selectedNodeId, setSelectedNodeId] = useState("subject");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [layoutMode, setLayoutMode] = useState("radial"); // "radial" | "pipeline"
  const [filterType, setFilterType] = useState("all"); // "all" | "critical" | "account" | "device" | "infra"
  const [traceActive, setTraceActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [copiedId, setCopiedId] = useState(false);
  const [flaggedNodes, setFlaggedNodes] = useState(new Set(["device", "subject"]));

  // Animation mounting & visibility states for fluid pop up and pop down transitions
  const [isRendered, setIsRendered] = useState(isOpen);
  const [isVisible, setIsVisible] = useState(false);
  const closeTimeoutRef = useRef(null);

  // Zoom & Pan State (viewBox: 800 x 520)
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1.0);
  const [isPanning, setIsPanning] = useState(false);
  const panStartRef = useRef({ x: 0, y: 0 });
  const svgRef = useRef(null);
  const zoomRef = useRef(zoom);
  const panRef = useRef(pan);

  // Keep refs synchronized with reactive state for zero-latency event handling
  useEffect(() => {
    zoomRef.current = zoom;
  }, [zoom]);
  useEffect(() => {
    panRef.current = pan;
  }, [pan]);

  // Dragging Node State
  const [draggingNodeId, setDraggingNodeId] = useState(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  // Format currency helper backed by active CurrencyContext
  const fmtAmt = useCallback(
    (val) => formatAmount(val),
    [formatAmount]
  );

  // Extract digits for deterministic identifiers
  const txDigits = (transactionId || "TX").replace(/\D/g, "");
  const subjectId = accountId || `ACC_${txDigits.slice(0, 4) || "4663"}`;
  const effectiveHubId = counterpartyId || `BEN_${txDigits.slice(-4) || "3703"}`;

  // Default coordinate layouts (viewBox: 800 x 520)
  const defaultLayouts = useMemo(
    () => ({
      radial: {
        subject: { x: 270, y: 260 },
        hub: { x: 500, y: 260 },
        device: { x: 385, y: 90 },
        vpn: { x: 100, y: 260 },
        mule1: { x: 670, y: 150 },
        mule2: { x: 670, y: 370 },
        otc: { x: 740, y: 260 },
      },
      pipeline: {
        vpn: { x: 90, y: 190 },
        device: { x: 90, y: 330 },
        subject: { x: 260, y: 260 },
        hub: { x: 440, y: 260 },
        mule1: { x: 600, y: 170 },
        mule2: { x: 600, y: 350 },
        otc: { x: 730, y: 260 },
      },
    }),
    []
  );

  // Custom node positions that analyst can drag
  const [nodePositions, setNodePositions] = useState(() => defaultLayouts.radial);

  // Reset positions when layoutMode changes
  useEffect(() => {
    setNodePositions(defaultLayouts[layoutMode]);
  }, [layoutMode, defaultLayouts]);

  // Topology node specifications
  const nodes = useMemo(
    () => ({
      subject: {
        id: "subject",
        nodeId: subjectId,
        label: "Subject Entity",
        subLabel: "Primary Account Under Review",
        category: "account",
        icon: Landmark,
        risk: signals?.review_tier ? String(signals.review_tier).replace(/_/g, " ").toUpperCase() : "UNAVAILABLE",
        riskScore: signals?.composite_score ?? null,
        color: P.spark,
        fanIn: 14,
        fanOut: 28,
        concentration: "42.1%",
        turnover: fmtAmt(amount),
        kyc: "Not supplied by API",
        jurisdiction: "Not supplied by API",
        ip: "Not supplied by API",
        notes:
          "Target entity exhibiting anomalous velocity spike. Outbound wire of " +
          fmtAmt(amount) +
          " initiated outside registered operating hours.",
        status: "FLAGGED IN CURRENT CASE",
      },
      hub: {
        id: "hub",
        nodeId: effectiveHubId,
        label: "Escrow Aggregator Hub",
        subLabel: "Beneficiary Escrow Account",
        category: "account",
        icon: Building2,
        risk: "HIGH",
        riskScore: 88,
        color: P.warning,
        fanIn: 84,
        fanOut: 19,
        concentration: "88.4%",
        turnover: `${formatCompact(142000000)} / month`,
        kyc: "Corporate Escrow Entity",
        jurisdiction: "New Delhi, NCR (IN)",
        ip: "165.21.40.91 (Data Center Gateway)",
        notes:
          "High concentration hub counterparty transacting with 84 distinct retail accounts within a 72-hour rolling window. Structural clustering coefficient: 0.82.",
        status: "SYNDICATE RECEPTACLE",
      },
      device: {
        id: "device",
        nodeId: "DEV_UUID_9912",
        label: "Shared Hardware UUID",
        subLabel: "Apple iPhone 15 Pro (WebGL Canvas Hash)",
        category: "device",
        icon: Fingerprint,
        risk: "CRITICAL",
        riskScore: 96,
        color: P.spark,
        fanIn: 0,
        fanOut: 4,
        concentration: "100.0%",
        turnover: "4 Associated Accounts",
        kyc: "Hardware Fingerprint Verified",
        jurisdiction: "Multi-Geo Geo-spoofed",
        ip: "Associated with 12 distinct ISP nodes",
        notes:
          "High-confidence device collusion: 4 distinct customer accounts authenticated with identical WebGL canvas fingerprint and hardware canvas signature within 48h.",
        status: "HARDWARE COLLUSION CLUSTER",
      },
      vpn: {
        id: "vpn",
        nodeId: "GEO_VPN_185.220",
        label: "Seychelles Transit Proxy",
        subLabel: "Commercial Anonymizer ASN 4412",
        category: "infra",
        icon: Globe,
        risk: "HIGH",
        riskScore: 85,
        color: P.warning,
        fanIn: 34,
        fanOut: 2,
        concentration: "N/A",
        turnover: "Hosting Pool Traffic",
        kyc: "Data Center Proxy (No KYC)",
        jurisdiction: "Victoria, Seychelles (SC)",
        ip: "185.220.101.5 (Commercial Tor/VPN Exit)",
        notes:
          "Known commercial hosting provider / data-center IP pool used for anonymization during high-value wire routing. Obfuscates geographic origin.",
        status: "ANONYMOUS TUNNEL",
      },
      mule1: {
        id: "mule1",
        nodeId: "ACC_MULE_3391",
        label: "Layering Mule Node A",
        subLabel: "Rapid Dispersal Transit Account",
        category: "account",
        icon: Landmark,
        risk: "HIGH",
        riskScore: 82,
        color: P.warning,
        fanIn: 12,
        fanOut: 2,
        concentration: "94.2%",
        turnover: `${formatCompact(1850000)} / month`,
        kyc: "Tier 1 Basic (Mule Profile)",
        jurisdiction: "Bengaluru, Karnataka (IN)",
        ip: "103.21.58.44",
        notes:
          "Immediate pass-through behavior: receives tranche funds and disperses 98.4% within 120 seconds to offshore liquidity corridors.",
        status: "RAPID PASSTHROUGH",
      },
      mule2: {
        id: "mule2",
        nodeId: "ACC_MULE_8104",
        label: "Layering Mule Node B",
        subLabel: "Velocity Anomaly Account",
        category: "account",
        icon: Landmark,
        risk: "MEDIUM",
        riskScore: 68,
        color: P.steel,
        fanIn: 8,
        fanOut: 1,
        concentration: "91.0%",
        turnover: `${formatCompact(1200000)} / month`,
        kyc: "Tier 1 Basic",
        jurisdiction: "Kolkata, West Bengal (IN)",
        ip: "103.21.58.49",
        notes:
          "Recent onboarding (account age 14 days). Sudden transactional burst 12x above peer group mean immediately following account creation.",
        status: "VELOCITY ANOMALY",
      },
      otc: {
        id: "otc",
        nodeId: "CORP_OTC_CYPRUS",
        label: "Settlement Liquidity Pool",
        subLabel: "Offshore OTC Asset Conversion",
        category: "account",
        icon: ShieldAlert,
        risk: "CRITICAL",
        riskScore: 94,
        color: P.spark,
        fanIn: 116,
        fanOut: 8,
        concentration: "96.5%",
        turnover: `${formatCompact(420000000)} / month`,
        kyc: "Unregulated Offshore Desk",
        jurisdiction: "Limassol, Cyprus (CY)",
        ip: "194.67.210.14 (Cyprus OTC Endpoint)",
        notes:
          "High-risk offshore OTC liquidity pool. Terminal destination for layering tranches, converting fiat wire transfers into unhosted bearer assets.",
        status: "TERMINAL SYNDICATE SINK",
      },
    }),
    [subjectId, effectiveHubId, amount, fmtAmt, formatCompact, P]
  );

  // Dynamic filter counts
  const filterCounts = useMemo(() => {
    const list = Object.values(nodes);
    return {
      all: list.length,
      critical: list.filter((n) => n.risk === "CRITICAL" || n.risk === "HIGH").length,
      account: list.filter((n) => n.category === "account").length,
      device: list.filter((n) => n.category === "device").length,
      infra: list.filter((n) => n.category === "infra").length,
    };
  }, [nodes]);

  // Link / Edge topology
  const edges = useMemo(
    () => [
      {
        id: "e-sub-hub",
        source: "subject",
        target: "hub",
        amount: fmtAmt(amount),
        type: "WIRE TRANSFER",
        direction: "outbound",
        latency: "Active Case",
        critical: true,
        trace: true,
      },
      {
        id: "e-dev-sub",
        source: "device",
        target: "subject",
        amount: "Device Match",
        type: "HARDWARE AUTH",
        direction: "binding",
        latency: "4 Accounts Colluding",
        critical: true,
        trace: true,
      },
      {
        id: "e-dev-hub",
        source: "device",
        target: "hub",
        amount: "UUID Match",
        type: "HARDWARE AUTH",
        direction: "binding",
        latency: "Same Hardware Signature",
        critical: true,
        trace: true,
      },
      {
        id: "e-vpn-sub",
        source: "vpn",
        target: "subject",
        amount: "Anonymized IP",
        type: "ROUTING PROXY",
        direction: "inbound",
        latency: "TOR/VPN Gateway",
        critical: false,
        trace: false,
      },
      {
        id: "e-hub-m1",
        source: "hub",
        target: "mule1",
        amount: formatAmount(185000),
        type: "LAYERING SPLIT",
        direction: "outbound",
        latency: "+120s Dispersal",
        critical: true,
        trace: true,
      },
      {
        id: "e-hub-m2",
        source: "hub",
        target: "mule2",
        amount: formatAmount(180000),
        type: "LAYERING SPLIT",
        direction: "outbound",
        latency: "+150s Dispersal",
        critical: false,
        trace: true,
      },
      {
        id: "e-m1-otc",
        source: "mule1",
        target: "otc",
        amount: formatAmount(182000),
        type: "TERMINAL DISPERSAL",
        direction: "outbound",
        latency: "+210s Conversion",
        critical: true,
        trace: true,
      },
      {
        id: "e-m2-otc",
        source: "mule2",
        target: "otc",
        amount: formatAmount(178000),
        type: "TERMINAL DISPERSAL",
        direction: "outbound",
        latency: "+240s Conversion",
        critical: false,
        trace: true,
      },
    ],
    [amount, fmtAmt, formatAmount]
  );

  // Active node data
  const activeNode = nodes[selectedNodeId] || nodes.subject;
  const ActiveIcon = activeNode.icon;

  // Incident links for selected node
  const incidentLinks = useMemo(() => {
    return edges.filter(
      (e) => e.source === selectedNodeId || e.target === selectedNodeId
    );
  }, [edges, selectedNodeId]);

  // Reset view handler
  const handleResetView = useCallback(() => {
    setZoom(1.0);
    setPan({ x: 0, y: 0 });
    setNodePositions(defaultLayouts[layoutMode]);
    playTick("nav");
  }, [layoutMode, defaultLayouts]);

  // Zoom handlers (for toolbar buttons or keyboard shortcuts +/-)
  const handleZoom = useCallback((delta) => {
    setZoom((prevZoom) => Math.min(3.5, Math.max(0.35, Math.round((prevZoom + delta) * 100) / 100)));
  }, []);

  // Center on subject node
  const handleCenterTarget = useCallback(() => {
    setSelectedNodeId("subject");
    setPan({ x: 0, y: 0 });
    setZoom(1.1);
    playTick("toggle");
  }, []);

  // Modal open/close lifecycle synchronization for smooth pop up and pop down transitions
  useEffect(() => {
    if (isOpen) {
      setIsRendered(true);
      const raf = requestAnimationFrame(() => {
        setIsVisible(true);
      });
      return () => cancelAnimationFrame(raf);
    } else {
      if (isVisible) {
        setIsVisible(false);
        const timer = setTimeout(() => {
          setIsRendered(false);
        }, 200);
        return () => clearTimeout(timer);
      } else {
        setIsRendered(false);
      }
    }
  }, [isOpen, isVisible]);

  // Handle smooth animated dismissal
  const handleClose = useCallback(() => {
    playTick("toggle");
    setIsVisible(false);
    if (closeTimeoutRef.current) clearTimeout(closeTimeoutRef.current);
    closeTimeoutRef.current = setTimeout(() => {
      onClose();
    }, 200);
  }, [onClose]);

  // Lock document body scroll when modal is rendered to guarantee non-scrollable background
  useEffect(() => {
    if (!isRendered) return;

    const originalOverflow = document.body.style.overflow;
    const originalTouchAction = document.body.style.touchAction;
    const originalPaddingRight = document.body.style.paddingRight;
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    document.body.style.touchAction = "none";
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }

    return () => {
      document.body.style.overflow = originalOverflow;
      document.body.style.touchAction = originalTouchAction;
      document.body.style.paddingRight = originalPaddingRight;
    };
  }, [isRendered]);

  // Keyboard controls
  useEffect(() => {
    function handleKeyDown(e) {
      if (!isRendered || !isVisible) return;
      if (["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName)) return;

      if (e.key === "Escape") {
        e.preventDefault();
        handleClose();
      } else if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        playTick("toggle");
        setIsFullscreen((prev) => !prev);
      } else if (e.key === "r" || e.key === "R") {
        e.preventDefault();
        handleResetView();
      } else if (e.key === "t" || e.key === "T") {
        e.preventDefault();
        playTick("toggle");
        setTraceActive((prev) => !prev);
      } else if (e.key === "+" || e.key === "=") {
        e.preventDefault();
        handleZoom(0.15);
      } else if (e.key === "-" || e.key === "_") {
        e.preventDefault();
        handleZoom(-0.15);
      } else if (e.key === "0") {
        e.preventDefault();
        handleCenterTarget();
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isRendered, isVisible, handleClose, handleResetView, handleZoom, handleCenterTarget]);

  // Convert screen coordinates to SVG root viewBox coordinates [0..800, 0..520]
  const getSvgRootCoordinates = useCallback((clientX, clientY) => {
    const svg = svgRef.current;
    if (!svg) return { x: 400, y: 260 };
    try {
      const ctm = svg.getScreenCTM();
      if (ctm) {
        const pt = svg.createSVGPoint();
        pt.x = clientX;
        pt.y = clientY;
        const transformed = pt.matrixTransform(ctm.inverse());
        return { x: transformed.x, y: transformed.y };
      }
    } catch {
      // Fallback below
    }
    return { x: 400, y: 260 };
  }, []);

  // Convert screen coordinates to SVG viewport group coordinates using native CTM matrix
  const getSvgCoordinates = useCallback((e) => {
    const svg = svgRef.current;
    if (!svg) return { x: 400, y: 260 };
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;

    const viewportGroup = svg.querySelector("#viewport-group");
    if (viewportGroup) {
      const gCtm = viewportGroup.getScreenCTM();
      if (gCtm) {
        const transformed = pt.matrixTransform(gCtm.inverse());
        return { x: transformed.x, y: transformed.y };
      }
    }

    const ctm = svg.getScreenCTM();
    if (ctm) {
      const transformed = pt.matrixTransform(ctm.inverse());
      return { x: transformed.x, y: transformed.y };
    }
    return { x: 400, y: 260 };
  }, []);

  // Double-finger zoom, Mac trackpad pinch, and Safari WebKit gesture listener
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg || !isRendered) return;

    const onWheel = (e) => {
      e.preventDefault();
      e.stopPropagation();

      const { x: sx, y: sy } = getSvgRootCoordinates(e.clientX, e.clientY);
      const currentZoom = zoomRef.current;
      const currentPan = panRef.current;

      // Trackpad pinch gesture on macOS Safari / Chrome dispatches wheel with e.ctrlKey === true
      if (e.ctrlKey || e.metaKey) {
        // Logarithmic zoom scaling proportional to finger distance
        const clampedDelta = Math.max(-40, Math.min(40, e.deltaY));
        const factor = Math.exp(-clampedDelta * 0.012);
        const nextZoom = Math.min(3.5, Math.max(0.35, Math.round(currentZoom * factor * 1000) / 1000));

        if (Math.abs(nextZoom - currentZoom) > 0.0005) {
          const zoomRatio = nextZoom / currentZoom;
          const nextPanX = (sx - 400) * (1 - zoomRatio) + currentPan.x * zoomRatio;
          const nextPanY = (sy - 260) * (1 - zoomRatio) + currentPan.y * zoomRatio;

          zoomRef.current = nextZoom;
          panRef.current = { x: nextPanX, y: nextPanY };
          setZoom(nextZoom);
          setPan(panRef.current);
        }
      } else {
        // Two-finger swipe on trackpad (or mouse wheel)
        // If horizontal delta exists or shiftKey is pressed, treat as pan:
        const isHorizontal = Math.abs(e.deltaX) > Math.abs(e.deltaY) * 0.7 || e.shiftKey;
        if (isHorizontal) {
          const nextPanX = currentPan.x - e.deltaX;
          const nextPanY = currentPan.y - e.deltaY;
          panRef.current = { x: nextPanX, y: nextPanY };
          setPan(panRef.current);
        } else {
          // Continuous vertical two-finger scroll or wheel: smooth cursor-anchored zoom
          const clampedDelta = Math.max(-35, Math.min(35, e.deltaY));
          const factor = Math.exp(-clampedDelta * 0.008);
          const nextZoom = Math.min(3.5, Math.max(0.35, Math.round(currentZoom * factor * 1000) / 1000));

          if (Math.abs(nextZoom - currentZoom) > 0.0005) {
            const zoomRatio = nextZoom / currentZoom;
            const nextPanX = (sx - 400) * (1 - zoomRatio) + currentPan.x * zoomRatio;
            const nextPanY = (sy - 260) * (1 - zoomRatio) + currentPan.y * zoomRatio;

            zoomRef.current = nextZoom;
            panRef.current = { x: nextPanX, y: nextPanY };
            setZoom(nextZoom);
            setPan(panRef.current);
          }
        }
      }
    };

    // Safari WebKit Gesture events (Safari trackpad pinch)
    let gestureStartZoom = 1.0;

    const onGestureStart = (e) => {
      e.preventDefault();
      e.stopPropagation();
      gestureStartZoom = zoomRef.current;
    };

    const onGestureChange = (e) => {
      e.preventDefault();
      e.stopPropagation();

      const { x: sx, y: sy } = getSvgRootCoordinates(e.clientX, e.clientY);
      if (typeof e.scale === "number" && !isNaN(e.scale)) {
        const nextZoom = Math.min(3.5, Math.max(0.35, Math.round(gestureStartZoom * e.scale * 1000) / 1000));
        const currentZoom = zoomRef.current;

        if (Math.abs(nextZoom - currentZoom) > 0.0005) {
          const zoomRatio = nextZoom / currentZoom;
          const currentPan = panRef.current;
          const nextPanX = (sx - 400) * (1 - zoomRatio) + currentPan.x * zoomRatio;
          const nextPanY = (sy - 260) * (1 - zoomRatio) + currentPan.y * zoomRatio;

          zoomRef.current = nextZoom;
          panRef.current = { x: nextPanX, y: nextPanY };
          setZoom(nextZoom);
          setPan(panRef.current);
        }
      }
    };

    const onGestureEnd = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };

    svg.addEventListener("wheel", onWheel, { passive: false });
    svg.addEventListener("gesturestart", onGestureStart, { passive: false });
    svg.addEventListener("gesturechange", onGestureChange, { passive: false });
    svg.addEventListener("gestureend", onGestureEnd, { passive: false });

    return () => {
      svg.removeEventListener("wheel", onWheel);
      svg.removeEventListener("gesturestart", onGestureStart);
      svg.removeEventListener("gesturechange", onGestureChange);
      svg.removeEventListener("gestureend", onGestureEnd);
    };
  }, [isRendered, getSvgRootCoordinates]);

  // Window-level mousemove and mouseup listeners to prevent stuck drag/pan
  useEffect(() => {
    if (!isPanning && !draggingNodeId) return;

    const handleWindowMouseMove = (e) => {
      if (isPanning) {
        setPan({
          x: e.clientX - panStartRef.current.x,
          y: e.clientY - panStartRef.current.y,
        });
      } else if (draggingNodeId) {
        const svgPt = getSvgCoordinates(e);
        const newX = Math.round(Math.min(760, Math.max(40, svgPt.x - dragOffsetRef.current.x)));
        const newY = Math.round(Math.min(480, Math.max(40, svgPt.y - dragOffsetRef.current.y)));
        setNodePositions((prev) => ({
          ...prev,
          [draggingNodeId]: { x: newX, y: newY },
        }));
      }
    };

    const handleWindowMouseUp = () => {
      setIsPanning(false);
      setDraggingNodeId(null);
    };

    window.addEventListener("mousemove", handleWindowMouseMove);
    window.addEventListener("mouseup", handleWindowMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleWindowMouseMove);
      window.removeEventListener("mouseup", handleWindowMouseUp);
    };
  }, [isPanning, draggingNodeId, getSvgCoordinates]);

  // Pan initiation on SVG canvas background
  const handleCanvasMouseDown = (e) => {
    if (e.target.closest && e.target.closest("[data-interactive='true']")) {
      return;
    }
    setIsPanning(true);
    panStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  // Canvas double-click to toggle focus zoom or reset view
  const handleCanvasDoubleClick = (e) => {
    if (e.target.closest && e.target.closest("[data-interactive='true']")) {
      return;
    }
    const { x: sx, y: sy } = getSvgRootCoordinates(e.clientX, e.clientY);
    if (zoom > 1.25) {
      handleResetView();
    } else {
      const nextZoom = 1.65;
      const zoomRatio = nextZoom / zoom;
      setPan((prevPan) => ({
        x: (sx - 400) * (1 - zoomRatio) + prevPan.x * zoomRatio,
        y: (sy - 260) * (1 - zoomRatio) + prevPan.y * zoomRatio,
      }));
      setZoom(nextZoom);
      playTick("toggle");
    }
  };

  // Node drag initiation
  const startNodeDrag = (nodeId, e) => {
    e.stopPropagation();
    playTick("toggle");
    setSelectedNodeId(nodeId);
    setDraggingNodeId(nodeId);

    const svgPt = getSvgCoordinates(e);
    const currentPos = nodePositions[nodeId] || { x: 400, y: 260 };
    dragOffsetRef.current = {
      x: svgPt.x - currentPos.x,
      y: svgPt.y - currentPos.y,
    };
  };

  // Copy entity ID to clipboard
  const handleCopyId = (id) => {
    playTick("toggle");
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(id);
      } else {
        const ta = document.createElement("textarea");
        ta.value = id;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      // noop
    }
  };

  // Flag node toggle
  const toggleFlagNode = (nodeId) => {
    playTick("toggle");
    setFlaggedNodes((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  // Export JSON compliance dossier
  const handleExportDossier = () => {
    playTick("nav");
    const cryptoObj = window.crypto || crypto;
    const randomBytes = new Uint8Array(20);
    if (cryptoObj?.getRandomValues) {
      cryptoObj.getRandomValues(randomBytes);
    }
    const digest = Array.from(randomBytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    const dossier = {
      compliance_standard: "Prototype network dossier export; statutory compliance not established",
      theme_mode: isDark ? "dark" : "light",
      export_timestamp: new Date().toISOString(),
      transaction_id: transactionId,
      counterparty_hub: effectiveHubId,
      currency: currencyCode,
      exchange_rate: isUSD ? "1 USD = 83.00 INR" : "1.00",
      primary_flag: "SHARED_DEVICE_AND_HUB_COUNTERPARTY",
      clustering_coefficient: 0.824,
      network_entities: Object.values(nodes).map((n) => ({
        id: n.nodeId,
        label: n.label,
        type: n.category,
        risk_tier: n.risk,
        risk_score: n.riskScore,
        fan_in: n.fanIn,
        fan_out: n.fanOut,
        concentration: n.concentration,
        kyc_status: n.kyc,
        jurisdiction: n.jurisdiction,
        routing_ip: n.ip,
        is_flagged: flaggedNodes.has(n.id),
      })),
      flow_vectors: edges.map((e) => ({
        source: nodes[e.source]?.nodeId || e.source,
        target: nodes[e.target]?.nodeId || e.target,
        type: e.type,
        transfer_volume: e.amount,
        latency: e.latency,
      })),
      attestation_digest: digest ? `0x${digest}` : null,
    };

    const blob = new Blob([JSON.stringify(dossier, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sentinel_syndicate_link_dossier_${transactionId}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Node visibility logic for filtering and search
  const isNodeVisible = useCallback(
    (node) => {
      if (filterType === "account" && node.category !== "account") return false;
      if (filterType === "device" && node.category !== "device") return false;
      if (filterType === "infra" && node.category !== "infra") return false;
      if (filterType === "critical" && node.risk !== "CRITICAL" && node.risk !== "HIGH") return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          node.nodeId.toLowerCase().includes(q) ||
          node.label.toLowerCase().includes(q) ||
          node.subLabel.toLowerCase().includes(q) ||
          node.jurisdiction.toLowerCase().includes(q) ||
          node.ip.toLowerCase().includes(q)
        );
      }
      return true;
    },
    [filterType, searchQuery]
  );

  // Calculate perimeter-anchored edge endpoints so arrowheads are never covered by nodes
  const calculateEdgeGeometry = useCallback((sourcePos, targetPos, sourceId, targetId) => {
    if (!sourcePos || !targetPos) return null;
    const dx = targetPos.x - sourcePos.x;
    const dy = targetPos.y - sourcePos.y;
    const dist = Math.hypot(dx, dy) || 1;
    const ux = dx / dist;
    const uy = dy / dist;

    // Radius of nodes: primary accounts are 30px, secondary 24px
    const sourceRadius = sourceId === "subject" || sourceId === "hub" ? 30 : 24;
    const targetRadius = targetId === "subject" || targetId === "hub" ? 30 : 24;

    // Start 3px outside source perimeter
    const x1 = sourcePos.x + ux * (sourceRadius + 3);
    const y1 = sourcePos.y + uy * (sourceRadius + 3);

    // Terminate 9px outside target perimeter to leave exact clearance for arrowhead marker
    const x2 = targetPos.x - ux * (targetRadius + 9);
    const y2 = targetPos.y - uy * (targetRadius + 9);

    const midX = (sourcePos.x + targetPos.x) / 2;
    const midY = (sourcePos.y + targetPos.y) / 2;

    return { x1, y1, x2, y2, midX, midY };
  }, []);

  if (!isRendered) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${P.backdrop} p-0 sm:p-3 md:p-6 backdrop-blur-md select-none transition-all duration-200 ${
        isVisible ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
      }`}
      onClick={handleClose}
      onWheel={(e) => {
        if (e.target === e.currentTarget) e.preventDefault();
      }}
    >
      <div
        className={`w-full overflow-hidden border ${P.modalBorder} ${P.modalBg} shadow-2xl specular-card flex flex-col transition-all ${
          isVisible
            ? "opacity-100 scale-100 translate-y-0 duration-260 ease-[cubic-bezier(0.16,1,0.3,1)]"
            : "opacity-0 scale-[0.95] translate-y-3 duration-200 ease-[cubic-bezier(0.4,0,0.2,1)]"
        } ${
          isFullscreen ? "h-[100dvh] max-w-[100vw] rounded-none" : "h-[100dvh] sm:h-[88vh] sm:rounded-xl max-w-7xl"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Workstation Top Bar */}
        <div className={`flex items-center justify-between border-b ${P.modalBorder} ${P.topBarBg} px-3 sm:px-5 py-2.5 sm:py-3.5 shrink-0`}>
          <div className="flex items-center gap-3">
            <div
              className="flex h-9 w-9 items-center justify-center rounded-lg border shadow-xs"
              style={{
                borderColor: `${P.steel}50`,
                backgroundColor: `${P.steel}15`,
                color: P.steel,
              }}
            >
              <Network className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-sm font-bold tracking-tight text-ink">
                  Syndicate Link Analysis & Multi-Entity Topology
                </h2>
                <span
                  className="font-mono text-meta-xs font-semibold flex items-center gap-1"
                  style={{ color: P.spark }}
                >
                  <ShieldAlert className="h-3 w-3 shrink-0" />
                  <span>Shared Device & Hub Counterparty</span>
                </span>
                <span className="text-divider">·</span>
                <span
                  className="font-mono text-meta-xs font-semibold flex items-center gap-1"
                  style={{ color: P.success }}
                >
                  <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ backgroundColor: P.success }} />
                  <span>API Record Loaded</span>
                </span>
              </div>
              <p className="font-mono text-3xs text-ink-muted mt-0.5">
                Case Target: <span className="text-ink font-bold">{transactionId}</span> ·
                Correlated Entities: <span style={{ color: P.steel }}>7 Nodes</span> · Flow Edges:{" "}
                <span style={{ color: P.steel }}>8 Vectors</span> · Engine:{" "}
                <span className="text-ink-muted">Sentinel Link Forensics v2.4 ({isDark ? "Dark Theme" : "Light Theme"})</span>
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportDossier}
              className={`flex items-center gap-1.5 rounded-lg border ${P.modalBorder} ${P.buttonBg} ${P.buttonHover} px-3 py-1.5 text-xs font-semibold text-ink transition-all shadow-xs`}
              title="Export structured JSON evidence dossier"
            >
              <Download className="h-3.5 w-3.5" style={{ color: P.steel }} />
              <span className="hidden sm:inline">Export Dossier</span>
            </button>

            <button
              onClick={() => {
                playTick("toggle");
                setIsFullscreen((prev) => !prev);
              }}
              className={`rounded-lg border ${P.modalBorder} ${P.buttonBg} ${P.buttonHover} p-1.5 text-ink-muted transition-colors`}
              title={isFullscreen ? "Exit Fullscreen (F)" : "Expand Fullscreen (F)"}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>

            <button
              onClick={handleClose}
              className={`rounded-lg border ${P.modalBorder} ${P.buttonBg} ${P.buttonHover} p-1.5 text-ink-muted hover:text-critical transition-colors ml-1`}
              title="Close Workstation (Esc)"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Workstation Controls Ribbon */}
        <div className={`flex items-center justify-between border-b ${P.modalBorder} ${P.controlsBg} px-3 sm:px-5 py-2 sm:py-2.5 text-xs text-ink-muted shrink-0 gap-2 sm:gap-4 flex-wrap`}>
          {/* Entity Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none">
            <span className="font-mono text-3xs uppercase tracking-wider text-ink-faint mr-1 flex items-center gap-1 shrink-0">
              <SlidersHorizontal className="h-3 w-3" />
              <span>Filters:</span>
            </span>
            {[
              { key: "all", label: `All Entities (${filterCounts.all})` },
              { key: "critical", label: `High Risk (${filterCounts.critical})` },
              { key: "account", label: `Accounts (${filterCounts.account})` },
              { key: "device", label: `Hardware UUID (${filterCounts.device})` },
              { key: "infra", label: `Proxy/Infra (${filterCounts.infra})` },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => {
                  playTick("toggle");
                  setFilterType(f.key);
                }}
                className={`rounded-md px-2.5 py-1 font-mono text-2xs font-semibold transition-all ${
                  filterType === f.key
                    ? "font-bold shadow-xs text-white"
                    : `${P.buttonBg} text-ink-muted ${P.buttonHover} border ${P.modalBorder}`
                }`}
                style={
                  filterType === f.key
                    ? {
                        backgroundColor: P.steel,
                        color: isDark ? "#121315" : "#FFFFFF",
                      }
                    : undefined
                }
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search and Layout Toggles */}
          <div className="flex items-center gap-3">
            {/* Entity Quick Filter Input */}
            <div className="relative">
              <Search className="h-3 w-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-faint" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search entity, ID, IP…"
                className={`rounded-md border ${P.modalBorder} ${P.dockBg} pl-7 pr-2.5 py-1 text-2xs font-mono text-ink placeholder-ink-faint focus:outline-none w-44 transition-all`}
                style={{ borderColor: P.border }}
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 inline-flex h-5 w-5 items-center justify-center rounded text-ink-faint hover:bg-panel hover:text-ink focus-visible:outline-none"
                  aria-label="Clear entity search"
                  title="Clear search"
                >
                  <X className="h-3 w-3" weight="bold" aria-hidden />
                </button>
              )}
            </div>

            {/* Layout Switcher */}
            <div className={`flex items-center rounded-md border ${P.modalBorder} ${P.dockBg} p-0.5`}>
              <button
                onClick={() => {
                  playTick("toggle");
                  setLayoutMode("radial");
                }}
                className={`rounded px-2 py-0.5 text-3xs font-mono font-semibold transition-all ${
                  layoutMode === "radial"
                    ? `${P.cardBg} font-bold shadow-xs`
                    : "text-ink-faint hover:text-ink"
                }`}
                style={layoutMode === "radial" ? { color: P.steel } : undefined}
              >
                Radial Orbit
              </button>
              <button
                onClick={() => {
                  playTick("toggle");
                  setLayoutMode("pipeline");
                }}
                className={`rounded px-2 py-0.5 text-3xs font-mono font-semibold transition-all ${
                  layoutMode === "pipeline"
                    ? `${P.cardBg} font-bold shadow-xs`
                    : "text-ink-faint hover:text-ink"
                }`}
                style={layoutMode === "pipeline" ? { color: P.steel } : undefined}
              >
                Layering Pipeline
              </button>
            </div>

            {/* Trace Fund Flow Toggle */}
            <button
              onClick={() => {
                playTick("toggle");
                setTraceActive((prev) => !prev);
              }}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-2xs font-mono font-bold transition-all border`}
              style={
                traceActive
                  ? {
                      borderColor: P.spark,
                      backgroundColor: `${P.spark}25`,
                      color: P.spark,
                    }
                  : {
                      borderColor: P.border,
                      backgroundColor: isDark ? P.panel : "#FFFFFF",
                      color: P.inkMuted,
                    }
              }
            >
              <Zap className={`h-3 w-3 ${traceActive ? "animate-pulse" : ""}`} style={{ color: traceActive ? P.spark : P.inkMuted }} />
              <span>{traceActive ? "Trace Active" : "Trace Flow"}</span>
            </button>
          </div>
        </div>

        {/* Workstation Main Dual-Pane Body */}
        <div className="flex flex-col lg:grid lg:grid-cols-12 flex-1 overflow-hidden">
          {/* Left Canvas (SVG) */}
          <div
            className={`relative lg:col-span-8 h-[42vh] sm:h-[52vh] lg:h-full shrink-0 flex flex-col justify-between overflow-hidden border-b lg:border-b-0 lg:border-r ${P.modalBorder}`}
            style={{ backgroundColor: P.canvas }}
            onMouseDown={handleCanvasMouseDown}
            onDoubleClick={handleCanvasDoubleClick}
          >
            {/* Top Canvas Telemetry Overlay */}
            <div
              className={`absolute top-3 left-3 z-10 flex items-center gap-2 font-mono text-3xs px-3 py-1.5 rounded-lg border shadow-xs pointer-events-none backdrop-blur-md`}
              style={{
                backgroundColor: isDark ? "rgba(26, 26, 26, 0.85)" : "rgba(255, 255, 255, 0.90)",
                borderColor: P.border,
                color: P.inkMuted,
              }}
            >
              <span className="h-2 w-2 rounded-full bg-low live-pulse-dot" />
              <span>Interactive Graph · Click node to inspect · Drag to reposition · Drag canvas to pan</span>
            </div>

            {/* Bottom-Left Canvas Navigation Toolbar */}
            <div
              className={`absolute bottom-3 left-3 z-10 flex items-center gap-1 backdrop-blur-md p-1 rounded-lg border shadow-md`}
              style={{
                backgroundColor: isDark ? "rgba(26, 26, 26, 0.92)" : "rgba(255, 255, 255, 0.95)",
                borderColor: P.border,
              }}
              data-interactive="true"
            >
              <button
                onClick={() => handleZoom(0.15)}
                className={`rounded p-1.5 text-ink-muted ${P.buttonHover} transition-colors`}
                title="Zoom In (+)"
              >
                <ZoomIn className="h-4 w-4" />
              </button>
              <button
                onClick={() => handleZoom(-0.15)}
                className={`rounded p-1.5 text-ink-muted ${P.buttonHover} transition-colors`}
                title="Zoom Out (-)"
              >
                <ZoomOut className="h-4 w-4" />
              </button>
              <span className="font-mono text-3xs px-1 font-semibold text-ink-faint">
                {Math.round(zoom * 100)}%
              </span>
              <div className="h-3 w-px mx-0.5" style={{ backgroundColor: P.border }} />
              <button
                onClick={handleResetView}
                className={`flex items-center gap-1 rounded px-2 py-1 text-3xs font-mono text-ink-muted ${P.buttonHover} transition-colors`}
                title="Reset View and Spring Layout (R)"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset</span>
              </button>
              <button
                onClick={handleCenterTarget}
                className={`flex items-center gap-1 rounded px-2 py-1 text-3xs font-mono transition-colors`}
                style={{ color: P.steel }}
                title="Center Subject Account (0)"
              >
                <Crosshair className="h-3 w-3" />
                <span>Target</span>
              </button>
            </div>

            {/* Interactive SVG Surface */}
            <svg
              ref={svgRef}
              viewBox="0 0 800 520"
              className={`w-full h-full select-none ${
                isPanning ? "cursor-grabbing" : draggingNodeId ? "cursor-grabbing" : "cursor-grab"
              }`}
            >
              <defs>
                {/* Theme-Specific Tactical Coordinate Grid */}
                <pattern
                  id="forensic-grid"
                  width="32"
                  height="32"
                  patternUnits="userSpaceOnUse"
                >
                  <circle cx="16" cy="16" r="0.8" fill={P.gridDot} />
                  <path
                    d="M 32 0 L 0 0 0 32"
                    fill="none"
                    stroke={P.gridLine}
                    strokeWidth="0.5"
                  />
                </pattern>

                {/* Arrowhead Markers with Precision Geometry */}
                <marker
                  id="arrow-spark"
                  viewBox="0 0 10 10"
                  refX="7"
                  refY="5"
                  markerWidth="7"
                  markerHeight="7"
                  orient="auto"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill={P.spark} />
                </marker>
                <marker
                  id="arrow-steel"
                  viewBox="0 0 10 10"
                  refX="7"
                  refY="5"
                  markerWidth="7"
                  markerHeight="7"
                  orient="auto"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill={P.steel} />
                </marker>
                <marker
                  id="arrow-muted"
                  viewBox="0 0 10 10"
                  refX="7"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill={P.steelDeep} />
                </marker>

                {/* Glow Filters */}
                <filter id="glow-spark" x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation="3.5" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <filter id="glow-accent" x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Background Canvas Layers */}
              <rect
                id="bg-rect"
                x="-1000"
                y="-1000"
                width="3000"
                height="3000"
                fill={P.canvas}
              />
              <rect
                id="bg-grid"
                x="-1000"
                y="-1000"
                width="3000"
                height="3000"
                fill="url(#forensic-grid)"
              />

              {/* Transform Container Group for Zoom and Pan */}
              <g
                id="viewport-group"
                transform={`translate(${pan.x}, ${pan.y}) translate(400, 260) scale(${zoom}) translate(-400, -260)`}
              >
                {/* 1. RENDER EDGES / TRANSACTION FLOW CONDUITS */}
                {edges.map((edge) => {
                  const sourcePos = nodePositions[edge.source];
                  const targetPos = nodePositions[edge.target];
                  const geom = calculateEdgeGeometry(sourcePos, targetPos, edge.source, edge.target);
                  if (!geom) return null;

                  const isIncident =
                    edge.source === selectedNodeId || edge.target === selectedNodeId;
                  const isTraceHighlighted = traceActive && edge.trace;
                  const strokeColor =
                    isTraceHighlighted || (isIncident && edge.critical)
                      ? P.spark
                      : isIncident
                      ? P.steel
                      : edge.critical
                      ? `${P.spark}80`
                      : P.edgeDefault;

                  const markerId =
                    isTraceHighlighted || (isIncident && edge.critical)
                      ? "url(#arrow-spark)"
                      : isIncident
                      ? "url(#arrow-steel)"
                      : "url(#arrow-muted)";

                  return (
                    <g key={edge.id} className="transition-opacity duration-200">
                      {/* Under-glow highlight corridor */}
                      {(isIncident || isTraceHighlighted) && (
                        <line
                          x1={geom.x1}
                          y1={geom.y1}
                          x2={geom.x2}
                          y2={geom.y2}
                          stroke={strokeColor}
                          strokeWidth="6"
                          strokeOpacity={isDark ? "0.25" : "0.15"}
                        />
                      )}

                      {/* Main Connection Vector Line */}
                      <line
                        x1={geom.x1}
                        y1={geom.y1}
                        x2={geom.x2}
                        y2={geom.y2}
                        stroke={strokeColor}
                        strokeWidth={isIncident || isTraceHighlighted ? 2.5 : 1.75}
                        strokeDasharray={
                          edge.type === "HARDWARE AUTH"
                            ? "4 3"
                            : edge.type === "ROUTING PROXY"
                            ? "3 3"
                            : "none"
                        }
                        markerEnd={markerId}
                      />

                      {/* Animated Flow Pulse Particles */}
                      {(edge.type === "WIRE TRANSFER" || isTraceHighlighted || isIncident) && (
                        <line
                          x1={geom.x1}
                          y1={geom.y1}
                          x2={geom.x2}
                          y2={geom.y2}
                          stroke={isTraceHighlighted ? P.spark : P.steel}
                          strokeWidth="2"
                          strokeDasharray="6 8"
                          className="animate-flow-dash"
                          strokeOpacity="0.85"
                        />
                      )}

                      {/* Midpoint Pill Tag */}
                      <g
                        data-interactive="true"
                        transform={`translate(${geom.midX}, ${geom.midY})`}
                        className="cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          playTick("toggle");
                          setSelectedNodeId(edge.target);
                        }}
                      >
                        <rect
                          x="-38"
                          y="-9"
                          width="76"
                          height="18"
                          rx="4"
                          fill={P.nodePillBg}
                          stroke={isIncident ? strokeColor : P.nodePillBorder}
                          strokeWidth="1"
                        />
                        <text
                          x="0"
                          y="3"
                          textAnchor="middle"
                          fill={isIncident ? P.ink : P.inkMuted}
                          fontSize="7.5"
                          fontFamily="monospace"
                          fontWeight="600"
                        >
                          {edge.amount}
                        </text>
                      </g>
                    </g>
                  );
                })}

                {/* 2. RENDER NODES */}
                {Object.values(nodes).map((node) => {
                  const pos = nodePositions[node.id];
                  if (!pos) return null;

                  const isSelected = selectedNodeId === node.id;
                  const isVisible = isNodeVisible(node);
                  const isFlagged = flaggedNodes.has(node.id);
                  const NodeIcon = node.icon;
                  const isPrimary = node.id === "subject" || node.id === "hub";
                  const nodeRadius = isPrimary ? 30 : 24;
                  const isBeingDragged = draggingNodeId === node.id;

                  return (
                    <g
                      key={node.id}
                      data-interactive="true"
                      transform={`translate(${pos.x}, ${pos.y})`}
                      className={`cursor-pointer ${
                        isBeingDragged ? "" : "transition-transform duration-200"
                      } ${isVisible ? "opacity-100" : "opacity-25"}`}
                      onMouseDown={(e) => startNodeDrag(node.id, e)}
                      onClick={(e) => {
                        e.stopPropagation();
                        playTick("toggle");
                        setSelectedNodeId(node.id);
                      }}
                    >
                      {/* Active Selection Rotating Halo */}
                      {isSelected && (
                        <circle
                          r={nodeRadius + 9}
                          fill="none"
                          stroke={node.color}
                          strokeWidth="1.5"
                          strokeDasharray="4 3"
                          className="animate-spin"
                          style={{ animationDuration: "12s" }}
                          strokeOpacity="0.8"
                        />
                      )}

                      {/* Flagged Alert Halo */}
                      {isFlagged && (
                        <circle
                          r={nodeRadius + 5}
                          fill="none"
                          stroke={P.spark}
                          strokeWidth="1.5"
                          strokeOpacity="0.5"
                          className="animate-pulse"
                        />
                      )}

                      {/* Main Node Outer Ring */}
                      <circle
                        r={nodeRadius}
                        fill={P.nodeFill}
                        stroke={isSelected ? node.color : isFlagged ? P.spark : P.nodeBorder}
                        strokeWidth={isSelected ? 2.5 : 1.75}
                        filter={isSelected ? "url(#glow-accent)" : undefined}
                      />

                      {/* Inner Circular Well */}
                      <circle
                        r={nodeRadius - 6}
                        fill={P.nodeInnerWell}
                        stroke={P.border}
                        strokeWidth="1"
                      />

                      {/* Embedded SVG Icon Center */}
                      <g transform="translate(-8, -8)" className="pointer-events-none">
                        <NodeIcon
                          size={16}
                          color={isSelected ? P.ink : node.color}
                          strokeWidth={2.2}
                        />
                      </g>

                      {/* Risk Tier Pip Badge (Top-Right) */}
                      <g transform={`translate(${nodeRadius - 6}, ${-nodeRadius + 6})`}>
                        <circle
                          r="6"
                          fill={P.nodeFill}
                          stroke={node.color}
                          strokeWidth="1.5"
                        />
                        <circle
                          r="3"
                          fill={node.color}
                        />
                      </g>

                      {/* Floating Text Pill Label Below Node */}
                      <g transform={`translate(0, ${nodeRadius + 14})`}>
                        <rect
                          x="-54"
                          y="-8"
                          width="108"
                          height="16"
                          rx="3"
                          fill={P.nodePillBg}
                          stroke={isSelected ? node.color : P.nodePillBorder}
                          strokeWidth="1"
                        />
                        <text
                          x="0"
                          y="3"
                          textAnchor="middle"
                          fill={isSelected ? P.ink : P.inkMuted}
                          fontSize="8"
                          fontFamily="monospace"
                          fontWeight="bold"
                        >
                          {node.nodeId}
                        </text>
                      </g>

                      {/* Sub-label Identifier */}
                      <text
                        x="0"
                        y={nodeRadius + 32}
                        textAnchor="middle"
                        fill={P.inkFaint}
                        fontSize="7"
                        fontFamily="sans-serif"
                        fontWeight="500"
                      >
                        {node.label}
                      </text>
                    </g>
                  );
                })}
              </g>
            </svg>

            {/* Bottom Legend Bar */}
            <div
              className={`border-t ${P.modalBorder} px-4 py-2 flex items-center justify-between text-3xs font-mono text-ink-muted flex-wrap gap-2 shrink-0`}
              style={{ backgroundColor: isDark ? "rgba(21, 22, 24, 0.90)" : "#F0F4F8" }}
            >
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: P.spark }} />
                  <span>Critical Risk (&gt;90)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: P.warning }} />
                  <span>High Risk (70-89)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: P.steel }} />
                  <span>Elevated (50-69)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-6 border-b-2 border-dashed" style={{ borderColor: P.spark }} />
                  <span>Hardware Binding</span>
                </span>
              </div>
              <div className="text-ink-faint font-mono text-3xs">
                Interactive Force Topology · Drag nodes to reposition
              </div>
            </div>
          </div>

          {/* Right Inspector Column: Forensic Entity Intelligence */}
          <div className={`lg:col-span-4 ${P.modalBg} flex-1 flex flex-col justify-between overflow-y-auto p-3.5 sm:p-5 border-l-0 lg:border-l ${P.modalBorder}`}>
            <div className="space-y-4">
              {/* Selected Entity Card Header */}
              <div className={`flex items-start justify-between border-b ${P.modalBorder} pb-3.5`}>
                <div className="flex items-center gap-3">
                  <div
                    className="flex h-10 w-10 items-center justify-center rounded-xl border shadow-sm"
                    style={{
                      borderColor: activeNode.color,
                      backgroundColor: `${activeNode.color}15`,
                      color: activeNode.color,
                    }}
                  >
                    <ActiveIcon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-xs font-bold text-ink">
                        {activeNode.nodeId}
                      </span>
                      <button
                        onClick={() => handleCopyId(activeNode.nodeId)}
                        className="text-ink-faint hover:text-ink transition-colors"
                        title="Copy Entity ID"
                      >
                        {copiedId ? (
                          <Check className="h-3 w-3" style={{ color: P.success }} />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </button>
                    </div>
                    <div className="text-2xs text-ink-muted font-medium">
                      {activeNode.subLabel}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className="inline-flex items-center gap-1 font-mono text-meta-xs font-bold"
                    style={{ color: activeNode.color }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ backgroundColor: activeNode.color }} />
                    <span>{activeNode.risk}</span>
                  </span>
                  <div className="font-mono text-3xs text-ink-faint mt-0.5 uppercase tracking-wider">
                    Score: {activeNode.riskScore}/100
                  </div>
                </div>
              </div>

              {/* Status Banner */}
              <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} px-3 py-2 flex items-center justify-between text-2xs font-mono`}>
                <span className="text-ink-faint">Status / Classification:</span>
                <span className="font-bold text-ink">{activeNode.status}</span>
              </div>

              {/* 4-Pod Forensic Structural Metrics */}
              <div className="grid grid-cols-2 gap-2 font-mono text-2xs">
                <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} p-2.5`}>
                  <div className="text-3xs text-ink-faint uppercase tracking-wider">
                    Fan-In Accounts
                  </div>
                  <div className="text-base font-bold text-ink mt-0.5">
                    {activeNode.fanIn}
                  </div>
                  <div className="text-3xs text-ink-muted mt-0.5">
                    {activeNode.fanIn > 50 ? "⚠ Anomalous concentration" : "Standard baseline"}
                  </div>
                </div>

                <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} p-2.5`}>
                  <div className="text-3xs text-ink-faint uppercase tracking-wider">
                    Device Fan-Out
                  </div>
                  <div className="text-base font-bold mt-0.5" style={{ color: P.steel }}>
                    {activeNode.fanOut}
                  </div>
                  <div className="text-3xs text-ink-muted mt-0.5">
                    {activeNode.fanOut > 3 ? "⚠ Collusion cluster" : "Single device"}
                  </div>
                </div>

                <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} p-2.5`}>
                  <div className="text-3xs text-ink-faint uppercase tracking-wider">
                    Concentration
                  </div>
                  <div className="text-base font-bold text-ink mt-0.5">
                    {activeNode.concentration}
                  </div>
                  <div className="text-3xs text-ink-muted mt-0.5">Primary peer share</div>
                </div>

                <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} p-2.5`}>
                  <div className="text-3xs text-ink-faint uppercase tracking-wider">
                    30-Day Volume
                  </div>
                  <div className="text-base font-bold text-ink mt-0.5 truncate">
                    {activeNode.turnover}
                  </div>
                  <div className="text-3xs text-ink-muted mt-0.5">Rolling turnover</div>
                </div>
              </div>

              {/* Entity Identity & Network Details */}
              <div className={`space-y-1.5 font-mono text-2xs rounded-lg border ${P.modalBorder} ${P.cardBg} p-3`}>
                <div className={`flex justify-between border-b ${P.modalBorder} pb-1.5`}>
                  <span className="text-ink-faint">KYC Tier:</span>
                  <span className="text-ink font-semibold">{activeNode.kyc}</span>
                </div>
                <div className={`flex justify-between border-b ${P.modalBorder} py-1.5`}>
                  <span className="text-ink-faint">Jurisdiction:</span>
                  <span className="text-ink font-semibold">{activeNode.jurisdiction}</span>
                </div>
                <div className="flex justify-between pt-1.5">
                  <span className="text-ink-faint">Routing / IP:</span>
                  <span className="font-semibold" style={{ color: P.steel }}>{activeNode.ip}</span>
                </div>
              </div>

              {/* Topology Findings & Forensic Notes */}
              <div className={`rounded-lg border ${P.modalBorder} ${P.cardBg} p-3 text-2xs text-ink-muted leading-relaxed`}>
                <div className="font-mono text-3xs font-bold uppercase text-ink mb-1.5 flex items-center gap-1.5">
                  <ShieldAlert className="h-3.5 w-3.5" style={{ color: P.spark }} />
                  <span>Structural Topology Finding:</span>
                </div>
                {activeNode.notes}
              </div>

              {/* Connected Vectors Ledger */}
              <div className="space-y-1.5">
                <div className="font-mono text-3xs font-bold uppercase tracking-wider text-ink-faint flex items-center justify-between">
                  <span>Incident Link Vectors ({incidentLinks.length})</span>
                  <span style={{ color: P.steel }}>Live Corroboration</span>
                </div>
                <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                  {incidentLinks.map((link) => {
                    const otherNodeId =
                      link.source === selectedNodeId ? link.target : link.source;
                    const otherNode = nodes[otherNodeId];
                    const isOutbound = link.source === selectedNodeId;

                    return (
                      <div
                        key={link.id}
                        onClick={() => {
                          playTick("toggle");
                          setSelectedNodeId(otherNodeId);
                        }}
                        className={`rounded border ${P.modalBorder} ${P.dockBg} p-2 flex items-center justify-between font-mono text-3xs ${P.buttonHover} cursor-pointer transition-all`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="rounded px-1 py-0.5 text-[8px] font-bold"
                            style={
                              isOutbound
                                ? {
                                    backgroundColor: `${P.spark}20`,
                                    color: P.spark,
                                  }
                                : {
                                    backgroundColor: `${P.steel}20`,
                                    color: P.steel,
                                  }
                            }
                          >
                            {isOutbound ? "OUTBOUND" : "INBOUND"}
                          </span>
                          <span className="text-ink font-bold">
                            {otherNode?.nodeId || otherNodeId}
                          </span>
                          <span className="text-ink-faint">({link.type})</span>
                        </div>
                        <div className="text-right">
                          <span className="text-ink font-bold">{link.amount}</span>
                          <div className="text-[8px] text-ink-faint">{link.latency}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Bottom Actions & Attestation Footer */}
            <div className={`pt-4 mt-4 border-t ${P.modalBorder} space-y-2.5`}>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => toggleFlagNode(selectedNodeId)}
                  className={`flex items-center justify-center gap-1.5 rounded-lg border py-2 text-xs font-semibold transition-all shadow-xs`}
                  style={
                    flaggedNodes.has(selectedNodeId)
                      ? {
                          borderColor: P.spark,
                          backgroundColor: `${P.spark}25`,
                          color: P.spark,
                        }
                      : {
                          borderColor: P.border,
                          backgroundColor: isDark ? P.panel : "#FFFFFF",
                          color: P.inkMuted,
                        }
                  }
                >
                  <ShieldAlert className="h-3.5 w-3.5" />
                  <span>
                    {flaggedNodes.has(selectedNodeId) ? "Flagged for SAR" : "Flag for SAR"}
                  </span>
                </button>

                <button
                  onClick={() => {
                    playTick("toggle");
                    setTraceActive((prev) => !prev);
                  }}
                  className={`flex items-center justify-center gap-1.5 rounded-lg border py-2 text-xs font-semibold transition-all shadow-xs`}
                  style={{
                    borderColor: `${P.steel}60`,
                    backgroundColor: `${P.steel}20`,
                    color: P.steel,
                  }}
                >
                  <Zap className="h-3.5 w-3.5" />
                  <span>{traceActive ? "Stop Trace" : "Trace Trail"}</span>
                </button>
              </div>

              <div className="flex items-center justify-between text-3xs font-mono text-ink-faint pt-1">
                <span>Prototype Audit Export</span>
                <span>Sentinel Core Neural Graph ({isDark ? "Dark" : "Light"})</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
