import { CheckCircle2, AlertTriangle, Minus, FileText, ExternalLink } from "./PhosphorIcons";

const STANCE_CFG = {
  supports: {
    Icon: CheckCircle2,
    iconClass: "text-low",
    containerClass: "border-border bg-panel-dock/40 hover:border-border-strong",
    label: "Supports Flag",
    labelClass: "text-text-secondary",
  },
  contradicts: {
    Icon: AlertTriangle,
    iconClass: "text-medium",
    containerClass: "border-border bg-panel-dock/40 hover:border-border-strong",
    label: "Contradicts Flag",
    labelClass: "text-text-secondary",
  },
  neutral: {
    Icon: Minus,
    iconClass: "text-text-muted",
    containerClass: "border-border bg-panel-dock/20 hover:border-border-strong",
    label: "Neutral",
    labelClass: "text-text-muted",
  },
};

function EvidenceLine({ item, onDocClick }) {
  const cfg = STANCE_CFG[item.stance] || STANCE_CFG.neutral;
  const { Icon } = cfg;

  return (
    <div className={`flex gap-3 rounded-control border p-3 transition-colors ${cfg.containerClass}`}>
      <Icon
        className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${cfg.iconClass}`}
        strokeWidth={1.75}
      />

      <div className="min-w-0 flex-1">
        {/* Document reference line */}
        <div className="mb-1.5 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onDocClick && onDocClick(item.document_id)}
              className="group inline-flex items-center gap-1.5 rounded-control border border-border bg-surface px-2 py-0.5 font-mono text-xs font-medium text-text-primary transition-colors hover:border-accent hover:text-accent focus:outline-none focus:ring-1 focus:ring-accent"
              aria-label={`Inspect evidence document ${item.document_id}`}
            >
              <FileText className="h-2.5 w-2.5 text-text-muted" />
              <span>{item.document_id}</span>
              <ExternalLink className="h-2 w-2 opacity-50 group-hover:opacity-100" />
            </button>
            <span className={`text-xs font-medium ${cfg.labelClass}`}>
              · {cfg.label}
            </span>
          </div>

          {item.relevance_score != null && (
            <span className="font-mono text-3xs tabular-nums text-text-muted">
              {(item.relevance_score * 100).toFixed(0)}% relevance
            </span>
          )}
        </div>

        {/* Statement excerpt */}
        <p className="text-xs leading-relaxed text-text-secondary">
          {item.statement}
        </p>
      </div>
    </div>
  );
}

export function SupportingEvidencePanel({ items, onDocClick }) {
  return (
    <div className="rounded-panel border border-border p-4 space-y-3" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
      <div className="flex items-center justify-between border-b border-border/40 pb-2">
        <h3 className="text-xs font-semibold text-text-primary">
          Supporting Evidence
        </h3>
        <span className="text-xs text-text-muted">
          {items.length} {items.length === 1 ? "document" : "documents"}
        </span>
      </div>
      {items.length === 0 ? (
        <div className="py-2 text-xs text-text-muted">
          No corroborating documents identified in current ingestion buffer.
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((e, i) => (
            <EvidenceLine key={i} item={e} onDocClick={onDocClick} />
          ))}
        </div>
      )}
    </div>
  );
}

export function CounterEvidencePanel({ items, onDocClick }) {
  return (
    <div className="rounded-panel border border-border p-4 space-y-3" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
      <div className="flex items-center justify-between border-b border-border/40 pb-2">
        <h3 className="text-xs font-semibold text-text-primary">
          Counter-Evidence Search
        </h3>
        <span className="text-xs text-text-muted">
          {items.length} {items.length === 1 ? "document" : "documents"}
        </span>
      </div>
      {items.length === 0 ? (
        <div className="py-2 text-xs text-text-muted">
          None found — the agent checked client records and found nothing contradicting the flag.
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((e, i) => (
            <EvidenceLine key={i} item={e} onDocClick={onDocClick} />
          ))}
        </div>
      )}
      <div className="border-t border-border/40 pt-2 text-xs text-text-muted leading-relaxed">
        Sentinel checks for exculpatory evidence before recommending escalation.
      </div>
    </div>
  );
}
