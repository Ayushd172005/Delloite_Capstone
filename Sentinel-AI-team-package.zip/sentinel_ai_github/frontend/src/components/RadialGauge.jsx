import { useMemo } from "react";

/**
 * RadialGauge: Ultra-clean, precision-engineered institutional risk gauge.
 * 
 * Geometry:
 * - 200° horseshoe arc from 170° to 370° (cy = 68, r = 52).
 * - Arc endpoints terminate strictly at y = 77.03.
 * - Center telemetry (score + label) is nestled cleanly inside the arc peak (y: 35-70).
 * - Status pill badge is placed at y = 93-113, providing a guaranteed 16px vertical clearance
 *   and 14px horizontal clearance from arc endpoints — mathematically eliminating collisions.
 * - Entire component renders in SVG vector space so all proportions scale identically
 *   across large inspection views (160px) and compact table/dossier panels (90px).
 */
export default function RadialGauge({ score, tier, size = 180 }) {
  const safeScore = score != null ? Math.min(100, Math.max(0, Number(score))) : 0;
  const isCompact = size < 110;

  // Horseshoe arc constants: 200° sweep from 170° to 370° (10°)
  // cx = 80, cy = 68, r = 52
  // Start: (28.79, 77.03) | Peak: (80, 16) | End: (131.21, 77.03)
  const arcLength = 181.51; // (2 * PI * 52 * 200) / 360
  const strokeDashoffset = arcLength - (safeScore / 100) * arcLength;

  // Active indicator pip coordinate
  const pipAngleDeg = 170 + (safeScore / 100) * 200;
  const pipRad = (pipAngleDeg * Math.PI) / 180;
  const pipX = (80 + 52 * Math.cos(pipRad)).toFixed(2);
  const pipY = (68 + 52 * Math.sin(pipRad)).toFixed(2);

  const tierConfig = useMemo(() => {
    const upper = tier ? String(tier).toUpperCase() : "";
    if (upper.includes("CRIT") || safeScore >= 85) {
      return {
        label: "CRITICAL",
        color: "var(--color-risk-crit, #ff6b35)",
        bg: "var(--color-risk-crit-bg, rgba(255, 107, 53, 0.12))",
        border: "var(--color-risk-crit-border, rgba(255, 107, 53, 0.35))",
      };
    }
    if (upper.includes("HIGH") || safeScore >= 70) {
      return {
        label: "HIGH RISK",
        color: "var(--color-risk-high, #f59e0b)",
        bg: "var(--color-risk-high-bg, rgba(245, 158, 11, 0.12))",
        border: "var(--color-risk-high-border, rgba(245, 158, 11, 0.35))",
      };
    }
    if (upper.includes("MED") || upper.includes("ELEV") || safeScore >= 40) {
      return {
        label: "ELEVATED",
        color: "var(--color-risk-med, #749dc4)",
        bg: "var(--color-risk-med-bg, rgba(116, 157, 196, 0.12))",
        border: "var(--color-risk-med-border, rgba(116, 157, 196, 0.35))",
      };
    }
    return {
      label: "NOMINAL",
      color: "var(--color-risk-low, #10b981)",
      bg: "var(--color-risk-low-bg, rgba(16, 185, 129, 0.12))",
      border: "var(--color-risk-low-border, rgba(16, 185, 129, 0.35))",
    };
  }, [tier, safeScore]);

  return (
    <div
      className="relative flex flex-col items-center justify-center select-none"
      style={{ width: size, maxWidth: "100%" }}
      role="meter"
      aria-valuenow={safeScore}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`Risk score: ${safeScore.toFixed(1)} out of 100`}
    >
      <svg
        viewBox="0 0 160 126"
        className="w-full h-auto overflow-visible select-none block"
      >
        <defs>
          <filter id="pipShadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.45" />
          </filter>
        </defs>

        {/* Precision Outer Tick Marks */}
        <g stroke="var(--color-border-subtle, rgba(255,255,255,0.12))" strokeWidth="1" strokeLinecap="round">
          {/* 0% Tick */}
          <line x1="24.81" y1="77.72" x2="20.87" y2="78.42" />
          {/* 25% Tick */}
          <line x1="37.11" y1="32.00" x2="34.04" y2="29.43" />
          {/* 50% Tick */}
          <line x1="80.00" y1="12.00" x2="80.00" y2="8.00" />
          {/* 75% Tick */}
          <line x1="122.89" y1="32.00" x2="125.96" y2="29.43" />
          {/* 100% Tick */}
          <line x1="135.19" y1="77.72" x2="139.13" y2="78.42" />
        </g>

        {/* Terminal Endpoint Value Markers (Only on non-compact sizes) */}
        {!isCompact && (
          <g fill="var(--color-ink-muted, #749dc4)" className="font-mono text-[7px] font-bold opacity-60">
            <text x="18" y="90" textAnchor="middle">0</text>
            <text x="142" y="90" textAnchor="middle">100</text>
          </g>
        )}

        {/* Background Inactive Arc Track */}
        <path
          d="M 28.79 77.03 A 52 52 0 1 1 131.21 77.03"
          fill="none"
          stroke="var(--color-border, #2d2d2d)"
          strokeWidth="6.5"
          strokeLinecap="round"
        />

        {/* Active Progress Arc */}
        <path
          d="M 28.79 77.03 A 52 52 0 1 1 131.21 77.03"
          fill="none"
          stroke={tierConfig.color}
          strokeWidth="6.5"
          strokeLinecap="round"
          strokeDasharray={arcLength}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-700 ease-out"
        />

        {/* Endpoint Needle Pip Indicator */}
        {safeScore > 0 && (
          <circle
            cx={pipX}
            cy={pipY}
            r="4"
            fill="#ffffff"
            stroke={tierConfig.color}
            strokeWidth="2.5"
            filter="url(#pipShadow)"
            className="transition-all duration-700 ease-out"
          />
        )}

        {/* Center Precision Telemetry Display */}
        <text
          x="80"
          y="56"
          textAnchor="middle"
          className="font-mono font-black tabular-nums tracking-tight"
          fill={tierConfig.color}
          fontSize="27"
        >
          {score != null ? Number(score).toFixed(1) : "—"}
        </text>

        <text
          x="80"
          y="69"
          textAnchor="middle"
          className="font-mono font-bold tracking-[0.2em] uppercase"
          fill="var(--color-ink-muted, #749dc4)"
          fontSize="7.5"
        >
          RISK SCORE
        </text>

        {/* Lower Bay Status Pill Badge — 16px clear of arc endpoints */}
        <g className="transition-all duration-300">
          <rect
            x="42"
            y="93"
            width="76"
            height="20"
            rx="10"
            fill={tierConfig.bg}
            stroke={tierConfig.border}
            strokeWidth="1"
          />
          <circle
            cx="52"
            cy="103"
            r="2.5"
            fill={tierConfig.color}
          />
          <text
            x="84"
            y="106.5"
            textAnchor="middle"
            className="font-mono font-bold tracking-wider uppercase"
            fill={tierConfig.color}
            fontSize="8"
          >
            {tierConfig.label}
          </text>
        </g>
      </svg>
    </div>
  );
}
