import { useState, useEffect } from "react";
import { Clock, Timer, AlertCircle, CheckCircle2 } from "./PhosphorIcons";

// Persistent deadline cache: preserves exact countdown time across tab switches, filters, and re-renders
const _deadlineCache = new Map();

function getOrCreateDeadline(row) {
  if (!row || row.auditor_decision) return null;
  const txId = row.transaction_id || "tx";
  if (_deadlineCache.has(txId)) {
    return _deadlineCache.get(txId);
  }

  let maxSeconds = 86400; // 24h — standard
  if (row.review_tier === "immediate_escalation") maxSeconds = 14400; // 4h
  else if (row.review_tier === "priority_review")  maxSeconds = 43200; // 12h

  let hash = 0;
  for (let i = 0; i < txId.length; i++) {
    hash = (hash << 5) - hash + txId.charCodeAt(i);
    hash |= 0;
  }
  const factor = (Math.abs(hash) % 1000) / 1000;
  const allocatedSec = Math.max(900, Math.floor(maxSeconds * factor));
  const deadlineMs = Date.now() + allocatedSec * 1000;
  _deadlineCache.set(txId, deadlineMs);
  return deadlineMs;
}

function formatRemaining(totalSec) {
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

/**
 * SlaBadge — Real-time live countdown SLA timer with icon + text + color.
 * Continuously ticks down every second based on true elapsed wall-clock time.
 *
 * States:
 *  - Attested (decision made): "SLA Met" — green check
 *  - Breached (remaining <= 0): "SLA breached" — red alert
 *  - At risk (< 2h remaining): "SLA at risk HH:MM:SS" — amber timer
 *  - Warning (2–6h remaining): "SLA HH:MM:SS" — amber clock
 *  - Normal: "SLA HH:MM:SS" — neutral clock
 */
export default function SlaBadge({ row, compact = false }) {
  const targetDeadline = getOrCreateDeadline(row);

  const calculateRemaining = () => {
    if (!targetDeadline || row?.auditor_decision) return null;
    return Math.max(0, Math.floor((targetDeadline - Date.now()) / 1000));
  };

  const [remaining, setRemaining] = useState(calculateRemaining);

  useEffect(() => {
    // Immediate sync on mount or row change
    setRemaining(calculateRemaining());
    if (!targetDeadline || row?.auditor_decision) return;

    // Ticks continuously every second
    const interval = setInterval(() => {
      const rem = Math.max(0, Math.floor((targetDeadline - Date.now()) / 1000));
      setRemaining(rem);
    }, 1000);

    return () => clearInterval(interval);
  }, [row?.transaction_id, row?.auditor_decision, row?.review_tier, targetDeadline]);

  // ── Attested ──
  if (row.auditor_decision) {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-badge px-1.5 py-0.5 font-mono text-meta-xs font-medium"
        style={{
          color:      "var(--risk-success)",
          background: "var(--risk-success-bg)",
          border:     "1px solid var(--risk-success-border)",
        }}
        aria-label="SLA met — decision recorded"
      >
        <CheckCircle2 className="h-2.5 w-2.5 shrink-0" aria-hidden />
        {!compact && <span>SLA Met</span>}
      </span>
    );
  }

  if (remaining === null) return null;

  // ── Breached ──
  if (remaining <= 0) {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-badge px-1.5 py-0.5 font-mono text-meta-xs font-semibold"
        style={{
          color:      "var(--risk-critical)",
          background: "var(--risk-critical-bg)",
          border:     "1px solid var(--risk-critical-border)",
        }}
        role="alert"
        aria-label="SLA deadline breached"
      >
        <AlertCircle className="h-2.5 w-2.5 shrink-0" aria-hidden />
        {!compact ? <span>SLA breached</span> : <span>Breached</span>}
      </span>
    );
  }

  const isAtRisk  = remaining < 7200;   // < 2h
  const isWarning = remaining < 21600;  // < 6h

  if (isAtRisk) {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-badge px-1.5 py-0.5 font-mono text-meta-xs tabular-nums font-semibold"
        style={{
          color:      "var(--risk-critical)",
          background: "var(--risk-critical-bg)",
          border:     "1px solid var(--risk-critical-border)",
        }}
        title={`SLA at risk — ${formatRemaining(remaining)} remaining`}
        aria-label={`SLA at risk, ${formatRemaining(remaining)} remaining`}
      >
        <Timer className="h-2.5 w-2.5 shrink-0" aria-hidden />
        {compact
          ? <span>{formatRemaining(remaining)}</span>
          : <span>At risk {formatRemaining(remaining)}</span>
        }
      </span>
    );
  }

  return (
    <span
      className="inline-flex items-center gap-1 rounded-badge px-1.5 py-0.5 font-mono text-meta-xs tabular-nums font-medium"
      style={{
        color:      isWarning ? "var(--risk-warning)" : "var(--text-muted)",
        background: isWarning ? "var(--risk-warning-bg)" : "var(--surface-subtle)",
        border:     `1px solid ${isWarning ? "var(--risk-warning-border)" : "var(--divider)"}`,
      }}
      title={`SLA — ${formatRemaining(remaining)} remaining`}
      aria-label={`SLA, ${formatRemaining(remaining)} remaining`}
    >
      <Clock className="h-2.5 w-2.5 shrink-0" aria-hidden />
      {compact
        ? <span>{formatRemaining(remaining)}</span>
        : <span>SLA {formatRemaining(remaining)}</span>
      }
    </span>
  );
}
