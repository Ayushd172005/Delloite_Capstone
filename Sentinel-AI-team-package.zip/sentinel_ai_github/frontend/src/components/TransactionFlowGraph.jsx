import { useState, useMemo } from "react";
import {
  Landmark,
  Cpu,
  CreditCard,
  Network,
  Activity,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  Fingerprint,
  Globe,
  Building2,
  CheckCircle2,
  AlertTriangle,
  Zap,
  ExternalLink,
} from "./PhosphorIcons";
import { useCurrency } from "../context/CurrencyContext";
import { playTick } from "../utils/audio";

export default function TransactionFlowGraph({
  transactionId,
  accountId,
  counterpartyId,
  amount,
  vertical = "aml",
  signals,
  compact = false,
  onOpenNetworkModal,
}) {
  const { formatAmount, formatCompact, isUSD } = useCurrency();
  const [activeNode, setActiveNode] = useState("engine");

  const txDigits = (transactionId || "TX").replace(/\D/g, "");
  const pseudoOrigin = accountId || `ACC_${txDigits.slice(0, 4) || "4663"}`;
  const pseudoDest = counterpartyId || `BEN_${txDigits.slice(-4) || "3703"}`;

  const rawComposite =
    signals?.composite_score != null ? Number(signals.composite_score) : null;
  const compositeScore = rawComposite != null ? Number(rawComposite.toFixed(1)) : null;
  const resolvedAmount = amount ?? signals?.amount ?? null;

  const rawTier =
    signals?.review_tier ||
    (compositeScore != null
      ? compositeScore >= 85
        ? "immediate_escalation"
        : compositeScore >= 70
        ? "priority_review"
        : compositeScore >= 40
        ? "standard_review"
        : "auto_clear"
      : null);

  const isHighRisk =
    (compositeScore ?? 0) >= 70 ||
    rawTier === "immediate_escalation" ||
    rawTier === "priority_review";

  const displayTier = rawTier ? rawTier.replace(/_/g, " ").toUpperCase() : "AWAITING API SIGNALS";
  const shortTierBadge = useMemo(() => {
    switch (rawTier) {
      case "immediate_escalation":
        return "ESCALATE";
      case "priority_review":
        return "PRIORITY";
      case "standard_review":
        return "REVIEW";
      case "auto_clear":
        return "CLEAR";
      default:
        return "ACTIVE";
    }
  }, [rawTier]);

  // Quantitative anomaly metrics
  const isoPct = useMemo(() => {
    if (signals?.isoforest_score != null) {
      return Math.min(100, Math.max(0, Math.round(Number(signals.isoforest_score) * 100)));
    }
    return null;
  }, [signals, compositeScore]);

  const aePct = useMemo(() => {
    if (signals?.autoencoder_score != null) {
      return Math.min(100, Math.max(0, Math.round(Number(signals.autoencoder_score) * 100)));
    }
    return null;
  }, [signals, compositeScore]);

  const benfordNonConformant = Boolean(signals?.benford_flag);

  const selectNode = (node) => {
    playTick("toggle");
    setActiveNode(node);
  };

  const verticalLabel = useMemo(() => {
    switch (vertical?.toLowerCase()) {
      case "retail":
        return "Retail P2P (UPI/IMPS)";
      case "corporate":
        return "Corporate Treasury Wire";
      case "aml":
      default:
        return "High-Value Ingestion Corridor";
    }
  }, [vertical]);

  return (
    <div className="rounded-xl border border-border bg-panel p-4 shadow-panel specular-card select-none space-y-4">
      {/* Topology Header */}
      <div className="flex items-center justify-between border-b border-border/40 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg border border-accent/40 bg-accent-dim text-accent shadow-2xs">
            <Network className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-ink tracking-tight">
                Transaction Topology & Vector Routing
              </span>
              <span className="hidden sm:inline-block font-mono text-meta-xs text-text-muted font-medium">
                Hop Protocol v2.4
              </span>
            </div>
            <div className="font-mono text-3xs text-ink-faint mt-0.5">
              Multi-Hop Flow Vector Analysis · {verticalLabel}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenNetworkModal && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                playTick("toggle");
                onOpenNetworkModal();
              }}
              className="flex items-center gap-1.5 rounded-lg border border-accent/40 bg-accent-dim px-2.5 py-1 text-3xs font-semibold text-accent hover:bg-accent/20 transition-all shadow-2xs"
              title="Open full interactive Syndicate Link Graph modal"
            >
              <Network className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Syndicate Link Analysis</span>
              <span className="sm:hidden">Graph</span>
              <ExternalLink className="h-3 w-3 opacity-75" />
            </button>
          )}

          <div className="flex items-center gap-1.5 font-mono text-3xs text-ink-faint">
            <span className="h-2 w-2 rounded-full bg-low live-pulse-dot" />
            <span className="font-semibold text-ink hidden sm:inline">Active Ingestion Route</span>
          </div>
        </div>
      </div>

      {/* Interactive Conduit Pipeline: 3 Equal-Height Structural Nodes with Aligned Bus */}
      <div className="relative">
        <div className={`flex ${compact ? "flex-col gap-3" : "flex-col md:flex-row items-stretch gap-2 lg:gap-3"}`}>
          {/* ── CARD 1: ORIGIN ENTITY (Hop 0) ── */}
          <div
            onClick={() => selectNode("origin")}
            className={`cursor-pointer rounded-xl border p-3.5 sm:p-4 transition-all duration-200 select-none flex flex-col justify-between relative group flex-1 min-w-0 ${
              activeNode === "origin"
                ? "border-accent bg-panel-raised shadow-raised ring-1 ring-accent/50"
                : "border-border bg-panel-dock/70 hover:border-border-strong hover:bg-panel-dock"
            }`}
          >
            {/* Terminal Connection Port (Right edge in horizontal mode) */}
            {!compact && (
              <div
                className={`hidden md:flex absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border z-20 items-center justify-center transition-colors shadow-2xs ${
                  activeNode === "origin"
                    ? "border-accent bg-panel-raised text-accent ring-2 ring-accent/30"
                    : "border-border bg-panel-dock text-ink-muted group-hover:border-accent group-hover:text-accent"
                }`}
                title="Conduit Egress Terminal"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
              </div>
            )}

            <div>
              {/* Header */}
              <div className="flex items-center justify-between font-mono text-3xs text-ink-faint pb-2 border-b border-border/30">
                <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-ink-muted whitespace-nowrap">
                  <Landmark className="h-3.5 w-3.5 text-accent shrink-0" />
                  <span>Origin</span>
                </span>
                <span className="font-mono text-meta-xs text-text-muted shrink-0 font-medium">
                  Hop 0
                </span>
              </div>

              {/* Primary Identity */}
              <div className="mt-2.5">
                <div className="font-mono text-xs font-bold text-ink tracking-tight flex items-center justify-between gap-1.5">
                  <span className="truncate">{pseudoOrigin}</span>
                  <span className="text-3xs font-medium text-ink-muted shrink-0">Debtor</span>
                </div>
                <div className="mt-0.5 font-mono text-3xs text-ink-faint truncate">
                  {vertical === "retail" ? "Retail Account" : vertical === "corporate" ? "Corporate Treasury" : "Commercial Account"}
                </div>
              </div>
            </div>

            {/* Spec / Key-Value Grid */}
            <div className="mt-3.5 pt-2.5 border-t border-border/30 space-y-2 font-mono text-3xs">
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">KYC:</span>
                <span className="font-semibold text-low flex items-center gap-1 shrink-0 whitespace-nowrap">
                  <CheckCircle2 className="h-2.5 w-2.5 shrink-0" />
                  <span>{accountId ? "Account Supplied" : "Benchmark Verified"}</span>
                </span>
              </div>
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">Jurisdiction:</span>
                <span className="font-medium text-ink flex items-center gap-1 shrink-0 whitespace-nowrap">
                  <Globe className="h-2.5 w-2.5 text-ink-muted shrink-0" />
                  <span>{isUSD ? "US · New York" : "IN · Mumbai"}</span>
                </span>
              </div>
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">Corridor:</span>
                <span className="font-medium text-ink-muted shrink-0 whitespace-nowrap truncate max-w-[150px] text-right" title={verticalLabel}>
                  {vertical === "retail" ? "UPI / IMPS Rail" : vertical === "corporate" ? "Treasury Wire" : "Ingestion Corridor"}
                </span>
              </div>
            </div>
          </div>

          {/* ── CONDUIT BRIDGE 1 ── */}
          <div className="flex md:flex-col items-center justify-center py-2 md:py-0 px-0.5 relative z-10 w-full md:w-8 lg:w-10 shrink-0">
            <div className="hidden md:flex w-full flex-col items-center justify-center">
              {/* Status Badge */}
              <span className="font-mono text-[9px] font-bold text-text-muted uppercase tracking-wider mb-1 whitespace-nowrap">
                Ingest
              </span>
              {/* Conduit Vector Line with Pulse */}
              <div className="w-full h-[2px] bg-border relative overflow-hidden rounded-full">
                <div className="absolute inset-0 bg-gradient-to-r from-accent/20 via-accent to-accent/20 animate-pulse" />
              </div>
              {/* Arrow Pulse */}
              <div className="flex items-center gap-0.5 text-accent font-mono text-[9px] font-black tracking-tighter mt-1.5">
                <span className="opacity-30">▶</span>
                <span className="opacity-60">▶</span>
                <span>▶</span>
              </div>
            </div>
            <div className="flex md:hidden items-center gap-2 font-mono text-3xs text-accent">
              <span>▼</span>
              <span className="text-ink-faint font-bold uppercase tracking-widest text-[8px]">
                Pipeline Ingest
              </span>
              <span>▼</span>
            </div>
          </div>

          {/* ── CARD 2: STATISTICAL ENSEMBLE (Pipeline Core) ── */}
          <div
            onClick={() => selectNode("engine")}
            className={`cursor-pointer rounded-xl border p-3.5 sm:p-4 transition-all duration-200 select-none flex flex-col justify-between relative group flex-1 min-w-0 ${
              activeNode === "engine"
                ? "border-accent bg-panel-raised shadow-raised ring-1 ring-accent/50"
                : "border-border bg-panel-dock/70 hover:border-border-strong hover:bg-panel-dock"
            }`}
          >
            {/* Left & Right Connection Terminals */}
            {!compact && (
              <>
                <div
                  className={`hidden md:flex absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border z-20 items-center justify-center transition-colors shadow-2xs ${
                    activeNode === "engine"
                      ? "border-accent bg-panel-raised text-accent ring-2 ring-accent/30"
                      : "border-border bg-panel-dock text-ink-muted group-hover:border-accent"
                  }`}
                  title="Conduit Ingress Terminal"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                </div>
                <div
                  className={`hidden md:flex absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border z-20 items-center justify-center transition-colors shadow-2xs ${
                    activeNode === "engine"
                      ? "border-accent bg-panel-raised text-accent ring-2 ring-accent/30"
                      : "border-border bg-panel-dock text-ink-muted group-hover:border-accent"
                  }`}
                  title="Conduit Egress Terminal"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                </div>
              </>
            )}

            <div>
              {/* Header */}
              <div className="flex items-center justify-between font-mono text-3xs pb-2 border-b border-border/30">
                <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-ink-muted whitespace-nowrap">
                  <Cpu className="h-3.5 w-3.5 text-accent shrink-0" />
                  <span>Ensemble</span>
                </span>
                <span
                  className={`inline-flex items-center gap-1 font-mono font-bold text-meta-xs shrink-0 ${
                    isHighRisk ? "text-critical" : "text-success"
                  }`}
                  title={displayTier}
                >
                  <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${isHighRisk ? "bg-critical" : "bg-success"}`} />
                  <span className="whitespace-nowrap">{shortTierBadge}</span>
                </span>
              </div>

              {/* Amount & Composite Index */}
              <div className="mt-2.5 flex items-baseline justify-between font-mono gap-2">
                <span className="text-sm font-black text-ink tracking-tight whitespace-nowrap">
                  {resolvedAmount != null ? formatAmount(resolvedAmount) : "—"}
                </span>
                <span
                  className={`text-xs font-bold whitespace-nowrap ${
                    isHighRisk ? "text-critical" : "text-low"
                  }`}
                >
                  {compositeScore == null ? "—" : `${compositeScore} / 100`}
                </span>
              </div>
            </div>

            {/* Model Anomaly Telemetry Meters */}
            <div className="mt-3 pt-2 border-t border-border/30 space-y-2 font-mono text-3xs">
              <div>
                <div className="flex justify-between items-center mb-0.5 gap-2">
                  <span className="text-ink-faint whitespace-nowrap shrink-0">Isolation Forest:</span>
                  <span className="font-bold text-ink whitespace-nowrap shrink-0">{isoPct == null ? "—" : `${isoPct}% Anomaly`}</span>
                </div>
                <div className="h-1.5 w-full bg-border/60 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isoPct >= 70 ? "bg-critical" : "bg-accent"
                    }`}
                    style={{ width: `${isoPct ?? 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-0.5 gap-2">
                  <span className="text-ink-faint whitespace-nowrap shrink-0">Autoencoder (MSE):</span>
                  <span className="font-bold text-ink whitespace-nowrap shrink-0">{aePct == null ? "—" : `${aePct}% Loss`}</span>
                </div>
                <div className="h-1.5 w-full bg-border/60 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      aePct >= 70 ? "bg-critical" : "bg-accent"
                    }`}
                    style={{ width: `${aePct ?? 0}%` }}
                  />
                </div>
              </div>

              <div className="flex justify-between items-center pt-0.5 gap-2">
                <span className="text-ink-faint whitespace-nowrap shrink-0">Benford Law:</span>
                <span
                  className={`font-semibold whitespace-nowrap shrink-0 ${
                    signals?.benford_flag ? "text-critical" : "text-low"
                  }`}
                >
                  {signals?.benford_flag ? "Non-Conformant ⚠" : "Conformant ✓"}
                </span>
              </div>
            </div>
          </div>

          {/* ── CONDUIT BRIDGE 2 ── */}
          <div className="flex md:flex-col items-center justify-center py-2 md:py-0 px-0.5 relative z-10 w-full md:w-8 lg:w-10 shrink-0">
            <div className="hidden md:flex w-full flex-col items-center justify-center">
              {/* Status Badge */}
              <span className="font-mono text-[9px] font-bold text-text-muted uppercase tracking-wider mb-1 whitespace-nowrap">
                Routing
              </span>
              {/* Conduit Vector Line with Pulse */}
              <div className="w-full h-[2px] bg-border relative overflow-hidden rounded-full">
                <div className="absolute inset-0 bg-gradient-to-r from-accent/20 via-accent to-accent/20 animate-pulse" />
              </div>
              {/* Arrow Pulse */}
              <div className="flex items-center gap-0.5 text-accent font-mono text-[9px] font-black tracking-tighter mt-1.5">
                <span className="opacity-30">▶</span>
                <span className="opacity-60">▶</span>
                <span>▶</span>
              </div>
            </div>
            <div className="flex md:hidden items-center gap-2 font-mono text-3xs text-accent">
              <span>▼</span>
              <span className="text-ink-faint font-bold uppercase tracking-widest text-[8px]">
                Settlement Route
              </span>
              <span>▼</span>
            </div>
          </div>

          {/* ── CARD 3: BENEFICIARY (Hop 1) ── */}
          <div
            onClick={() => selectNode("dest")}
            className={`cursor-pointer rounded-xl border p-3.5 sm:p-4 transition-all duration-200 select-none flex flex-col justify-between relative group flex-1 min-w-0 ${
              activeNode === "dest"
                ? "border-accent bg-panel-raised shadow-raised ring-1 ring-accent/50"
                : "border-border bg-panel-dock/70 hover:border-border-strong hover:bg-panel-dock"
            }`}
          >
            {/* Terminal Connection Port (Left edge in horizontal mode) */}
            {!compact && (
              <div
                className={`hidden md:flex absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border z-20 items-center justify-center transition-colors shadow-2xs ${
                  activeNode === "dest"
                    ? "border-accent bg-panel-raised text-accent ring-2 ring-accent/30"
                    : "border-border bg-panel-dock text-ink-muted group-hover:border-accent group-hover:text-accent"
                }`}
                title="Conduit Ingress Terminal"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-accent" />
              </div>
            )}

            <div>
              {/* Header */}
              <div className="flex items-center justify-between font-mono text-3xs text-ink-faint pb-2 border-b border-border/30">
                <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-ink-muted whitespace-nowrap">
                  <Building2 className="h-3.5 w-3.5 text-accent shrink-0" />
                  <span>Beneficiary</span>
                </span>
                <span className="font-mono text-meta-xs text-text-muted shrink-0 font-medium">
                  Hop 1
                </span>
              </div>

              {/* Primary Identity */}
              <div className="mt-2.5">
                <div className="font-mono text-xs font-bold text-ink tracking-tight flex items-center justify-between gap-1.5">
                  <span className="truncate">{pseudoDest}</span>
                  <span className="text-3xs font-medium text-ink-muted shrink-0">Creditor</span>
                </div>
                <div className="mt-0.5 font-mono text-3xs text-ink-faint truncate">
                  {vertical === "retail" ? "Peer Merchant" : vertical === "corporate" ? "Settlement Account" : "Escrow Account"}
                </div>
              </div>
            </div>

            {/* Spec / Key-Value Grid */}
            <div className="mt-3.5 pt-2.5 border-t border-border/30 space-y-2 font-mono text-3xs">
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">Depository:</span>
                <span className="font-medium text-ink shrink-0 whitespace-nowrap">
                  {isUSD ? (vertical === "corporate" ? "JPM Chase Escrow" : "Citibank NY") : (vertical === "corporate" ? "SBI Commercial" : "HDFC Escrow")}
                </span>
              </div>
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">24h Velocity:</span>
                <span className="font-medium text-ink shrink-0 whitespace-nowrap">8 TX · {formatCompact(1420000)}</span>
              </div>
              <div className="flex justify-between items-center gap-2">
                <span className="text-ink-faint shrink-0 whitespace-nowrap">Topology:</span>
                <span
                  className={`font-bold shrink-0 whitespace-nowrap flex items-center gap-1 ${
                    isHighRisk ? "text-critical" : "text-low"
                  }`}
                >
                  {isHighRisk ? "High Inflow Hub" : "Nominal"}
                </span>
              </div>
            </div>

            {/* In-Card Modal Trigger */}
            {onOpenNetworkModal && (
              <div className="mt-3 pt-2 border-t border-border/40 flex justify-end">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    playTick("toggle");
                    onOpenNetworkModal();
                  }}
                  className="flex items-center gap-1 font-mono text-3xs font-bold text-accent hover:underline"
                >
                  <span className="whitespace-nowrap">Inspect Cluster</span>
                  <ArrowRight className="h-2.5 w-2.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Dynamic Precision Detail Inspector for Selected Node */}
      <div className="rounded-xl border border-border bg-panel-dock/90 p-3.5 text-2xs font-mono space-y-2.5 shadow-2xs">
        <div className="flex items-center justify-between border-b border-border/40 pb-2">
          <div className="flex items-center gap-2">
            <Activity className="h-3.5 w-3.5 text-accent animate-pulse" />
            <span className="font-bold text-ink uppercase tracking-wider text-3xs">
              {activeNode === "origin"
                ? "Origin Node Forensic Record · Hop 0"
                : activeNode === "engine"
                ? "Tri-Model Inference Telemetry · Pipeline Core"
                : "Beneficiary Settlement Profile · Hop 1"}
            </span>
          </div>
          <span className="inline-flex items-center gap-1.5 font-mono text-meta-xs font-semibold text-accent">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
            <span>Graph Node Recorded · Prototype Audit Trail</span>
          </span>
        </div>

        {/* Origin Node View */}
        {activeNode === "origin" && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-3xs">
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Typology</span>
              <span className="text-ink font-bold block mt-0.5 truncate">Corporate Liquidity</span>
              <span className="text-low text-3xs block mt-0.5 truncate">Commercial Profile</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Account Age</span>
              <span className="text-ink font-bold block mt-0.5 truncate">842 Days Active</span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Nov 2023 Onboarding</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">30d Turnover</span>
              <span className="text-ink font-bold block mt-0.5 truncate">{formatCompact(24000000)} / mo</span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Peak Corridor</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Gateway</span>
              <span className="text-accent font-bold block mt-0.5 truncate">TLS 1.3 · Known Device</span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Hardware Canvas Match</span>
            </div>
          </div>
        )}

        {/* Engine Node View */}
        {activeNode === "engine" && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-3xs">
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Weights</span>
              <span className="text-ink font-bold block mt-0.5 truncate">Iso 35 · AE 45 · Ben 20</span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Calibrated Matrix</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Latency</span>
              <span className="text-ink font-bold block mt-0.5 truncate">3.4 ms Inference</span>
              <span className="text-low text-3xs block mt-0.5 truncate">Zero Queuing Lag</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Consensus</span>
              <span className={`font-bold block mt-0.5 truncate ${isHighRisk ? "text-critical" : "text-low"}`}>
                {isHighRisk ? "Risk Outlier" : "Nominal"}
              </span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Score &gt; 90 Tier</span>
            </div>
            <div className="rounded border border-border/60 bg-panel/60 p-2">
              <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Compliance</span>
              <span className="text-accent font-bold block mt-0.5 truncate">FinCEN / RBI</span>
              <span className="text-ink-muted text-3xs block mt-0.5 truncate">Statutory Anchored</span>
            </div>
          </div>
        )}

        {/* Destination Node View */}
        {activeNode === "dest" && (
          <div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-3xs">
              <div className="rounded border border-border/60 bg-panel/60 p-2">
                <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Depository</span>
                <span className="text-ink font-bold block mt-0.5 truncate">HDFC Bank Ltd</span>
                <span className="text-ink-muted text-3xs block mt-0.5 truncate">Escrow Gateway</span>
              </div>
              <div className="rounded border border-border/60 bg-panel/60 p-2">
                <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Settlement Rail</span>
                <span className="text-ink font-bold block mt-0.5 truncate">RTGS / SWIFT</span>
                <span className="text-low text-3xs block mt-0.5 truncate">Immediate Settlement</span>
              </div>
              <div className="rounded border border-border/60 bg-panel/60 p-2">
                <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Sanctions</span>
                <span className="text-low font-bold block mt-0.5 truncate">Negative (Clear)</span>
                <span className="text-ink-muted text-3xs block mt-0.5 truncate">OFAC / UN / RBI</span>
              </div>
              <div className="rounded border border-border/60 bg-panel/60 p-2">
                <span className="text-ink-faint block uppercase text-3xs tracking-wider truncate">Cluster Coeff</span>
                <span className={`font-bold block mt-0.5 truncate ${isHighRisk ? "text-critical" : "text-ink"}`}>
                  {isHighRisk ? "88.4% Outlier" : "Dispersed"}
                </span>
                <span className="text-ink-muted text-3xs block mt-0.5 truncate">8 Wires / 24h</span>
              </div>
            </div>

            {onOpenNetworkModal && (
              <div className="mt-2.5 pt-2 border-t border-border/40 flex justify-end">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    playTick("toggle");
                    onOpenNetworkModal();
                  }}
                  className="flex items-center gap-1.5 font-mono text-3xs font-bold text-accent hover:underline"
                >
                  <Network className="h-3 w-3" />
                  <span>Launch Interactive Syndicate Link Analysis (7 Nodes)</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
