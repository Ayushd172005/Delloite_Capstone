import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Search,
  ShieldAlert,
  Sun,
  Moon,
  DollarSign,
  History,
  Volume2,
  VolumeX,
  Sparkles,
  ArrowRight,
  Command,
  CornerDownLeft,
  X,
  FileSearch,
  Cpu,
} from "./PhosphorIcons";
import { useTheme } from "../context/ThemeContext";
import { useCurrency } from "../context/CurrencyContext";
import { isSoundEnabled, setSoundEnabled, playTick } from "../utils/audio";

export default function CommandPalette({ isOpen, onClose, onOpenScorer }) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const { theme, toggle: toggleTheme, isDark } = useTheme();
  const { locale, toggle: toggleCurrency, localeLabel } = useCurrency();
  const navigate = useNavigate();
  const inputRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery("");
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const soundOn = isSoundEnabled();

  const actions = [
    {
      id: "live-scorer",
      title: "Simulate & Score Transaction",
      subtitle: "Execute live causal ML ensemble & Sentinel forensic synthesis on test transactions",
      Icon: Sparkles,
      run: () => {
        playTick("action");
        if (onOpenScorer) onOpenScorer();
      },
    },
    {
      id: "queue",
      title: "Case queue",
      subtitle: "Navigate to flagged transaction stream",
      Icon: ShieldAlert,
      run: () => {
        playTick("toggle");
        navigate("/");
      },
    },
    {
      id: "audit",
      title: "Evidence ledger",
      subtitle: "Inspect tamper-evident block explorer & hash chain",
      Icon: History,
      run: () => {
        playTick("toggle");
        navigate("/audit-trail");
      },
    },
    {
      id: "governance",
      title: "Model health & calibration",
      subtitle: "Inspect ensemble weights, drift PSI metrics, and threshold curves",
      Icon: Cpu,
      run: () => {
        playTick("toggle");
        navigate("/model-health");
      },
    },
    {
      id: "theme",
      title: `Toggle Theme (Current: ${isDark ? "Drafting Table Dark" : "Studio Ivory Light"})`,
      subtitle: "Switch between Obsidian Charcoal & Studio Linen",
      Icon: isDark ? Sun : Moon,
      run: () => {
        playTick("toggle");
        toggleTheme();
      },
    },
    {
      id: "currency",
      title: `Toggle Currency Format (Current: ${localeLabel})`,
      subtitle: "Switch between Indian Lakhs (₹) and International ($)",
      Icon: DollarSign,
      run: () => {
        playTick("toggle");
        toggleCurrency();
      },
    },
    {
      id: "audio",
      title: `Toggle Acoustic Haptics (Current: ${soundOn ? "Enabled" : "Muted"})`,
      subtitle: "Switch mechanical micro-tick keyboard audio",
      Icon: soundOn ? VolumeX : Volume2,
      run: () => {
        const next = !soundOn;
        setSoundEnabled(next);
        if (next) playTick("toggle");
      },
    },
  ];

  const filtered = actions.filter(
    (a) =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.subtitle.toLowerCase().includes(query.toLowerCase()) ||
      query.toLowerCase().includes(a.id)
  );

  // If query looks like a transaction ID, allow jumping directly to it
  if (query.trim().length >= 3) {
    const txId = query.trim().toUpperCase();
    filtered.unshift({
      id: "jump_tx",
      title: `Inspect Case Dossier: ${txId}`,
      subtitle: "Direct jump to forensic transaction dossier",
      Icon: Search,
      run: () => {
        playTick("nav");
        navigate(`/investigation/${txId}`);
      },
    });
  }

  useEffect(() => {
    function handleKeyDown(e) {
      if (!isOpen) return;

      if (e.key === "ArrowDown") {
        e.preventDefault();
        playTick("nav");
        setSelectedIndex((prev) => (prev + 1) % (filtered.length || 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        playTick("nav");
        setSelectedIndex((prev) => (prev - 1 + filtered.length) % (filtered.length || 1));
      } else if (e.key === "Enter" && filtered[selectedIndex]) {
        e.preventDefault();
        filtered[selectedIndex].run();
        onClose();
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, filtered, selectedIndex, onClose]);

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="fixed left-1/2 top-1/4 z-50 w-full max-w-lg -translate-x-1/2 p-4">
        <div
          role="dialog"
          aria-modal="true"
          className="overflow-hidden rounded-xl border border-border-strong bg-panel shadow-panel-lg"
        >
          {/* Search Input */}
          <div className="flex items-center gap-2.5 border-b border-border bg-panel-raised px-4 py-3">
            <Command className="h-4 w-4 text-accent" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setSelectedIndex(0);
              }}
              placeholder="Type a command or case ID (e.g. TRF_46631F673703)…"
              className="flex-1 bg-transparent font-mono text-xs text-ink placeholder:text-ink-faint focus:outline-none"
            />
          </div>

          {/* Results List */}
          <div className="max-h-72 overflow-y-auto p-2 scrollbar-thin">
            {filtered.length === 0 ? (
              <div className="py-6 text-center font-mono text-2xs text-ink-faint">
                Zero commands or cases matching "{query}"
              </div>
            ) : (
              <ul className="space-y-1">
                {filtered.map((item, idx) => {
                  const isSelected = selectedIndex === idx;
                  const { Icon } = item;
                  return (
                    <li
                      key={item.id}
                      onClick={() => {
                        item.run();
                        onClose();
                      }}
                      onMouseEnter={() => setSelectedIndex(idx)}
                      className={`flex cursor-pointer items-center justify-between rounded-lg px-3 py-2 text-xs transition-colors ${
                        isSelected
                          ? "bg-accent-dim text-accent border border-accent/30"
                          : "text-ink hover:bg-panel-raised border border-transparent"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className="h-4 w-4 shrink-0 text-ink-muted" />
                        <div>
                          <div className="font-mono text-xs font-semibold">{item.title}</div>
                          <div className="text-3xs text-ink-faint">{item.subtitle}</div>
                        </div>
                      </div>
                      {isSelected && (
                        <span className="font-mono text-3xs font-semibold text-accent">
                          Select
                        </span>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between border-t border-border bg-panel-dock px-4 py-2 text-2xs text-ink-faint font-mono">
            <span>Institutional Command & Navigation Hub</span>
            <span>Sentinel OS</span>
          </div>
        </div>
      </div>
    </>
  );
}
