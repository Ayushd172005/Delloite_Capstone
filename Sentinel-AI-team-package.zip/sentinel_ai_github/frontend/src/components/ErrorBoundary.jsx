import React from "react";
import { AlertOctagon, RotateCcw } from "./PhosphorIcons";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Sentinel Component Error Boundary caught exception:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="rounded-lg border border-critical-border bg-critical-bg/20 p-6 text-center font-mono space-y-3">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-critical-border bg-critical-bg text-critical">
            <AlertOctagon className="h-5 w-5" />
          </div>
          <h3 className="text-sm font-bold text-critical uppercase">
            COMPONENT TELEMETRY FAULT
          </h3>
          <p className="text-2xs text-ink-muted max-w-md mx-auto">
            An isolated exception occurred within this viewport component. The rest of the Sentinel surveillance shell remains operational.
          </p>
          {this.state.error && (
            <div className="max-w-xl mx-auto text-left rounded bg-panel-dock border border-critical-border/50 p-2.5 text-3xs text-critical font-mono overflow-x-auto">
              {this.state.error.toString()}
            </div>
          )}
          <div className="pt-2 flex items-center justify-center gap-2">
            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              className="inline-flex items-center gap-1.5 rounded border border-critical-border bg-critical-bg px-3 py-1.5 text-2xs font-bold text-critical hover:bg-critical-bg/80"
            >
              <RotateCcw className="h-3 w-3" />
              <span>REINITIALIZE VIEWPORT</span>
            </button>
            <button
              onClick={() => window.location.assign("/")}
              className="inline-flex items-center gap-1.5 rounded border border-border bg-panel px-3 py-1.5 text-2xs font-bold text-ink-muted hover:text-ink"
            >
              <span>RETURN TO QUEUE</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
