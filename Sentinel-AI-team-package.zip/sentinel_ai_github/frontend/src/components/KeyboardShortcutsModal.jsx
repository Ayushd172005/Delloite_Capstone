import { useEffect } from "react";
import { X, Keyboard } from "./PhosphorIcons";
import Kbd from "./Kbd";
import { playTick } from "../utils/audio";

export default function KeyboardShortcutsModal({ isOpen, onClose }) {
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    const originalTouchAction = document.body.style.touchAction;
    const originalPaddingRight = document.body.style.paddingRight;
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    document.body.style.touchAction = "none";
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }

    function handleKeyDown(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        playTick("toggle");
        onClose();
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
      document.body.style.touchAction = originalTouchAction;
      document.body.style.paddingRight = originalPaddingRight;
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const categories = [
    {
      title: "Global Navigation",
      shortcuts: [
        { keys: ["1"], desc: "Case queue" },
        { keys: ["2"], desc: "Evidence ledger" },
        { keys: ["3"], desc: "Model health" },
        { keys: ["C"], desc: "Toggle Currency (₹/$)" },
        { keys: ["⌘", "K"], desc: "Command Palette" },
        { keys: ["S"], desc: "Keyboard Shortcuts" },
      ],
    },
    {
      title: "Queue Triage",
      shortcuts: [
        { keys: ["K", "↓"], desc: "Next case" },
        { keys: ["J", "↑"], desc: "Previous case" },
        { keys: ["Enter"], desc: "Open full investigation" },
        { keys: ["X"], desc: "Toggle case selection" },
        { keys: ["Shift", "A"], desc: "Select / deselect all" },
        { keys: ["V"], desc: "Toggle Workbench / Grid" },
      ],
    },
    {
      title: "Dossier Actions",
      shortcuts: [
        { keys: ["1"], desc: "Accept / Clear case" },
        { keys: ["2"], desc: "Escalate case" },
        { keys: ["3"], desc: "Request more evidence" },
        { keys: ["4"], desc: "Dismiss case" },
        { keys: ["G"], desc: "Syndicate Link Graph" },
        { keys: ["K", "→"], desc: "Next case (Investigation)" },
        { keys: ["J", "←"], desc: "Previous case (Investigation)" },
        { keys: ["Esc"], desc: "Return to queue" },
      ],
    },
    {
      title: "Graph Workstation",
      shortcuts: [
        { keys: ["F"], desc: "Toggle Fullscreen Canvas" },
        { keys: ["R"], desc: "Reset Zoom & Pan" },
        { keys: ["T"], desc: "Auto-Trace High Risk Cluster" },
        { keys: ["0"], desc: "Recenter Focus Entity" },
        { keys: ["Esc"], desc: "Close Graph Modal" },
      ],
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.55)", backdropFilter: "blur(4px)" }}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Keyboard shortcuts reference"
    >
      <div
        className="w-full max-w-2xl overflow-hidden rounded-panel animate-modal-in select-none"
        style={{
          background: "var(--surface)",
          border: "1px solid var(--divider)",
          boxShadow: "var(--shadow-modal)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4"
          style={{ background: "var(--surface-raised)", borderBottom: "1px solid var(--divider)" }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="flex h-7 w-7 items-center justify-center rounded-control"
              style={{ background: "var(--accent-dim)", border: "1px solid color-mix(in srgb, var(--accent) 30%, transparent)" }}
            >
              <Keyboard className="h-4 w-4 text-accent" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-text-primary">Keyboard Shortcuts</h2>
              <p className="font-mono text-meta-xs text-text-muted">
                Keyboard-first workflow for rapid case triage
              </p>
            </div>
          </div>
          <button
            onClick={() => { playTick("toggle"); onClose(); }}
            className="rounded-control p-1 text-text-muted transition-colors hover:text-text-primary"
            style={{ background: "var(--surface-subtle)", border: "1px solid var(--divider)" }}
            aria-label="Close shortcuts modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <div key={cat.title} className="space-y-3">
              <div
                className="font-mono text-meta-xs font-bold uppercase tracking-wider pb-1"
                style={{ color: "var(--accent)", borderBottom: "1px solid var(--divider)" }}
              >
                {cat.title}
              </div>
              <div className="space-y-2.5">
                {cat.shortcuts.map((sc) => (
                  <div key={sc.desc} className="flex items-start justify-between gap-2">
                    <span className="text-2xs text-text-secondary leading-tight">{sc.desc}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      {sc.keys.map((k) => (
                        <Kbd key={k} className="text-meta-xs">{k}</Kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div
          className="px-5 py-3 flex items-center justify-between font-mono text-meta-xs"
          style={{
            borderTop: "1px solid var(--divider)",
            background: "var(--surface-subtle)",
            color: "var(--text-muted)",
          }}
        >
          <span>Press <Kbd>Esc</Kbd> to dismiss</span>
          <span>Sentinel AI v2</span>
        </div>
      </div>
    </div>
  );
}
