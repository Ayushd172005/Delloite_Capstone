export default function BrandLogo({ size = 28, className = "", showText = false, textClassName = "" }) {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Sentinel S monogram: a quiet, folded mark for review and signal. */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
        aria-label="Sentinel AI Logo"
      >
        <title>Sentinel AI Logo</title>
        <path
          d="M25.25 7.25C23.1 5.45 20.35 4.5 17.25 4.5C11.15 4.5 7 7.55 7 11.95C7 16.25 10.05 18.05 15.35 19.3L18.15 19.95C21.35 20.7 22.75 21.65 22.75 23.35C22.75 25.55 20.55 27.5 16.2 27.5C12.55 27.5 9.25 26.3 6.65 24.05"
          stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" className="text-accent"
        />
        <path
          d="M25.2 7.25L21.65 11.1"
          stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" className="text-accent/55"
        />
      </svg>

      {showText && (
        <div className={`flex items-baseline gap-1.5 min-w-0 ${textClassName}`}>
          <span className="font-sans font-bold tracking-tight text-text-primary text-sm">
            Sentinel
          </span>
          <span className="font-sans font-semibold tracking-wider text-accent text-xs uppercase">
            AI
          </span>
        </div>
      )}
    </div>
  );
}
