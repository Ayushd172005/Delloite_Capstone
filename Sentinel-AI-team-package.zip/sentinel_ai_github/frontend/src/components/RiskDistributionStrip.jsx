import { useMemo } from "react";
import { playTick } from "../utils/audio";

export default function RiskDistributionStrip({ rows = [], activeBin, onSelectBin }) {
  const bins = useMemo(() => {
    // 10 bins: 0-10, 10-20, ... 90-100
    const counts = Array(10).fill(0);
    for (const r of rows) {
      const score = Number(r.composite_score ?? 0);
      const binIdx = Math.min(9, Math.max(0, Math.floor(score / 10)));
      counts[binIdx]++;
    }
    const maxCount = Math.max(...counts, 1);
    return counts.map((count, i) => ({
      range: `${i * 10}–${(i + 1) * 10}`,
      min: i * 10,
      max: (i + 1) * 10,
      count,
      pct: count > 0 ? Math.max(12, Math.round((count / maxCount) * 100)) : 4,
      isCrit: i >= 8,
      isHigh: i >= 7 && i < 8,
      isMed: i >= 5 && i < 7,
      color: i >= 8 ? "var(--risk-critical)" : i >= 7 ? "var(--risk-warning)" : i >= 5 ? "var(--risk-warning)" : "var(--risk-success)",
    }));
  }, [rows]);

  const handleSelect = (b) => {
    playTick("toggle");
    const isSelected = activeBin?.min === b.min;
    onSelectBin(isSelected ? null : b);
  };

  return (
    <div className="flex flex-col justify-between gap-1.5 select-none w-full">
      <div className="flex items-center justify-between text-xs font-sans text-text-muted">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-text-secondary">Risk Score Spectrum</span>
          <span className="text-[11px] text-text-muted">(10 Bins)</span>
        </div>
        {activeBin != null ? (
          <button
            onClick={() => {
              playTick("toggle");
              onSelectBin(null);
            }}
            className="text-accent hover:underline font-semibold text-xs transition-colors"
          >
            Clear Filter ({activeBin.range})
          </button>
        ) : (
          <span className="text-[11px] text-text-muted font-mono">{rows.length} cases</span>
        )}
      </div>

      {/* Mini Histogram Bars with solid semantic fills and hover states */}
      <div
        className="flex h-9 items-end gap-1 rounded-control border border-divider px-2 py-1.5"
        style={{ background: "var(--surface-subtle)" }}
        role="group"
        aria-label="Risk score distribution bins"
      >
        {bins.map((b, idx) => {
          const isSelected = activeBin?.min === b.min;

          return (
            <button
              key={idx}
              type="button"
              title={`Bin ${b.range}: ${b.count} cases (Click to filter)`}
              onClick={() => handleSelect(b)}
              className={`group relative flex h-full flex-1 flex-col justify-end transition-all cursor-pointer ${
                isSelected
                  ? "opacity-100 scale-105"
                  : activeBin != null
                  ? "opacity-40 hover:opacity-80"
                  : "opacity-80 hover:opacity-100 hover:scale-105"
              }`}
            >
              <div
                className={`w-full rounded-[2px] transition-all duration-200 ${
                  isSelected ? "ring-2 ring-accent shadow-xs" : ""
                }`}
                style={{
                  height: `${b.pct}%`,
                  backgroundColor: b.color,
                  opacity: b.count === 0 ? 0.2 : 1,
                }}
              />
            </button>
          );
        })}
      </div>

      {/* Axis markers */}
      <div className="flex justify-between font-mono text-[10px] text-text-muted px-1">
        <span>0</span>
        <span>25</span>
        <span>50</span>
        <span>75</span>
        <span>100</span>
      </div>
    </div>
  );
}
