import { useMemo } from "react";
import { ShieldCheck, Lock, CheckCircle2, ShieldAlert } from "./PhosphorIcons";

/**
 * CryptographicSeal: Precision-engineered Cyber-Attestation Emblem
 * Replaces blurry curved textpath circles with razor-sharp geometric vectors,
 * faceted cyber-shield contours, and glowing cryptographic status telemetry.
 */
export default function CryptographicSeal({
  hash = "0x8f4cb21e",
  size = 56,
  status = "VERIFIED",
  className = "",
}) {
  const isPositive = ["VERIFIED", "ANCHORED", "COMMITTED", "ACCEPT", "ACCEPTED", "APPROVE", "APPROVED"].includes(
    String(status).toUpperCase()
  );
  const isCritical = ["ESCALATED", "ESCALATE", "CRITICAL", "SAR"].includes(
    String(status).toUpperCase()
  );
  const isDismiss = ["DISMISS", "DISMISSED"].includes(
    String(status).toUpperCase()
  );

  const glowColor = isPositive
    ? "rgba(52, 211, 153, 0.4)"
    : isCritical
    ? "rgba(255, 107, 53, 0.45)"
    : isDismiss
    ? "rgba(160, 160, 160, 0.25)"
    : "rgba(116, 157, 196, 0.35)";

  const strokeColor = isPositive
    ? "var(--color-risk-low)"
    : isCritical
    ? "var(--color-risk-crit)"
    : isDismiss
    ? "var(--divider)"
    : "var(--color-accent)";

  const gradientId = useMemo(
    () => `sealGrad_${Math.random().toString(36).substr(2, 9)}`,
    []
  );

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
      title={`Tamper-Evident Regulatory Attestation: ${hash} [${status}]`}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible drop-shadow-xs"
      >
        <defs>
          {/* Subtle metallic linear gradient */}
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={strokeColor} stopOpacity="0.9" />
            <stop offset="50%" stopColor="var(--color-border-strong)" stopOpacity="0.6" />
            <stop offset="100%" stopColor={strokeColor} stopOpacity="0.9" />
          </linearGradient>

          {/* Soft core glow */}
          <filter id="emblemGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Outer Corner Precision Tick Brackets */}
        <path
          d="M 12 22 L 12 14 L 20 14"
          fill="none"
          stroke="var(--color-border-strong)"
          strokeWidth="1.25"
        />
        <path
          d="M 88 22 L 88 14 L 80 14"
          fill="none"
          stroke="var(--color-border-strong)"
          strokeWidth="1.25"
        />
        <path
          d="M 12 78 L 12 86 L 20 86"
          fill="none"
          stroke="var(--color-border-strong)"
          strokeWidth="1.25"
        />
        <path
          d="M 88 78 L 88 86 L 80 86"
          fill="none"
          stroke="var(--color-border-strong)"
          strokeWidth="1.25"
        />

        {/* Outer Faceted Geometric Cyber-Shield Contour */}
        <polygon
          points="50,6 88,22 88,64 50,94 12,64 12,22"
          fill="var(--color-panel-dock)"
          stroke={`url(#${gradientId})`}
          strokeWidth="1.5"
          strokeLinejoin="round"
        />

        {/* Inner Precision Hairline Shield */}
        <polygon
          points="50,14 81,27 81,61 50,86 19,61 19,27"
          fill="var(--color-panel)"
          stroke="var(--color-border)"
          strokeWidth="0.75"
          strokeDasharray="3 3"
        />

        {/* Center High-Tech Cryptographic Crest: Stylized Padlock & Shield */}
        <g transform="translate(32, 26) scale(1.5)" filter="url(#emblemGlow)">
          {/* Padlock Shackle */}
          <path
            d="M 8 13 V 8 C 8 4.68 10.68 2 14 2 C 17.32 2 20 4.68 20 8 V 13"
            fill="none"
            stroke={strokeColor}
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Padlock Body */}
          <rect
            x="5"
            y="12"
            width="18"
            height="13"
            rx="2.5"
            fill="var(--color-panel-raised)"
            stroke={strokeColor}
            strokeWidth="1.75"
          />
          {/* Core Keyhole Beacon */}
          <circle cx="14" cy="17" r="1.75" fill={strokeColor} />
          <path
            d="M 14 18.5 L 14 21.5"
            stroke={strokeColor}
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </g>

        {/* Bottom Horizontal Micro Telemetry Bar */}
        <g transform="translate(0, 72)">
          {/* Status Label Pill */}
          <rect
            x="24"
            y="2"
            width="52"
            height="11"
            rx="2"
            fill="var(--color-panel-dock)"
            stroke={strokeColor}
            strokeWidth="0.75"
          />
          <text
            x="50"
            y="10"
            textAnchor="middle"
            className="font-mono text-[6.5px] font-extrabold uppercase tracking-wider"
            fill={strokeColor}
          >
            {status}
          </text>
        </g>

        {/* Micro hash fragment indicator */}
        <text
          x="50"
          y="20"
          textAnchor="middle"
          className="font-mono text-[5.5px] font-semibold tracking-widest text-ink-muted"
          fill="var(--color-ink-muted)"
        >
          ATTESTED
        </text>
      </svg>
    </div>
  );
}
