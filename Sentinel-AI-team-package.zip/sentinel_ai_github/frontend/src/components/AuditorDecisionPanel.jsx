import { useState, useEffect } from "react";
import {
  CheckCircle2,
  AlertOctagon,
  FileSearch,
  X,
  Loader2,
  CheckCheck,
  ExternalLink,
  ShieldAlert,
} from "./PhosphorIcons";
import { Link } from "react-router-dom";
import CryptographicSeal from "./CryptographicSeal";

const ACTIONS = [
  {
    key: "1",
    value: "APPROVE",
    label: "APPROVE",
    desc: "No compliance breach found; cleared for settlement",
    Icon: CheckCircle2,
    tone: "border-low-border bg-low-bg text-low hover:bg-low-bg/80 focus:ring-low",
  },
  {
    key: "2",
    value: "ESCALATE",
    label: "ESCALATE",
    desc: "Refer to Senior Compliance Officer & FinCEN liaison",
    Icon: AlertOctagon,
    tone: "border-critical-border bg-critical-bg text-critical hover:bg-critical-bg/80 focus:ring-critical",
  },
  {
    key: "3",
    value: "SAR",
    label: "FILE SAR",
    desc: "File Suspicious Activity Report with regulatory body",
    Icon: FileSearch,
    tone: "border-medium-border bg-medium-bg text-medium hover:bg-medium-bg/80 focus:ring-medium",
  },
  {
    key: "4",
    value: "DISMISS",
    label: "DISMISS",
    desc: "Benign commercial pattern; false positive cleared",
    Icon: X,
    tone: "border-border-strong bg-panel-raised text-ink-muted hover:text-ink focus:ring-accent",
  },
];

const RATIONALE_PRESETS = [
  {
    tag: "Recurring Counterparty",
    text: "Verified commercial relationship with known recurring counterparty.",
  },
  {
    tag: "Structuring Alert",
    text: "Flagged as high-velocity structuring near statutory reporting threshold.",
  },
  {
    tag: "IP/Device Mismatch",
    text: "Anomalous geographic IP dispersion and device fingerprint mismatch.",
  },
  {
    tag: "Incomplete KYC",
    text: "Insufficient documentation submitted to justify transaction magnitude.",
  },
];

export default function AuditorDecisionPanel({
  existingDecision,
  existingReason,
  busy,
  onDecide,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [reason, setReason] = useState(existingReason || "");

  // Sync state whenever external decision or reason changes
  useEffect(() => {
    setIsEditing(false);
    setReason(existingReason || "");
  }, [existingDecision, existingReason]);

  const handleAction = async (val) => {
    try {
      await onDecide(val, reason);
      setIsEditing(false);
      setReason("");
    } catch {
      // Keep isEditing true on error so auditor sees error message
    }
  };

  // Keyboard shortcut listener for hotkeys 1-4 when not typing
  useEffect(() => {
    function handleKeyDown(e) {
      if ((existingDecision && !isEditing) || busy) return;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        return;
      }
      const match = ACTIONS.find((a) => a.key === e.key);
      if (match) {
        e.preventDefault();
        handleAction(match.value);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [existingDecision, isEditing, busy, reason, onDecide]);

  // ─── Already decided state ───────────────────────────────
  if (existingDecision && !isEditing) {
    const isEscalate = ["ESCALATE", "SAR", "CRITICAL"].includes(existingDecision);
    const isDismiss = ["DISMISS", "DISMISSED"].includes(existingDecision);
    const badgeColor = isEscalate ? "text-critical" : isDismiss ? "text-text-muted" : "text-low";
    const panelBorder = isEscalate
      ? "border-critical-border/70 bg-critical-bg/20"
      : isDismiss
      ? "border-border bg-panel-raised/30"
      : "border-low-border/70 bg-low-bg/20";

    return (
      <div className={`rounded-panel border p-4 space-y-3 ${panelBorder}`} style={{ boxShadow: "var(--shadow-panel)" }}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <CryptographicSeal size={48} status={existingDecision} />
            <div>
              <div className={`flex items-center gap-1.5 font-mono text-xs font-bold uppercase tracking-wider ${badgeColor}`}>
                <CheckCheck className="h-4 w-4 shrink-0" strokeWidth={2.5} />
                <span>Disposition Committed: {existingDecision.replace(/_/g, " ")}</span>
              </div>
              <div className="text-xs text-text-muted mt-0.5">
                Cryptographically attested by Compliance Officer
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              setReason(existingReason || "");
              setIsEditing(true);
            }}
            className="rounded-control border border-border bg-surface px-2 py-1 text-xs font-medium text-text-secondary hover:text-text-primary hover:border-border-strong transition-colors"
          >
            Amend
          </button>
        </div>

        {existingReason && (
          <div className="rounded-control border border-border/70 bg-surface/80 p-2.5 text-xs leading-relaxed text-text-secondary">
            <span className="text-xs font-semibold text-text-muted block mb-0.5">
              Rationale Logged:
            </span>
            <span className="italic text-text-primary">"{existingReason}"</span>
          </div>
        )}

        <div className="flex items-center justify-between border-t border-border/40 pt-2 text-xs text-text-muted">
          <span className="flex items-center gap-1.5 text-low font-medium">
            <span className="h-1.5 w-1.5 rounded-full bg-low" />
            <span>Attested & Recorded</span>
          </span>
          <Link
            to="/audit-trail"
            className="inline-flex items-center gap-1 text-accent hover:underline font-medium"
          >
            <span>Audit Ledger</span>
            <ExternalLink className="h-3 w-3" />
          </Link>
        </div>
      </div>
    );
  }

  // ─── Decision form ────────────────────────────────────────
  return (
    <div className="rounded-panel border border-border p-4 space-y-3" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
      <div className="flex items-center justify-between border-b border-border/60 pb-2">
        <span className="text-xs font-semibold text-text-primary">
          {isEditing ? "Amend Prior Disposition" : "Auditor Decision"}
        </span>
        {isEditing ? (
          <button
            onClick={() => setIsEditing(false)}
            className="text-xs text-text-muted hover:text-text-primary underline"
          >
            Cancel
          </button>
        ) : (
          <span className="text-xs text-text-muted">Supervisory Sign-Off</span>
        )}
      </div>

      <p className="text-xs text-text-secondary">
        Your decision will be anchored to the immutable audit ledger.
      </p>

      {/* Rationale textarea */}
      <div className="mt-2">
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Decision rationale (recommended for escalations)…"
          rows={3}
          disabled={busy}
          className="w-full resize-none rounded-control border border-border bg-panel-dock px-3 py-2 text-xs text-text-primary placeholder:text-text-muted focus:border-accent focus:outline-none disabled:opacity-50"
        />

        {/* Quick rationale presets */}
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {RATIONALE_PRESETS.map((p) => (
            <button
              key={p.tag}
              type="button"
              disabled={busy}
              onClick={() => setReason(p.text)}
              className="rounded-control bg-panel-dock border border-border/60 px-2 py-0.5 text-left text-xs text-text-secondary transition-colors hover:bg-surface hover:text-text-primary disabled:opacity-50"
            >
              + {p.tag}
            </button>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {ACTIONS.map((a) => {
          const { Icon } = a;
          return (
            <button
              key={a.value}
              disabled={busy}
              onClick={() => handleAction(a.value)}
              title={`${a.label}: ${a.desc}`}
              className={`flex flex-col items-center justify-center gap-1.5 rounded-control border px-2.5 py-2.5 text-center transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 ${a.tone}`}
            >
              <div className="flex items-center justify-center">
                {busy ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Icon className="h-4 w-4" strokeWidth={2} />
                )}
              </div>
              <span className="font-mono text-2xs font-bold tracking-wide">{a.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
