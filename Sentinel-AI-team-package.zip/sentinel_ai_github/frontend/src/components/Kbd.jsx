export default function Kbd({ children, className = "" }) {
  return (
    <kbd
      className={`inline-flex items-center justify-center rounded border border-divider/60 bg-surface-subtle px-1.5 py-0.5 font-mono text-3xs font-medium text-text-secondary ${className}`}
    >
      {children}
    </kbd>
  );
}
