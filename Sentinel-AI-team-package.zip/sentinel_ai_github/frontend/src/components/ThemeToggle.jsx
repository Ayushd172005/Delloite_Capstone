import { Sun, Moon } from "@phosphor-icons/react";
import { useTheme } from "../context/ThemeContext";
import { playTick } from "../utils/audio";

/**
 * ThemeToggle — animated Sun/Moon button with audio micro-tick.
 * variant="icon" → icon only (for TopBar)
 * variant="full" → icon + label (for Sidebar)
 */
export default function ThemeToggle({ variant = "icon" }) {
  const { theme, toggle, isDark } = useTheme();

  const handleToggle = (e) => {
    playTick("toggle");
    toggle(e);
  };

  if (variant === "full") {
    return (
      <button
        onClick={handleToggle}
        className="flex w-full items-center justify-between rounded-md px-3 py-2 text-xs font-sans font-medium text-text-secondary transition-colors hover:bg-surface hover:text-text-primary"
        aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
        title={isDark ? "Switch to light mode" : "Switch to dark mode"}
      >
        <div className="flex items-center gap-2.5">
          {isDark ? (
            <Sun className="h-4 w-4 shrink-0 text-accent" weight="regular" />
          ) : (
            <Moon className="h-4 w-4 shrink-0 text-accent" weight="regular" />
          )}
          <span>{isDark ? "Studio Light" : "Drafting Dark"}</span>
        </div>
      </button>
    );
  }

  // Icon-only variant for TopBar
  return (
    <button
      onClick={handleToggle}
      className="flex h-8 w-8 items-center justify-center rounded-control text-text-muted transition-all hover:text-text-primary hover:border-accent/40 focus:outline-none"
      style={{
        background: "var(--surface)",
        border: "1px solid var(--divider)",
      }}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Switch to Studio Light mode" : "Switch to Drafting Dark mode"}
    >
      {isDark ? (
        <Sun className="h-4 w-4 text-accent" weight="regular" />
      ) : (
        <Moon className="h-4 w-4 text-accent" weight="regular" />
      )}
    </button>
  );
}
