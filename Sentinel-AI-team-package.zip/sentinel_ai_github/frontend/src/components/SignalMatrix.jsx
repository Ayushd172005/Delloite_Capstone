/**
 * SignalMatrix: Refined, eye-friendly anomaly diagnostic indicators
 * Renders compact, harmonious micro-badges for ML / statistical models:
 * - IF: Isolation Forest
 * - AE: Autoencoder
 * - BF: Benford's Law
 * - NW: Network Topology
 */
export default function SignalMatrix({ signals, rulesTriggered = [] }) {
  const rules = Array.isArray(rulesTriggered) ? rulesTriggered : [];
  
  const hasIF = rules.some((r) => r.toLowerCase().includes("isolation") || r.toLowerCase().includes("forest") || r.toLowerCase().includes("unusual_amount"));
  const hasAE = rules.some((r) => r.toLowerCase().includes("autoencoder") || r.toLowerCase().includes("velocity") || r.toLowerCase().includes("rapid"));
  const hasBF = rules.some((r) => r.toLowerCase().includes("benford") || r.toLowerCase().includes("structuring") || r.toLowerCase().includes("threshold"));
  const hasNW = rules.some((r) => r.toLowerCase().includes("fan") || r.toLowerCase().includes("network") || r.toLowerCase().includes("device"));

  const badges = [
    { label: "IF", active: hasIF, title: "Isolation Forest" },
    { label: "AE", active: hasAE, title: "Autoencoder" },
    { label: "BF", active: hasBF, title: "Benford Structuring" },
    { label: "NW", active: hasNW, title: "Network Cluster" },
  ];

  return (
    <div className="flex items-center gap-1 font-mono text-3xs">
      {badges.map((b) => (
        <span
          key={b.label}
          title={`${b.title}: ${b.active ? "Flagged" : "Nominal"}`}
          className={`inline-block rounded px-1 py-0.5 transition-colors ${
            b.active
              ? "bg-accent-dim text-accent font-semibold border border-accent/30"
              : "text-ink-faint/50 border border-transparent"
          }`}
        >
          {b.label}
        </span>
      ))}
    </div>
  );
}
