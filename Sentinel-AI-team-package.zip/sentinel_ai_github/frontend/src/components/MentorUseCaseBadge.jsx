// Renders the mentor-aligned business use-case label(s) EXACTLY as returned by the
// backend's `signals.use_case` field (see use_cases.py / app.py) - e.g. "New Device +
// High-Value Transaction", "Fan-In Network", "Fan-Out Network", "Fan-In/Fan-Out Network",
// "Near-Threshold Structuring". The backend joins multiple simultaneous use cases with
// "; " (see use_cases.add_all_use_cases) - split back into separate badges here for
// display, but never rename or rephrase the label itself: it comes verbatim from the
// frozen backend, not from this component.
export default function MentorUseCaseBadge({ useCase, size = "sm" }) {
  if (!useCase) return null;
  const labels = useCase.split(";").map((s) => s.trim()).filter(Boolean);
  const pad = size === "sm" ? "px-1.5 py-0.5 text-2xs" : "px-2 py-1 text-xs";
  return (
    <>
      {labels.map((label) => (
        <span
          key={label}
          className={`inline-block rounded-md bg-panel-raised text-ink-muted ${pad} font-medium whitespace-nowrap`}
        >
          {label}
        </span>
      ))}
    </>
  );
}
