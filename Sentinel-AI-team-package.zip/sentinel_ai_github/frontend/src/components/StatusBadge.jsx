import {
  Clock,
  Timer,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight,
  FileText,
  XCircle,
  Lock,
  HelpCircle,
} from "./PhosphorIcons";

/**
 * StatusBadge — Fixed status vocabulary with icon + text + color.
 * Never relies on color alone to convey meaning.
 *
 * Supported status keys:
 * PENDING | SLA_AT_RISK | SLA_BREACHED | ACCEPT | ACCEPTED | ESCALATE | ESCALATED |
 * SAR | SAR_FILED | DISMISS | DISMISSED | ATTESTED | REQUEST_MORE_EVIDENCE | OVERRIDE
 */

const STATUS = {
  PENDING: {
    label: "Pending",
    Icon: Clock,
    textColor: "var(--text-secondary)",
    bgColor:   "var(--surface-subtle)",
    border:    "var(--divider)",
  },
  SLA_AT_RISK: {
    label: "SLA at risk",
    Icon: Timer,
    textColor: "var(--risk-warning)",
    bgColor:   "var(--risk-warning-bg)",
    border:    "var(--risk-warning-border)",
  },
  SLA_BREACHED: {
    label: "SLA breached",
    Icon: AlertCircle,
    textColor: "var(--risk-critical)",
    bgColor:   "var(--risk-critical-bg)",
    border:    "var(--risk-critical-border)",
  },
  APPROVE: {
    label: "Approved",
    Icon: CheckCircle2,
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
  },
  APPROVED: {
    label: "Approved",
    Icon: CheckCircle2,
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
  },
  ACCEPT: {
    label: "Accepted",
    Icon: CheckCircle2,
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
  },
  ACCEPTED: {
    label: "Accepted",
    Icon: CheckCircle2,
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
  },
  ESCALATE: {
    label: "Escalated",
    Icon: ArrowUpRight,
    textColor: "var(--risk-warning)",
    bgColor:   "var(--risk-warning-bg)",
    border:    "var(--risk-warning-border)",
  },
  ESCALATED: {
    label: "Escalated",
    Icon: ArrowUpRight,
    textColor: "var(--risk-warning)",
    bgColor:   "var(--risk-warning-bg)",
    border:    "var(--risk-warning-border)",
  },
  SAR: {
    label: "SAR filed",
    Icon: FileText,
    textColor: "var(--risk-info)",
    bgColor:   "var(--risk-info-bg)",
    border:    "var(--risk-info-border)",
  },
  SAR_FILED: {
    label: "SAR filed",
    Icon: FileText,
    textColor: "var(--risk-info)",
    bgColor:   "var(--risk-info-bg)",
    border:    "var(--risk-info-border)",
  },
  DISMISS: {
    label: "Dismissed",
    Icon: XCircle,
    textColor: "var(--text-muted)",
    bgColor:   "var(--surface-subtle)",
    border:    "var(--divider)",
  },
  DISMISSED: {
    label: "Dismissed",
    Icon: XCircle,
    textColor: "var(--text-muted)",
    bgColor:   "var(--surface-subtle)",
    border:    "var(--divider)",
  },
  ATTESTED: {
    label: "Attested",
    Icon: Lock,
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
  },
  REQUEST_MORE_EVIDENCE: {
    label: "Needs evidence",
    Icon: HelpCircle,
    textColor: "var(--risk-warning)",
    bgColor:   "var(--risk-warning-bg)",
    border:    "var(--risk-warning-border)",
  },
  OVERRIDE: {
    label: "Overridden",
    Icon: AlertCircle,
    textColor: "var(--risk-info)",
    bgColor:   "var(--risk-info-bg)",
    border:    "var(--risk-info-border)",
  },
};

export default function StatusBadge({ status, size = "md" }) {
  const key = status?.toUpperCase?.() ?? "PENDING";
  const cfg = STATUS[key] || STATUS.PENDING;
  const { label, Icon } = cfg;

  const padding = size === "sm" ? "px-1.5 py-0.5 gap-1 text-meta-xs" : "px-2 py-0.5 gap-1.5 text-2xs";

  return (
    <span
      className={`inline-flex items-center rounded-badge font-medium ${padding}`}
      style={{
        color:       cfg.textColor,
        background:  cfg.bgColor,
        border:      `1px solid ${cfg.border}`,
      }}
      aria-label={label}
    >
      <Icon className={`shrink-0 ${size === "sm" ? "h-2.5 w-2.5" : "h-3 w-3"}`} aria-hidden />
      <span>{label}</span>
    </span>
  );
}
