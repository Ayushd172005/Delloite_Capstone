import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  CheckCircle,
  ArrowUpRight,
  FileText,
  XCircle,
  PaperPlaneRight,
  LockKey,
  ArrowSquareOut,
  Warning,
  Cpu,
  Database,
  UserCheck,
  ArrowsClockwise,
  X,
} from "@phosphor-icons/react";
import BrandLogo from "./BrandLogo";
import RadialGauge from "./RadialGauge";
import TransactionFlowGraph from "./TransactionFlowGraph";
import RiskBadge from "./RiskBadge";
import SlaBadge from "./SlaBadge";
import StatusBadge from "./StatusBadge";
import CryptographicSeal from "./CryptographicSeal";
import { useCurrency } from "../context/CurrencyContext";
import { compactCaseId } from "../utils/caseId";
import { fmtVertical } from "../utils/format";
import { submitAuditorDecision } from "../api/investigations";
import { getCase } from "../api/transactions";
import { playTick } from "../utils/audio";

const QUICK_REASONS = [
  "Verified legitimate corporate invoice",
  "Structuring pattern across multiple windows",
  "Velocity burst exceeds account standard deviation",
  "Beneficiary sanctioned country proxy match",
  "False positive — verified source of funds",
];

const ACTIONS = [
  {
    key: "APPROVE",
    label: "Approve",
    shortcut: "A",
    Icon: CheckCircle,
    color: "var(--risk-success)",
    bg:    "var(--risk-success-bg)",
    border:"var(--risk-success-border)",
  },
  {
    key: "ESCALATE",
    label: "Escalate",
    shortcut: "E",
    Icon: ArrowUpRight,
    color: "var(--risk-warning)",
    bg:    "var(--risk-warning-bg)",
    border:"var(--risk-warning-border)",
  },
  {
    key: "SAR",
    label: "File SAR",
    shortcut: "S",
    Icon: FileText,
    color: "var(--risk-info)",
    bg:    "var(--risk-info-bg)",
    border:"var(--risk-info-border)",
  },
  {
    key: "DISMISS",
    label: "Dismiss",
    shortcut: "D",
    Icon: XCircle,
    color: "var(--text-muted)",
    bg:    "var(--surface-subtle)",
    border:"var(--divider)",
  },
];

function EvidenceSectionHeader({ icon: Icon, label, badge, type }) {
  const typeColor = {
    ai:     "var(--risk-info)",
    source: "var(--text-secondary)",
    human:  "var(--risk-success)",
    audit:  "var(--text-muted)",
  }[type] || "var(--text-secondary)";

  return (
    <div
      className="flex items-center gap-2 pb-2 mb-3 border-b border-divider"
    >
      <span
        className="flex h-5 w-5 items-center justify-center rounded"
        style={{ background: `color-mix(in srgb, ${typeColor} 15%, transparent)`, color: typeColor }}
      >
        <Icon className="h-3.5 w-3.5" weight="bold" aria-hidden />
      </span>
      <span className="text-xs font-semibold font-sans text-text-primary">{label}</span>
      {badge && (
        <span className="ml-auto font-mono text-meta-xs text-text-muted">
          {badge}
        </span>
      )}
    </div>
  );
}

export default function ForensicWorkbenchDossier({
  row,
  onDispositionSuccess,
  queueList = [],
}) {
  const { formatAmount } = useCurrency();

  const [triageAction, setTriageAction] = useState(null);
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [successEvent, setSuccessEvent] = useState(null);

  // Reset state when row changes
  useEffect(() => {
    setTriageAction(null);
    setReason("");
    setSubmitError(null);
    setSuccessEvent(null);
  }, [row?.transaction_id]);

  // Hotkeys: A, E, S, D (not inside inputs)
  useEffect(() => {
    function handleKeyDown(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
      if (!row) return;
      const key = e.key.toUpperCase();
      if (key === "A") { e.preventDefault(); playTick("toggle"); setTriageAction("APPROVE"); }
      else if (key === "E") { e.preventDefault(); playTick("toggle"); setTriageAction("ESCALATE"); }
      else if (key === "S") { e.preventDefault(); playTick("toggle"); setTriageAction("SAR"); }
      else if (key === "D") { e.preventDefault(); playTick("toggle"); setTriageAction("DISMISS"); }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [row]);

  const handleConfirmDecision = async () => {
    if (!triageAction || !row) return;
    setSubmitting(true);
    setSubmitError(null);

    try {
      const res = await submitAuditorDecision(row.transaction_id, {
        action: triageAction,
        reason: reason || `Triage disposition: ${triageAction}`,
        auditor: "forensic.operator@sentinel.ai",
      });

      playTick("disposition");
      setSuccessEvent(res?.event || { event_id: `evt_${Date.now()}` });
      onDispositionSuccess?.(row.transaction_id, triageAction, reason);
      setTriageAction(null);
    } catch (err) {
      setSubmitError(err?.message || "Failed to submit attestation to ledger");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Empty state ──
  if (!row) {
    return (
      <div
        className="flex h-full flex-col items-center justify-center p-10 text-center select-none"
        style={{ background: "var(--surface)" }}
      >
        <div
          className="flex h-14 w-14 items-center justify-center rounded-full mb-4"
          style={{ background: "var(--surface-subtle)", border: "1px solid var(--divider)" }}
        >
          <BrandLogo size={28} />
        </div>
        <h3 className="font-sans text-sm font-semibold text-text-primary mb-1">
          Workbench Standby
        </h3>
        <p className="max-w-xs text-xs font-sans text-text-secondary">
          Select a case in the surveillance queue to inspect its complete forensic dossier.
        </p>
      </div>
    );
  }

  const [caseSignals, setCaseSignals] = useState(null);

  useEffect(() => {
    if (!row?.transaction_id) {
      setCaseSignals(null);
      return;
    }
    let cancelled = false;
    getCase(row.transaction_id)
      .then((data) => {
        if (!cancelled && data?.signals) {
          setCaseSignals(data.signals);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [row?.transaction_id]);

  const composite = Number(row.composite_score ?? 0);
  const signals = caseSignals || row.signals || {
    composite_score: row.composite_score,
    review_tier: row.review_tier,
    benford_flag: null,
  };
  const iso = signals.isoforest_score ?? null;
  const ae = signals.autoencoder_score ?? null;
  const currentDecision = row.auditor_decision;

  // Count model signals above threshold (>= 0.65)
  const signalsAboveThreshold = [iso, ae].filter((v) => v != null && v >= 0.65).length + (signals.benford_flag ? 1 : 0);

  return (
    <div
      className="flex h-full flex-col select-none"
      style={{ background: "var(--surface)" }}
    >
      {/* ════════════════════════════════════════════════
          STICKY DOSSIER HEADER
          ════════════════════════════════════════════════ */}
      <div
        className="shrink-0 px-5 pt-4 pb-3 space-y-3"
        style={{
          background: "var(--surface-raised)",
          borderBottom: "1px solid var(--divider)",
          boxShadow: "var(--shadow-panel)",
        }}
      >
        {/* ── Top row: identity ── */}
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1.5 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                key={row.transaction_id}
                className="font-mono font-bold text-decision-md tracking-tight text-text-primary animate-case-transition"
                title={row.transaction_id}
              >
                {compactCaseId(row.transaction_id)}
              </span>
              <RiskBadge tier={row.review_tier} score={composite} size="sm" />
            </div>
            <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
              <span className="font-sans text-xs text-text-secondary">
                {fmtVertical(row.vertical)}
              </span>
              <span className="font-semibold text-text-primary">{formatAmount(row.amount)}</span>
              <SlaBadge row={row} compact />
              <StatusBadge status={currentDecision || "PENDING"} size="sm" />
            </div>
            {/* Risk narrative */}
            {signalsAboveThreshold > 0 && !currentDecision && (
              <p className="font-sans text-xs text-text-muted">
                {signalsAboveThreshold} model signal{signalsAboveThreshold > 1 ? "s" : ""} above detection threshold
              </p>
            )}
          </div>

          {/* Full Case link */}
          <Link
            to={`/investigation/${row.transaction_id}`}
            state={{ row, queueList }}
            className="flex shrink-0 items-center gap-1 rounded-control px-2.5 py-1.5 font-sans text-xs font-medium transition-colors hover:border-accent/40"
            style={{
              background: "var(--surface-subtle)",
              border: "1px solid var(--divider)",
              color: "var(--text-secondary)",
            }}
            title="Open full case investigation"
            aria-label={`Open full investigation for ${row.transaction_id}`}
          >
            <span>Full Case</span>
            <ArrowSquareOut className="h-3.5 w-3.5" weight="bold" aria-hidden />
          </Link>
        </div>

        {/* ── Action group ── */}
        {currentDecision ? (
          <div
            className="flex items-center gap-3 rounded-panel p-3 border border-success/20 bg-success-bg"
            role="status"
          >
            <CryptographicSeal hash={`0x${row.transaction_id.slice(-8)}`} size={40} status="COMMITTED" />
            <div>
              <div
                className="flex items-center gap-1.5 font-sans text-xs font-bold text-success"
              >
                <LockKey className="h-3.5 w-3.5" weight="bold" aria-hidden />
                <span>Attested: {currentDecision}</span>
              </div>
              <p className="font-sans text-xs text-text-secondary mt-0.5">
                {row.decision_reason
                  ? `"${row.decision_reason}"`
                  : "Committed to immutable audit ledger"}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-2">
            {ACTIONS.map((action) => {
              const isActive = triageAction === action.key;
              return (
                <button
                  key={action.key}
                  onClick={() => { playTick("toggle"); setTriageAction(action.key); }}
                  className="flex items-center gap-1.5 rounded-control px-3 py-1.5 font-sans text-xs font-medium transition-all"
                  style={{
                    color:      isActive ? action.color : "var(--text-secondary)",
                    background: isActive ? action.bg    : "var(--surface-subtle)",
                    border:     `1px solid ${isActive ? action.border : "var(--divider)"}`,
                    fontWeight: isActive ? 600 : 500,
                  }}
                  aria-pressed={isActive}
                  title={`${action.label} (${action.shortcut})`}
                >
                  <action.Icon className="h-3.5 w-3.5 shrink-0" weight="bold" aria-hidden />
                  <span>{action.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* ── Disposition drawer ── */}
        {triageAction && !currentDecision && (
          <div
            className="rounded-panel p-3.5 space-y-3 slide-in-right border border-divider"
            style={{
              background: "var(--surface-raised)",
            }}
          >
            <div className="flex items-center justify-between font-sans text-xs">
              <span className="font-semibold text-text-primary">
                Confirm Disposition:&nbsp;
                <span className="text-accent">{triageAction}</span>
              </span>
              <button
                onClick={() => setTriageAction(null)}
                className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs font-sans text-text-muted hover:bg-surface hover:text-text-primary transition-colors cursor-pointer focus-visible:outline-none"
                aria-label="Cancel disposition"
              >
                <X className="h-3 w-3" weight="bold" aria-hidden />
                <span>Cancel</span>
              </button>
            </div>

            {/* Preset reasons */}
            <div className="flex flex-wrap gap-1">
              {QUICK_REASONS.map((qr) => (
                <button
                  key={qr}
                  onClick={() => setReason(qr)}
                  className="rounded-badge px-2 py-0.5 font-sans text-xs text-left transition-all"
                  style={{
                    color:      reason === qr ? "var(--accent)"         : "var(--text-secondary)",
                    background: reason === qr ? "var(--accent-dim)"     : "var(--surface-subtle)",
                    border:     `1px solid ${reason === qr
                      ? "color-mix(in srgb, var(--accent) 30%, transparent)"
                      : "var(--divider)"
                    }`,
                    fontWeight: reason === qr ? 600 : 400,
                  }}
                >
                  {qr}
                </button>
              ))}
            </div>

            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Attestation findings (optional)…"
              rows={2}
              className="w-full rounded-control p-2.5 font-sans text-xs resize-none focus:outline-none"
              style={{
                background: "var(--surface-subtle)",
                border: "1px solid var(--divider)",
                color: "var(--text-primary)",
              }}
              onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
              onBlur={(e) => (e.target.style.borderColor = "var(--divider)")}
            />

            {submitError && (
              <p className="font-sans text-xs text-critical">
                Error: {submitError}
              </p>
            )}

            <div className="flex items-center justify-between pt-0.5">
              <span className="flex items-center gap-1 font-sans text-xs text-text-muted">
                <LockKey className="h-3.5 w-3.5 text-accent" weight="bold" aria-hidden />
                Regulatory audit record sealed
              </span>
              <button
                onClick={handleConfirmDecision}
                disabled={submitting}
                className="flex items-center gap-1.5 rounded-control px-3.5 py-1.5 font-sans text-xs font-semibold text-white dark:text-canvas hover:opacity-95 disabled:opacity-50 transition-opacity bg-accent shadow-xs"
              >
                {submitting ? (
                  <ArrowsClockwise className="h-3.5 w-3.5 animate-spin" weight="bold" aria-hidden />
                ) : (
                  <PaperPlaneRight className="h-3.5 w-3.5" weight="bold" aria-hidden />
                )}
                <span>{submitting ? "Attesting…" : "Sign & Commit"}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ════════════════════════════════════════════════
          SCROLLABLE EVIDENCE BODY
          ════════════════════════════════════════════════ */}
      <div className="dossier-evidence-body flex-1 overflow-y-auto scrollbar-thin px-5 py-4 space-y-5">

        {/* ── AI Finding ── */}
        <section className="dossier-section dossier-ai" aria-label="AI model finding">
          <EvidenceSectionHeader
            icon={Cpu}
            label="Statistical Anomaly Synthesis"
            badge="Ensemble Consensus"
            type="ai"
          />
          <div className="space-y-4 pt-1">
            <div className="grid grid-cols-1 sm:grid-cols-[130px_1fr] gap-4 items-center">
              <div className="flex justify-center">
                <RadialGauge score={composite} tier={row.review_tier} size={115} />
              </div>

              <div className="space-y-3">
                {/* Isolation Forest */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-sans">
                    <span className="text-text-secondary font-medium">Isolation Forest (Outlier Variance)</span>
                    <span className="font-mono font-semibold text-text-primary tabular-nums">
                      {iso == null ? "—" : `${(iso * 100).toFixed(1)}%`}
                    </span>
                  </div>
                  <div className="relative h-1.5 w-full rounded-full overflow-hidden bg-surface-subtle border border-divider">
                    <div
                      className="h-full rounded-full transition-all duration-500 bg-accent"
                      style={{ width: `${iso == null ? 0 : Math.min(100, iso * 100)}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-critical opacity-80"
                      style={{ left: "65%" }}
                      title="Detection threshold: 65%"
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-text-muted font-sans">
                    <span>Threshold: 65.0%</span>
                    <span className={iso >= 0.65 ? "text-critical font-medium" : "text-success font-medium"}>
                      {iso == null ? "—" : iso >= 0.65 ? "Threshold Exceeded" : "Nominal"}
                    </span>
                  </div>
                </div>

                {/* Autoencoder */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-sans">
                    <span className="text-text-secondary font-medium">Autoencoder (Manifold Reconstruction Loss)</span>
                    <span className="font-mono font-semibold text-text-primary tabular-nums">
                      {ae == null ? "—" : `${(ae * 100).toFixed(1)}%`}
                    </span>
                  </div>
                  <div className="relative h-1.5 w-full rounded-full overflow-hidden bg-surface-subtle border border-divider">
                    <div
                      className="h-full rounded-full transition-all duration-500 bg-accent"
                      style={{ width: `${ae == null ? 0 : Math.min(100, ae * 100)}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-critical opacity-80"
                      style={{ left: "65%" }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-text-muted font-sans">
                    <span>Threshold: 65.0%</span>
                    <span className={ae >= 0.65 ? "text-critical font-medium" : "text-success font-medium"}>
                      {ae == null ? "—" : ae >= 0.65 ? "Threshold Exceeded" : "Nominal"}
                    </span>
                  </div>
                </div>

                {/* Benford */}
                <div className="flex items-center justify-between text-xs font-sans pt-1 border-t border-divider">
                  <span className="text-text-secondary">Benford First-Digit Conformance</span>
                  <span
                    className="font-medium text-xs"
                    style={{ color: signals.benford_flag ? "var(--risk-critical)" : "var(--risk-success)" }}
                  >
                    {signals.benford_flag ? "Anomalous Distribution (Non-conformant)" : "Conformant (Natural Distribution)"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── Source Evidence ── */}
        <section className="dossier-section dossier-source" aria-label="Source evidence and transaction context">
          <EvidenceSectionHeader icon={Database} label="Source Evidence" type="source" />
          <div className="space-y-1.5">
            <TransactionFlowGraph
              transactionId={row.transaction_id}
              accountId={row.account_id}
              counterpartyId={row.counterparty_id}
              amount={row.amount}
              vertical={row.vertical}
              signals={signals}
              compact={true}
            />

            {/* Triggered rules */}
            {row.rules_triggered && row.rules_triggered.length > 0 && (
              <div className="space-y-1.5 mt-3">
                <p className="font-sans text-xs font-semibold uppercase tracking-wider text-text-muted">
                  Triggered Heuristics ({row.rules_triggered.length})
                </p>
                <div className="flex flex-wrap gap-1">
                  {row.rules_triggered.map((rule) => (
                    <span
                      key={rule}
                      className="rounded px-2 py-0.5 font-mono text-meta-xs bg-surface-subtle text-text-secondary border border-divider"
                    >
                      {rule.replace(/_/g, " ")}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>

        <section className="dossier-section dossier-context" aria-label="Case context">
          <EvidenceSectionHeader icon={FileText} label="Case context" badge="Review reference" type="source" />
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-2.5">
            {[
              ["Account", row.account_id || "Derived from transaction"],
              ["Counterparty", row.counterparty_id || "Derived from transaction"],
              ["Queue lane", fmtVertical(row.vertical)],
              ["Rules triggered", `${row.rules_triggered?.length ?? 0} heuristics`],
            ].map(([label, value]) => (
              <div key={label} className="rounded-control border border-divider bg-surface p-3 min-w-0">
                <div className="font-sans text-[10px] font-semibold uppercase tracking-wider text-text-muted">{label}</div>
                <div className="mt-1 truncate font-mono text-xs font-medium text-text-primary" title={value}>{value}</div>
              </div>
            ))}
          </div>
        </section>

        {/* ── Human Action (if attested) ── */}
        {currentDecision && (
          <section className="dossier-section dossier-human" aria-label="Human reviewer decision">
            <EvidenceSectionHeader icon={UserCheck} label="Reviewer Decision" type="human" />
            <div
              className="rounded-panel p-3 border border-success/20 bg-success-bg"
            >
              <div className="flex items-center gap-2 text-xs font-bold text-success mb-1 font-sans">
                <CheckCircle className="h-4 w-4" weight="bold" aria-hidden />
                <span>{currentDecision}</span>
              </div>
              {row.decision_reason && (
                <p className="font-sans text-xs text-text-secondary italic">
                  "{row.decision_reason}"
                </p>
              )}
              <p className="font-mono text-[11px] text-text-muted mt-1">
                forensic.operator@sentinel.ai
              </p>
            </div>
          </section>
        )}

      </div>
    </div>
  );
}
