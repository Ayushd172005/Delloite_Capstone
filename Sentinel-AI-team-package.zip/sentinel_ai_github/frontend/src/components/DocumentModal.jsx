import { useEffect, useRef, useState } from "react";
import { X, FileText, CheckCircle2, AlertTriangle, Minus, Hash, Copy, Check, Code, ShieldCheck } from "./PhosphorIcons";
import { playTick } from "../utils/audio";

// Extract entity properties if available from statement text or docId
function extractEntities(docId, statement) {
  const text = statement || "";
  const entities = [];

  // IP Regex
  const ipMatch = text.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/);
  if (ipMatch) entities.push({ label: "IPV4 ADDRESS", value: ipMatch[0] });

  // Account Regex
  const accMatch = text.match(/\b(ACC_\w+|[A-Z]{2}\d{6,})\b/i);
  if (accMatch) entities.push({ label: "ACCOUNT REFERENCE", value: accMatch[0] });

  // Amount Match
  const amtMatch = text.match(/(\$|₹|EUR)\s?[\d,]+(\.\d+)?/);
  if (amtMatch) entities.push({ label: "EXTRACTED SUM", value: amtMatch[0] });

  return entities;
}

function classifyDocument(docId) {
  if (!docId) return "EVIDENCE DOSSIER RECORD";
  const id = docId.toLowerCase();
  if (id.includes("mock")) return "SYNTHETIC SURVEILLANCE TELEMETRY";
  if (id.includes("kyc")) return "STATUTORY CUSTOMER IDENTIFICATION";
  if (id.includes("wire")) return "SWIFT / FEDWIRE SETTLEMENT LOG";
  if (id.includes("device")) return "CLIENT HARDWARE SESSION TELEMETRY";
  return "COUNTERPARTY TRANSACTION RECORD";
}

const STANCE_CFG = {
  supports: {
    Icon: CheckCircle2,
    label: "CORROBORATES SUSPICION",
    class: "text-low bg-low-bg border-low-border",
  },
  contradicts: {
    Icon: AlertTriangle,
    label: "CONTRADICTS SUSPICION",
    class: "text-medium bg-medium-bg border-medium-border",
  },
  neutral: {
    Icon: Minus,
    label: "NEUTRAL REFERENCE",
    class: "text-ink-faint bg-panel-dock border-border",
  },
};

export default function DocumentModal({ documentId, evidenceItem, onClose }) {
  const panelRef = useRef(null);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState("dossier"); // "dossier" | "raw"

  // Focus trap, Escape key, and body scroll lock
  useEffect(() => {
    if (!documentId) return;
    const prev = document.activeElement;
    panelRef.current?.focus();

    const originalOverflow = document.body.style.overflow;
    const originalTouchAction = document.body.style.touchAction;
    const originalPaddingRight = document.body.style.paddingRight;
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    document.body.style.touchAction = "none";
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }

    function handleKey(e) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = originalOverflow;
      document.body.style.touchAction = originalTouchAction;
      document.body.style.paddingRight = originalPaddingRight;
      prev?.focus();
    };
  }, [documentId, onClose]);

  if (!documentId) return null;

  const item = evidenceItem || {};
  const classification = classifyDocument(documentId);
  const stanceCfg = STANCE_CFG[item.stance] || STANCE_CFG.neutral;
  const { Icon: StanceIcon } = stanceCfg;

  // Real SHA-256 simulation
  const pseudoHash = `0x${documentId
    .split("")
    .reduce((acc, c) => acc + c.charCodeAt(0).toString(16), "")
    .padEnd(64, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
    .slice(0, 64)}`;

  const entities = extractEntities(documentId, item.statement);

  const copyHash = () => {
    playTick("disposition");
    navigator.clipboard.writeText(pseudoHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-base/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-over panel */}
      <aside
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={`Evidence dossier ${documentId}`}
        tabIndex={-1}
        className="slide-in-right fixed right-0 top-0 z-50 flex h-full w-full max-w-lg flex-col border-l border-border bg-panel shadow-panel-lg focus:outline-none"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-3.5 bg-panel">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-4 w-4 text-accent" />
            <div>
              <span className="text-sm font-semibold text-ink">
                Evidence Document · {documentId}
              </span>
              <div className="text-3xs text-ink-faint">
                Attested Evidence Record
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="flex h-7 w-7 items-center justify-center rounded-md text-ink-faint transition-colors hover:bg-panel-dock hover:text-ink"
              aria-label="Close dossier panel"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center justify-between border-b border-border px-5 py-2 text-xs bg-panel">
          <span className="text-ink-faint text-2xs">View Mode:</span>
          <div className="flex gap-1 text-2xs">
            <button
              onClick={() => {
                playTick("toggle");
                setViewMode("dossier");
              }}
              className={`rounded px-2.5 py-1 font-medium transition-colors ${
                viewMode === "dossier"
                  ? "bg-accent text-white dark:text-base font-semibold"
                  : "text-ink-muted hover:text-ink"
              }`}
            >
              Analysis
            </button>
            <button
              onClick={() => {
                playTick("toggle");
                setViewMode("raw");
              }}
              className={`rounded px-2.5 py-1 font-medium transition-colors ${
                viewMode === "raw"
                  ? "bg-accent text-white dark:text-base font-semibold"
                  : "text-ink-muted hover:text-ink"
              }`}
            >
              Raw Payload
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto scrollbar-thin px-5 py-5 space-y-4">
          {/* Classification & Stance */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded border border-border bg-panel-dock p-2.5">
              <div className="font-mono text-3xs uppercase tracking-wider text-ink-faint">
                CLASSIFICATION
              </div>
              <div className="mt-1 font-mono text-xs font-semibold text-ink">
                {classification}
              </div>
            </div>

            <div className="rounded border border-border bg-panel-dock p-2.5">
              <div className="font-mono text-3xs uppercase tracking-wider text-ink-faint">
                SIGNAL CORROBORATION
              </div>
              <div className="mt-1">
                <span className={`inline-flex items-center gap-1 font-mono text-2xs font-bold ${stanceCfg.class} px-1.5 py-0.5 rounded`}>
                  <StanceIcon className="h-3 w-3" />
                  {stanceCfg.label}
                </span>
              </div>
            </div>
          </div>

          {viewMode === "dossier" ? (
            <>
              {/* Primary Statement */}
              <div>
                <div className="mb-1 font-mono text-3xs uppercase tracking-wider text-ink-faint">
                  FORENSIC STATEMENT
                </div>
                <div className="rounded-md border border-border bg-panel-raised p-3 text-xs leading-relaxed text-ink">
                  {item.statement || "No textual statement provided for this evidence node."}
                </div>
              </div>

              {/* Extracted Entities */}
              {entities.length > 0 && (
                <div>
                  <div className="mb-1 font-mono text-3xs uppercase tracking-wider text-ink-faint">
                    PARSED ENTITY VECTORS
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {entities.map((ent, i) => (
                      <div key={i} className="rounded border border-border/80 bg-panel-dock p-2">
                        <span className="font-mono text-3xs text-ink-faint">{ent.label}</span>
                        <div className="font-mono text-xs font-bold text-ink mt-0.5 truncate">
                          {ent.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Relevance breakdown */}
              {item.relevance_score != null && (
                <div className="rounded border border-border bg-panel-dock p-3">
                  <div className="flex items-center justify-between font-mono text-3xs text-ink-faint">
                    <span>VECTOR SIMILARITY / RELEVANCE</span>
                    <span className="font-bold text-ink">
                      {Math.round(item.relevance_score * 100)}% MATCH
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 w-full rounded-full bg-border overflow-hidden">
                    <div
                      className="h-full bg-accent transition-all duration-500"
                      style={{ width: `${Math.round(item.relevance_score * 100)}%` }}
                    />
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Raw JSON View */
            <div className="rounded border border-border bg-base p-3">
              <pre className="overflow-x-auto font-mono text-3xs leading-relaxed text-ink-muted">
                {JSON.stringify(
                  {
                    document_id: documentId,
                    classification,
                    stance: item.stance,
                    relevance_score: item.relevance_score,
                    statement: item.statement,
                    audit_digest: pseudoHash,
                    status: "VERIFIED_TAMPER_EVIDENT",
                  },
                  null,
                  2
                )}
              </pre>
            </div>
          )}

          {/* Statutory Audit Record Digest */}
          <div className="rounded border border-border bg-panel-dock p-3">
            <div className="flex items-center justify-between font-mono text-3xs text-ink-faint">
              <span>STATUTORY AUDIT DIGEST</span>
              <button
                onClick={copyHash}
                className="inline-flex items-center gap-1 text-accent hover:underline"
              >
                {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                <span>{copied ? "COPIED" : "COPY"}</span>
              </button>
            </div>
            <div className="mt-1 font-mono text-3xs text-ink-muted break-all select-all">
              {pseudoHash}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-border bg-panel-raised px-5 py-3 font-mono text-3xs text-ink-faint flex items-center justify-between">
          <span>ATTESTATION AUTHORITY: SENTINEL-V2</span>
          <span>IMMUTABLE EVIDENCE DOCK</span>
        </div>
      </aside>
    </>
  );
}
