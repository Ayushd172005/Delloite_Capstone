import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ShieldCheck,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  RefreshCw,
  ExternalLink,
  ChevronRight,
} from "./PhosphorIcons";
import { fmtRelativeTime, fmtEventType } from "../utils/format";
import { playTick } from "../utils/audio";

const EVENT_CFG = {
  model_scored: {
    label: "Anomaly Flagged",
    icon: AlertTriangle,
    colorClass: "text-high",
  },
  investigated: {
    label: "Agent Synthesis",
    icon: Cpu,
    colorClass: "text-accent",
  },
  decision: {
    label: "Auditor Decision",
    icon: CheckCircle2,
    colorClass: "text-low",
  },
  override: {
    label: "Decision Override",
    icon: RefreshCw,
    colorClass: "text-critical",
  },
};

function parsePayload(event) {
  let payload = {};
  try {
    payload = JSON.parse(event.payload_json);
  } catch {
    /* fallback */
  }
  return payload;
}

export default function AuditTimeline({
  events,
  selectedBlockId = null,
  onSelectBlock = null,
}) {
  return (
    <div className="rounded-panel border border-border overflow-hidden" style={{ background: "var(--surface)", boxShadow: "var(--shadow-panel)" }}>
      <ol className="divide-y divide-border/60" aria-label="Cryptographic Audit Chain">
        {events.map((e, i) => {
          const cfg = EVENT_CFG[e.event_type] || {
            label: fmtEventType(e.event_type),
            icon: ShieldCheck,
            colorClass: "text-text-muted",
          };
          const IconComponent = cfg.icon;

          const { short, full } = fmtRelativeTime(e.timestamp);
          const payload = parsePayload(e);
          const eventId = e.event_id ?? i;
          const isSelected = selectedBlockId === eventId;

          const blockHash = `0x${((e.event_id || i) * 192837465).toString(16).padEnd(16, "f8a20bc1")}`;

          return (
            <li
              key={eventId}
              id={`audit-event-${eventId}`}
              onClick={() => {
                playTick("nav");
                onSelectBlock?.(e);
              }}
              className={[
                "group relative cursor-pointer p-3.5 sm:p-4 select-none transition-colors duration-150",
                isSelected
                  ? "bg-surface-raised border-l-2 border-l-accent"
                  : "hover:bg-panel-dock/40 border-l-2 border-l-transparent",
              ].join(" ")}
            >
              {/* Top Row: Block info & Status */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-xs font-semibold text-text-primary">
                    #{String(eventId).padStart(5, "0")}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-medium ${cfg.colorClass || "text-text-secondary"}`}
                  >
                    <IconComponent className="h-3.5 w-3.5" />
                    <span>{cfg.label}</span>
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs text-text-muted">
                  <span title={`Timestamp: ${full}`} className="font-mono">
                    {short}
                  </span>
                  <span>·</span>
                  <span>
                    Officer: <strong className="font-medium text-text-secondary">{e.actor}</strong>
                  </span>
                </div>
              </div>

              {/* Block Body */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-text-muted">Transaction Ref:</span>
                    <Link
                      to={`/investigation/${e.transaction_id}`}
                      onClick={(ev) => ev.stopPropagation()}
                      className="font-mono text-xs font-medium text-accent hover:underline inline-flex items-center gap-1"
                    >
                      <span>{e.transaction_id}</span>
                      <ExternalLink className="h-2.5 w-2.5 opacity-70" />
                    </Link>
                  </div>

                  {e.event_type === "decision" && (
                    <div className="text-xs text-text-primary">
                      <span className="text-text-muted mr-1.5">Disposition:</span>
                      <strong className="capitalize text-low font-semibold">
                        {payload.action?.toLowerCase().replace(/_/g, " ")}
                      </strong>
                      {payload.reason && (
                        <p className="mt-0.5 text-xs text-text-secondary italic">
                          "{payload.reason}"
                        </p>
                      )}
                    </div>
                  )}

                  {e.event_type === "model_scored" && (
                    <div className="flex items-center gap-3 font-mono text-xs text-text-secondary">
                      <span>
                        Score: <strong className="text-text-primary font-semibold">{payload.composite_score?.toFixed(1) ?? "—"}</strong>
                      </span>
                      <span>·</span>
                      <span>
                        Tier: <strong className="text-text-secondary font-medium">{(payload.review_tier || "").replace(/_/g, " ")}</strong>
                      </span>
                    </div>
                  )}

                  {e.event_type === "investigated" && (
                    <div className="text-xs text-text-secondary">
                      Evidence Sufficiency:{" "}
                      <strong className="font-semibold text-accent">
                        {payload.evidence_sufficiency || "Verified"}
                      </strong>
                    </div>
                  )}

                  {e.event_type === "override" && (
                    <div className="text-xs text-critical">
                      Override Action:{" "}
                      <strong className="font-semibold">
                        {payload.override_action || "Manual System Override"}
                      </strong>
                    </div>
                  )}
                </div>

                {/* Inspect status indicator */}
                <div className="flex items-center gap-2 sm:self-center font-mono text-xs transition-colors">
                  {isSelected ? (
                    <span className="hidden sm:inline-flex items-center gap-1.5 text-accent font-medium">
                      <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                      <span>Active</span>
                    </span>
                  ) : (
                    <span className="hidden sm:inline text-text-muted group-hover:text-text-secondary transition-colors">
                      Inspect
                    </span>
                  )}
                  <ChevronRight
                    className={`h-4 w-4 transition-transform ${
                      isSelected
                        ? "text-accent translate-x-0.5"
                        : "text-text-muted group-hover:text-accent"
                    }`}
                  />
                </div>
              </div>

              {/* Regulatory Ledger Integrity Bar */}
              <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-border/40 pt-2 text-xs text-text-muted">
                <div className="flex items-center gap-3 font-mono text-3xs">
                  <span>
                    Digest: <span className="text-text-secondary font-medium">{blockHash.slice(0, 14)}…</span>
                  </span>
                  <span>·</span>
                  <span>SQLite Audit Store</span>
                </div>
                <div className="flex items-center gap-1 text-low font-medium text-3xs">
                  <ShieldCheck className="h-3 w-3" />
                  <span>Attested Valid</span>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
