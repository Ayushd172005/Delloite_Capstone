/**
 * RiskBadge — severity + score, always paired, never standalone.
 *
 * Shows: [colored dot] [severity label] [score number]
 * Example: ● Critical 93
 *
 * Props:
 *   level   — "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" (explicit)
 *   tier    — API tier string (mapped to level if level not provided)
 *   score   — numeric composite score (0-100)
 *   size    — "xs" | "sm" | "md" (default)
 *   showScore — boolean, default true
 */

const LEVELS = {
  LOW: {
    label: "Low",
    textColor: "var(--risk-success)",
    bgColor:   "var(--risk-success-bg)",
    border:    "var(--risk-success-border)",
    dot:       "var(--risk-success)",
  },
  MEDIUM: {
    label: "Medium",
    textColor: "var(--risk-warning)",
    bgColor:   "var(--risk-warning-bg)",
    border:    "var(--risk-warning-border)",
    dot:       "var(--risk-warning)",
  },
  HIGH: {
    label: "High",
    textColor: "var(--color-risk-high)",
    bgColor:   "var(--color-risk-high-bg)",
    border:    "var(--color-risk-high-border)",
    dot:       "var(--color-risk-high)",
  },
  CRITICAL: {
    label: "Critical",
    textColor: "var(--risk-critical)",
    bgColor:   "var(--risk-critical-bg)",
    border:    "var(--risk-critical-border)",
    dot:       "var(--risk-critical)",
  },
};

const TIER_TO_LEVEL = {
  standard_review:      "LOW",
  priority_review:      "MEDIUM",
  immediate_escalation: "CRITICAL",
};

function scoreToLevel(score) {
  const s = Number(score ?? 0);
  if (s >= 85) return "CRITICAL";
  if (s >= 70) return "HIGH";
  if (s >= 50) return "MEDIUM";
  return "LOW";
}

export default function RiskBadge({ level, tier, score, size = "md", showScore = true }) {
  const resolved = level || TIER_TO_LEVEL[tier] || (score != null ? scoreToLevel(score) : "LOW");
  const cfg = LEVELS[resolved] || LEVELS.LOW;

  const sizeClass =
    size === "xs" ? "px-1.5 py-0.5 gap-1 text-xs" :
    size === "sm" ? "px-2 py-0.5 gap-1 text-xs font-semibold" :
                   "px-2.5 py-1 gap-1.5 text-xs font-bold";

  const dotSize = size === "xs" ? "h-1.5 w-1.5" : "h-2 w-2";

  return (
    <span
      className={`inline-flex items-center rounded-badge font-mono font-medium tracking-tight ${sizeClass}`}
      style={{
        color:      cfg.textColor,
        background: cfg.bgColor,
        border:     `1px solid ${cfg.border}`,
      }}
    >
      <span
        className={`shrink-0 rounded-full ${dotSize}`}
        style={{ background: cfg.dot }}
        aria-hidden
      />
      <span>{cfg.label}</span>
      {showScore && score != null && (
        <span className="tabular-nums opacity-90 font-bold">{Math.round(score)}</span>
      )}
    </span>
  );
}
