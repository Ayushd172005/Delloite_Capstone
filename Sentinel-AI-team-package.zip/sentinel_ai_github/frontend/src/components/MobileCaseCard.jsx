import { useNavigate } from "react-router-dom";
import { ChevronRight, ShieldAlert, ArrowUpRight } from "./PhosphorIcons";
import RiskBadge from "./RiskBadge";
import StatusBadge from "./StatusBadge";
import MentorUseCaseBadge from "./MentorUseCaseBadge";
import SlaBadge from "./SlaBadge";
import { useCurrency } from "../context/CurrencyContext";
import { fmtVertical, rulesTriggeredToUseCase } from "../utils/format";
import { compactCaseId } from "../utils/caseId";
import { playTick } from "../utils/audio";

export default function MobileCaseCard({
  row,
  isSelected = false,
  onToggleSelect,
  isActive = false,
}) {
  const navigate = useNavigate();
  const { formatAmount } = useCurrency();

  const handleCardClick = () => {
    playTick("nav");
    navigate(`/investigation/${row.transaction_id}`);
  };

  const handleCheckboxClick = (e) => {
    e.stopPropagation();
    playTick("toggle");
    onToggleSelect?.(row.transaction_id);
  };

  const s = Math.min(100, Math.max(0, Number(row.composite_score || 0)));
  const barColor =
    s >= 85 ? "var(--risk-critical)" :
    s >= 70 ? "var(--color-risk-high)" :
    s >= 50 ? "var(--risk-warning)" :
              "var(--risk-success)";

  const typologyLabel = row.use_case
    ? null
    : row.rules_triggered?.length > 0
    ? rulesTriggeredToUseCase(row.rules_triggered)
    : null;

  return (
    <div
      onClick={handleCardClick}
      className={`group relative rounded-xl border p-3.5 transition-all duration-150 select-none cursor-pointer active:scale-[0.99] focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-canvas ${
        isSelected
          ? "border-accent bg-accent/5 shadow-sm"
          : isActive
          ? "border-accent/60 bg-surface-raised shadow-xs"
          : "border-divider bg-surface hover:border-accent/40 hover:bg-surface-raised shadow-xs"
      }`}
      style={{
        background: isSelected ? "color-mix(in srgb, var(--accent) 8%, var(--surface))" : undefined,
      }}
      role="button"
      tabIndex={0}
      aria-label={`Case ${row.transaction_id}, Amount ${formatAmount(row.amount)}, Risk Score ${row.composite_score}`}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleCardClick();
        }
      }}
    >
      {/* ── Card Header: Checkbox + ID + Vertical + SLA ── */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            onClick={handleCheckboxClick}
            className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-divider hover:border-accent transition-colors bg-surface-raised"
            style={{
              borderColor: isSelected ? "var(--accent)" : undefined,
              background: isSelected ? "var(--accent)" : undefined,
            }}
            role="checkbox"
            aria-checked={isSelected}
            aria-label={`Select case ${row.transaction_id}`}
          >
            {isSelected && (
              <span className="text-white text-xs font-bold leading-none">✓</span>
            )}
          </div>
          <span
            className="font-mono text-xs font-bold tracking-tight text-text-primary truncate"
            title={row.transaction_id}
          >
            {compactCaseId(row.transaction_id)}
          </span>
          {row.vertical && (
            <span className="font-mono text-3xs font-semibold px-1.5 py-0.5 rounded-badge bg-surface-subtle text-text-secondary border border-divider/80 shrink-0">
              {fmtVertical(row.vertical)}
            </span>
          )}
        </div>

        <div className="shrink-0 flex items-center gap-1.5">
          {row.auditor_decision ? (
            <StatusBadge status={row.auditor_decision} size="sm" />
          ) : (
            row.sla_remaining_seconds != null && (
              <SlaBadge remainingSeconds={row.sla_remaining_seconds} />
            )
          )}
        </div>
      </div>

      {/* ── Middle: Amount & Typology ── */}
      <div className="mt-2.5 flex items-baseline justify-between gap-2">
        <div>
          <div className="font-mono text-base font-bold tracking-tight text-text-primary">
            {formatAmount(row.amount)}
          </div>
          <div className="font-mono text-3xs text-text-muted mt-0.5">
            {row.originator_account ? `Acct ··${String(row.originator_account).slice(-4)}` : "Primary Account"}
          </div>
        </div>

        <div className="text-right">
          {row.use_case ? (
            <MentorUseCaseBadge useCase={row.use_case} size="sm" />
          ) : typologyLabel ? (
            <span className="inline-block font-mono text-2xs px-2 py-0.5 rounded-badge bg-surface-subtle text-text-secondary border border-divider/60 font-medium">
              {typologyLabel}
            </span>
          ) : (
            <span className="font-mono text-2xs text-text-muted">—</span>
          )}
        </div>
      </div>

      {/* ── Footer: Risk Score & Action Indicator ── */}
      <div
        className="mt-3 pt-2.5 border-t flex items-center justify-between gap-2"
        style={{ borderColor: "var(--divider)" }}
      >
        <div className="flex items-center gap-2">
          <RiskBadge score={row.composite_score} tier={row.review_tier} size="sm" />
          <div className="flex items-center gap-1">
            <div
              className="h-1.5 w-12 rounded-full overflow-hidden bg-divider/80"
              role="presentation"
            >
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{ width: `${s}%`, background: barColor }}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 font-mono text-2xs text-accent font-semibold group-hover:translate-x-0.5 transition-transform">
          <span>Review</span>
          <ChevronRight className="h-3.5 w-3.5" />
        </div>
      </div>
    </div>
  );
}
