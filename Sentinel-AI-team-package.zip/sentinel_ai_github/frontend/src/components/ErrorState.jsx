import { AlertCircle, RefreshCw } from "./PhosphorIcons";

/**
 * ErrorState — local, actionable error with retry + last success timestamp.
 * Not generic "something went wrong".
 */
export default function ErrorState({ title, message, onRetry, lastFreshAt }) {
  const lastSuccessLabel = (() => {
    if (!lastFreshAt) return null;
    const diffSec = Math.floor((Date.now() - lastFreshAt) / 1000);
    if (diffSec < 60) return `Last successful: ${diffSec}s ago`;
    return `Last successful: ${Math.floor(diffSec / 60)}m ago`;
  })();

  return (
    <div
      className="flex flex-col items-center justify-center py-14 text-center"
    >
      <div
        className="flex h-12 w-12 items-center justify-center rounded-full mb-4"
        style={{
          background: "var(--risk-critical-bg)",
          border: "1px solid var(--risk-critical-border)",
        }}
      >
        <AlertCircle className="h-5 w-5" style={{ color: "var(--risk-critical)" }} aria-hidden />
      </div>

      <div
        className="font-mono text-sm font-semibold"
        style={{ color: "var(--risk-critical)" }}
      >
        {title}
      </div>

      {message && (
        <div className="mt-2 max-w-md font-mono text-2xs" style={{ color: "var(--text-secondary)" }}>
          {message}
        </div>
      )}

      {lastSuccessLabel && (
        <div className="mt-1 font-mono text-meta-xs" style={{ color: "var(--text-muted)" }}>
          {lastSuccessLabel}
        </div>
      )}

      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 flex items-center gap-2 rounded-control px-4 py-1.5 font-mono text-2xs font-semibold transition-colors"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--divider)",
            color: "var(--text-primary)",
          }}
        >
          <RefreshCw className="h-3 w-3" aria-hidden />
          <span>Try again</span>
        </button>
      )}
    </div>
  );
}
