import { useState } from "react";
import { ShieldAlert, CheckCircle2, Download, X, Loader2, Sparkles } from "./PhosphorIcons";
import { useCurrency } from "../context/CurrencyContext";
import { playTick } from "../utils/audio";

export default function BatchActionDock({
  selectedRows,
  onClearSelection,
  onBatchAction,
}) {
  const [loadingAction, setLoadingAction] = useState(null);
  const { formatAmount, currencyCode, convertAmount, isUSD } = useCurrency();

  if (!selectedRows || selectedRows.length === 0) return null;

  const totalAmount = selectedRows.reduce((acc, r) => acc + (Number(r.amount) || 0), 0);

  const handleAction = async (actionType) => {
    setLoadingAction(actionType);
    playTick("toggle");
    try {
      await onBatchAction(actionType, selectedRows);
    } finally {
      setLoadingAction(null);
    }
  };

  const handleExportManifest = () => {
    playTick("nav");
    const manifest = {
      export_timestamp: new Date().toISOString(),
      generator: "Sentinel AI Batch Triage Engine v2.0",
      total_cases: selectedRows.length,
      total_amount_inr: totalAmount,
      total_amount_converted: convertAmount(totalAmount),
      active_currency: currencyCode,
      exchange_rate: isUSD ? "1 USD = 83.00 INR" : "1.0",
      transactions: selectedRows.map((r) => ({
        transaction_id: r.transaction_id,
        vertical: r.vertical,
        amount: r.amount,
        composite_score: r.composite_score,
        review_tier: r.review_tier,
        decision: r.auditor_decision || "PENDING",
      })),
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sentinel_batch_manifest_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom)+10px)] md:bottom-6 left-1/2 -translate-x-1/2 z-40 animate-case-transition select-none w-[calc(100%-1rem)] sm:w-auto max-w-2xl">
      <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 sm:gap-4 rounded-panel border border-accent/40 bg-panel px-3 py-2.5 sm:px-5 sm:py-3 shadow-2xl backdrop-blur-md specular-card">
        {/* Count & Amount Info */}
        <div className="flex items-center gap-2.5 sm:gap-3 border-r border-border pr-2.5 sm:pr-4 shrink-0">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-accent text-panel font-mono text-xs font-bold">
            {selectedRows.length}
          </span>
          <div>
            <div className="text-xs font-bold text-ink">
              <span className="hidden sm:inline">{selectedRows.length === 1 ? "1 Case Selected" : `${selectedRows.length} Cases Selected`}</span>
              <span className="inline sm:hidden">{selectedRows.length} Selected</span>
            </div>
            <div className="font-mono text-3xs text-ink-muted">
              Total: <span className="font-semibold text-accent">{formatAmount(totalAmount)}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-1 sm:flex-initial justify-end">
          {/* Batch Escalate */}
          <button
            disabled={loadingAction !== null}
            onClick={() => handleAction("ESCALATE")}
            className="flex items-center gap-1 sm:gap-1.5 rounded-lg bg-critical/15 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-critical border border-critical/30 hover:bg-critical/25 transition-all disabled:opacity-50 shadow-xs"
          >
            {loadingAction === "ESCALATE" ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <ShieldAlert className="h-3.5 w-3.5" />
            )}
            <span className="hidden sm:inline">Batch Escalate (SAR)</span>
            <span className="inline sm:hidden">Escalate</span>
          </button>

          {/* Batch Clear */}
          <button
            disabled={loadingAction !== null}
            onClick={() => handleAction("DISMISS")}
            className="flex items-center gap-1 sm:gap-1.5 rounded-lg bg-low/15 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-low border border-low/30 hover:bg-low/25 transition-all disabled:opacity-50 shadow-xs"
          >
            {loadingAction === "DISMISS" ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <CheckCircle2 className="h-3.5 w-3.5" />
            )}
            <span className="hidden sm:inline">Batch Clear</span>
            <span className="inline sm:hidden">Clear</span>
          </button>

          {/* Export Manifest */}
          <button
            onClick={handleExportManifest}
            className="hidden sm:flex items-center gap-1.5 rounded-lg border border-border bg-panel-dock px-3 py-1.5 text-xs font-medium text-ink-muted hover:border-accent hover:text-ink transition-all shadow-xs"
            title="Download cryptographically verifiable batch manifest"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export</span>
          </button>
        </div>

        {/* Dismiss selection */}
        <button
          onClick={() => {
            playTick("toggle");
            onClearSelection();
          }}
          className="rounded p-1 text-ink-muted hover:bg-panel-dock hover:text-ink transition-colors shrink-0 focus-visible:outline-none"
          title="Clear selection (Esc)"
          aria-label="Clear selected cases"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
