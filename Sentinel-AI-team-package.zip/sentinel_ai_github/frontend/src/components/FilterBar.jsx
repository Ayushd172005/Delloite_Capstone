import { useRef } from "react";
import { MagnifyingGlass, ArrowsClockwise, X, Faders } from "@phosphor-icons/react";
import { playTick } from "../utils/audio";
import RiskDistributionStrip from "./RiskDistributionStrip";
import { useCurrency } from "../context/CurrencyContext";

const VERTICALS = ["retail", "corporate", "aml"];
const TIERS = [
  { value: "standard_review",     label: "Standard" },
  { value: "priority_review",     label: "Priority" },
  { value: "immediate_escalation",label: "Escalation" },
];

function fmtVerticalLabel(v) {
  if (v.toLowerCase() === "aml") return "AML";
  return v.charAt(0).toUpperCase() + v.slice(1).toLowerCase();
}

function FilterPill({ active, onClick, children }) {
  return (
    <button
      onClick={() => { playTick("toggle"); onClick(); }}
      aria-pressed={active}
      className={[
        "relative flex items-center rounded-badge px-2.5 py-1 text-xs font-sans font-medium transition-all duration-100 whitespace-nowrap",
        active
          ? "font-semibold"
          : "text-text-muted hover:text-text-primary",
      ].join(" ")}
      style={active ? {
        background: "var(--accent-dim)",
        color: "var(--accent)",
        border: "1px solid color-mix(in srgb, var(--accent) 30%, transparent)",
      } : {
        background: "transparent",
        border: "1px solid transparent",
      }}
    >
      {active && (
        <span
          className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-accent align-middle shrink-0"
          aria-hidden
        />
      )}
      {children}
    </button>
  );
}

export default function FilterBar({
  search,
  onSearch,
  vertical,
  onVertical,
  tier,
  onTier,
  amountLimit,
  onAmountLimit,
  onRefresh,
  refreshing,
  lastRefreshedAt = null,
  density,
  onDensityChange,
  activeRiskBin,
  onSelectRiskBin,
  rows = [],
}) {
  const { isUSD } = useCurrency();
  const searchRef = useRef(null);
  const activeFilterCount = [vertical, tier, amountLimit, activeRiskBin].filter(Boolean).length;
  const hasActiveFilters = activeFilterCount > 0 || search.trim().length > 0;

  const clearAll = () => {
    onSearch("");
    onVertical(null);
    onTier(null);
    onAmountLimit?.(null);
    onSelectRiskBin?.(null);
    playTick("toggle");
  };

  const lastRefreshedLabel = (() => {
    if (!lastRefreshedAt) return null;
    const diffSec = Math.floor((Date.now() - lastRefreshedAt) / 1000);
    if (diffSec < 60) return `${diffSec}s ago`;
    return `${Math.floor(diffSec / 60)}m ago`;
  })();

  return (
    <div
      style={{
        background: "var(--surface)",
        borderBottom: "1px solid var(--divider)",
      }}
    >
      {/* ── Main filter row ── */}
      <div className="flex flex-wrap items-center gap-x-3 sm:gap-x-4 gap-y-2 px-3 sm:px-5 py-2.5">
        {/* Search */}
        <div className="relative w-full sm:w-56 shrink-0">
          <MagnifyingGlass
            className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-text-muted"
            weight="bold"
            aria-hidden
          />
          <input
            ref={searchRef}
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search transaction ID…"
            aria-label="Search transactions by ID"
            className="w-full rounded-control py-1.5 pl-8 pr-8 text-xs font-sans text-text-primary placeholder:text-text-muted focus:outline-none"
            style={{
              background: "var(--surface-subtle)",
              border: "1px solid var(--divider)",
            }}
            onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
            onBlur={(e) => (e.target.style.borderColor = "var(--divider)")}
          />
          {search && (
            <button
              onClick={() => { onSearch(""); searchRef.current?.focus(); }}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
              aria-label="Clear search"
            >
              <X className="h-3.5 w-3.5" weight="bold" aria-hidden />
            </button>
          )}
        </div>

        {/* Divider */}
        <span className="hidden sm:inline h-4 w-px bg-divider" aria-hidden />

        {/* Vertical filter group */}
        <fieldset className="flex items-center gap-0.5 overflow-x-auto max-w-full pb-0.5 sm:pb-0 scrollbar-none">
          <legend className="sr-only">Filter by vertical</legend>
          <span className="mr-1.5 text-[11px] font-semibold text-text-muted uppercase tracking-wider font-sans shrink-0">
            Vertical
          </span>
          <FilterPill active={!vertical} onClick={() => onVertical(null)}>All</FilterPill>
          {VERTICALS.map((v) => (
            <FilterPill key={v} active={vertical === v} onClick={() => onVertical(v)}>
              {fmtVerticalLabel(v)}
            </FilterPill>
          ))}
        </fieldset>

        {/* Divider */}
        <span className="hidden sm:inline h-4 w-px bg-divider" aria-hidden />

        {/* Tier filter group */}
        <fieldset className="flex items-center gap-0.5 overflow-x-auto max-w-full pb-0.5 sm:pb-0 scrollbar-none">
          <legend className="sr-only">Filter by SLA tier</legend>
          <span className="mr-1.5 text-[11px] font-semibold text-text-muted uppercase tracking-wider font-sans shrink-0">
            Tier
          </span>
          <FilterPill active={!tier} onClick={() => onTier(null)}>All</FilterPill>
          {TIERS.map((t) => (
            <FilterPill key={t.value} active={tier === t.value} onClick={() => onTier(t.value)}>
              {t.label}
            </FilterPill>
          ))}
        </fieldset>

        {/* Divider */}
        <span className="hidden sm:inline h-4 w-px bg-divider" aria-hidden />

        {/* Amount Limit filter group */}
        <fieldset className="flex items-center gap-0.5 overflow-x-auto max-w-full pb-0.5 sm:pb-0 scrollbar-none">
          <legend className="sr-only">Filter by amount threshold</legend>
          <span className="mr-1.5 text-[11px] font-semibold text-text-muted uppercase tracking-wider font-sans shrink-0">
            Amount
          </span>
          <FilterPill active={!amountLimit} onClick={() => onAmountLimit?.(null)}>
            All
          </FilterPill>
          <FilterPill
            active={amountLimit === "high_value"}
            onClick={() => onAmountLimit?.(amountLimit === "high_value" ? null : "high_value")}
          >
            {isUSD ? "≥ $1.2K" : "≥ ₹1.0L"}
          </FilterPill>
          <FilterPill
            active={amountLimit === "statutory_limit"}
            onClick={() => onAmountLimit?.(amountLimit === "statutory_limit" ? null : "statutory_limit")}
          >
            {isUSD ? "≥ $3.0K" : "≥ ₹2.5L"}
          </FilterPill>
        </fieldset>

        {/* Divider */}
        <span className="hidden md:inline h-4 w-px bg-divider" aria-hidden />

        {/* Density toggle (Desktop only) */}
        <div
          className="hidden md:flex items-center rounded-control p-0.5"
          style={{ background: "var(--surface-subtle)", border: "1px solid var(--divider)" }}
          role="group"
          aria-label="Row density"
        >
          <button
            onClick={() => { playTick("toggle"); onDensityChange?.("standard"); }}
            className={`rounded px-2 py-0.5 text-xs font-sans font-medium transition-colors ${
              density === "standard"
                ? "bg-surface-raised text-text-primary shadow-xs font-semibold"
                : "text-text-muted hover:text-text-primary"
            }`}
            aria-pressed={density === "standard"}
          >
            Standard
          </button>
          <button
            onClick={() => { playTick("toggle"); onDensityChange?.("compact"); }}
            className={`rounded px-2 py-0.5 text-xs font-sans font-medium transition-colors ${
              density === "compact"
                ? "bg-surface-raised text-text-primary shadow-xs font-semibold"
                : "text-text-muted hover:text-text-primary"
            }`}
            aria-pressed={density === "compact"}
          >
            Compact
          </button>
        </div>

        {/* Active filter count + clear all */}
        {hasActiveFilters && (
          <div className="flex items-center gap-2 ml-1">
            <span
              className="flex items-center gap-1 rounded-badge px-2 py-0.5 text-xs font-sans font-medium"
              style={{
                background: "var(--accent-dim)",
                color: "var(--accent)",
                border: "1px solid color-mix(in srgb, var(--accent) 25%, transparent)",
              }}
            >
              <Faders className="h-3 w-3" weight="bold" aria-hidden />
              {activeFilterCount > 0 ? `${activeFilterCount} filter${activeFilterCount > 1 ? "s" : ""}` : "Search active"}
            </span>
            <button
              onClick={clearAll}
              className="text-xs font-sans text-text-muted underline decoration-dotted underline-offset-2 hover:text-text-primary transition-colors cursor-pointer"
            >
              Clear
            </button>
          </div>
        )}

        {/* Spacer */}
        <div className="flex-1" />

        {/* Refresh */}
        <button
          onClick={onRefresh}
          disabled={refreshing}
          className="flex items-center gap-1.5 rounded-control px-3 py-1.5 text-xs font-sans font-medium text-text-secondary transition-colors hover:text-text-primary hover:bg-surface-subtle disabled:opacity-50 border border-divider bg-surface shadow-xs"
          aria-label="Refresh queue"
          title={lastRefreshedLabel ? `Last refreshed ${lastRefreshedLabel}` : "Refresh queue"}
        >
          <ArrowsClockwise
            className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`}
            weight="bold"
            aria-hidden
          />
          <span>{refreshing ? "Refreshing…" : "Refresh"}</span>
          {lastRefreshedLabel && !refreshing && (
            <span className="hidden lg:inline font-mono text-[11px] text-text-muted ml-0.5">
              {lastRefreshedLabel}
            </span>
          )}
        </button>
      </div>

      {/* ── Risk Distribution Strip (compact inline) ── */}
      {rows.length > 0 && (
        <div
          className="px-3 sm:px-5 py-2.5 border-t border-divider"
        >
          <RiskDistributionStrip
            rows={rows}
            activeBin={activeRiskBin}
            onSelectBin={onSelectRiskBin}
          />
        </div>
      )}
    </div>
  );
}
