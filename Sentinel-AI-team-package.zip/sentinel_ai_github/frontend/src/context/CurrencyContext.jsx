import { createContext, useContext, useState, useMemo } from "react";

// Institutional FX conversion peg: 1 USD = 83.00 INR (or 1 INR = 1 / 83 USD)
export const USD_TO_INR_RATE = 83.0;

const CurrencyContext = createContext(null);

export function CurrencyProvider({ children }) {
  const [currency, setCurrencyState] = useState(() => {
    const saved = localStorage.getItem("sentinel-currency");
    // Normalize saved value: "usd" or legacy "intl" -> "usd", otherwise "in"
    if (saved === "intl" || saved === "usd") return "usd";
    return "in";
  });

  const toggle = () => {
    setCurrencyState((curr) => {
      const next = curr === "in" ? "usd" : "in";
      localStorage.setItem("sentinel-currency", next);
      return next;
    });
  };

  const setCurrency = (c) => {
    const next = c === "usd" || c === "intl" ? "usd" : "in";
    localStorage.setItem("sentinel-currency", next);
    setCurrencyState(next);
  };

  const isUSD = currency === "usd";
  const isINR = currency === "in";
  const symbol = isUSD ? "$" : "₹";
  const currencyCode = isUSD ? "USD" : "INR";
  const localeLabel = isUSD ? "$ USD" : "₹ IN";
  const locale = isUSD ? "usd" : "in"; // backward compatibility for components reading `locale`

  // Convert raw amount (base data in INR) to active currency
  function convertAmount(n) {
    if (n == null || isNaN(Number(n))) return 0;
    const num = Number(n);
    return isUSD ? num / USD_TO_INR_RATE : num;
  }

  // Format amount with currency symbol and appropriate locale separation
  function formatAmount(n, opts = {}) {
    if (n == null || isNaN(Number(n))) return "—";
    const rawNum = Number(n);
    const { showSymbol = true, decimals = 0, convert = true, compact = false } = opts;
    const val = convert ? convertAmount(rawNum) : rawNum;

    if (compact) {
      if (isINR) {
        // Indian compact: Crores (>= 1e7) and Lakhs (>= 1e5)
        if (Math.abs(val) >= 10000000) {
          return `${showSymbol ? "₹" : ""}${(val / 10000000).toFixed(1)} Cr`;
        }
        if (Math.abs(val) >= 100000) {
          return `${showSymbol ? "₹" : ""}${(val / 100000).toFixed(1)}L`;
        }
        return `${showSymbol ? "₹" : ""}${Math.round(val).toLocaleString("en-IN")}`;
      } else {
        // US compact: Millions (>= 1e6) and Thousands (>= 1e3)
        if (Math.abs(val) >= 1000000) {
          return `${showSymbol ? "$" : ""}${(val / 1000000).toFixed(2)}M`;
        }
        if (Math.abs(val) >= 1000) {
          return `${showSymbol ? "$" : ""}${(val / 1000).toFixed(1)}K`;
        }
        return `${showSymbol ? "$" : ""}${Math.round(val).toLocaleString("en-US")}`;
      }
    }

    if (isINR) {
      const formatted = val.toLocaleString("en-IN", {
        maximumFractionDigits: decimals,
        minimumFractionDigits: decimals,
      });
      return showSymbol ? `₹${formatted}` : formatted;
    } else {
      const formatted = val.toLocaleString("en-US", {
        maximumFractionDigits: decimals,
        minimumFractionDigits: decimals,
      });
      return showSymbol ? `$${formatted}` : formatted;
    }
  }

  function formatAmountDecimals(n) {
    return formatAmount(n, { decimals: 2 });
  }

  function formatCompact(n) {
    return formatAmount(n, { compact: true });
  }

  const contextValue = useMemo(
    () => ({
      currency,
      locale,
      isUSD,
      isINR,
      toggle,
      setCurrency,
      formatAmount,
      formatAmountDecimals,
      formatCompact,
      convertAmount,
      symbol,
      currencyCode,
      localeLabel,
      exchangeRate: USD_TO_INR_RATE,
      rateLabel: `1 USD = ₹${USD_TO_INR_RATE.toFixed(2)}`,
    }),
    [currency, isUSD, isINR, locale, symbol, currencyCode, localeLabel]
  );

  return (
    <CurrencyContext.Provider value={contextValue}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error("useCurrency must be used inside CurrencyProvider");
  return ctx;
}

