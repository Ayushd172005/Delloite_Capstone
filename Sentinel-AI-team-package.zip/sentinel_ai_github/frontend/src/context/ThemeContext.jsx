import { createContext, useContext, useEffect, useState, useCallback } from "react";

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    const stored = localStorage.getItem("sentinel-theme");
    if (stored === "dark" || stored === "light") return stored;
    return window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("sentinel-theme", theme);
  }, [theme]);

  const toggle = useCallback((event) => {
    const nextIsDark = theme !== "dark";
    const nextTheme = nextIsDark ? "dark" : "light";

    // If View Transitions API not supported or reduced motion requested, use smooth class transition
    if (
      typeof document.startViewTransition !== "function" ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      document.documentElement.classList.add("theme-switching");
      setTheme(nextTheme);
      setTimeout(() => {
        document.documentElement.classList.remove("theme-switching");
      }, 350);
      return;
    }

    // Precision Technical Blade Sweep:
    // Decoupled from cursor position (no corner bias).
    // Dark → Light: Sweeps Left-to-Right like morning illumination across the workstation.
    // Light → Dark: Sweeps Right-to-Left like the obsidian shield drawing across the glass.
    const isToDark = nextIsDark;

    const startClip = isToDark
      ? "polygon(100% 0%, 100% 0%, 118% 100%, 118% 100%)"
      : "polygon(0% 0%, 0% 0%, -18% 100%, -18% 100%)";

    const endClip = isToDark
      ? "polygon(-20% 0%, 100% 0%, 100% 100%, -2% 100%)"
      : "polygon(0% 0%, 120% 0%, 102% 100%, 0% 100%)";

    const transition = document.startViewTransition(() => {
      setTheme(nextTheme);
      if (nextIsDark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    });

    transition.ready.then(() => {
      // 1. Incoming theme: sweeps across with a 12° angled precision drafting blade
      document.documentElement.animate(
        {
          clipPath: [startClip, endClip],
        },
        {
          duration: 400,
          easing: "cubic-bezier(0.19, 1, 0.22, 1)",
          pseudoElement: "::view-transition-new(root)",
        }
      );

      // 2. Outgoing theme: subtle depth recess & gentle contrast fade
      document.documentElement.animate(
        {
          transform: ["scale(1)", "scale(0.992)"],
          opacity: [1, 0.82],
        },
        {
          duration: 400,
          easing: "cubic-bezier(0.19, 1, 0.22, 1)",
          pseudoElement: "::view-transition-old(root)",
        }
      );
    });
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, toggle, isDark: theme === "dark" }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used inside ThemeProvider");
  return ctx;
}
