import { useState } from "react";
import {
  MagnifyingGlass,
  SpeakerHigh,
  SpeakerSimpleSlash,
  Keyboard,
  Sparkle,
} from "@phosphor-icons/react";
import BrandLogo from "../components/BrandLogo";
import { useSystemStatus } from "../context/SystemStatusContext";
import { useCurrency } from "../context/CurrencyContext";
import ThemeToggle from "../components/ThemeToggle";
import { isSoundEnabled, setSoundEnabled, playTick } from "../utils/audio";

export default function TopBar({ onOpenCommandPalette, onOpenShortcuts, onOpenScorer }) {
  const { isMock, transactionsLoaded } = useSystemStatus();
  const { localeLabel, toggle: toggleCurrency, symbol, rateLabel } = useCurrency();
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  const formattedLoaded =
    transactionsLoaded != null
      ? Number(transactionsLoaded).toLocaleString()
      : null;

  const toggleSound = () => {
    const next = !soundOn;
    setSoundEnabled(next);
    setSoundOn(next);
    if (next) playTick("toggle");
  };

  const handleCurrency = () => {
    playTick("toggle");
    toggleCurrency();
  };

  return (
    <header
      className="flex h-11 shrink-0 items-center justify-between px-3 sm:px-4 select-none bg-surface relative z-20 gap-2 sm:gap-4 border-b"
      style={{ borderColor: "var(--divider)" }}
    >
      {/* ── Left: Mobile brand logo or Desktop telemetry ── */}
      <div className="flex md:hidden items-center gap-2.5 shrink-0">
        <BrandLogo size={22} />
        <span className="font-semibold text-xs tracking-tight text-text-primary font-sans">
          Sentinel AI
        </span>
      </div>

      <div className="hidden md:flex items-center gap-3 shrink-0 text-xs">
        <div className="flex items-center gap-2 text-text-primary">
          <span className="relative flex h-1.5 w-1.5 shrink-0">
            <span
              className={`relative inline-flex h-1.5 w-1.5 rounded-full ${
                isMock ? "bg-warning" : "bg-success"
              }`}
            />
          </span>
          <span className="font-medium text-text-primary font-sans text-xs">
            {isMock ? "Simulation" : "Live review"}
          </span>
        </div>

        {formattedLoaded && (
          <span className="hidden sm:inline-flex items-center gap-1.5 text-text-muted font-sans border-l pl-3 border-divider text-xs">
            <span className="font-mono font-medium text-text-secondary">{formattedLoaded}</span>
            <span>records in queue</span>
          </span>
        )}

        <span className="hidden xl:inline-flex items-center gap-1 text-text-muted text-[11px] font-sans">
          <span className="text-accent font-medium">12ms</span> latency
        </span>
      </div>

      {/* ── Center: Command Bar Trigger ── */}
      <div className="flex-1 max-w-xl mx-1 sm:mx-3 min-w-0">
        <button
          onClick={onOpenCommandPalette}
          className="w-full h-7 sm:h-8 flex items-center justify-between rounded px-2.5 text-xs text-text-muted transition-all hover:text-text-primary hover:border-accent/30 focus:outline-none group bg-surface-subtle border border-divider"
          title="Open Command Center (⌘K)"
          aria-label="Open command palette"
        >
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <MagnifyingGlass className="h-3.5 w-3.5 text-text-muted shrink-0 group-hover:text-accent transition-colors" weight="bold" aria-hidden />
            <span className="font-sans text-xs text-text-muted group-hover:text-text-secondary transition-colors truncate text-left">
              <span className="hidden sm:inline">Search cases, counterparties, typologies…</span>
              <span className="inline sm:hidden">Search cases…</span>
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-0.5 px-1.5 py-0.5 rounded border border-divider bg-surface text-[10px] font-mono text-text-muted">
            <span>⌘K</span>
          </div>
        </button>
      </div>

      {/* ── Right: Consolidated Utility Controls ── */}
      <div className="flex items-center gap-1.5 shrink-0">
        {/* Unified Live Transaction Simulation & ML Pipeline Scorer */}
        <button
          onClick={() => {
            playTick("action");
            if (onOpenScorer) onOpenScorer();
          }}
          className="flex h-7 sm:h-7.5 items-center gap-1.5 rounded px-2.5 text-xs font-sans font-medium text-accent transition-colors hover:bg-accent-dim hover:text-accent-strong cursor-pointer bg-accent-dim border border-accent/20"
          title="Simulate & score transactions with real-time ML ensemble and Sentinel autonomous synthesis"
          aria-label="Simulate & Score Transaction"
        >
          <Sparkle className="h-3 w-3 shrink-0 text-accent" weight="fill" aria-hidden />
          <span className="hidden sm:inline">Simulate & Score</span>
          <span className="inline sm:hidden">Simulate</span>
        </button>

        {/* Currency Switcher */}
        <button
          onClick={handleCurrency}
          className="flex h-7 sm:h-7.5 items-center gap-1.5 rounded px-2 sm:px-2.5 text-xs font-sans text-text-secondary transition-colors hover:text-text-primary hover:bg-surface-subtle border border-divider bg-surface"
          title={`Toggle currency (${localeLabel} · ${rateLabel})`}
          aria-label={`Toggle currency format (${localeLabel})`}
        >
          <span className="font-mono font-bold text-accent text-xs">{symbol}</span>
          <span className="hidden sm:inline font-medium text-text-secondary">{localeLabel}</span>
        </button>

        {/* Shortcuts HUD (Desktop) */}
        <button
          onClick={() => {
            playTick("toggle");
            onOpenShortcuts();
          }}
          className="hidden sm:flex h-7 sm:h-7.5 w-7 sm:w-7.5 items-center justify-center rounded text-text-muted transition-colors hover:text-text-primary focus:outline-none border border-divider bg-surface"
          title="Keyboard shortcuts"
          aria-label="Open keyboard shortcuts reference"
        >
          <Keyboard className="h-3.5 w-3.5" weight="regular" aria-hidden />
        </button>

        {/* Theme toggle */}
        <ThemeToggle variant="icon" />

        {/* Acoustic Haptics toggle (Desktop) */}
        <button
          onClick={toggleSound}
          className="hidden sm:flex h-7 sm:h-7.5 w-7 sm:w-7.5 items-center justify-center rounded text-text-muted transition-colors hover:text-text-primary focus:outline-none border border-divider bg-surface"
          title={soundOn ? "Mute acoustic micro-ticks" : "Enable acoustic micro-ticks"}
          aria-label={soundOn ? "Mute acoustic haptics" : "Enable acoustic haptics"}
          aria-pressed={soundOn}
        >
          {soundOn ? (
            <SpeakerHigh className="h-4 w-4 text-accent" weight="regular" aria-hidden />
          ) : (
            <SpeakerSimpleSlash className="h-4 w-4 text-text-muted" weight="regular" aria-hidden />
          )}
        </button>
      </div>
    </header>
  );
}
