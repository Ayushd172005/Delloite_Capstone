import { useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  ListChecks,
  ClockCounterClockwise,
  Cpu,
  Sun,
  Moon,
  Keyboard,
  WifiHigh,
  WifiSlash,
  ArrowsClockwise,
} from "@phosphor-icons/react";
import BrandLogo from "../components/BrandLogo";
import { useSystemStatus } from "../context/SystemStatusContext";
import { useCurrency } from "../context/CurrencyContext";
import { useTheme } from "../context/ThemeContext";
import { playTick } from "../utils/audio";

const NAV = [
  { to: "/",            label: "Case queue",      icon: ListChecks,             end: true, key: "1" },
  { to: "/audit-trail", label: "Evidence ledger", icon: ClockCounterClockwise,  key: "2" },
  { to: "/model-health",label: "Model health",    icon: Cpu,                    key: "3" },
];

function navClass({ isActive }) {
  return [
    "group flex items-center justify-between rounded px-2.5 py-2 text-xs font-medium transition-colors font-sans",
    isActive
      ? "bg-surface-subtle text-text-primary font-semibold border-l-2 border-accent pl-2"
      : "text-text-secondary hover:bg-surface-subtle hover:text-text-primary border-l-2 border-transparent pl-2",
  ].join(" ");
}

function SystemStatus({ status }) {
  const isOk       = status === "operational";
  const isChecking = status === "checking";

  const dot   = isOk ? "bg-success" : isChecking ? "bg-warning" : "bg-critical";
  const label = isOk ? "Operational" : isChecking ? "Syncing…" : "Disconnected";
  const Icon  = isOk ? WifiHigh : isChecking ? ArrowsClockwise : WifiSlash;
  const color = isOk ? "text-success" : isChecking ? "text-warning" : "text-critical";

  return (
    <div
      className="flex items-center justify-between rounded px-2.5 py-1.5 text-meta-xs border border-divider"
      style={{ background: "var(--surface-subtle)" }}
      role="status"
      aria-label={`System status: ${label}`}
    >
      <div className="flex items-center gap-2 min-w-0">
        <span className="relative flex h-1.5 w-1.5 shrink-0">
          <span className={`relative inline-flex h-1.5 w-1.5 rounded-full ${dot}`} />
        </span>
        <Icon className={`h-3.5 w-3.5 shrink-0 ${color}`} weight="bold" aria-hidden />
        <span className="font-medium truncate text-text-secondary">{label}</span>
      </div>
      <span className="text-text-muted text-[10px] shrink-0 font-medium uppercase tracking-wider">
        Active
      </span>
    </div>
  );
}

export default function Sidebar({ onOpenShortcuts }) {
  const navigate = useNavigate();
  const { status } = useSystemStatus();
  const { localeLabel, toggle: toggleCurrency, symbol, rateLabel } = useCurrency();
  const { isDark, toggle: toggleTheme } = useTheme();

  // Global keyboard navigation
  useEffect(() => {
    function handleKeyDown(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
      if (e.metaKey || e.ctrlKey) return;

      if (e.key === "1") { e.preventDefault(); playTick("toggle"); navigate("/"); }
      else if (e.key === "2") { e.preventDefault(); playTick("toggle"); navigate("/audit-trail"); }
      else if (e.key === "3") { e.preventDefault(); playTick("toggle"); navigate("/model-health"); }
      else if (e.key === "c" || e.key === "C") { e.preventDefault(); playTick("toggle"); toggleCurrency(); }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [navigate, toggleCurrency]);

  return (
    <aside
      className="hidden md:flex h-full w-56 shrink-0 flex-col border-r bg-surface select-none"
      style={{ borderColor: "var(--divider)" }}
      aria-label="Primary navigation"
    >
      {/* ── Brand Header ─────────────────────────────────── */}
      <div
        className="flex items-center gap-2.5 px-4 py-3 border-b h-11 shrink-0"
        style={{ borderColor: "var(--divider)" }}
      >
        <BrandLogo size={22} />
        <div className="min-w-0 flex items-baseline gap-1.5">
          <span className="text-xs font-semibold tracking-tight text-text-primary font-sans">
            Sentinel
          </span>
          <span className="font-mono text-[10px] text-text-muted">
            v2.0
          </span>
        </div>
      </div>

      {/* ── Navigation ───────────────────────────────────── */}
      <nav className="flex-1 px-2.5 py-3 space-y-0.5" aria-label="Main Navigation">
        <div className="px-2 pt-1 pb-2 text-[10px] font-semibold text-text-muted uppercase tracking-wider font-sans">
          Review spaces
        </div>
        {NAV.map(({ to, label, icon: Icon, end, key }) => (
          <NavLink key={to} to={to} end={end} className={navClass}>
            <div className="flex items-center gap-2">
              <Icon className="h-3.5 w-3.5 shrink-0 text-text-muted group-[.active]:text-accent" weight="regular" aria-hidden />
              <span>{label}</span>
            </div>
            <span className="font-mono text-[10px] text-text-muted/60 group-hover:text-text-muted">{key}</span>
          </NavLink>
        ))}
      </nav>

      {/* ── Bottom Controls ──────────────────────────────── */}
      <div
        className="border-t px-3 py-3 space-y-1"
        style={{ borderColor: "var(--divider)" }}
        role="group"
        aria-label="Global preferences"
      >
        {/* Theme toggle */}
        <button
          onClick={(e) => { playTick("toggle"); toggleTheme(e); }}
          className="flex w-full items-center justify-between rounded-control px-3 py-2 text-xs font-sans text-text-secondary transition-colors hover:bg-surface hover:text-text-primary"
          aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
          title={isDark ? "Switch to light mode" : "Switch to dark mode"}
        >
          <div className="flex items-center gap-2.5">
            {isDark
              ? <Sun className="h-4 w-4 shrink-0 text-accent" weight="regular" aria-hidden />
              : <Moon className="h-4 w-4 shrink-0 text-accent" weight="regular" aria-hidden />
            }
            <span>{isDark ? "Studio Light" : "Drafting Dark"}</span>
          </div>
        </button>

        {/* Currency toggle */}
        <button
          onClick={() => { playTick("toggle"); toggleCurrency(); }}
          className="flex w-full items-center justify-between rounded-control px-3 py-2 text-xs font-sans text-text-secondary transition-colors hover:bg-surface hover:text-text-primary"
          aria-label={`Toggle currency. Current: ${localeLabel} (${rateLabel})`}
          title={`Currency: ${localeLabel} (${rateLabel})`}
        >
          <div className="flex items-center gap-2.5">
            <span className="font-mono font-bold text-accent w-4 text-center text-xs" aria-hidden>
              {symbol}
            </span>
            <span>Currency: {localeLabel}</span>
          </div>
        </button>

        {/* Shortcuts */}
        <button
          onClick={() => { playTick("toggle"); onOpenShortcuts?.(); }}
          className="flex w-full items-center justify-between rounded-control px-3 py-2 text-xs font-sans text-text-secondary transition-colors hover:bg-surface hover:text-text-primary"
          aria-label="Open keyboard shortcuts reference"
          title="Keyboard shortcuts"
        >
          <div className="flex items-center gap-2.5">
            <Keyboard className="h-4 w-4 text-text-muted" weight="regular" aria-hidden />
            <span>Shortcuts</span>
          </div>
        </button>
      </div>

      {/* ── System Status ────────────────────────────────── */}
      <div
        className="border-t px-3 py-3"
        style={{ borderColor: "var(--divider)" }}
      >
        <SystemStatus status={status} />
      </div>
    </aside>
  );
}
