import { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  ListChecks,
  ClockCounterClockwise,
  Cpu,
  Faders,
  X,
  Sun,
  Moon,
  SpeakerHigh,
  SpeakerSimpleSlash,
  Keyboard,
  WifiHigh,
  WifiSlash,
  ArrowsClockwise,
  CurrencyInr,
} from "@phosphor-icons/react";
import { useSystemStatus } from "../context/SystemStatusContext";
import { useCurrency } from "../context/CurrencyContext";
import { useTheme } from "../context/ThemeContext";
import { isSoundEnabled, setSoundEnabled, playTick } from "../utils/audio";

const NAV_ITEMS = [
  { to: "/", label: "Queue", icon: ListChecks, end: true },
  { to: "/audit-trail", label: "Ledger", icon: ClockCounterClockwise },
  { to: "/model-health", label: "Models", icon: Cpu },
];

export default function MobileNavDock({ onOpenShortcuts, onOpenCommandPalette }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { status, transactionsLoaded, isMock } = useSystemStatus();
  const { localeLabel, toggle: toggleCurrency } = useCurrency();
  const { isDark, toggle: toggleTheme } = useTheme();
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  const isOk = status === "operational";
  const isChecking = status === "checking";
  const StatusIcon = isOk ? WifiHigh : isChecking ? ArrowsClockwise : WifiSlash;
  const statusColor = isOk ? "text-success" : isChecking ? "text-warning" : "text-critical";
  const statusLabel = isOk ? "Operational" : isChecking ? "Syncing…" : "Offline";

  const handleSoundToggle = () => {
    const next = !soundOn;
    setSoundEnabled(next);
    setSoundOn(next);
    if (next) playTick("toggle");
  };

  const handleCurrencyToggle = () => {
    playTick("toggle");
    toggleCurrency();
  };

  const handleThemeToggle = () => {
    playTick("toggle");
    toggleTheme();
  };

  return (
    <>
      {/* ── Mobile Bottom Navigation Bar (Dock) ── */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 select-none border-t border-divider backdrop-blur-xl"
        style={{
          background: isDark ? "rgba(22, 25, 28, 0.94)" : "rgba(245, 247, 248, 0.94)",
          paddingBottom: "env(safe-area-inset-bottom, 0px)",
        }}
        aria-label="Mobile Bottom Navigation"
      >
        <div className="flex h-14 items-center justify-around px-2">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={() => playTick("nav")}
              className={({ isActive }) =>
                `flex flex-1 flex-col items-center justify-center py-1 text-2xs font-medium font-sans transition-colors ${
                  isActive
                    ? "text-accent font-semibold"
                    : "text-text-muted hover:text-text-primary"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div
                    className={`flex h-7 w-12 items-center justify-center rounded-full transition-all ${
                      isActive ? "bg-accent-dim text-accent" : ""
                    }`}
                  >
                    <Icon className="h-4 w-4" weight={isActive ? "bold" : "regular"} />
                  </div>
                  <span className="mt-0.5 tracking-tight">{label}</span>
                </>
              )}
            </NavLink>
          ))}

          {/* 4th item: Quick Controls / Settings Drawer Toggle */}
          <button
            type="button"
            onClick={() => {
              playTick("toggle");
              setDrawerOpen(true);
            }}
            className={`flex flex-1 flex-col items-center justify-center py-1 text-2xs font-medium font-sans transition-colors ${
              drawerOpen ? "text-accent font-semibold" : "text-text-muted hover:text-text-primary"
            }`}
            aria-label="Open mobile preferences and controls"
          >
            <div
              className={`flex h-7 w-12 items-center justify-center rounded-full transition-all ${
                drawerOpen ? "bg-accent-dim text-accent" : ""
              }`}
            >
              <Faders className="h-4 w-4" weight="regular" />
            </div>
            <span className="mt-0.5 tracking-tight">Controls</span>
          </button>
        </div>
      </nav>

      {/* ── Slide-up Quick Controls Bottom Sheet ── */}
      {drawerOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-case-transition"
          onClick={() => setDrawerOpen(false)}
        >
          <div
            className="w-full rounded-t-2xl border-t border-divider p-5 space-y-4 shadow-2xl"
            style={{
              background: "var(--surface)",
              paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 1.25rem)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sheet Handle & Header */}
            <div className="flex items-center justify-between border-b border-divider pb-3">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                <h3 className="font-bold text-sm tracking-tight text-text-primary font-sans">
                  Preferences & System Controls
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="rounded-full p-1 text-text-muted hover:bg-surface-subtle hover:text-text-primary transition-colors"
                aria-label="Close controls drawer"
              >
                <X className="h-4 w-4" weight="bold" />
              </button>
            </div>

            {/* Live Engine Status Strip */}
            <div
              className="flex items-center justify-between rounded-control p-3 text-xs border border-divider"
              style={{ background: "var(--surface-subtle)" }}
            >
              <div className="flex items-center gap-2">
                <StatusIcon className={`h-4 w-4 ${statusColor}`} weight="bold" />
                <span className={`font-semibold ${statusColor} font-sans`}>{statusLabel}</span>
              </div>
              {transactionsLoaded != null && (
                <span className="text-text-muted text-xs font-mono">
                  {Number(transactionsLoaded).toLocaleString()} tx synced
                </span>
              )}
            </div>

            {/* Quick Toggle Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              {/* Currency Toggle */}
              <button
                type="button"
                onClick={handleCurrencyToggle}
                className="flex items-center justify-between rounded-control border border-divider p-3 text-xs font-medium font-sans text-text-primary transition-colors hover:bg-surface-subtle"
              >
                <div className="flex items-center gap-2">
                  <CurrencyInr className="h-4 w-4 text-accent" weight="bold" />
                  <span>Currency</span>
                </div>
                <span className="rounded bg-accent-dim px-2 py-0.5 font-mono text-xs font-bold text-accent">
                  {localeLabel}
                </span>
              </button>

              {/* Theme Toggle */}
              <button
                type="button"
                onClick={handleThemeToggle}
                className="flex items-center justify-between rounded-control border border-divider p-3 text-xs font-medium font-sans text-text-primary transition-colors hover:bg-surface-subtle"
              >
                <div className="flex items-center gap-2">
                  {isDark ? (
                    <Moon className="h-4 w-4 text-accent" weight="regular" />
                  ) : (
                    <Sun className="h-4 w-4 text-warning" weight="regular" />
                  )}
                  <span>Theme</span>
                </div>
                <span className="font-sans text-xs text-text-muted">
                  {isDark ? "Dark" : "Light"}
                </span>
              </button>

              {/* Sound Toggle */}
              <button
                type="button"
                onClick={handleSoundToggle}
                className="flex items-center justify-between rounded-control border border-divider p-3 text-xs font-medium font-sans text-text-primary transition-colors hover:bg-surface-subtle"
              >
                <div className="flex items-center gap-2">
                  {soundOn ? (
                    <SpeakerHigh className="h-4 w-4 text-success" weight="regular" />
                  ) : (
                    <SpeakerSimpleSlash className="h-4 w-4 text-text-muted" weight="regular" />
                  )}
                  <span>Haptics</span>
                </div>
                <span className="font-sans text-xs text-text-muted">
                  {soundOn ? "Active" : "Mute"}
                </span>
              </button>

              {/* Shortcuts HUD */}
              <button
                type="button"
                onClick={() => {
                  setDrawerOpen(false);
                  onOpenShortcuts?.();
                }}
                className="flex items-center justify-between rounded-control border border-divider p-3 text-xs font-medium font-sans text-text-primary transition-colors hover:bg-surface-subtle"
              >
                <div className="flex items-center gap-2">
                  <Keyboard className="h-4 w-4 text-accent" weight="regular" />
                  <span>Shortcuts</span>
                </div>
                <span className="font-mono text-xs text-text-muted">HUD</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
