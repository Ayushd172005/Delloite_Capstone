import { useState, useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import MobileNavDock from "./MobileNavDock";
import CommandPalette from "../components/CommandPalette";
import KeyboardShortcutsModal from "../components/KeyboardShortcutsModal";
import LiveMLScorerModal from "../components/LiveMLScorerModal";

export default function AppShell() {
  const location = useLocation();
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [scorerOpen, setScorerOpen] = useState(false);

  // Global Cmd+K and ? listeners
  useEffect(() => {
    function handleKeyDown(e) {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen((prev) => !prev);
      } else if ((e.key === "s" || e.key === "S" || e.key === "?") && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setShortcutsOpen((prev) => !prev);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div
      className="flex h-screen h-[100dvh] font-sans overflow-hidden"
      style={{ background: "var(--canvas)", color: "var(--text-primary)" }}
    >
      <Sidebar onOpenShortcuts={() => setShortcutsOpen(true)} />

      <div className="flex min-w-0 flex-1 flex-col h-full overflow-hidden">
        <TopBar
          onOpenCommandPalette={() => setPaletteOpen(true)}
          onOpenShortcuts={() => setShortcutsOpen(true)}
          onOpenScorer={() => setScorerOpen(true)}
        />
        <main
          className="min-h-0 flex-1 overflow-y-auto scrollbar-thin pb-[calc(4.5rem+env(safe-area-inset-bottom))] md:pb-0"
          style={{ background: "var(--canvas)" }}
          id="main-content"
        >
          <div key={location.pathname} className="workspace-content min-h-full">
            <Outlet context={{ onOpenScorer: () => setScorerOpen(true) }} />
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation Dock */}
      <MobileNavDock
        onOpenShortcuts={() => setShortcutsOpen(true)}
        onOpenCommandPalette={() => setPaletteOpen(true)}
        onOpenScorer={() => setScorerOpen(true)}
      />

      {/* Global Command Palette */}
      <CommandPalette
        isOpen={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        onOpenScorer={() => setScorerOpen(true)}
      />

      {/* Global Keyboard Shortcuts Modal */}
      <KeyboardShortcutsModal
        isOpen={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />

      {/* Live ML Pipeline & Sentinel Scorer Modal */}
      <LiveMLScorerModal
        isOpen={scorerOpen}
        onClose={() => setScorerOpen(false)}
      />
    </div>
  );
}
