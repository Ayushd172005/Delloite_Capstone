// Institutional Model Governance & Telemetry Dataset
// Sources: drift_report.json, calibrated_thresholds.json, calibrated_composite_weights.json,
// cost_sensitive_evaluation.csv, data_quality_report.json, and workload_metrics.json.

export const MODEL_META = {
  version: "v2.0",
  dataset_version: "pro_dataset_v1",
  feature_version: "fe_engine_v2",
  release_date: "2026-09-09T21:04:25Z",
  total_records_audited: 345000,
  architecture: "Multi-Engine Ensemble (Isolation Forest + Autoencoder + Benford + Causal Network)",
  status: "CALIBRATED_STABLE",
};

export const VERTICAL_METRICS = {
  aml: {
    label: "Anti-Money Laundering (PMLA / FATF)",
    transactions_analyzed: 19420,
    flagged_for_review: 4495,
    pct_flagged: 23.15,
    pct_auto_cleared: 76.85,
    high_risk_cases: 236,
    total_fraud_in_holdout: 308,
    fraud_caught_in_queue: 304,
    fraud_missed_by_auto_clear: 4,
    capture_rate_pct: 98.7,
    top_1pct_capture_rate: 44.16,
    top_5pct_capture_rate: 72.08,
    workload_reduction_pct: 76.85,
    roc_auc: 0.968,
    fpr_threshold: 15.79,
    weights: {
      isoforest: 0.55,
      autoencoder: 0.35,
      rules: 0.05,
      benford: 0.05,
    },
    cost_evaluation: {
      sentinel_cost_inr: 3047500,
      review_everything_cost_inr: 9710000,
      review_nothing_cost_inr: 61600000,
      savings_inr: 6662500,
      savings_pct: 68.6,
    },
    tier_cutoffs: [
      { max_score: 15.79, tier: "auto_clear", label: "Auto-Cleared (76.85%)" },
      { max_score: 23.51, tier: "standard_review", label: "Standard Review (15.2%)" },
      { max_score: 38.76, tier: "priority_review", label: "Priority Review (6.7%)" },
      { max_score: 100.0, tier: "immediate_escalation", label: "Immediate Escalation (1.2%)" },
    ],
  },
  corporate: {
    label: "Corporate Banking & Treasury",
    transactions_analyzed: 19206,
    flagged_for_review: 3696,
    pct_flagged: 19.24,
    pct_auto_cleared: 80.76,
    high_risk_cases: 191,
    total_fraud_in_holdout: 261,
    fraud_caught_in_queue: 138,
    fraud_missed_by_auto_clear: 123,
    capture_rate_pct: 52.87,
    top_1pct_capture_rate: 43.30,
    top_5pct_capture_rate: 45.98,
    workload_reduction_pct: 80.76,
    roc_auc: 0.7855,
    fpr_threshold: 21.99,
    weights: {
      isoforest: 0.55,
      autoencoder: 0.35,
      rules: 0.05,
      benford: 0.05,
    },
    cost_evaluation: {
      sentinel_cost_inr: 7998000,
      review_everything_cost_inr: 9603000,
      review_nothing_cost_inr: 13050000,
      savings_inr: 1605000,
      savings_pct: 16.7,
    },
    tier_cutoffs: [
      { max_score: 21.99, tier: "auto_clear", label: "Auto-Cleared (80.76%)" },
      { max_score: 28.79, tier: "standard_review", label: "Standard Review (12.1%)" },
      { max_score: 40.41, tier: "priority_review", label: "Priority Review (6.1%)" },
      { max_score: 100.0, tier: "immediate_escalation", label: "Immediate Escalation (1.0%)" },
    ],
  },
  retail: {
    label: "Retail Payments & Consumer Credit",
    transactions_analyzed: 19306,
    flagged_for_review: 3363,
    pct_flagged: 17.42,
    pct_auto_cleared: 82.58,
    high_risk_cases: 149,
    total_fraud_in_holdout: 664,
    fraud_caught_in_queue: 334,
    fraud_missed_by_auto_clear: 330,
    capture_rate_pct: 50.3,
    top_1pct_capture_rate: 26.20,
    top_5pct_capture_rate: 34.34,
    workload_reduction_pct: 82.58,
    roc_auc: 0.7153,
    fpr_threshold: 22.56,
    weights: {
      isoforest: 0.45,
      autoencoder: 0.15,
      rules: 0.20,
      benford: 0.20,
    },
    cost_evaluation: {
      sentinel_cost_inr: 3331500,
      review_everything_cost_inr: 9653000,
      review_nothing_cost_inr: 3320000,
      savings_inr: 6321500,
      savings_pct: 65.5,
    },
    tier_cutoffs: [
      { max_score: 22.56, tier: "auto_clear", label: "Auto-Cleared (82.58%)" },
      { max_score: 32.92, tier: "standard_review", label: "Standard Review (11.8%)" },
      { max_score: 54.20, tier: "priority_review", label: "Priority Review (4.8%)" },
      { max_score: 100.0, tier: "immediate_escalation", label: "Immediate Escalation (0.8%)" },
    ],
  },
};

export const FEATURE_DRIFT_REPORT = [
  {
    vertical: "aml",
    features: [
      { metric: "amount_mean", baseline: 8287.01, current: 8184.53, pct_change: -1.24, psi: 0.012, status: "STABLE" },
      { metric: "amount_std", baseline: 28278.44, current: 28388.79, pct_change: 0.39, psi: 0.008, status: "STABLE" },
      { metric: "amount_p95", baseline: 23656.92, current: 22705.25, pct_change: -4.02, psi: 0.021, status: "STABLE" },
      { metric: "transaction_freq_mean", baseline: 1.152, current: 1.170, pct_change: 1.52, psi: 0.015, status: "STABLE" },
      { metric: "isoforest_top5_anomaly", baseline: 0.428, current: 0.409, pct_change: -4.48, psi: 0.034, status: "STABLE" },
      { metric: "new_counterparty_rate", baseline: 0.995, current: 0.988, pct_change: -0.67, psi: 0.005, status: "STABLE" },
    ],
  },
  {
    vertical: "corporate",
    features: [
      { metric: "amount_mean", baseline: 12450.32, current: 12380.11, pct_change: -0.56, psi: 0.010, status: "STABLE" },
      { metric: "amount_std", baseline: 38400.12, current: 38120.45, pct_change: -0.73, psi: 0.009, status: "STABLE" },
      { metric: "amount_p95", baseline: 41200.00, current: 40950.00, pct_change: -0.61, psi: 0.011, status: "STABLE" },
      { metric: "transaction_freq_mean", baseline: 2.105, current: 2.140, pct_change: 1.66, psi: 0.018, status: "STABLE" },
      { metric: "isoforest_top5_anomaly", baseline: 0.380, current: 0.375, pct_change: -1.32, psi: 0.020, status: "STABLE" },
      { metric: "new_counterparty_rate", baseline: 0.840, current: 0.832, pct_change: -0.95, psi: 0.012, status: "STABLE" },
    ],
  },
  {
    vertical: "retail",
    features: [
      { metric: "amount_mean", baseline: 412.50, current: 408.10, pct_change: -1.07, psi: 0.014, status: "STABLE" },
      { metric: "amount_std", baseline: 1250.80, current: 1262.30, pct_change: 0.92, psi: 0.007, status: "STABLE" },
      { metric: "amount_p95", baseline: 1850.00, current: 1840.00, pct_change: -0.54, psi: 0.009, status: "STABLE" },
      { metric: "transaction_freq_mean", baseline: 3.420, current: 3.480, pct_change: 1.75, psi: 0.022, status: "STABLE" },
      { metric: "isoforest_top5_anomaly", baseline: 0.410, current: 0.398, pct_change: -2.93, psi: 0.028, status: "STABLE" },
      { metric: "new_counterparty_rate", baseline: 0.620, current: 0.615, pct_change: -0.81, psi: 0.006, status: "STABLE" },
    ],
  },
];

export const DATA_QUALITY_CERTIFICATE = [
  {
    vertical: "Corporate Banking",
    n_rows: 115000,
    null_rate: "0.00%",
    duplicate_ids: 0,
    non_positive_amounts: 0,
    negative_balance_violations: 0,
    depletion_ratio_violations: 0,
    unparseable_timestamps: 0,
    status: "PASS",
  },
  {
    vertical: "Anti-Money Laundering",
    n_rows: 115000,
    null_rate: "0.00%",
    duplicate_ids: 0,
    non_positive_amounts: 0,
    negative_balance_violations: 0,
    depletion_ratio_violations: 0,
    unparseable_timestamps: 0,
    status: "PASS",
  },
  {
    vertical: "Retail Payments",
    n_rows: 115000,
    null_rate: "0.00%",
    duplicate_ids: 0,
    non_positive_amounts: 0,
    negative_balance_violations: 0,
    depletion_ratio_violations: 0,
    unparseable_timestamps: 0,
    status: "PASS",
  },
];

// Dynamic Trade-off Simulator calculation
export function calculateSimulatedTradeoff(verticalKey, thresholdScore) {
  const vert = VERTICAL_METRICS[verticalKey] || VERTICAL_METRICS.aml;
  const totalCases = vert.transactions_analyzed;
  const totalFraud = vert.total_fraud_in_holdout;

  const normalized = Math.max(0, Math.min(100, thresholdScore));
  const reviewPct = Math.max(2, Math.min(100, 100 - (normalized * 0.95)));
  const queueCases = Math.round((reviewPct / 100) * totalCases);

  const captureRate = Math.max(0.2, Math.min(0.99, 1 - Math.pow(normalized / 100, 1.8)));
  const caughtFraud = Math.round(totalFraud * captureRate);
  const missedFraud = totalFraud - caughtFraud;

  const reviewCostINR = queueCases * 500;
  const fraudLossINR = missedFraud * 200000;
  const totalCostINR = reviewCostINR + fraudLossINR;

  const naiveEverythingCostINR = totalCases * 500;
  const naiveNothingCostINR = totalFraud * 200000;
  const savingsVsEverythingINR = naiveEverythingCostINR - totalCostINR;

  return {
    queueCases,
    reviewPct: Math.round(reviewPct * 10) / 10,
    caughtFraud,
    missedFraud,
    captureRatePct: Math.round(captureRate * 1000) / 10,
    reviewCostINR,
    fraudLossINR,
    totalCostINR,
    savingsVsEverythingINR,
    savingsPct: Math.round((savingsVsEverythingINR / naiveEverythingCostINR) * 1000) / 10,
  };
}
