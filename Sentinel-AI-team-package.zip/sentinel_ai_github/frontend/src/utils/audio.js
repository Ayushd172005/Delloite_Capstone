// Web Audio API micro-haptics synthesizer
// Produces an ultra-subtle, elegant mechanical tick (<5ms)
let audioCtx = null;
let soundEnabled = true;

try {
  const saved = localStorage.getItem("sentinel-sound");
  if (saved !== null) {
    soundEnabled = saved === "true";
  }
} catch {
  // ignore
}

function getAudioContext() {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playTick(type = "nav") {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === "nav") {
      // Very short high-frequency tick (1000Hz -> 300Hz in 8ms)
      osc.type = "sine";
      osc.frequency.setValueAtTime(950, now);
      osc.frequency.exponentialRampToValueAtTime(320, now + 0.008);
      gain.gain.setValueAtTime(0.015, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.008);
      osc.start(now);
      osc.stop(now + 0.009);
    } else if (type === "disposition") {
      // Pleasant confirmation chord
      osc.type = "triangle";
      osc.frequency.setValueAtTime(520, now);
      osc.frequency.exponentialRampToValueAtTime(780, now + 0.04);
      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === "toggle") {
      // Micro click
      osc.type = "sine";
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.006);
      gain.gain.setValueAtTime(0.018, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.006);
      osc.start(now);
      osc.stop(now + 0.007);
    }
  } catch {
    // Gracefully ignore any browser audio constraints
  }
}

export function isSoundEnabled() {
  return soundEnabled;
}

export function setSoundEnabled(val) {
  soundEnabled = !!val;
  try {
    localStorage.setItem("sentinel-sound", String(soundEnabled));
  } catch {
    // ignore
  }
}
