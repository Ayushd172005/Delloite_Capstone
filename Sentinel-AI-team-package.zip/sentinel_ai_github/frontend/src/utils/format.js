/**
 * Central formatting utilities for Sentinel AI.
 * Single source of truth for all display transformations.
 */

/**
 * Normalize vertical field values to display-ready strings.
 * "aml" → "AML", "retail" → "Retail", null → "—"
 */
export function fmtVertical(v) {
  if (!v) return "—";
  const lower = v.toLowerCase();
  if (lower === "aml") return "AML";
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

/**
 * Convert snake_case review_tier to Title Case display string.
 * "immediate_escalation" → "Immediate Escalation"
 */
export function fmtTier(tier) {
  if (!tier) return "—";
  return tier
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Convert snake_case event_type to display label.
 */
export function fmtEventType(type) {
  const MAP = {
    model_scored: "Risk Alert",
    investigated: "AI Investigation",
    decision: "Auditor Decision",
    override: "Decision Override",
  };
  return MAP[type] || type.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Relative time formatter — always readable, caps future dates.
 * Returns a short human string and a full ISO string for tooltips.
 */
export function fmtRelativeTime(isoString) {
  if (!isoString) return { short: "—", full: "—" };
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return { short: "—", full: isoString };

  const now = new Date();
  // Cap future dates to now — prevents "in X hours" on test data
  const effective = d > now ? now : d;
  const diff = now - effective;

  const full = d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  let short;
  if (diff < 60_000) {
    short = "Just now";
  } else if (diff < 3_600_000) {
    const m = Math.floor(diff / 60_000);
    short = `${m}m ago`;
  } else if (diff < 86_400_000) {
    const h = Math.floor(diff / 3_600_000);
    const time = effective.toLocaleTimeString(undefined, {
      hour: "2-digit",
      minute: "2-digit",
    });
    short = h === 0 ? `Today at ${time}` : `${h}h ago`;
  } else if (diff < 7 * 86_400_000) {
    const days = Math.floor(diff / 86_400_000);
    short = days === 1 ? "Yesterday" : `${days}d ago`;
  } else {
    short = effective.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
    });
  }

  return { short, full };
}

/**
 * Format money with en-IN locale (Indian lakh system).
 * Standalone formatter used as fallback where context isn't available.
 */
export function fmtMoneyIN(n, decimals = 0) {
  if (n == null || isNaN(Number(n))) return "—";
  return "₹" + Number(n).toLocaleString("en-IN", {
    maximumFractionDigits: decimals,
    minimumFractionDigits: decimals,
  });
}

/**
 * Convert INR amount to USD using the benchmark peg (1 USD = 83.00 INR).
 */
export function convertINRtoUSD(n, rate = 83.0) {
  if (n == null || isNaN(Number(n))) return 0;
  return Number(n) / rate;
}

/**
 * Format money with en-US locale (standard thousands separator).
 * Supports automatic conversion if convert=true.
 */
export function fmtMoneyUSD(n, decimals = 0, convert = false) {
  if (n == null || isNaN(Number(n))) return "—";
  const val = convert ? convertINRtoUSD(n) : Number(n);
  return "$" + val.toLocaleString("en-US", {
    maximumFractionDigits: decimals,
    minimumFractionDigits: decimals,
  });
}


/**
 * Capitalize a string in Title Case.
 */
export function toTitleCase(str) {
  if (!str) return "";
  return str
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Derive a use-case display label from rules_triggered array
 * when use_case field is absent.
 */
const RULE_TO_LABEL = {
  just_under_limit: "Near-Threshold Structuring",
  round_number: "Round-Number Amount",
  velocity_spike: "Velocity Spike",
  new_counterparty_high_value: "New Counterparty + High Value",
  balance_depletion: "Balance Depletion",
  off_hours_weekend: "Off-Hours / Weekend Activity",
  dormant_reactivation: "Dormant Account Reactivation",
  shared_device: "Shared Device Network",
  hub_counterparty: "Fan-In / Fan-Out Counterparty",
};

export function rulesTriggeredToUseCase(rules) {
  if (!rules || rules.length === 0) return null;
  // Return the most-specific single label from the first matched rule
  return RULE_TO_LABEL[rules[0]] || rules[0].replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
