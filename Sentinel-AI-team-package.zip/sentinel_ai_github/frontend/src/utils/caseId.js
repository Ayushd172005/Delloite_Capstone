export function compactCaseId(value) {
  const id = String(value ?? "");
  const parts = id.split(/[-_]/).filter(Boolean);
  if (id.length <= 12 || parts.length < 2) return id;

  const family = parts[0] || id.slice(0, 3);
  const tail = (parts.at(-1) || id).slice(-6);
  return `${family} ··${tail}`;
}
