import { useEffect } from "react";

/**
 * Sets document.title for the current route.
 * Restores previous title on unmount.
 */
export function useDocumentTitle(title) {
  useEffect(() => {
    const prev = document.title;
    document.title = title;
    return () => {
      document.title = prev;
    };
  }, [title]);
}
