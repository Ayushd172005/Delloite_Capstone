/** @type {import('tailwindcss').Config} */

function withOpacity(variableName) {
  return ({ opacityValue }) => {
    if (opacityValue !== undefined) {
      return `rgba(var(${variableName}), ${opacityValue})`;
    }
    return `var(${variableName.replace("-rgb", "")})`;
  };
}

export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // ── Semantic design tokens (RGB-alpha aware) ──────────────────
        canvas:          withOpacity("--canvas-rgb"),
        shell:           withOpacity("--shell-rgb"),
        surface:         withOpacity("--surface-rgb"),
        "surface-raised":withOpacity("--surface-raised-rgb"),
        "surface-subtle":withOpacity("--surface-subtle-rgb"),
        "text-primary":  "var(--text-primary)",
        "text-secondary":"var(--text-secondary)",
        "text-muted":    "var(--text-muted)",
        divider:         "var(--divider)",
        "divider-strong":"var(--divider-strong)",
        accent:          withOpacity("--accent-rgb"),
        "accent-dim":    "var(--accent-dim)",
        "accent-strong": "var(--accent-strong)",

        // Status semantic tokens
        critical:        withOpacity("--risk-critical-rgb"),
        "critical-bg":   "var(--risk-critical-bg)",
        "critical-border":"var(--risk-critical-border)",
        warning:         withOpacity("--risk-warning-rgb"),
        "warning-bg":    "var(--risk-warning-bg)",
        "warning-border":"var(--risk-warning-border)",
        success:         withOpacity("--risk-success-rgb"),
        "success-bg":    "var(--risk-success-bg)",
        "success-border":"var(--risk-success-border)",
        info:            withOpacity("--risk-info-rgb"),
        "info-bg":       "var(--risk-info-bg)",
        "info-border":   "var(--risk-info-border)",

        // ── Legacy compat aliases (existing components keep working) ──
        base:            withOpacity("--canvas-rgb"),
        panel:           withOpacity("--surface-rgb"),
        "panel-raised":  withOpacity("--surface-raised-rgb"),
        "panel-overlay": withOpacity("--surface-raised-rgb"),
        "panel-dock":    withOpacity("--surface-subtle-rgb"),
        border:          "var(--divider)",
        "border-subtle": "var(--divider)",
        "border-strong": "var(--divider-strong)",
        ink:             "var(--text-primary)",
        "ink-muted":     "var(--text-secondary)",
        "ink-faint":     "var(--text-muted)",
        "accent-soft":   "var(--accent-dim)",

        // Risk tokens (legacy)
        low:             withOpacity("--risk-success-rgb"),
        "low-bg":        "var(--risk-success-bg)",
        "low-border":    "var(--risk-success-border)",
        medium:          withOpacity("--risk-warning-rgb"),
        "medium-bg":     "var(--risk-warning-bg)",
        "medium-border": "var(--risk-warning-border)",
        high:            withOpacity("--risk-warning-rgb"),
        "high-bg":       "var(--risk-warning-bg)",
        "high-border":   "var(--risk-warning-border)",

        link:            withOpacity("--risk-info-rgb"),
        "link-bg":       "var(--risk-info-bg)",
      },

      fontFamily: {
        sans: ["Inter", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "sans-serif"],
        mono: ["JetBrains Mono", "SFMono-Regular", "Menlo", "Monaco", "Consolas", "monospace"],
      },

      fontSize: {
        // Design system typography tokens
        "display-sm":  ["1.375rem", { lineHeight: "1.75rem", fontWeight: "650", letterSpacing: "-0.015em" }], // 22px
        "heading-md":  ["1.125rem", { lineHeight: "1.55rem", fontWeight: "650" }], // 18px
        "decision-md": ["1.0rem",    { lineHeight: "1.45rem", fontWeight: "650" }], // 16px
        "label-sm":    ["0.8125rem",{ lineHeight: "1.2rem",  fontWeight: "600", letterSpacing: "0.01em" }], // 13px
        "meta-xs":     ["0.75rem",  { lineHeight: "1.1rem",  fontWeight: "500" }], // 12px
        "mono-data":   ["0.875rem", { lineHeight: "1.3rem",  fontWeight: "600" }], // 14px

        // Enhanced readability base sizes
        "2xs": ["0.8125rem", { lineHeight: "1.15rem" }], // 13px
        "3xs": ["0.75rem",   { lineHeight: "1.05rem" }], // 12px
      },

      borderRadius: {
        "panel":   "8px",
        "control": "6px",
        "badge":   "4px",
      },

      boxShadow: {
        panel:           "var(--shadow-panel)",
        "panel-raised":  "var(--shadow-raised)",
        "panel-modal":   "var(--shadow-modal)",
        "panel-md":      "var(--shadow-raised)",
        "panel-lg":      "var(--shadow-modal)",
        "inset-highlight": "inset 0 1px 0 0 rgba(255, 255, 255, 0.05)",
      },

      animation: {
        "spin-slow":   "spin 2s linear infinite",
        "pulse-dot":   "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "subtle-ping": "subtlePing 2.5s cubic-bezier(0, 0, 0.2, 1) infinite",
      },

      keyframes: {
        subtlePing: {
          "75%, 100%": { transform: "scale(1.4)", opacity: "0" },
        },
      },
    },
  },
  plugins: [],
};
