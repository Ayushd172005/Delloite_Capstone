import { test, describe } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import parser from "@babel/parser";
import traversePkg from "@babel/traverse";
const traverse = traversePkg.default || traversePkg;

import { fmtVertical, fmtTier, rulesTriggeredToUseCase, fmtMoneyIN, convertINRtoUSD, fmtMoneyUSD } from "../src/utils/format.js";
import {
  MODEL_META,
  VERTICAL_METRICS,
  FEATURE_DRIFT_REPORT,
  DATA_QUALITY_CERTIFICATE,
  calculateSimulatedTradeoff,
} from "../src/data/governanceData.js";

describe("Frontend Format Utilities", () => {
  test("fmtVertical correctly maps vertical keys to labels", () => {
    assert.equal(fmtVertical("aml"), "AML");
    assert.equal(fmtVertical("corporate"), "Corporate");
    assert.equal(fmtVertical("retail"), "Retail");
    assert.equal(fmtVertical("unknown"), "Unknown");
    assert.equal(fmtVertical(null), "—");
  });

  test("fmtTier correctly maps review tiers to labels", () => {
    assert.equal(fmtTier("auto_clear"), "Auto Clear");
    assert.equal(fmtTier("standard_review"), "Standard Review");
    assert.equal(fmtTier("priority_review"), "Priority Review");
    assert.equal(fmtTier("immediate_escalation"), "Immediate Escalation");
    assert.equal(fmtTier(null), "—");
  });

  test("rulesTriggeredToUseCase extracts primary typology heuristic", () => {
    assert.equal(rulesTriggeredToUseCase(["velocity_spike"]), "Velocity Spike");
    assert.equal(rulesTriggeredToUseCase(["just_under_limit"]), "Near-Threshold Structuring");
    assert.equal(rulesTriggeredToUseCase(["shared_device"]), "Shared Device Network");
    assert.equal(rulesTriggeredToUseCase([]), null);
  });

  test("fmtMoneyIN formats into Indian numbering system", () => {
    assert.equal(fmtMoneyIN(100000), "₹1,00,000");
    assert.equal(fmtMoneyIN(2500000), "₹25,00,000");
    assert.equal(fmtMoneyIN(null), "—");
  });

  test("convertINRtoUSD accurately converts amounts using 83.0 benchmark peg", () => {
    assert.equal(convertINRtoUSD(83000), 1000);
    assert.equal(convertINRtoUSD(0), 0);
    assert.equal(convertINRtoUSD(null), 0);
    const converted = convertINRtoUSD(372839.57);
    assert.ok(Math.abs(converted - 4492.043) < 0.01);
  });

  test("fmtMoneyUSD formats amounts in standard US currency style", () => {
    assert.equal(fmtMoneyUSD(1000), "$1,000");
    assert.equal(fmtMoneyUSD(1000.5, 2), "$1,000.50");
    assert.equal(fmtMoneyUSD(83000, 0, true), "$1,000");
    assert.equal(fmtMoneyUSD(null), "—");
  });
});

describe("Surveillance Queue Limit & Threshold Filtering", () => {
  const sampleTransactions = [
    { transaction_id: "TX_RETAIL_1", amount: 15000, vertical: "retail" },
    { transaction_id: "TX_CORP_1", amount: 125000, vertical: "corporate" },
    { transaction_id: "TX_AML_1", amount: 372839.57, vertical: "aml" },
    { transaction_id: "TX_STAT_1", amount: 1200000, vertical: "aml" },
  ];

  test("High Value limit threshold (>= 100,000 INR / $1.2K) isolates high-exposure transactions", () => {
    const highValue = sampleTransactions.filter((r) => r.amount >= 100000);
    assert.equal(highValue.length, 3);
    assert.ok(!highValue.some((r) => r.transaction_id === "TX_RETAIL_1"));
  });

  test("Statutory limit threshold (>= 250,000 INR / $3.0K) captures AML/PMLA reporting breaches", () => {
    const statutory = sampleTransactions.filter((r) => r.amount >= 250000);
    assert.equal(statutory.length, 2);
    assert.deepEqual(statutory.map((r) => r.transaction_id), ["TX_AML_1", "TX_STAT_1"]);
  });
});

describe("Model Governance & Calibration Telemetry Data", () => {
  test("Model metadata matches verified production specification", () => {
    assert.equal(MODEL_META.version, "v2.0");
    assert.equal(MODEL_META.status, "CALIBRATED_STABLE");
    assert.equal(MODEL_META.total_records_audited, 345000);
  });

  test("Ensemble model weights sum to 1.00 for all verticals", () => {
    for (const [vKey, vData] of Object.entries(VERTICAL_METRICS)) {
      const sum = Object.values(vData.weights).reduce((a, b) => a + b, 0);
      assert.ok(
        Math.abs(sum - 1.0) < 0.001,
        `Weights for ${vKey} should sum to 1.00, got ${sum}`
      );
    }
  });

  test("Validation ROC-AUC meets institutional benchmark tiers", () => {
    assert.ok(VERTICAL_METRICS.aml.roc_auc >= 0.95, "AML ROC-AUC must be >= 0.95");
    assert.ok(VERTICAL_METRICS.corporate.roc_auc >= 0.75, "Corporate ROC-AUC must be >= 0.75");
    assert.ok(VERTICAL_METRICS.retail.roc_auc >= 0.70, "Retail ROC-AUC must be >= 0.70");
  });

  test("Data hygiene certificate confirms zero nulls across 345,000 records", () => {
    assert.equal(DATA_QUALITY_CERTIFICATE.length, 3);
    for (const cert of DATA_QUALITY_CERTIFICATE) {
      assert.equal(cert.null_rate, "0.00%");
      assert.equal(cert.duplicate_ids, 0);
      assert.equal(cert.status, "PASS");
      assert.equal(cert.n_rows, 115000);
    }
  });

  test("Feature drift PSI remains strictly within stable boundaries (< 0.05)", () => {
    for (const report of FEATURE_DRIFT_REPORT) {
      for (const feat of report.features) {
        assert.ok(
          feat.psi < 0.05,
          `Feature ${feat.metric} in ${report.vertical} has elevated PSI: ${feat.psi}`
        );
        assert.equal(feat.status, "STABLE");
      }
    }
  });

  test("Dynamic Trade-off Simulator produces rational financial cost curves", () => {
    const simLow = calculateSimulatedTradeoff("aml", 10);
    const simHigh = calculateSimulatedTradeoff("aml", 50);

    // Lower threshold means more cases reviewed, higher capture, fewer missed
    assert.ok(simLow.queueCases > simHigh.queueCases, "Lower threshold should review more cases");
    assert.ok(simLow.caughtFraud >= simHigh.caughtFraud, "Lower threshold should catch more fraud");
    assert.ok(simLow.missedFraud <= simHigh.missedFraud, "Lower threshold should miss less fraud");
    assert.ok(simLow.reviewCostINR > simHigh.reviewCostINR, "Lower threshold costs more to review");
  });
});

describe("Batch Selection & Set Operations", () => {
  test("Toggle and select-all logic maintains set consistency", () => {
    let selected = new Set();

    // Toggle on TX1
    selected.add("TX1");
    assert.ok(selected.has("TX1"));
    assert.equal(selected.size, 1);

    // Toggle on TX2
    selected.add("TX2");
    assert.ok(selected.has("TX2"));
    assert.equal(selected.size, 2);

    // Toggle off TX1
    selected.delete("TX1");
    assert.ok(!selected.has("TX1"));
    assert.equal(selected.size, 1);

    // Select all from a batch of 5 IDs
    const batch = ["TX1", "TX2", "TX3", "TX4", "TX5"];
    selected = new Set(batch);
    assert.equal(selected.size, 5);

    // Clear all
    selected.clear();
    assert.equal(selected.size, 0);
  });

  test("Cumulative batch financial amount calculation is accurate", () => {
    const sampleRows = [
      { transaction_id: "T1", amount: 150000 },
      { transaction_id: "T2", amount: 350000 },
      { transaction_id: "T3", amount: 500000 },
    ];
    const total = sampleRows.reduce((sum, r) => sum + r.amount, 0);
    assert.equal(total, 1000000);
  });
});

describe("Design System Status & SLA Logic", () => {
  test("Status vocabulary completeness — verifies core state labels", () => {
    const requiredStatuses = [
      "PENDING",
      "SLA_AT_RISK",
      "SLA_BREACHED",
      "ACCEPT",
      "ESCALATE",
      "SAR",
      "DISMISS",
      "ATTESTED",
    ];
    assert.equal(requiredStatuses.length, 8);
    for (const s of requiredStatuses) {
      assert.ok(typeof s === "string" && s.length > 0);
    }
  });

  test("Risk level boundary score logic maps accurately", () => {
    function scoreToLevel(score) {
      const s = Number(score ?? 0);
      if (s >= 85) return "CRITICAL";
      if (s >= 70) return "HIGH";
      if (s >= 50) return "MEDIUM";
      return "LOW";
    }

    assert.equal(scoreToLevel(95), "CRITICAL");
    assert.equal(scoreToLevel(85), "CRITICAL");
    assert.equal(scoreToLevel(75), "HIGH");
    assert.equal(scoreToLevel(70), "HIGH");
    assert.equal(scoreToLevel(55), "MEDIUM");
    assert.equal(scoreToLevel(50), "MEDIUM");
    assert.equal(scoreToLevel(49), "LOW");
    assert.equal(scoreToLevel(0), "LOW");
  });

  test("SLA remaining seconds formatter creates valid HH:MM:SS timestamps", () => {
    function formatRemaining(totalSec) {
      const h = Math.floor(totalSec / 3600);
      const m = Math.floor((totalSec % 3600) / 60);
      const s = totalSec % 60;
      return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    }

    assert.equal(formatRemaining(3661), "01:01:01");
    assert.equal(formatRemaining(0), "00:00:00");
    assert.equal(formatRemaining(14400), "04:00:00");
    assert.equal(formatRemaining(86400), "24:00:00");
  });
});

describe("Sentinel product language and identity", () => {
  test("shell uses casework language and the mark is a distinctive S monogram", () => {
    const sidebar = fs.readFileSync(path.join(process.cwd(), "src/layout/Sidebar.jsx"), "utf8");
    const topbar = fs.readFileSync(path.join(process.cwd(), "src/layout/TopBar.jsx"), "utf8");
    const logo = fs.readFileSync(path.join(process.cwd(), "src/components/BrandLogo.jsx"), "utf8");
    const table = fs.readFileSync(path.join(process.cwd(), "src/components/TransactionTable.jsx"), "utf8");

    assert.match(sidebar, /Case queue/);
    assert.match(sidebar, /Evidence ledger/);
    assert.match(topbar, /Live review/);
    assert.doesNotMatch(logo, /Hexagonal Shield/);
    assert.match(logo, /Sentinel S monogram/);
    assert.match(table, /compactCaseId/);
    assert.match(fs.readFileSync(path.join(process.cwd(), "src/utils/caseId.js"), "utf8"), /return `\$\{family\} ··\$\{tail\}`/);
    const queue = fs.readFileSync(path.join(process.cwd(), "src/pages/RiskQueue.jsx"), "utf8");
    assert.match(queue, /counterparty_name/);
    assert.match(queue, /aria-label="Search cases, counterparties, and typologies"/);
  });
});

describe("Dark theme token system", () => {
  test("uses distinct graphite surfaces and restrained semantic colors", () => {
    const css = fs.readFileSync(path.join(process.cwd(), "src/index.css"), "utf8");
    const networkModal = fs.readFileSync(path.join(process.cwd(), "src/components/NetworkLinkModal.jsx"), "utf8");

    assert.match(css, /--canvas:\s+#090A0B/);
    assert.match(css, /--surface:\s+#111214/);
    assert.match(css, /--surface-raised:\s+#18191C/);
    assert.match(css, /--accent:\s+#A8B8FF/);
    assert.match(css, /--risk-critical:\s+#F47772/);
    assert.match(css, /\.dark table thead,[\s\S]*color: var\(--text-muted\)/);
    assert.match(networkModal, /canvas: "#090A0B"/);
    assert.match(networkModal, /spark: "#F47772"/);
  });
});

describe("RadialGauge Mathematical Clearance & Geometry Guarantee", () => {
  const cx = 80, cy = 68, r = 52;
  const startAngleDeg = 170, endAngleDeg = 370;
  const pillTop = 93, pillBottom = 113;
  const pillLeft = 42, pillRight = 118;

  test("Arc endpoints terminate strictly with >= 15px clearance above status pill", () => {
    const startY = cy + r * Math.sin((startAngleDeg * Math.PI) / 180);
    const endY = cy + r * Math.sin((endAngleDeg * Math.PI) / 180);

    assert.ok(startY <= 77.05, `Start endpoint Y should be <= 77.05, got ${startY}`);
    assert.ok(endY <= 77.05, `End endpoint Y should be <= 77.05, got ${endY}`);

    const verticalClearance = pillTop - Math.max(startY, endY);
    assert.ok(
      verticalClearance >= 15.0,
      `Vertical clearance between arc ends and pill must be >= 15px, got ${verticalClearance}px`
    );
  });

  test("Indicator needle pip coordinates never collide with pill boundary across 0-100 score range", () => {
    for (let score = 0; score <= 100; score += 1) {
      const angleDeg = startAngleDeg + (score / 100) * 200;
      const rad = (angleDeg * Math.PI) / 180;
      const pipX = cx + r * Math.cos(rad);
      const pipY = cy + r * Math.sin(rad);

      // Pip must never enter the pill bounding box [42..118] x [93..113]
      assert.ok(
        pipY < pillTop,
        `Pip Y (${pipY.toFixed(2)}) at score ${score}% breached pill top boundary (${pillTop})`
      );
    }
  });

  test("Arc horizontal span allows ample lateral clearance for centered pill badge", () => {
    const startX = cx + r * Math.cos((startAngleDeg * Math.PI) / 180);
    const endX = cx + r * Math.cos((endAngleDeg * Math.PI) / 180);

    const leftClearance = pillLeft - startX;
    const rightClearance = endX - pillRight;

    assert.ok(
      leftClearance > 13.0,
      `Left lateral clearance should be > 13px, got ${leftClearance}px`
    );
    assert.ok(
      rightClearance > 13.0,
      `Right lateral clearance should be > 13px, got ${rightClearance}px`
    );
  });
});

describe("Syndicate Link Topology & Graph Workstation Specifications", () => {
  const REQUIRED_NODES = ["subject", "hub", "device", "vpn", "mule1", "mule2", "otc"];

  test("Topology guarantees presence of all 7 critical forensic entity categories", () => {
    assert.equal(REQUIRED_NODES.length, 7);
    assert.ok(REQUIRED_NODES.includes("subject"));
    assert.ok(REQUIRED_NODES.includes("hub"));
    assert.ok(REQUIRED_NODES.includes("device"));
    assert.ok(REQUIRED_NODES.includes("otc"));
  });

  test("Radial and Pipeline layouts maintain valid boundary coordinates within 800x520 canvas", () => {
    const radialCoords = {
      subject: { x: 270, y: 260 },
      hub: { x: 500, y: 260 },
      device: { x: 385, y: 90 },
      vpn: { x: 100, y: 260 },
      mule1: { x: 670, y: 150 },
      mule2: { x: 670, y: 370 },
      otc: { x: 740, y: 260 },
    };

    for (const [key, pos] of Object.entries(radialCoords)) {
      assert.ok(pos.x >= 40 && pos.x <= 760, `Node ${key} x (${pos.x}) must stay within canvas bounds [40..760]`);
      assert.ok(pos.y >= 40 && pos.y <= 480, `Node ${key} y (${pos.y}) must stay within canvas bounds [40..480]`);
    }
  });

  test("Minimum pairwise distance between any two default nodes prevents overlapping labels (> 60px)", () => {
    const radialCoords = {
      subject: { x: 270, y: 260 },
      hub: { x: 500, y: 260 },
      device: { x: 385, y: 90 },
      vpn: { x: 100, y: 260 },
      mule1: { x: 670, y: 150 },
      mule2: { x: 670, y: 370 },
      otc: { x: 740, y: 260 },
    };

    const keys = Object.keys(radialCoords);
    for (let i = 0; i < keys.length; i++) {
      for (let j = i + 1; j < keys.length; j++) {
        const k1 = keys[i];
        const k2 = keys[j];
        const p1 = radialCoords[k1];
        const p2 = radialCoords[k2];
        const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
        assert.ok(
          dist >= 60.0,
          `Nodes ${k1} and ${k2} must have distance >= 60px to prevent visual collision, got ${dist.toFixed(1)}px`
        );
      }
    }
  });

  test("Critical risk entities meet AML escalation thresholds (score >= 90)", () => {
    const criticalScores = [92, 96, 94]; // subject (92), device (96), otc (94)
    for (const score of criticalScores) {
      assert.ok(score >= 90, `Critical entity score (${score}) must be >= 90`);
    }
  });

  test("Graph theme token dictionaries provide complete dark/light parity", () => {
    const REQUIRED_THEME_KEYS = [
      "canvas", "shell", "panel", "panelRaised", "panelDock",
      "gridDot", "gridLine", "border", "ink", "inkMuted",
      "steel", "spark", "warning", "success", "nodeFill",
      "nodeInnerWell", "nodePillBg", "modalBg", "modalBorder"
    ];

    const darkTokens = {
      canvas: "#121315", shell: "#1a1a1a", panel: "#212328", panelRaised: "#2d2d2d", panelDock: "#17181c",
      gridDot: "rgba(255, 255, 255, 0.08)", gridLine: "rgba(255, 255, 255, 0.025)", border: "rgba(255, 255, 255, 0.09)",
      ink: "#EDEDED", inkMuted: "#9DAEC0", steel: "#749dc4", spark: "#ff6b35", warning: "#f59e0b", success: "#10b981",
      nodeFill: "#212328", nodeInnerWell: "#17181c", nodePillBg: "#17181c", modalBg: "bg-[#1a1a1a]", modalBorder: "border-white/10"
    };

    const lightTokens = {
      canvas: "#EEF2F6", shell: "#E3EAF1", panel: "#FFFFFF", panelRaised: "#FFFFFF", panelDock: "#F0F4F8",
      gridDot: "rgba(20, 32, 43, 0.12)", gridLine: "rgba(20, 32, 43, 0.04)", border: "rgba(42, 65, 84, 0.14)",
      ink: "#14202B", inkMuted: "#526475", steel: "#087E69", spark: "#C43D35", warning: "#A56600", success: "#16734E",
      nodeFill: "#FFFFFF", nodeInnerWell: "#F0F4F8", nodePillBg: "#FFFFFF", modalBg: "bg-white", modalBorder: "border-slate-200"
    };

    for (const key of REQUIRED_THEME_KEYS) {
      assert.ok(darkTokens[key] != null, `Dark theme missing key: ${key}`);
      assert.ok(lightTokens[key] != null, `Light theme missing key: ${key}`);
      assert.notEqual(darkTokens[key], lightTokens[key], `Token ${key} should differ between light and dark`);
    }
  });
});

describe("Transaction Topology & Vector Routing Conduit Specifications", () => {
  test("Deterministic account ID derivation produces valid Hop 0 and Hop 1 identifiers", () => {
    const txId = "TRF_46631F673703";
    const digits = txId.replace(/\D/g, "");
    const origin = `ACC_${digits.slice(0, 4) || "4663"}`;
    const dest = `BEN_${digits.slice(-4) || "3703"}`;

    assert.equal(origin, "ACC_4663");
    assert.equal(dest, "BEN_3703");
  });

  test("Model anomaly scores clamp strictly within 0-100% boundary", () => {
    const testCases = [
      { iso: 0.968, ae: 0.998, expectedIso: 97, expectedAe: 100 },
      { iso: 0.45, ae: 0.32, expectedIso: 45, expectedAe: 32 },
      { iso: 0.0, ae: 0.0, expectedIso: 0, expectedAe: 0 },
      { iso: 1.05, ae: 1.2, expectedIso: 100, expectedAe: 100 }, // clamp check
    ];

    for (const tc of testCases) {
      const clampedIso = Math.min(100, Math.max(0, Math.round(tc.iso * 100)));
      const clampedAe = Math.min(100, Math.max(0, Math.round(tc.ae * 100)));
      assert.equal(clampedIso, tc.expectedIso);
      assert.equal(clampedAe, tc.expectedAe);
    }
  });

  test("Immediate escalation triggers on composite score >= 85 or tier tag", () => {
    const isEscalation = (score, tier) =>
      tier === "immediate_escalation" || (score != null && score >= 85);

    assert.ok(isEscalation(93, "immediate_escalation"));
    assert.ok(isEscalation(86, null));
    assert.ok(!isEscalation(72, "priority_review"));
    assert.ok(!isEscalation(20, "auto_clear"));
  });

  test("All 3 pipeline conduit nodes (Hop 0, Pipeline Core, Hop 1) define complete telemetry specs", () => {
    const NODES = ["origin", "engine", "dest"];
    assert.equal(NODES.length, 3);
    assert.ok(NODES.includes("origin"));
    assert.ok(NODES.includes("engine"));
    assert.ok(NODES.includes("dest"));
  });

  test("Real case TRF_46631F673703 payload computes all telemetry fields without undefined variables", () => {
    const rawSignals = {
      composite_score: 92.77450324718941,
      review_tier: "immediate_escalation",
      isoforest_score: 0.968,
      autoencoder_score: 0.998,
      benford_flag: false,
      rules_triggered: [],
    };
    const compositeScore = Number(rawSignals.composite_score);
    const isoPct = Math.min(100, Math.max(0, Math.round(Number(rawSignals.isoforest_score) * 100)));
    const aePct = Math.min(100, Math.max(0, Math.round(Number(rawSignals.autoencoder_score) * 100)));

    assert.equal(isoPct, 97);
    assert.equal(aePct, 100);
    assert.equal(Math.round(compositeScore), 93);
    assert.equal(rawSignals.review_tier, "immediate_escalation");
  });
});

describe("Static AST Codebase Integrity & Variable Binding Verification", () => {
  test("All JSX/JS source files contain zero unbound identifiers (prevents runtime ReferenceError)", () => {
    const globals = new Set([
      "window", "document", "console", "localStorage", "sessionStorage",
      "setTimeout", "clearTimeout", "setInterval", "clearInterval",
      "Math", "Number", "String", "Boolean", "Array", "Object", "Date",
      "JSON", "RegExp", "Map", "Set", "URL", "URLSearchParams", "navigator",
      "fetch", "Promise", "Error", "parseInt", "parseFloat", "isNaN", "isFinite",
      "encodeURIComponent", "decodeURIComponent", "Blob", "crypto",
      "requestAnimationFrame", "cancelAnimationFrame"
    ]);

    const errors = [];
    function checkFile(filePath) {
      const code = fs.readFileSync(filePath, "utf8");
      let ast;
      try {
        ast = parser.parse(code, { sourceType: "module", plugins: ["jsx"] });
      } catch (err) {
        errors.push(`Syntax error in ${filePath}: ${err.message}`);
        return;
      }
      traverse(ast, {
        Program(progPath) {
          progPath.traverse({
            ReferencedIdentifier(identPath) {
              const name = identPath.node.name;
              if (globals.has(name)) return;
              if (!identPath.scope.hasBinding(name)) {
                errors.push(`Unbound identifier '${name}' at ${path.relative(".", filePath)}:${identPath.node.loc?.start?.line}`);
              }
            }
          });
        }
      });
    }

    function walk(dir) {
      for (const item of fs.readdirSync(dir)) {
        const full = path.join(dir, item);
        if (fs.statSync(full).isDirectory()) walk(full);
        else if (full.endsWith(".jsx") || full.endsWith(".js")) checkFile(full);
      }
    }

    walk("src");
    assert.deepEqual(errors, [], `Found unbound variables:\n${errors.join("\n")}`);
  });

  test("All relative import statements across src/ resolve to existing files on disk (prevents Vite import-analysis failure)", () => {
    const missingImports = [];
    const srcDir = path.resolve("src");

    function checkImports(filePath) {
      const content = fs.readFileSync(filePath, "utf8");
      const dir = path.dirname(filePath);
      const regex = /import\s+(?:(?:[\w*\s{},]*)\s+from\s+)?['"]([^'"]+)['"]/g;
      let match;
      while ((match = regex.exec(content)) !== null) {
        const importPath = match[1];
        if (importPath.startsWith(".")) {
          const resolvedBase = path.resolve(dir, importPath);
          const candidates = [
            resolvedBase,
            resolvedBase + ".js",
            resolvedBase + ".jsx",
            resolvedBase + ".json",
            path.join(resolvedBase, "index.js"),
            path.join(resolvedBase, "index.jsx"),
          ];
          const exists = candidates.some((c) => fs.existsSync(c) && fs.statSync(c).isFile());
          if (!exists) {
            missingImports.push(`${path.relative(".", filePath)} -> '${importPath}'`);
          }
        }
      }
    }

    function walk(dir) {
      for (const item of fs.readdirSync(dir)) {
        const full = path.join(dir, item);
        if (fs.statSync(full).isDirectory()) walk(full);
        else if (full.endsWith(".jsx") || full.endsWith(".js")) checkImports(full);
      }
    }

    walk(srcDir);
    assert.deepEqual(missingImports, [], `Found missing import targets:\n${missingImports.join("\n")}`);
  });
});
