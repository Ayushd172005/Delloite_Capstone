import puppeteer from "puppeteer-core";
import path from "node:path";

const CHROME_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const OUTPUT_DIR = "/Users/aaditya/.gemini/antigravity/brain/de6efaf1-bab3-42fe-b315-37a355330eea";

async function captureConcepts() {
  const browser = await puppeteer.launch({
    executablePath: CHROME_PATH,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    headless: true,
  });

  const concepts = ["a", "b", "c"];
  const themes = ["dark", "light"];

  for (const c of concepts) {
    for (const th of themes) {
      const page = await browser.newPage();
      await page.setViewport({ width: 1512, height: 982, deviceScaleFactor: 2 });
      await page.goto(`http://localhost:5173/concepts?dir=${c}`, { waitUntil: "networkidle0" });
      
      await page.evaluate((theme) => {
        localStorage.setItem("sentinel-theme", theme);
        if (theme === "dark") {
          document.documentElement.classList.add("dark");
        } else {
          document.documentElement.classList.remove("dark");
        }
      }, th);
      
      await new Promise((r) => setTimeout(r, 600));

      const outPath = path.join(OUTPUT_DIR, `concept_${c}_${th}.png`);
      await page.screenshot({ path: outPath, fullPage: false });
      console.log(`Captured: ${outPath}`);
      await page.close();
    }
  }

  await browser.close();
}

captureConcepts().catch((err) => {
  console.error("Capture failed:", err);
  process.exit(1);
});
