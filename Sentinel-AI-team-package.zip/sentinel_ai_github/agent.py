"""
Sentinel AI v2 - Investigation agent.

Implements the workflow from the master prompt (items 16-19):
  transaction -> risk signals -> retrieve evidence -> inspect evidence ->
  identify supporting evidence -> identify counter-evidence (MANDATORY) ->
  determine evidence sufficiency -> structured, Pydantic-validated conclusion ->
  recommended auditor action

AI-assisted, evidence-grounded investigation agent. The system pre-fetches structured
transaction, risk, historical, use-case, and evidence context via real local functions
(get_transaction, get_account_history, search_evidence, get_risk_signals) operating on
the scored/evidence data - the agent must call these rather than invent facts. When
ANTHROPIC_API_KEY is set, call_agent() sends that assembled context to Claude for a
single structured investigation response and validates it against the existing schema;
when it isn't (this sandbox has no key), or validation fails, deterministic_investigate()
runs the identical evidence-gathering steps and produces the same schema using rule-based
reasoning instead of an LLM. This satisfies "agent works or has a deterministic fallback" -
the fallback is not a stub, it performs the real supporting/counter-evidence
comparison, just without LLM-authored prose.
"""
import os
import json
import logging
from typing import Literal, List, Optional
from pydantic import BaseModel, Field, field_validator
import pandas as pd
import numpy as np
import time
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

# In-memory investigation cache: prevents redundant LLM invocations and protects token rate limits
_INVESTIGATION_CACHE = {}

from retrieval import EvidenceStore
from config import BENFORD_DISABLED_VERTICALS
from groq_rotator import (
    get_ordered_groq_keys,
    get_groq_rotation_status,
    mark_key_rate_limited,
    mask_key,
)

# ---------------------------------------------------------------------------
# Structured output schema (master prompt item 19) - never allow arbitrary LLM
# text to directly control the application; every agent output is validated
# against this schema before it can become a Case.
# ---------------------------------------------------------------------------

class EvidenceItem(BaseModel):
    document_id: str
    statement: str
    stance: Literal["supports", "contradicts", "neutral"]

class Investigation(BaseModel):
    transaction_id: str
    risk_score: float = Field(ge=0, le=100)
    risk_level: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    finding: str
    anomaly_drivers: List[str]
    supporting_evidence: List[EvidenceItem]
    counter_evidence: List[EvidenceItem]
    evidence_sufficiency: Literal["SUFFICIENT", "INSUFFICIENT"]
    recommended_action: Literal["ACCEPT", "ESCALATE", "DISMISS", "REQUEST_MORE_EVIDENCE"]
    confidence: float = Field(
        ge=0, le=1,
        description="Investigation confidence: how sufficient and internally consistent "
                     "the gathered evidence is. This is NOT a calibrated probability that "
                     "fraud occurred - it reflects whether the agent had enough grounded "
                     "material to reach a clear conclusion, nothing more."
    )

    @field_validator("counter_evidence")
    @classmethod
    def counter_evidence_was_checked(cls, v):
        # Not "must be non-empty" (sometimes there genuinely is none) - but the field
        # must exist and be a real list, i.e. the agent was required to consider it.
        # This validator exists to document that the check is mandatory, not to fabricate
        # counter-evidence when none was found.
        return v


# ---------------------------------------------------------------------------
# Tool functions - the ONLY way the agent may obtain facts. All operate on real
# data already computed by the pipeline (no invented facts).
# ---------------------------------------------------------------------------

class SentinelTools:
    def __init__(self, scored_df, evidence_store: EvidenceStore):
        self.scored = scored_df.set_index("transaction_id", drop=False)
        self.store = evidence_store

    def get_transaction(self, transaction_id):
        row = self.scored.loc[transaction_id]
        return {
            "transaction_id": transaction_id, "vertical": row["vertical"],
            "amount": float(row["amount"]), "transaction_time": str(row["transaction_time"]),
            "account_id": row["account_id"], "counterparty_id": row["counterparty_id"],
        }

    def get_risk_signals(self, transaction_id):
        row = self.scored.loc[transaction_id]
        rules_triggered = [c.replace("flag_", "") for c in row.index
                            if c.startswith("flag_") and row.get(c) == 1
                            and "shared" not in c and "hub" not in c]
        signals = {
            "composite_score": round(float(row["composite_score"]), 2),
            "review_tier": row["review_tier"],
            "isoforest_score": round(float(row["isoforest_score"]), 3),
            "autoencoder_score": round(float(row["autoencoder_score"]), 3),
            "benford_flag": bool(row.get("benford_flag", 0)),
            "rules_triggered": rules_triggered,
            "amount_zscore": round(float(row.get("amount_zscore", 0)), 2),
            "amount_pct_rank_personal": round(float(row.get("amount_pct_rank_personal", 0)), 3),
        }
        if row["vertical"] in BENFORD_DISABLED_VERTICALS:
            signals["benford_reliability_note"] = (
                "Benford's Law does not discriminate fraud in this vertical (measured "
                "AUC ~0.50, see evaluation report) - do not cite benford_flag as evidence."
            )
        return signals

    def get_use_case_context(self, transaction_id):
        """Mentor-aligned business use-case context (use_cases.py), if any applies to
        this transaction. Returns None when no use case fired - the agent must not
        infer or invent one."""
        row = self.scored.loc[transaction_id]
        if "use_case" not in row.index or pd.isna(row.get("use_case")):
            return None
        reasons_val = row.get("use_case_reasons")
        if isinstance(reasons_val, (list, tuple, np.ndarray)):
            reasons = [str(r) for r in reasons_val if pd.notna(r)]
        elif isinstance(reasons_val, str):
            reasons = [reasons_val]
        else:
            reasons = []
        return {
            "use_case": row["use_case"],
            "reasons": reasons,
        }

    def get_account_history(self, transaction_id, limit=5):
        txn = self.scored.loc[transaction_id]
        txn_time = pd.to_datetime(txn["transaction_time"])
        if getattr(txn_time, "tzinfo", None) is not None:
            txn_time = txn_time.tz_convert("UTC").tz_localize(None)
        scored_times = pd.to_datetime(self.scored["transaction_time"])
        hist = self.scored[
            (self.scored["account_id"] == txn["account_id"]) &
            (scored_times < txn_time)
        ].sort_values("transaction_time", ascending=False).head(limit)
        return hist[["transaction_id", "amount", "transaction_time"]].to_dict("records")

    def search_evidence(self, transaction_id, retrospective=False):
        own = self.store.retrieve_own_transaction_docs(transaction_id)
        related = self.store.retrieve(transaction_id, retrospective=retrospective)
        return {"own_documents": own, "related_evidence": related}


# ---------------------------------------------------------------------------
# Deterministic fallback investigation (no LLM required) - runs the same
# evidence-gathering steps and produces the same schema.
# ---------------------------------------------------------------------------

def deterministic_investigate(transaction_id, tools: SentinelTools) -> Investigation:
    txn = tools.get_transaction(transaction_id)
    signals = tools.get_risk_signals(transaction_id)
    history = tools.get_account_history(transaction_id)
    evidence = tools.search_evidence(transaction_id)
    use_case_context = tools.get_use_case_context(transaction_id)

    drivers = []
    if use_case_context:
        drivers.append(f"Mentor-aligned business use case: {use_case_context['use_case']}")
        drivers.extend(use_case_context["reasons"])
    if signals["isoforest_score"] > 0.7:
        drivers.append(f"isolation-forest anomaly score {signals['isoforest_score']} (high)")
    if signals["autoencoder_score"] > 0.5:
        drivers.append(f"autoencoder reconstruction error {signals['autoencoder_score']} (elevated)")
    if signals["rules_triggered"]:
        drivers.append("rule triggers: " + ", ".join(signals["rules_triggered"]))
    if signals["benford_flag"] and "benford_reliability_note" not in signals:
        drivers.append("Benford digit-distribution deviation on this cohort")
    if not drivers:
        drivers.append("elevated composite score without a single dominant driver")

    # supporting evidence: prior history showing this amount is far outside the norm
    supporting = []
    if history:
        max_hist = max(h["amount"] for h in history)
        if txn["amount"] > max_hist * 1.5:
            ratio = txn["amount"] / max_hist if max_hist > 0 else float("inf")
            supporting.append(EvidenceItem(
                document_id=evidence["own_documents"][0]["document_id"] if evidence["own_documents"] else "N/A",
                statement=f"Amount is {ratio:.1f}x the largest of the last {len(history)} prior "
                          f"transactions on this account (max {max_hist:.2f})",
                stance="supports",
            ))
    for d in evidence["related_evidence"][:3]:
        supporting.append(EvidenceItem(
            document_id=d["document_id"],
            statement=f"Comparable transaction found via {d['reason_for_retrieval']} "
                      f"(relevance {d['relevance_score']}): amount {d.get('metadata', {}).get('amount', 'n/a')}",
            stance="neutral",
        ))

    # counter-evidence: MANDATORY check - look for a matching approval record
    counter = []
    approval_docs = [d for d in evidence["own_documents"] if d["source_type"] == "approval_record"]
    for d in approval_docs:
        counter.append(EvidenceItem(
            document_id=d["document_id"],
            statement=f"A prior approval record exists for this transaction: {d['text']}",
            stance="contradicts",
        ))

    # sufficiency + risk level + recommended action
    has_direct_history = len(history) > 0
    sufficiency = "SUFFICIENT" if (has_direct_history or approval_docs) else "INSUFFICIENT"

    score = signals["composite_score"]
    if counter:  # counter-evidence pulls the rating down regardless of raw score
        risk_level = "LOW" if score < 50 else "MEDIUM"
        action = "DISMISS" if score < 60 else "REQUEST_MORE_EVIDENCE"
    elif score >= 70:
        risk_level = "CRITICAL" if score >= 90 else "HIGH"
        action = "ESCALATE"
    elif score >= 40:
        risk_level = "MEDIUM"
        action = "REQUEST_MORE_EVIDENCE" if sufficiency == "INSUFFICIENT" else "ESCALATE"
    else:
        risk_level = "LOW"
        action = "DISMISS"

    confidence = 0.85 if sufficiency == "SUFFICIENT" else 0.45
    if counter:
        confidence = min(confidence, 0.6)  # conflicting evidence caps confidence

    finding = (
        f"Transaction {transaction_id} scored {score:.1f}/100 ({txn['vertical']} vertical), "
        f"driven by: {'; '.join(drivers)}."
    )
    if counter:
        finding += f" However, {len(counter)} counter-evidence item(s) were found that weigh against escalation."

    inv = Investigation(
        transaction_id=transaction_id, risk_score=score, risk_level=risk_level, finding=finding,
        anomaly_drivers=drivers, supporting_evidence=supporting, counter_evidence=counter,
        evidence_sufficiency=sufficiency, recommended_action=action, confidence=round(confidence, 2),
    )
    return inv


# ---------------------------------------------------------------------------
# Live-LLM path
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are an audit investigation agent for Sentinel AI. You must use the provided \
tools to gather facts - never invent transaction details, history, or evidence. For the given \
transaction, gather risk signals, account history, and evidence, then produce a structured \
investigation with BOTH supporting_evidence and counter_evidence (counter-evidence is mandatory \
to check for, even if you find none). Distinguish FACT (grounded in a specific tool result) from \
INFERENCE (your reasoning) from UNCERTAINTY (things you cannot determine). Output must validate \
against the Investigation schema. If evidence is insufficient to support a conclusion, say so \
explicitly rather than guessing. If use_case_context is present, treat it as a business-relevant \
starting scenario (e.g. "New Device + High-Value Transaction", "Fan-Out Network", "Near-Threshold \
Structuring") to investigate against - it is a prioritization hint, not a fraud determination; \
still gather and weigh supporting and counter-evidence independently."""

def _call_groq_agent(transaction_id, tools: SentinelTools, api_key: str, model: Optional[str] = None) -> Optional[Investigation]:
    """Optimized Groq LLM investigation agent using token-efficient context, native JSON mode,
    bounded token reservation (380 tokens), retry with backoff, and model fallback."""
    try:
        from groq import Groq, RateLimitError
    except ImportError:
        logger.warning("groq library not installed; falling back to deterministic.")
        return None

    # Model hierarchy: preferred primary, followed by secondary fallback
    models_to_try = [
        model or os.environ.get("GROQ_MODEL", "qwen/qwen3.8-27b"),
        "groq/compound-mini",
    ]
    models_to_try = list(dict.fromkeys(models_to_try))

    # Trim context to essential signals to preserve Groq TPM/RPM limits
    txn = tools.get_transaction(transaction_id)
    signals = tools.get_risk_signals(transaction_id)
    use_case = tools.get_use_case_context(transaction_id)
    history = tools.get_account_history(transaction_id, limit=3)
    raw_evidence = tools.search_evidence(transaction_id)

    evidence = {
        "own_documents": raw_evidence.get("own_documents", [])[:2],
        "related_evidence": [
            {
                "document_id": d.get("document_id"),
                "relevance_score": d.get("relevance_score"),
                "reason_for_retrieval": d.get("reason_for_retrieval"),
                "amount": d.get("metadata", {}).get("amount"),
            }
            for d in raw_evidence.get("related_evidence", [])[:2]
        ],
    }

    context = {
        "transaction": txn,
        "risk_signals": signals,
        "use_case_context": use_case,
        "account_history": history,
        "evidence": evidence,
    }

    groq_system = (
        "You are Sentinel AI's Senior Forensic Financial Investigator. "
        "All tools have ALREADY run. The complete transaction dossier, composite risk signals, prior history, and evidence documents are provided in the user context. "
        "Do NOT emit tool calls, function calls, markdown backticks, or conversational prose. "
        "Directly produce a complete, structured forensic investigation JSON object conforming strictly to this schema:\n"
        "{\n"
        f'  "transaction_id": "{transaction_id}",\n'
        '  "risk_score": <float between 0 and 100>,\n'
        '  "risk_level": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",\n'
        '  "finding": "<concise evidence-grounded finding, 1-2 sentences, max 45 words>",\n'
        '  "anomaly_drivers": ["<driver 1>", ...],\n'
        '  "supporting_evidence": [{"document_id": "<doc_id>", "statement": "<statement>", "stance": "supports"}],\n'
        '  "counter_evidence": [{"document_id": "<doc_id>", "statement": "<statement>", "stance": "contradicts"}],\n'
        '  "evidence_sufficiency": "SUFFICIENT" | "INSUFFICIENT",\n'
        '  "recommended_action": "ACCEPT" | "ESCALATE" | "DISMISS" | "REQUEST_MORE_EVIDENCE",\n'
        '  "confidence": <float between 0.0 and 1.0>\n'
        "}\n"
        "Keep finding concise, objective, and professional. In supporting_evidence and counter_evidence statements, articulate concrete financial and behavioral facts (such as transaction amounts, entity relationships, velocity patterns, or approval status). Never cite raw retrieval mechanics or state 'relevance score is zero'. Output strictly valid JSON."
    )

    client = Groq(api_key=api_key, timeout=12.0)

    for m in models_to_try:
        for attempt in range(2):
            try:
                resp = client.chat.completions.create(
                    model=m,
                    messages=[
                        {"role": "system", "content": groq_system},
                        {"role": "user", "content": json.dumps(context, default=str)},
                    ],
                    response_format={"type": "json_object"},
                    temperature=0.1,
                    max_tokens=420,
                )

                text = (resp.choices[0].message.content or "").strip()
                if text.startswith("```json"):
                    text = text[7:]
                elif text.startswith("```"):
                    text = text[3:]
                if text.endswith("```"):
                    text = text[:-3]
                text = text.strip()
                data = json.loads(text)

                # Defensive normalization and schema guarantee
                data["transaction_id"] = transaction_id
                if "finding" not in data or not data["finding"]:
                    data["finding"] = f"Forensic analysis completed for transaction {transaction_id}."

                if "anomaly_drivers" not in data or not isinstance(data["anomaly_drivers"], list):
                    data["anomaly_drivers"] = [f"composite score {signals.get('composite_score', 0)}"]

                # Normalize evidence items
                def _normalize_evidence(items, default_stance):
                    norm = []
                    if isinstance(items, list):
                        for it in items:
                            if isinstance(it, dict) and "document_id" in it and "statement" in it:
                                stance = it.get("stance", default_stance)
                                if stance not in ("supports", "contradicts", "neutral"):
                                    stance = default_stance
                                norm.append(EvidenceItem(
                                    document_id=str(it["document_id"]),
                                    statement=str(it["statement"]),
                                    stance=stance,
                                ))
                    return norm

                data["supporting_evidence"] = _normalize_evidence(data.get("supporting_evidence"), "supports")
                data["counter_evidence"] = _normalize_evidence(data.get("counter_evidence"), "contradicts")

                # Bound scores to valid ranges
                risk_score = float(data.get("risk_score", signals.get("composite_score", 50.0)))
                data["risk_score"] = max(0.0, min(100.0, risk_score))

                if data.get("risk_level") not in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
                    s = data["risk_score"]
                    data["risk_level"] = "CRITICAL" if s >= 90 else ("HIGH" if s >= 70 else ("MEDIUM" if s >= 40 else "LOW"))

                if data.get("evidence_sufficiency") not in ("SUFFICIENT", "INSUFFICIENT"):
                    has_docs = (len(data["supporting_evidence"]) + len(data["counter_evidence"])) > 0
                    data["evidence_sufficiency"] = "SUFFICIENT" if has_docs else "INSUFFICIENT"

                if data.get("recommended_action") not in ("ACCEPT", "ESCALATE", "DISMISS", "REQUEST_MORE_EVIDENCE"):
                    data["recommended_action"] = "ESCALATE" if data["risk_score"] >= 60 else "DISMISS"

                conf = float(data.get("confidence", 0.85 if data["evidence_sufficiency"] == "SUFFICIENT" else 0.5))
                data["confidence"] = max(0.0, min(1.0, round(conf, 2)))

                return Investigation(**data)
            except RateLimitError as rle:
                logger.warning("Groq RateLimit on key %s (attempt %d): %s", mask_key(api_key), attempt + 1, rle)
                if attempt == 0:
                    time.sleep(2.0)
                    continue
                mark_key_rate_limited(api_key, cooldown_seconds=60.0)
                break
            except Exception as e:
                logger.warning("Groq call failed on key %s (%s): %s", mask_key(api_key), m, e)
                break

    return None


def _call_anthropic_agent(transaction_id, tools: SentinelTools, api_key: str, model: Optional[str] = None) -> Optional[Investigation]:
    try:
        from anthropic import Anthropic
        client = Anthropic(api_key=api_key)
        model_name = model or "claude-sonnet-4-6"
        context = {
            "transaction": tools.get_transaction(transaction_id),
            "risk_signals": tools.get_risk_signals(transaction_id),
            "use_case_context": tools.get_use_case_context(transaction_id),
            "account_history": tools.get_account_history(transaction_id),
            "evidence": tools.search_evidence(transaction_id),
        }
        resp = client.messages.create(
            model=model_name, max_tokens=1200, system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": json.dumps(context, indent=2, default=str)}],
        )
        text = "".join(b.text for b in resp.content if b.type == "text")
        data = json.loads(text)
        return Investigation(**data)
    except Exception as e:
        logger.warning("Anthropic agent call failed (%s); falling back cleanly to deterministic investigation.", e)
        return None


def call_agent(transaction_id, tools: SentinelTools, model=None, force_refresh=False) -> Investigation:
    """Entry point for investigation agent: Checks cache, tries Groq (with 6h rotation & failover), tries Anthropic, falls back to deterministic."""
    if not force_refresh and transaction_id in _INVESTIGATION_CACHE:
        return _INVESTIGATION_CACHE[transaction_id]

    ordered_keys = get_ordered_groq_keys()
    if ordered_keys:
        for attempt_idx, (key_idx, api_key) in enumerate(ordered_keys):
            role = "primary (6h active slot)" if attempt_idx == 0 else f"failover standby #{attempt_idx}"
            logger.info("Executing Groq investigation with %s key slot #%d (%s)", role, key_idx + 1, mask_key(api_key))
            inv = _call_groq_agent(transaction_id, tools, api_key=api_key, model=model)
            if inv is not None:
                _INVESTIGATION_CACHE[transaction_id] = inv
                return inv
            logger.warning(
                "Groq agent call failed with %s key slot #%d (%s); attempting next key if available.",
                role, key_idx + 1, mask_key(api_key)
            )

    anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY")
    if anthropic_api_key:
        inv = _call_anthropic_agent(transaction_id, tools, api_key=anthropic_api_key, model=model)
        if inv is not None:
            _INVESTIGATION_CACHE[transaction_id] = inv
            return inv

    inv = deterministic_investigate(transaction_id, tools)
    _INVESTIGATION_CACHE[transaction_id] = inv
    return inv


if __name__ == "__main__":
    scored = pd.read_parquet("scored_transactions.parquet")
    evidence_df = pd.read_parquet("evidence_documents.parquet")
    store = EvidenceStore(evidence_df, scored)
    tools = SentinelTools(scored, store)

    flagged = scored[scored["review_tier"] != "auto_clear"].sort_values("composite_score", ascending=False)
    sample_ids = flagged["transaction_id"].head(3).tolist()
    for tid in sample_ids:
        inv = call_agent(tid, tools)
        print(f"\n=== {tid} ===")
        print(inv.model_dump_json(indent=2))
