import { useNavigate } from "react-router-dom";
import RiskBadge from "./RiskBadge";
import StatusBadge from "./StatusBadge";

function fmtMoney(n) {
  return "₹" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export default function TransactionTable({ rows }) {
  const navigate = useNavigate();
  return (
    <table className="w-full border-collapse text-left text-xs">
      <thead>
        <tr className="border-b border-border text-2xs uppercase tracking-wide text-ink-faint">
          <th className="px-4 py-2 font-medium">Risk</th>
          <th className="px-4 py-2 font-medium">Transaction</th>
          <th className="px-4 py-2 font-medium">Vertical</th>
          <th className="px-4 py-2 font-medium">Amount</th>
          <th className="px-4 py-2 font-medium">Signals</th>
          <th className="px-4 py-2 font-medium">Status</th>
          <th className="px-4 py-2 font-medium"></th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr
            key={r.transaction_id}
            onClick={() => navigate(`/investigation/${r.transaction_id}`, { state: { row: r } })}
            className="cursor-pointer border-b border-border/60 hover:bg-panel-raised/50"
          >
            <td className="px-4 py-2.5">
              <RiskBadge tier={r.review_tier} score={r.composite_score} size="sm" />
            </td>
            <td className="whitespace-nowrap px-4 py-2.5 font-mono text-ink-muted">{r.transaction_id}</td>
            <td className="whitespace-nowrap px-4 py-2.5 capitalize text-ink-muted">{r.vertical}</td>
            <td className="whitespace-nowrap px-4 py-2.5 font-mono text-ink">{fmtMoney(r.amount)}</td>
            <td className="whitespace-nowrap px-4 py-2.5 text-ink-faint">
              {r.rule_flag_count} signal{r.rule_flag_count === 1 ? "" : "s"}
            </td>
            <td className="whitespace-nowrap px-4 py-2.5">
              {r.auditor_decision ? <StatusBadge status={r.auditor_decision} /> : <StatusBadge status="PENDING" />}
            </td>
            <td className="whitespace-nowrap px-4 py-2.5 text-right text-link">View →</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
